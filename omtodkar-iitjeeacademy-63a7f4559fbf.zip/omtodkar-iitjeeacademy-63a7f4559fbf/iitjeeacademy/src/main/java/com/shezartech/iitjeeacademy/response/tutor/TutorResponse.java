package com.shezartech.iitjeeacademy.response.tutor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.shezartech.iitjeeacademy.entity.StudentEntity;
import com.shezartech.iitjeeacademy.entity.TutorEntity;
import com.shezartech.iitjeeacademy.model.Pricing;
import com.shezartech.iitjeeacademy.model.PricingDao;
import com.shezartech.iitjeeacademy.response.SuccessResponse;

public class TutorResponse extends SuccessResponse
{
	private static Map<Integer, Pricing> pricings = new HashMap<Integer, Pricing>();
	
	public static class StudentEntityViewModel
	{
		public Integer targetYear;
		
		public String firstName;
		
		public String lastName;
		
		public Pricing pricing;
		
		public int globalRank;
		
		public StudentEntityViewModel(StudentEntity student)
		{
			this.targetYear = student.getTargetYear();
			this.firstName = student.getFirstName();
			this.lastName = student.getLastName();
			this.globalRank = student.getGlobalRank();
			this.pricing = pricings.get(student.getSubscriptionModel());
		}
	}
	
	public static class StudentInfo
	{
		public String targetYear;
		
		public long numberOfStudents;
		
		public StudentInfo(){}

		public StudentInfo(String targetYear, long numberOfStudents)
		{
			super();
			this.targetYear = targetYear;
			this.numberOfStudents = numberOfStudents;
		}
	}
	
	public static class FinancialSummary
	{
		public Integer targetYear;
		
		public int revenue;

		public FinancialSummary(Integer targetYear, int revenue)
		{
			super();
			this.targetYear = targetYear;
			this.revenue = revenue;
		}
	}
	
	@JsonInclude(Include.NON_NULL)
	public TutorEntity tutor;
	
	@JsonInclude(Include.NON_NULL)
	public Set<StudentEntityViewModel> students = new HashSet<TutorResponse.StudentEntityViewModel>();
	
	@JsonInclude(Include.NON_NULL)
	public List<StudentInfo> studentInfos;
	
	public List<FinancialSummary> financialSummaries = new ArrayList<TutorResponse.FinancialSummary>();
	
	public TutorResponse(TutorEntity tutor)
	{
		super();
		this.tutor = tutor;
	}
	
	public TutorResponse()
	{
		super();
	}
	
	public TutorResponse(Set<StudentEntity> students)
	{
		super();
		for(Pricing pricing :(new PricingDao()).findAll())
		{
			TutorResponse.pricings.put(pricing.getId(), pricing);
		};
		
		for(StudentEntity student: students)
		{
			this.students.add(new StudentEntityViewModel(student));
		}
	}
	
	public TutorResponse(List<StudentInfo> studentInfos)
	{
		super();
		this.studentInfos = studentInfos;
	}

	public void setFinancialSummaries(List<FinancialSummary> financialSummaries)
	{
		this.financialSummaries = financialSummaries;
	}
}
