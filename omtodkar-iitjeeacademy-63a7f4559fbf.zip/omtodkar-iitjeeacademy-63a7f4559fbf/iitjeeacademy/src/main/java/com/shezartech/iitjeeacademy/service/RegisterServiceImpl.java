package com.shezartech.iitjeeacademy.service;

import java.sql.Timestamp;
import java.util.Date;
import java.util.Map;

import org.mindrot.jbcrypt.BCrypt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.shezartech.iitjeeacademy.config.WebSecurityConfig.ClientSecretsConfiguration.Provider;
import com.shezartech.iitjeeacademy.dao.InstituteDao;
import com.shezartech.iitjeeacademy.dao.StudentDao;
import com.shezartech.iitjeeacademy.dao.SubjectDao;
import com.shezartech.iitjeeacademy.dao.TopicDao;
import com.shezartech.iitjeeacademy.dao.TransactionDao;
import com.shezartech.iitjeeacademy.dao.TutorDao;
import com.shezartech.iitjeeacademy.entity.AccuracyEntity;
import com.shezartech.iitjeeacademy.entity.StudentEntity;
import com.shezartech.iitjeeacademy.entity.SubjectEntity;
import com.shezartech.iitjeeacademy.entity.SubjectglobalranksEntity;
import com.shezartech.iitjeeacademy.entity.SubjectlevelsEntity;
import com.shezartech.iitjeeacademy.entity.SubjectstateranksEntity;
import com.shezartech.iitjeeacademy.entity.TopicEntity;
import com.shezartech.iitjeeacademy.entity.TopiclevelsEntity;
import com.shezartech.iitjeeacademy.entity.TransactionsEntity;
import com.shezartech.iitjeeacademy.entity.TutorEntity;
import com.shezartech.iitjeeacademy.exception.RegisterException;
import com.shezartech.iitjeeacademy.model.PricingDao;

@Service
public class RegisterServiceImpl implements RegisterService {
	
	@Autowired
	private TutorDao tutorDao;
	
	@Autowired
	private StudentDao studentDao;
	
	@Autowired
	private InstituteDao instituteDao;
	
	@Autowired
	private SubjectDao subjectDao;
	
	@Autowired
	private TopicDao topicDao;
	
	@Autowired
	private TransactionDao transactionDao;

	@Transactional
	@Override
	public void registerTutor(TutorEntity tutor)
	{
		tutor.setPassword(hashPassword(tutor.getPassword()));
		
		tutorDao.persist(tutor);
	}
	
	public static String hashPassword(String password)
	{
		String temp = BCrypt.hashpw(password, BCrypt.gensalt());
		StringBuilder hashedPassword = new StringBuilder(temp);
		hashedPassword.setCharAt(2, 'y');
		return hashedPassword.toString();
	}

	@Override
	@Transactional
	public boolean isEmailValidForTutor(String email) {
		
		return tutorDao.find(email) == null && instituteDao.find(email) == null;
	}
	
	@Override
	@Transactional
	public StudentEntity registerStudent(Map<String, Object> studentMap, Provider provider)
	{
		int globalRank = 50000, stateRank = 0;
		PricingDao pricingDao = new PricingDao();
		Timestamp now = new Timestamp((new Date()).getTime());
		int model;
		
		StudentEntity student = new StudentEntity();
		
		switch (provider)
		{
		case FACEBOOK:
			
			student.setFirstName((String) studentMap.get("first_name"));
			student.setLastName((String) studentMap.get("last_name"));
			student.setEmail((String) studentMap.get("email"));
			student.setFacebookId((String) studentMap.get("id"));
			student.setFacebookLink((String) studentMap.get("link"));
			model = 4; //this'll be a trial user
			student.setLastLoginTime(now); //the user is logged-in immediately
			//this value is in IST
			
			break;
			
		case GOOGLE:
			
			student.setFirstName((String) studentMap.get("given_name"));
			student.setLastName((String) studentMap.get("family_name"));
			student.setEmail((String) studentMap.get("email"));
			student.setGoogleId((String) studentMap.get("sub"));
			student.setGoogleLink((String) studentMap.get("profile"));
			model = 4; //this'll be a trial user
			student.setLastLoginTime(now); //the user is logged-in immediately
			//this value is in IST
			
			break;

		case PAID_STUDENT:
			student.setFirstName((String) studentMap.get("firstname"));
			student.setLastName((String) studentMap.get("lastname"));
			student.setEmail((String) studentMap.get("email"));
			student.setPassword(hashPassword((String) studentMap.get("password")));
			
			TransactionsEntity transaction = transactionDao.find(Integer.parseInt((String) studentMap.get("transactionId")));
			if(
					transaction == null || 
					!transaction.getEmail().equals((String)studentMap.get("email")) ||
					transaction.getResponseCode() != 0
					)
				throw new RegisterException("Transaction is not valid");
			transaction.setRegistrationComplete(true);
			student.setTransactionId(transaction.getTransactionId());
			
			model = transaction.getSubscriptionModel();
			
			break;
			
		case TRIAL_STUDENT:
			student.setFirstName((String) studentMap.get("firstname"));
			student.setLastName((String) studentMap.get("lastname"));
			student.setEmail((String) studentMap.get("email"));
			student.setPassword(hashPassword((String) studentMap.get("password")));
			model = 4; //this'll be a trial user
			
			break;
			
		default:
				throw new RuntimeException(String.format("Provider %s is not supported", provider.getName()));
		}
		
		student.setGlobalRank(globalRank);
		student.setRegistrationDate(now);// in IST
		
		student.setSubscriptionModel(model);
		
		Timestamp subscriptionLimit = new Timestamp(now.getTime() + pricingDao.find(model).getTimestampDuration());
		student.setSubscriptionLimit(subscriptionLimit);// in IST
		
		student.setPhotopath("0"); //try to download photo from google or facebook and set the value accordingly
		
		for(SubjectEntity subject: subjectDao.findAll())
		{
			SubjectglobalranksEntity subjectglobalranks = new SubjectglobalranksEntity();
			subjectglobalranks.setSubject(subject);
			subjectglobalranks.setRank(globalRank);
			subjectglobalranks.setUser(student);
			
			SubjectstateranksEntity subjectstateranks = new SubjectstateranksEntity();
			subjectstateranks.setSubject(subject);
			subjectstateranks.setRank(stateRank);
			subjectstateranks.setUser(student);
			
			SubjectlevelsEntity subjectlevels = new SubjectlevelsEntity();
			subjectlevels.setLevel(1);
			subjectlevels.setSubject(subject);
			subjectlevels.setUser(student);
			
			student.getSubjectglobalranksEntity().add(subjectglobalranks);
			student.getSubjectstateranksEntities().add(subjectstateranks);
			student.getSubjectlevelsEntities().add(subjectlevels);
		}
		
		for(TopicEntity topic: topicDao.findAll())
		{
			TopiclevelsEntity topiclevels = new TopiclevelsEntity();
			topiclevels.setLevel(1);
			topiclevels.setTopicId(topic);
			topiclevels.setUserId(student);
			
			AccuracyEntity accuracy = new AccuracyEntity();
			accuracy.setTopicsByTopicId(topic);
			accuracy.setUserId(student);
			
			try {
				ObjectMapper objectMapper = new ObjectMapper();
				int[] num = new int[20];
				accuracy.setAccuracy(objectMapper.writeValueAsString(num));
				
			} catch (JsonProcessingException e) {
				throw new RuntimeException(e);
			}
			
			student.getTopiclevelsEntities().put(topic.getId(), topiclevels);
			student.getAccuracyEntities().put(topic.getId(), accuracy);
		}
		
		studentDao.persist(student);
		return student;
	}
}