package com.shezartech.iitjeeacademy.service;

import java.util.List;
import java.util.Set;

import com.shezartech.iitjeeacademy.entity.StudentEntity;
import com.shezartech.iitjeeacademy.entity.TutorEntity;
import com.shezartech.iitjeeacademy.response.tutor.TutorResponse.FinancialSummary;
import com.shezartech.iitjeeacademy.response.tutor.TutorResponse.StudentInfo;

public interface TutorService
{

	Set<StudentEntity> getStudents(String email);

	TutorEntity findTutor(String email);

	Set<StudentEntity> getStudents(String email, String targetYear);

	List<StudentInfo> getStudentInformation(String email);

	List<FinancialSummary> getFinancialSummaries(String email);



}
