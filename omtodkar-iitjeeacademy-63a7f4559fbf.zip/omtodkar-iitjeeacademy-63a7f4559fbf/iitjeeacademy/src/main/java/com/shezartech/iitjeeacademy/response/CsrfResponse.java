package com.shezartech.iitjeeacademy.response;

public class CsrfResponse extends Response{
	
	public CsrfResponse(){
		super();
		super.setResponse(new Status("csrf-mismatch", "Token Mismatch", "failed"));
	}
}
