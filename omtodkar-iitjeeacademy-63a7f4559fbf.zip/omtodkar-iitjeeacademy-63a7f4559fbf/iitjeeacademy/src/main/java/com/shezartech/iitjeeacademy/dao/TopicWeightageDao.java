package com.shezartech.iitjeeacademy.dao;

import java.util.List;

import com.shezartech.iitjeeacademy.entity.SubjectEntity;
import com.shezartech.iitjeeacademy.entity.TopicWeightageEntity;

public interface TopicWeightageDao extends Dao<TopicWeightageEntity, Integer>{

	List<TopicWeightageEntity> findAll(SubjectEntity subject);
}
