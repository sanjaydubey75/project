package com.shezartech.iitjeeacademy.dao;

import com.shezartech.iitjeeacademy.entity.StudentEntity;
import com.shezartech.iitjeeacademy.entity.TopiclevelsEntity;

public interface StudentDao extends Dao<StudentEntity, Integer>
{
	StudentEntity find(String email);
}
