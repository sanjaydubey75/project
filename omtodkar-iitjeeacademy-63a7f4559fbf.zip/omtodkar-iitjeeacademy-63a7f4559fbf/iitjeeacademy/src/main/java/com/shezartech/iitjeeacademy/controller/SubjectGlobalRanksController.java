package com.shezartech.iitjeeacademy.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.shezartech.iitjeeacademy.config.URIConstants;

@RestController
@RequestMapping(value = URIConstants.SubjectGlobalRanksController)
public class SubjectGlobalRanksController
{
	
}
