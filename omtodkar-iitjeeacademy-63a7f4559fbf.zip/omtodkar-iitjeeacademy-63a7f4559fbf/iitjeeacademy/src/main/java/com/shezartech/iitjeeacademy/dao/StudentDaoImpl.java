package com.shezartech.iitjeeacademy.dao;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.shezartech.iitjeeacademy.entity.StudentEntity;
import com.shezartech.iitjeeacademy.entity.TopiclevelsEntity;

@Repository
public class StudentDaoImpl extends DaoImpl<StudentEntity, Integer> implements StudentDao {

	public StudentDaoImpl(){
		super(StudentEntity.class);
	}
	
	@Override
	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory)
	{
		super.setSessionFactory(sessionFactory);
	}
	
	@Override
	public StudentEntity find(String email)
	{
		Query query = getCurrentSession()
				.createSQLQuery("select * from student s where s.email = :email")
				.addEntity(StudentEntity.class)
				.setParameter("email", email);
		
//		Criteria criteria = getCurrentSession().createCriteria(entityClass);
//		criteria.add(Restrictions.eq("email", email));
//		StudentEntity student = (StudentEntity) criteria.uniqueResult();
		
		StudentEntity student = (StudentEntity) query.uniqueResult();
		return student;
	}
}
