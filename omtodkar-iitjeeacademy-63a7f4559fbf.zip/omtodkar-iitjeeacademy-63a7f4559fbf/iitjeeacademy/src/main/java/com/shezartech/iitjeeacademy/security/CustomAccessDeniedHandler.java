package com.shezartech.iitjeeacademy.security;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.web.access.AccessDeniedHandler;

import com.fasterxml.jackson.databind.ObjectMapper;

public class CustomAccessDeniedHandler implements AccessDeniedHandler
{
	protected static final Logger LOGGER = LoggerFactory.getLogger(CustomAccessDeniedHandler.class);
	private final ObjectMapper om = new ObjectMapper();

	@Override
	public void handle(HttpServletRequest request,
			HttpServletResponse response,
			AccessDeniedException accessDeniedException) throws IOException,
			ServletException
	{

		int status = HttpServletResponse.SC_FORBIDDEN;
		response.setStatus(HttpServletResponse.SC_FORBIDDEN);
		response.setContentType("application/json");
		
//		UnAuthorizedResponse unAuthorizedResponse = 
//				new UnAuthorizedResponse(
//						status, HttpStatus.valueOf(status).name(), 
//						accessDeniedException.getClass().getName(), accessDeniedException.getMessage());
//		
//		response.getOutputStream().println(unAuthorizedResponse.toString());
		
		ErrorMessage errorMessage = new ErrorMessage(status, HttpStatus.valueOf(status).getReasonPhrase(), accessDeniedException.getMessage());
		om.writeValue(response.getOutputStream(), errorMessage);
	}
	
//	static class UnAuthorizedResponse
//	{
//		public int status;
//		public String error;
//		public String exception;
//		public String message;
//		public UnAuthorizedResponse(int status, String error, String exception, String message)
//		{
//			super();
//			this.status = status;
//			this.error = error;
//			this.exception = exception;
//			this.message = message;
//		}
//		
//		@Override
//		@JsonIgnore
//		public String toString()
//		{
//			ObjectMapper mapper = new ObjectMapper();
//			try
//			{
//				return mapper.writeValueAsString(this);
//			}
//			catch (JsonProcessingException e)
//			{
//				LOGGER.error("error while serizalizing UnAuthorizedResponse");
//			}
//			return null;
//		}
//	}

}
