package com.shezartech.iitjeeacademy.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.shezartech.iitjeeacademy.config.URIConstants;
import com.shezartech.iitjeeacademy.entity.StatewiseselectionEntity;
import com.shezartech.iitjeeacademy.service.StateService;

@RestController
@RequestMapping(value = URIConstants.StateController)
public class StateController
{

	@Autowired
	private StateService stateService;
	
	@RequestMapping(method = RequestMethod.GET)
	@PreAuthorize("hasRole('student')")
	public List<StatewiseselectionEntity> getDetails()
	{
		return stateService.getAllStates();
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/{id}")
	@PreAuthorize("hasRole('student')")
	public StatewiseselectionEntity getState(@PathVariable(value="id") Integer id)
	{
		return stateService.getState(id);
	}
}
