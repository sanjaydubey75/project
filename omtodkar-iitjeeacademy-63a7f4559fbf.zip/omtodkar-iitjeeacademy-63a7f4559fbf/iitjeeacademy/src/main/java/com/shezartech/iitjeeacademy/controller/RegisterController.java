package com.shezartech.iitjeeacademy.controller;

import java.util.Map;

import javax.validation.Valid;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.shezartech.iitjeeacademy.config.URIConstants;
import com.shezartech.iitjeeacademy.config.WebSecurityConfig.ClientSecretsConfiguration.Provider;
import com.shezartech.iitjeeacademy.entity.TutorEntity;
import com.shezartech.iitjeeacademy.exception.RegisterException;
import com.shezartech.iitjeeacademy.response.FailureResponse;
import com.shezartech.iitjeeacademy.response.NgValidateResponse;
import com.shezartech.iitjeeacademy.response.SuccessResponse;
import com.shezartech.iitjeeacademy.security.ErrorMessage;
import com.shezartech.iitjeeacademy.service.RegisterService;

@RestController
@RequestMapping(value = URIConstants.Register)
public class RegisterController {
	
	private static final String TutorRegister = "/tutor";
	private static final String StudentRegister = "/student";
	private static final String StudentRegisterTrial = "/student/trial";
	
	private static final String ValidateTutorEmail = "/validate/tutor/email";

	private static final Logger logger = LoggerFactory.getLogger(RegisterController.class);
	
	@Autowired
	private RegisterService registerService;
	
	@RequestMapping(value = RegisterController.TutorRegister, method = RequestMethod.POST)
	public com.shezartech.iitjeeacademy.response.Response registerTutor(@RequestBody @Valid final TutorEntity tutor, BindingResult result)
	{
		if(!result.hasErrors() && registerService.isEmailValidForTutor(tutor.getEmail())){
			registerService.registerTutor(tutor);
			return new SuccessResponse();
		}
		else
		{
			return new FailureResponse("Oops! Server encountered an error. Please try again", "register");
		}
	}
	
	@RequestMapping(value = RegisterController.ValidateTutorEmail, method = RequestMethod.POST)
	public com.shezartech.iitjeeacademy.response.Response validateEmailForTutor(@RequestBody Map<String, String> params,
			BindingResult result)
	{	
		String email = params.get("value");
		if(registerService.isEmailValidForTutor(email)) return new NgValidateResponse(true, email);
		else return (new NgValidateResponse(false, email));
	}
	
	@RequestMapping(value = RegisterController.StudentRegister, method = RequestMethod.POST)
	public Response registerStudent(@RequestBody Map<String, Object> studentMap)
	{
		try
		{
			registerService.registerStudent(studentMap, Provider.PAID_STUDENT);
			return Response.status(Status.CREATED).build();
		}
		catch(RegisterException exception)
		{
			ErrorMessage errorMessage = 
					new ErrorMessage(Status.BAD_REQUEST.getStatusCode(), 
							Status.BAD_REQUEST.getReasonPhrase(), exception.getMessage());
			return Response.status(Status.BAD_REQUEST).entity(errorMessage).build();
		}
	}
	
	@RequestMapping(value = RegisterController.StudentRegisterTrial, method = RequestMethod.POST)
	public Response registerStudentTrial(@RequestBody Map<String, Object> studentMap)
	{
		registerService.registerStudent(studentMap, Provider.TRIAL_STUDENT);
		return Response.status(Status.CREATED).build();
	}
}