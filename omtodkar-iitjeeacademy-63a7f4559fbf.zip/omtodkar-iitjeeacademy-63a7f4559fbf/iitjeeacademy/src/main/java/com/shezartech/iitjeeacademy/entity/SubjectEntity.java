package com.shezartech.iitjeeacademy.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.Length;

@Entity
@Table(name = "subjects")
public class SubjectEntity implements ModelEntity{

	@Id
	@Length(max = 50)
	@Column(name="subject_id", length = 50)
    private String id;

	@Length(max = 500)
	@Column(name="name", length = 500, nullable = false)
    private String name;
    
	@Length(max = 1000)
	@Column(name = "info", length = 1000, nullable = false)
    private String info;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}
}
