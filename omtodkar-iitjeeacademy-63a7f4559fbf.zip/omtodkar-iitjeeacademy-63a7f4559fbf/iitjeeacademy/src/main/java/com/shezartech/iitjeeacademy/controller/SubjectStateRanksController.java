package com.shezartech.iitjeeacademy.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.shezartech.iitjeeacademy.config.URIConstants;
import com.shezartech.iitjeeacademy.service.StudentService;

@RestController
@RequestMapping(value = URIConstants.SubjectStateRanksController)
public class SubjectStateRanksController {
	
	@Autowired
	private StudentService studentService;

}
