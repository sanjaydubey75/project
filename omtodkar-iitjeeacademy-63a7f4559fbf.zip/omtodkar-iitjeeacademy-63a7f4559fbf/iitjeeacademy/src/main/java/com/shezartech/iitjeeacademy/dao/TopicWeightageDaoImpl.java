package com.shezartech.iitjeeacademy.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.shezartech.iitjeeacademy.entity.SubjectEntity;
import com.shezartech.iitjeeacademy.entity.TopicWeightageEntity;

@Repository
public class TopicWeightageDaoImpl extends DaoImpl<TopicWeightageEntity, Integer> implements TopicWeightageDao{

	@Override
	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		super.setSessionFactory(sessionFactory);
	}
	
	public TopicWeightageDaoImpl(){
		super(TopicWeightageEntity.class);
	}

	@Override
	public List<TopicWeightageEntity> findAll(SubjectEntity subject) {
		Criteria criteria = getCurrentSession().createCriteria(this.entityClass);
		criteria.add(Restrictions.eq("subjectsBySubjectId", subject));
		return criteria.list();
	}
}
