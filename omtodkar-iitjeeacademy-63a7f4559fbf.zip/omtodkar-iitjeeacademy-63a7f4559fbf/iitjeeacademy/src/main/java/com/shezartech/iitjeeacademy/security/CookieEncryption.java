package com.shezartech.iitjeeacademy.security;


public class CookieEncryption {
	
	public static void main(String args[]) throws Exception{
		String plainText = "{'userName':'shobhit','userEmail':'shobhit@gmail.com','datestampcreated':1426855821,'role':'student'}";
//		String string = temp.replace("'", "\"");
//		
//		String encryptedValue = "eyJpdiI6Ijk0ZVRJRk40YWNHQVNQTDZPRnFWeFE9PSIsInZhbHVlIjoiXC9mNFBqUzJZQlFOT3k1dG8ySUdCdnF4QkU4UjJFa1dmQ1hlb0ZYSEp4UCs5ejNDWE5JdFBsd1ZZeURKcmRcLzNhUkFTYXpDemw1VzJMZkE0UUZsN3dsYU5uWERBYUlpWk0weGYxVm1BTVdKWWpxTmFSMDJhQTRyMnlnTmV5dGdmNGQ5UGJBQ3RPM3lGdzlCazY3VGpZTVE9PSIsIm1hYyI6ImE2NDA1YzdhNTE3M2MwZmQzYjU3MTc2ZDg3NzNhYmNlMmE4ZmI0OTY3YjU1NzQzYzgyN2M5MzYwMTU2MDhmOWUifQ==";
//		String encryptedValue = "eyJpdiI6IkNRbENRYTMrRzhwY1hFcXhJT1NzNWc9PSIsInZhbHVlIjoiK0NKRDNoSFRZeTB6OVIxbk5nak9xUUpmS2k5UmtrRURNZUZnaTZheXljcWhlYkVkNXdXT2ZOSGFyYnVhK1Nab0xId0Frb3VIb3Z3cmZyZWZ3c3J1K1FyQXJ3VWgxak9sK2FWS2xlR1YzOTdOZmNYWUdTeitnZjFFTENcL3FEa0tPdjRGZ3RSUDVwWU54ckdEajJySmdOdz09IiwibWFjIjoiMGUxZGY1ZGUyYjI3YzBkOTYzNTE5ZDAyNTBjYmU2NWQxNWU0MmJkNmE5ODY4NDA4NzUzZDI0MGNhOWFmMWE5MiJ9";
		String encryptedValue = "eyJpdiI6IjQ1cW9xRE5UZVEzZHFkM3ltVlpKdHc9PSIsInZhbHVlIjoieUdaWlR1MVp2V1l1V0NiSXFDSG1Fdz09IiwibWFjIjoiMjRmYWEzNTU4OTJkZmM3ZWRmNDc5OTFmMDhhZDMzNjEwZWE4OWEyZjJkMDRhZDFkMjY2NWE0ZmQ5ZTNhZmFmNyJ9";
		
		//first try to decrypt
		Encrypter encrypter = new Encrypter();
		String a = encrypter.decrypt(encryptedValue);
		
		System.out.println(a);
		
		String cipherText = encrypter.encrypt("abcd");
		System.out.println(cipherText);
		
		String decrypt = encrypter.decrypt(cipherText);
		System.out.println(decrypt);
	}
}