package com.shezartech.iitjeeacademy.service;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.transaction.Transactional;

import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.google.common.io.Files;
import com.shezartech.iitjeeacademy.config.WebSecurityConfig.ClientSecretsConfiguration.Provider;
import com.shezartech.iitjeeacademy.dao.StateDao;
import com.shezartech.iitjeeacademy.dao.StudentDao;
import com.shezartech.iitjeeacademy.entity.MotivatorEntity;
import com.shezartech.iitjeeacademy.entity.StatewiseselectionEntity;
import com.shezartech.iitjeeacademy.entity.StudentEntity;
import com.shezartech.iitjeeacademy.entity.SubjectglobalranksEntity;
import com.shezartech.iitjeeacademy.entity.SubjectlevelsEntity;
import com.shezartech.iitjeeacademy.entity.SubjectstateranksEntity;
import com.shezartech.iitjeeacademy.entity.TopiclevelsEntity;
import com.shezartech.iitjeeacademy.security.Md5;
import com.shezartech.iitjeeacademy.security.Uniqid;

@Service
public class StudentServiceImpl implements StudentService
{

	@Autowired
	private StudentDao studentDao;
	
	@Autowired
	private StateDao stateDao;
	
	@Autowired
    ServletContext servletContext;
	
	@Override
	@Transactional
	public StudentEntity findStudent(String email)
	{
		return this.studentDao.find(email);
	}
	
	@Override
	@Transactional
	public void linkAccount(Map<String, Object> studentMap, Provider provider)
	{
		StudentEntity student = this.findStudent((String) studentMap.get("email"));
		
		switch (provider) {
		case FACEBOOK:
			student.setFacebookId((String) studentMap.get("id"));
			student.setFacebookLink((String) studentMap.get("link"));
			break;
			
		case GOOGLE:
			student.setGoogleId((String) studentMap.get("sub"));
			student.setGoogleLink((String) studentMap.get("profile"));
			break;

		default:
			throw new RuntimeException(String.format("Provider %s is not supported", provider.getName()));
		}
	}
	
	@Transactional
	@Override
	public List<SubjectglobalranksEntity> getSubjectGlobalRanks(StudentEntity student)
	{
		student = studentDao.find(student.getId());
		Hibernate.initialize(student.getSubjectglobalranksEntity());
		return student.getSubjectglobalranksEntity();
	}
	
	@Transactional
	@Override
	public List<SubjectstateranksEntity> getSubjectStateRanks(StudentEntity student)
	{
		student = studentDao.find(student.getId());
		Hibernate.initialize(student.getSubjectstateranksEntities());
		return student.getSubjectstateranksEntities();
	}
	
	@Transactional
	@Override
	public List<SubjectlevelsEntity> getSubjectlevelsEntities(StudentEntity student)
	{
		student = studentDao.find(student.getId());
		Hibernate.initialize(student.getSubjectlevelsEntities());
		return student.getSubjectlevelsEntities();
	}
	
	@Transactional
	@Override
	public List<String> getEmptyProfileFields(StudentEntity student)
	{
		List<String> temp = new ArrayList<String>();
		student = studentDao.find(student.getId());
		
		if(!StringUtils.hasText(student.getMobileNumber()))
				temp.add("mobileNumber");
		if(!StringUtils.hasText(student.getPassword()))
			temp.add("password");
		if(student.getTargetYear() == null)
			temp.add("targetYear");
		if(student.getBirthday() == null)
			temp.add("birthday");
		if(student.getState() == null)
			temp.add("state");
		
		return temp;
	}
	
	@Transactional
	@Override
	public StudentEntity editProfile(StudentEntity studentPrincipal, Map<String, Object> studentMap,
			MultipartFile file)
	{
		studentPrincipal = studentDao.find(studentPrincipal.getId());
		studentPrincipal.setBirthday(Date.valueOf((String) studentMap.get("birthday")));
		
		StatewiseselectionEntity state = stateDao.find((Integer) studentMap.get("state"));
		studentPrincipal.setState(state);
		studentPrincipal.setTargetYear((Integer) studentMap.get("targetYear"));
		studentPrincipal.setMobileNumber((String) studentMap.get("mobileNumber"));
		if(StringUtils.hasText((CharSequence) studentMap.get("password")))
			studentPrincipal.setPassword(
					RegisterServiceImpl.hashPassword((String) studentMap.get("password")));
		if(StringUtils.hasText((String) studentMap.get("institution")))
			studentPrincipal.setInstitution((String) studentMap.get("institution"));
		if(StringUtils.hasText((String) studentMap.get("parentEmail")))
			studentPrincipal.setParentEmail((String) studentMap.get("parentEmail"));
		
		if(file != null)
		{
			Uniqid uniqid = new Uniqid();
			String filename = Md5.md5(uniqid.uniqid(String.valueOf(studentPrincipal.getId()), true))
					+ "." + Files.getFileExtension(file.getOriginalFilename());
			FileUploadService fileUploadService = new FileUploadServiceImpl(
					servletContext.getRealPath("/"), "static", "student", "profilepics");
			fileUploadService.upload(file, filename);
			fileUploadService.delete(studentPrincipal.getPhotopath());
			studentPrincipal.setPhotopath(filename);
		}
		
		return studentPrincipal;
	}
	
	@Transactional
	@Override
	public MotivatorEntity getMotivator(StudentEntity student)
	{
		student = studentDao.find(student.getId());
		Hibernate.initialize(student.getMotivator());
		return student.getMotivator();
	}
	
	@Transactional
	@Override
	public void setMotivator(StudentEntity student, MotivatorEntity motivator)
	{
		student = studentDao.find(student.getId());
		MotivatorEntity motivator1 = student.getMotivator();
		
		if(motivator1 != null)
		{
			motivator1.setEmail(motivator.getEmail());
			motivator1.setName(motivator.getName());
			motivator1.setPhone(motivator.getPhone());
			motivator1.setRelationship(motivator.getRelationship());
		}
		else
			student.setMotivator(motivator);
	}
	
	@Transactional
	@Override
	public TopiclevelsEntity getTopicLevel(StudentEntity student, String topicId)
	{
		student = studentDao.find(student.getId());
		return student.getTopiclevelsEntities().get(topicId);
	}
}
