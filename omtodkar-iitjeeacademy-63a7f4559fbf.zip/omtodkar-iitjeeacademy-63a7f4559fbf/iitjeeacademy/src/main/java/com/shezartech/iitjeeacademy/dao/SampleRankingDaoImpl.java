package com.shezartech.iitjeeacademy.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.shezartech.iitjeeacademy.entity.SamplerankingEntity;
import com.shezartech.iitjeeacademy.service.RankingService;

public class SampleRankingDaoImpl extends DaoImpl<SamplerankingEntity, Integer>implements SampleRankingDao
{

	public SampleRankingDaoImpl()
	{
		super(SamplerankingEntity.class);
	}
	
	@Override
	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory)
	{
		super.setSessionFactory(sessionFactory);
	}

}
