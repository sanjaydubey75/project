package com.shezartech.iitjeeacademy.service;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidParameterSpecException;
import java.sql.Timestamp;
import java.util.Date;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.shezartech.iitjeeacademy.dao.StudentDao;
import com.shezartech.iitjeeacademy.dao.TutorDao;
import com.shezartech.iitjeeacademy.entity.StudentEntity;
import com.shezartech.iitjeeacademy.entity.TutorEntity;
import com.shezartech.iitjeeacademy.security.Encrypter;
import com.shezartech.iitjeeacademy.security.UserAuthCookie;

@Service
public class AuthenticationServiceImpl implements AuthenticationService
{
	
	@Autowired
	private StudentDao studentDao;
	
	@Autowired
	private TutorDao tutorDao;
	
	@Autowired
	private HttpServletResponse httpServletResponse;
	
	@Autowired
	private HttpServletRequest httpServletRequest;
	
	@Transactional
	@Override
	public void setTimestamp(UserDetails details)
	{
		if(details instanceof StudentEntity)
		{
			StudentEntity student = studentDao.find(details.getUsername());
			student.setLastLoginTime(new Timestamp((new Date()).getTime()));
		}
	}
	
	@Override
	public void setAuthenticationCookie(UserDetails details)
	{
		UserAuthCookie userAuthCookie = null;
		if(details instanceof TutorEntity)
			userAuthCookie = new UserAuthCookie((TutorEntity)details);
		else if(details instanceof StudentEntity)
			userAuthCookie = new UserAuthCookie((StudentEntity)details);
		
		setAuthenticationCookie(userAuthCookie);
	}
	
	@Override
	public String getUserType(UserDetails details)
	{
		if(details instanceof StudentEntity)
			return StudentEntity.Type;
		if(details instanceof TutorEntity)
			return TutorEntity.Type;
		return null;
	}
	
	private void setAuthenticationCookie(UserAuthCookie userAuthCookie)
	{
		Gson gson = new Gson();
		String cookieValue = gson.toJson(userAuthCookie);
		Encrypter encrypter = new Encrypter();
		try
		{
			String cookieValueEncrypted = encrypter.encrypt(cookieValue);
			String cookieValueEncoded = URLEncoder.encode(cookieValueEncrypted, "UTF-8");
			Cookie cookie = new Cookie("auth-token", cookieValueEncoded);
			cookie.setPath("/");
			cookie.setMaxAge(3600);
			cookie.setSecure(true);
			cookie.setHttpOnly(false); // so that the client just deletes this cookie on logout
			httpServletResponse.addCookie(cookie);
		}
		catch (InvalidKeyException | NoSuchAlgorithmException
				| NoSuchPaddingException | InvalidParameterSpecException
				| IllegalBlockSizeException | BadPaddingException
				| InvalidAlgorithmParameterException
				| UnsupportedEncodingException e)
		{
			e.printStackTrace();
		}
	}
}