package com.shezartech.iitjeeacademy.exception;

public class NullCookieException extends Exception{
	
	public NullCookieException(){
		
		super("Cookie is null");
	}
}
