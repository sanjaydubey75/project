package com.shezartech.iitjeeacademy.response;

public class FailureResponse extends Response{

	public FailureResponse(){
		super();
		super.setResponse(new Status("failure-response", "", "failed"));
	}
	
	public FailureResponse(String code, String message){
		super();
		super.setResponse(new Status(code, message, "failed"));
	}
	
	public FailureResponse setMessage(String message){
		this.response.setMessage(message);
		return this;
	}
}