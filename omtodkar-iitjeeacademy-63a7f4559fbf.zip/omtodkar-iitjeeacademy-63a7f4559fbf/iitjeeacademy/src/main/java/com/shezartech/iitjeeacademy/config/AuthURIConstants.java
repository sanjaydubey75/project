package com.shezartech.iitjeeacademy.config;

public class AuthURIConstants extends URIConstants{
	
	public static final String AuthenticatedURI = AuthURIConstants.AbsoluteURI + "/auth";
}
