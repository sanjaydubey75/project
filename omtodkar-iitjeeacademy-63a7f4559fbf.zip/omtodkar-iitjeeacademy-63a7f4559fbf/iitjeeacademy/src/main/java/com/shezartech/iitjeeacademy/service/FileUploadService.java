package com.shezartech.iitjeeacademy.service;

import org.springframework.web.multipart.MultipartFile;

public interface FileUploadService
{

	void upload(MultipartFile file, String name);

	void delete(String name);

}
