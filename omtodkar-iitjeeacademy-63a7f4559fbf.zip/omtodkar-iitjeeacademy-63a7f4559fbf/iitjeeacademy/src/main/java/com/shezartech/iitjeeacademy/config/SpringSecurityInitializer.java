package com.shezartech.iitjeeacademy.config;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

public class SpringSecurityInitializer extends
		AbstractSecurityWebApplicationInitializer
{

}
