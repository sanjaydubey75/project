package com.shezartech.iitjeeacademy.dao;

import com.shezartech.iitjeeacademy.entity.StatewiseselectionEntity;

public interface StateDao extends Dao<StatewiseselectionEntity, Integer>
{

}
