package com.shezartech.iitjeeacademy.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;

@Entity
@Table(name = "motivator")
public class MotivatorEntity implements ModelEntity
{

	@Id
	@GeneratedValue
	private Integer id;//will signify motivator's identity
	
	@Length(max = 255)
	private String name;
	
	@Length(max = 255)
	@Column(unique = true)
	@NotNull
	private String email;
	
	@Length(max = 20)
	private String phone;
	
	@Length(max = 255)
	private String relationship;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getRelationship() {
		return relationship;
	}

	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}
}
