package com.shezartech.iitjeeacademy.service;

import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import com.shezartech.iitjeeacademy.config.WebSecurityConfig.ClientSecretsConfiguration.Provider;
import com.shezartech.iitjeeacademy.entity.MotivatorEntity;
import com.shezartech.iitjeeacademy.entity.StudentEntity;
import com.shezartech.iitjeeacademy.entity.SubjectglobalranksEntity;
import com.shezartech.iitjeeacademy.entity.SubjectlevelsEntity;
import com.shezartech.iitjeeacademy.entity.SubjectstateranksEntity;
import com.shezartech.iitjeeacademy.entity.TopiclevelsEntity;

public interface StudentService
{

	StudentEntity findStudent(String email);

	void linkAccount(Map<String, Object> studentMap, Provider provider);

	List<SubjectglobalranksEntity> getSubjectGlobalRanks(StudentEntity student);

	List<SubjectstateranksEntity> getSubjectStateRanks(StudentEntity student);

	List<SubjectlevelsEntity> getSubjectlevelsEntities(StudentEntity student);

	//the compulsory fields are mobile number, password, targetYear, birthday, state
	List<String> getEmptyProfileFields(StudentEntity student);

	StudentEntity editProfile(StudentEntity studentPrincipal,
			Map<String, Object> studentMap, MultipartFile file);

	MotivatorEntity getMotivator(StudentEntity student);

	void setMotivator(StudentEntity student, MotivatorEntity motivator);

	TopiclevelsEntity getTopicLevel(StudentEntity student, String topicId);

}
