package com.shezartech.iitjeeacademy.response;

public class SuccessResponse extends Response{

	public SuccessResponse(){
		super();
		super.setResponse(new Status("success-response", "", "success"));
	}
}