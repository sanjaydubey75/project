package com.shezartech.iitjeeacademy.service;

public interface RankingService {

}
