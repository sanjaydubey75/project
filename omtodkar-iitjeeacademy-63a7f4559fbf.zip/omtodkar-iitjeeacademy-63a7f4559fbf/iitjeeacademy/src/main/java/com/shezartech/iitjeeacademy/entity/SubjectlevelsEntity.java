package com.shezartech.iitjeeacademy.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIdentityReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

/**
 * Created by shobhit on 3/26/2015.
 */
@Entity
@Table(name = "subjectlevels")
public class SubjectlevelsEntity implements ModelEntity{
	
	@Id
	@ManyToOne
	@JsonIgnore
    private StudentEntity user;
	
	@Column(name = "level", nullable = false)
    private int level;
    
    @Id
    @ManyToOne
    @JoinColumn(name = "subjectId", referencedColumnName = "subject_id", nullable = false)
    @JsonIdentityReference(alwaysAsId = true)
	@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
    private SubjectEntity subject;
    
    @Column(nullable=true, name = "started_practice")
    private boolean startedPractice;
    
    
    public StudentEntity getUser() {
        return user;
    }

    public void setUser(StudentEntity userId) {
        this.user = userId;
    }
    
    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    
    public SubjectEntity getSubject() {
        return subject;
    }

    public void setSubject(SubjectEntity subjectId) {
        this.subject = subjectId;
    }
}
