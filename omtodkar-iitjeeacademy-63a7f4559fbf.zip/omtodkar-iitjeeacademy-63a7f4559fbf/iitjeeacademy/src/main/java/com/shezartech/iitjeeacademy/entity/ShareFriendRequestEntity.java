package com.shezartech.iitjeeacademy.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * Created by shobhit on 3/26/2015.
 */
@Entity
@Table(name = "share_friend_request")
public class ShareFriendRequestEntity implements ModelEntity{
	
	@Id
    @Column(name = "Id", columnDefinition = "char(36) NOT NULL")
//	@GeneratedValue(generator = "uuid")
//	@GenericGenerator(name = "uuid", strategy = "uuid2")
    private String id;
	
	@Column(name="friendEmail", nullable=false)
    private String friendEmail;
    
	@Column(name = "time", nullable = false)
    private Timestamp time;
	
	@ManyToOne
	private QuestionEntity question;
    
    @ManyToOne
    @JoinColumn(name="studentId", referencedColumnName="id", nullable=false)
    private StudentEntity studentId;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFriendEmail() {
        return friendEmail;
    }

    public void setFriendEmail(String friendEmail) {
        this.friendEmail = friendEmail;
    }

    
    
    public Timestamp getTime() {
        return time;
    }

    public void setTime(Timestamp time) {
        this.time = time;
    }
    
    public StudentEntity getStudentId() {
        return studentId;
    }

    public void setStudentId(StudentEntity studentId) {
        this.studentId = studentId;
    }

	public QuestionEntity getQuestion() {
		return question;
	}

	public void setQuestion(QuestionEntity question) {
		this.question = question;
	}
}
