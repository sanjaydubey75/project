package com.shezartech.iitjeeacademy.config;

import java.util.Properties;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

@Configuration
@ComponentScan(basePackages = { "com.shezartech.iitjeeacademy" })
public class MailConfig extends WebMvcConfigurerAdapter
{

	private static final String host = "mail.shezartech.com";
	private static final int port = 465;
	private static final String username = "shobhit@shezartech.com";
	private static final String password = "shobhit@1234";
	public static final String recipientMail = "shezartech2014@gmail.com";
	
//	private static final String username = "support@godrejguru.com";
//	private static final String password = "support@1234";
//	public static final String recipientMail = "helpdesk@godrejguru.com";
	
	private static final Properties javaMailProperties = new Properties()
	{
		{
			setProperty("mail.transport.protocol", "smtps");
			setProperty("mail.smtps.auth", "true");
//			setProperty("mail.smtp.starttls.enable", "true");
			setProperty("mail.smtp.ssl.enable", "true");
			setProperty("mail.debug", "true");
		}
	};

	@Bean(name = "mailSender")
	public JavaMailSender mailSender()
	{
		JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
		mailSender.setHost(host);
		mailSender.setPort(port);
		mailSender.setUsername(username);
		mailSender.setPassword(password);
		mailSender.setJavaMailProperties(javaMailProperties);
		
		return mailSender;
	}
}
