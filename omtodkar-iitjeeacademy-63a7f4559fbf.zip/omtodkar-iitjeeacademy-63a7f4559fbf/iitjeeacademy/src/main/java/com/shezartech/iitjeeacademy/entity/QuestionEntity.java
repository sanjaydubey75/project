package com.shezartech.iitjeeacademy.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.validator.constraints.Length;

@Entity
@Table(name = "questions")
public class QuestionEntity implements ModelEntity {

	@Length(max = 100)
	@Id
	@Column(length = 100, name = "id")
	private String id;

	@ManyToOne(targetEntity = SubjectEntity.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "subject_id", referencedColumnName = "subject_id", nullable = false)
	private SubjectEntity subject;

	@ManyToOne(targetEntity = TopicEntity.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "topic_id", referencedColumnName = "topic_id", nullable = false)
	private TopicEntity topic;

	@Column(length = 5500, name = "description", nullable = false)
	@Length(max = 5500)
	private String description;

	@Length(max = 500)
	@Column(length = 500, name = "pic", nullable = false)
	private String pic;

	@Length(max = 1500)
	@Column(length = 1500, name = "cha", nullable = false)
	private String choiceA;

	@Length(max = 500)
	@Column(length = 500, name = "pica", nullable = false)
	private String picA;

	@Length(max = 1500)
	@Column(length = 1500, name = "chb", nullable = false)
	private String choiceB;

	@Length(max = 500)
	@Column(length = 500, name = "picb", nullable = false)
	private String picB;

	@Length(max = 1500)
	@Column(length = 1500, name = "chc", nullable = false)
	private String choiceC;

	@Length(max = 500)
	@Column(length = 500, name = "picc", nullable = false)
	private String picC;

	@Length(max = 1500)
	@Column(length = 1500, name = "chd", nullable = false)
	private String choiceD;

	@Length(max = 500)
	@Column(length = 500, name = "picd", nullable = false)
	private String picD;

	@Length(max = 100)
	@Column(length = 100, name = "answer", nullable = false)
	private String answer;

	@Column(length = 20, name = "attempt", nullable = false)
	private Long attempt;

	@Column(length = 20, name = "correct", nullable = false)
	private Long correct;

	@Column(length = 11, name = "level", nullable = false)
	private int level;

	@Column(length = 11, name = "checked", nullable = false)
	private int checked;

	@Column(length = 10, name = "BookId", nullable = false)
	private int bookId;

	@Length(max = 10)
	@Column(length = 10, name = "PageNumber", nullable = false)
	private String pageNumber;

	@Column(name = "SolutionAvailable", nullable = false)
	private boolean solutionAvailable;

	@Temporal(TemporalType.TIME)
	@Column(nullable = false)
	private Date timelimit;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public SubjectEntity getSubject() {
		return subject;
	}

	public void setSubject(SubjectEntity subject) {
		this.subject = subject;
	}

	public TopicEntity getTopic() {
		return topic;
	}

	public void setTopic(TopicEntity topic) {
		this.topic = topic;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPic() {
		return pic;
	}

	public void setPic(String pic) {
		this.pic = pic;
	}

	public String getChoiceA() {
		return choiceA;
	}

	public void setChoiceA(String choiceA) {
		this.choiceA = choiceA;
	}

	public String getPicA() {
		return picA;
	}

	public void setPicA(String picA) {
		this.picA = picA;
	}

	public String getChoiceB() {
		return choiceB;
	}

	public void setChoiceB(String choiceB) {
		this.choiceB = choiceB;
	}

	public String getPicB() {
		return picB;
	}

	public void setPicB(String picB) {
		this.picB = picB;
	}

	public String getChoiceC() {
		return choiceC;
	}

	public void setChoiceC(String choiceC) {
		this.choiceC = choiceC;
	}

	public String getPicC() {
		return picC;
	}

	public void setPicC(String picC) {
		this.picC = picC;
	}

	public String getChoiceD() {
		return choiceD;
	}

	public void setChoiceD(String choiceD) {
		this.choiceD = choiceD;
	}

	public String getPicD() {
		return picD;
	}

	public void setPicD(String picD) {
		this.picD = picD;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public Long getAttempt() {
		return attempt;
	}

	public void setAttempt(Long attempt) {
		this.attempt = attempt;
	}

	public Long getCorrect() {
		return correct;
	}

	public void setCorrect(Long correct) {
		this.correct = correct;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public int getChecked() {
		return checked;
	}

	public void setChecked(int checked) {
		this.checked = checked;
	}

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public String getPageNumber() {
		return pageNumber;
	}

	public void setPageNumber(String pageNumber) {
		this.pageNumber = pageNumber;
	}

	public boolean isSolutionAvailable() {
		return solutionAvailable;
	}

	public void setSolutionAvailable(boolean solutionAvailable) {
		this.solutionAvailable = solutionAvailable;
	}

	public Date getTimelimit() {
		return timelimit;
	}

	public void setTimelimit(Date timelimit) {
		this.timelimit = timelimit;
	}
}
