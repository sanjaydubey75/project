package com.shezartech.iitjeeacademy.model;

public class Pricing
{
	private int id;
	private String duration;
	private int amount;
	private long timestampDuration;
	
	public Pricing(int id, String duration, int amount, long timestampDuration)
	{
		super();
		this.id = id;
		this.duration = duration;
		this.amount = amount;
		this.timestampDuration = timestampDuration;
	}
	public int getId()
	{
		return id;
	}
	public void setId(int id)
	{
		this.id = id;
	}
	public String getDuration()
	{
		return duration;
	}
	public void setDuration(String duration)
	{
		this.duration = duration;
	}
	public int getAmount()
	{
		return amount;
	}
	public void setAmount(int amount)
	{
		this.amount = amount;
	}
	public long getTimestampDuration() {
		return timestampDuration;
	}
	public void setTimestampDuration(long timestampDuration) {
		this.timestampDuration = timestampDuration;
	}
}
