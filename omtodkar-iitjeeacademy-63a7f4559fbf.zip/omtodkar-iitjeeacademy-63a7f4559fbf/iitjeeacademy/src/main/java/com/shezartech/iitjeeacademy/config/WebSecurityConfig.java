package com.shezartech.iitjeeacademy.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.config.annotation.SecurityConfigurer;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.DefaultSecurityFilterChain;

import com.shezartech.iitjeeacademy.security.AuthenticationFailureExceptionHandler;
import com.shezartech.iitjeeacademy.security.CustomAccessDeniedHandler;
import com.shezartech.iitjeeacademy.security.CustomAuthenticationProvider;
import com.shezartech.iitjeeacademy.security.XAuthTokenConfigurer;
import com.shezartech.iitjeeacademy.service.StudentService;
import com.shezartech.iitjeeacademy.service.TutorService;

//@EnableTransactionManagement
//@EnableSpringConfigured
//@Order
@EnableWebSecurity(debug = true)
@Configuration
@ComponentScan(basePackages = { "com.shezartech.iitjeeacademy" })
@EnableGlobalMethodSecurity(securedEnabled = true, prePostEnabled = true)
public class WebSecurityConfig extends WebSecurityConfigurerAdapter
{
	@Autowired
	private TutorService tutorService;
	
	@Autowired
	private StudentService studentService; 

	@Autowired
	public void configureGlobal(AuthenticationManagerBuilder auth)
	{
		auth.authenticationProvider(customAuthenticationProvider());
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception
	{
		http.csrf().disable();
		http.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);
		
		http.exceptionHandling().authenticationEntryPoint(new AuthenticationFailureExceptionHandler());
		http.exceptionHandling().accessDeniedHandler(new CustomAccessDeniedHandler());

//		String[] restEndpointsToSecure = { "news" };
//		for (String endpoint : restEndpointsToSecure)
//		{
//			http.authorizeRequests().antMatchers("/" + endpoint + "/**").hasRole("student");
//		}

		SecurityConfigurer<DefaultSecurityFilterChain, HttpSecurity> securityConfigurerAdapter = 
				new XAuthTokenConfigurer(tutorService, studentService);
		http.apply(securityConfigurerAdapter);
	}

//	@Override
//	protected void configure(AuthenticationManagerBuilder authManagerBuilder)
//			throws Exception {
//		authManagerBuilder.userDetailsService(userDao);
//	}

//	@Bean
//	@Override
//	public UserDetailsService userDetailsServiceBean() throws Exception
//	{
//		return super.userDetailsServiceBean();
//	}
//
	@Bean
	@Override
	public AuthenticationManager authenticationManagerBean() throws Exception
	{
		return super.authenticationManagerBean();
	}
	
	@Bean
	public AuthenticationProvider customAuthenticationProvider()
	{
		return new CustomAuthenticationProvider();
	}
	
	@Bean
	public ClientSecretsConfiguration clientSecrets(){
		return new ClientSecretsConfiguration();
	}
	
	public static class ClientSecretsConfiguration {

		public final String facebook = "cf089bd02c738f447edf9c592bf26000";

		public final String google = "ozfVbZeEtCL_glmsd2nElrYw";

		public String getFacebook() {
			return facebook;
		}

		public String getGoogle() {
			return google;
		}
		
		public enum Provider {
			FACEBOOK("facebook"), GOOGLE("google"), LINKEDIN("linkedin"), GITHUB(
					"github"), FOURSQUARE("foursquare"), TWITTER("twitter"),
					PAID_STUDENT("paidStudent"), TRIAL_STUDENT("trialStudent");

			String name;

			Provider(final String name) {
				this.name = name;
			}

			public String getName() {
				return this.name;
			}
		}
	}
}