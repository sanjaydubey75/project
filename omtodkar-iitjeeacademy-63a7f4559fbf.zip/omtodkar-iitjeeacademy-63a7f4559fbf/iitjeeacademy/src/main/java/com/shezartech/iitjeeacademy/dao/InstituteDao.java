package com.shezartech.iitjeeacademy.dao;

import com.shezartech.iitjeeacademy.entity.InstituteEntity;

public interface InstituteDao extends Dao<InstituteEntity, Integer>{

	public InstituteEntity find(String email);
}