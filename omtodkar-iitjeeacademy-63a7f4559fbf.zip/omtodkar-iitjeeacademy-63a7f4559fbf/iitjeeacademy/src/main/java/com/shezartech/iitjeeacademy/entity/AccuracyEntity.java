package com.shezartech.iitjeeacademy.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * Created by shobhit on 3/26/2015.
 */
@Entity
@Table(name = "accuracy")
public class AccuracyEntity implements ModelEntity {

	@Id
	@ManyToOne
	private StudentEntity user;

	@Column(name = "accuracy", length = 1000, nullable = false)
	private String accuracy;

	@Id
	@ManyToOne
	@JoinColumn(name = "topic_id", referencedColumnName = "topic_id", nullable = false)
	private TopicEntity topicsByTopicId;

	public StudentEntity getUserId() {
		return user;
	}

	public void setUserId(StudentEntity userId) {
		this.user = userId;
	}

	public String getAccuracy() {
		return accuracy;
	}

	public void setAccuracy(String accuracy) {
		this.accuracy = accuracy;
	}

	public TopicEntity getTopicsByTopicId() {
		return topicsByTopicId;
	}

	public void setTopicsByTopicId(TopicEntity topicsByTopicId) {
		this.topicsByTopicId = topicsByTopicId;
	}
}
