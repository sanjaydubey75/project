package com.shezartech.iitjeeacademy.security;

import com.shezartech.iitjeeacademy.entity.StudentEntity;
import com.shezartech.iitjeeacademy.entity.TutorEntity;

public class UserAuthCookie {

	private String userName;
	
	private String userEmail;
	
	private String datestampcreated;
	
	private String type;
	
	public UserAuthCookie()
	{
		
	}
	
	public UserAuthCookie(StudentEntity student)
	{
		this.userEmail = student.getEmail();
		this.type = StudentEntity.Type;
		this.userName = student.getFirstName();
		this.datestampcreated = Long.toString((System.currentTimeMillis()/1000));
	}
	
	public UserAuthCookie(TutorEntity tutor)
	{
		this.userEmail = tutor.getEmail();
		this.type = TutorEntity.Type;
		this.userName = tutor.getName();
		this.datestampcreated = Long.toString((System.currentTimeMillis()/1000));
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getDatestampcreated() {
		return datestampcreated;
	}

	public void setDatestampcreated(String datestampcreated) {
		this.datestampcreated = datestampcreated;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
}