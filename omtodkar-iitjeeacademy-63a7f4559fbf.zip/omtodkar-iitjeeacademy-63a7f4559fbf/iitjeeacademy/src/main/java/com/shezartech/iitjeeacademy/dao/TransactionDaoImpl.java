package com.shezartech.iitjeeacademy.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.shezartech.iitjeeacademy.entity.TransactionsEntity;

@Repository
public class TransactionDaoImpl extends DaoImpl<TransactionsEntity, Integer> implements TransactionDao
{

	public TransactionDaoImpl(){
		super(TransactionsEntity.class);
	}
	
	@Override
	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		super.setSessionFactory(sessionFactory);
	}
}
