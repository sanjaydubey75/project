package com.shezartech.iitjeeacademy.dao;

import java.util.List;

import com.shezartech.iitjeeacademy.entity.QuestionEntity;

public interface QuestionDao extends Dao<QuestionEntity, String>{

	List<QuestionEntity> getAllQuestions(int level, String topicId);

}
