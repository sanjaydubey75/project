package com.shezartech.iitjeeacademy.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

public class Response {
	
	protected Status response;

	public Response() {
		super();
	}

	public void setResponse(Status status) {
		this.response = status;
	}

	@JsonInclude(Include.NON_NULL)
	public Status getResponse() {
		return response;
	}
}