package com.shezartech.iitjeeacademy.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.transaction.Transactional;

import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shezartech.iitjeeacademy.dao.TutorDao;
import com.shezartech.iitjeeacademy.entity.StudentEntity;
import com.shezartech.iitjeeacademy.entity.TutorEntity;
import com.shezartech.iitjeeacademy.model.PricingDao;
import com.shezartech.iitjeeacademy.response.tutor.TutorResponse;
import com.shezartech.iitjeeacademy.response.tutor.TutorResponse.FinancialSummary;
import com.shezartech.iitjeeacademy.response.tutor.TutorResponse.StudentInfo;

@Service
public class TutorServiceImpl implements TutorService
{

	@Autowired
	private TutorDao tutorDao;
	
	@Transactional
	@Override
	public Set<StudentEntity> getStudents(String email)
	{
		TutorEntity tutor = tutorDao.find(email);
		if(tutor != null)
			return tutor.getStudents();
		else
			return new HashSet<StudentEntity>();
	}
	
	@Transactional
	@Override
	public Set<StudentEntity> getStudents(String email, String targetYear)
	{
		TutorEntity tutor = tutorDao.find(email);
		if(tutor != null)
		{
			Set<StudentEntity> tempStudent = new HashSet<StudentEntity>();
			
			if(targetYear == null)
			{
				tempStudent = tutor.getStudents();
				Hibernate.initialize(tempStudent);
				return tempStudent;
			}
			else if(targetYear.equals("undefined"))
			{
				for(StudentEntity student : tutor.getStudents())
				{
					if(student.getTargetYear() == null)
						tempStudent.add(student);
				}
				return tempStudent;
			}
			else
			{
				for(StudentEntity student : tutor.getStudents())
				{
					if(targetYear.equals(student.getTargetYear()))
						tempStudent.add(student);
				}
				return tempStudent;
			}
		}
			
		else
			return new HashSet<StudentEntity>();
	}
	
	@Transactional
	@Override
	public TutorEntity findTutor(String email)
	{
		return tutorDao.find(email);
	}
	
	@Transactional
	@Override
	public List<StudentInfo> getStudentInformation(String email)
	{
		TutorEntity tutor = tutorDao.find(email);
		if(tutor != null)
		{
			List<StudentInfo> studentInfos = tutorDao.getStudentInfo(tutor);
			
			return studentInfos;
		}
		else
			return new ArrayList<TutorResponse.StudentInfo>();
	}
	
	@Override
	@Transactional
	public List<FinancialSummary> getFinancialSummaries(String email)
	{
		TutorEntity tutor = tutorDao.find(email);
		if(tutor != null)
		{
			Map<Integer, Integer> financialSummary = new HashMap<Integer, Integer>();
			
			PricingDao pricingDao = new PricingDao();
			
			for (StudentEntity student : tutor.getStudents())
			{
				Integer targetYear = student.getTargetYear();
				int amount = pricingDao.find(student.getSubscriptionModel()).getAmount();
				
				if(financialSummary.containsKey(targetYear))
				{
					financialSummary.put(targetYear, financialSummary.get(targetYear) + amount);
				}
				else
				{
					financialSummary.put(targetYear, amount);
				}
			}
			
			List<FinancialSummary> financialSummaries = new ArrayList<TutorResponse.FinancialSummary>();
			for(Map.Entry<Integer, Integer> entry : financialSummary.entrySet())
			{
				financialSummaries.add(new FinancialSummary(entry.getKey(), entry.getValue()));
			}
			return financialSummaries;
		}
		else
			return new ArrayList<FinancialSummary>();
	}
}
