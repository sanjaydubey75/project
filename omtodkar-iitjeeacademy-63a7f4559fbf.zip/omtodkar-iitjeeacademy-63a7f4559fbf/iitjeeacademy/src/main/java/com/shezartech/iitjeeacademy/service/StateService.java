package com.shezartech.iitjeeacademy.service;

import java.util.List;

import com.shezartech.iitjeeacademy.entity.StatewiseselectionEntity;

public interface StateService {

	List<StatewiseselectionEntity> getAllStates();

	StatewiseselectionEntity getState(int id);

}
