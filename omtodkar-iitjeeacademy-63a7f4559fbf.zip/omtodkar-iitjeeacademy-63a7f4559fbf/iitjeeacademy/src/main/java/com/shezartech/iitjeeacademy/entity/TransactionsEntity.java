package com.shezartech.iitjeeacademy.entity;

import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

/**
 * Created by shobhit on 3/26/2015.
 */
@Entity
@javax.persistence.Table(name = "transactions")
public class TransactionsEntity implements ModelEntity {

	@Id
	@javax.persistence.Column(name = "transactionId")
	@GeneratedValue
	private int transactionId;
	
	@javax.persistence.Column(name = "orderRefNumber", unique = true, nullable = true)
	private long orderRefNumber;
	
	@javax.persistence.Column(name = "invoiceNumber", unique = true, nullable = true)
	private long invoiceNumber;
	
	@javax.persistence.Column(name = "startTime", nullable = true)
	private Timestamp startTime;
	
	@javax.persistence.Column(name = "endTime", nullable = true)
	private Timestamp endTime;
	
	@javax.persistence.Column(name = "complete", nullable = true)
	private boolean complete;

	@javax.persistence.Column(name = "registrationComplete", nullable = true)
	private boolean registrationComplete;

	@javax.persistence.Column(name = "email", length = 200, nullable = true)
	private String email;

	@javax.persistence.Column(name = "firstName", length = 1000, nullable = true)
	private String firstName;

	@javax.persistence.Column(name = "lastName", length = 100, nullable = true)
	private String lastName;

	@javax.persistence.Column(name = "mobileNumber", length = 20, nullable = true)
	private String mobileNumber;

	@javax.persistence.Column(name = "amount", nullable = true)
	private int amount;

	@javax.persistence.Column(name = "subscriptionModel", length = 30, nullable = true)
	private int subscriptionModel;

	@javax.persistence.Column(name = "responseCode", nullable = true)
	private int responseCode;

	@javax.persistence.Column(name = "responseMessage", length = 50, nullable = true)
	private String responseMessage;

	@javax.persistence.Column(name = "EPGTransactionId", length= 20, nullable = true)
	private String epgTransactionId;

	@javax.persistence.Column(name = "authIdentityCode", nullable = true)
	private Integer authIdentityCode;

	@javax.persistence.Column(name = "RRN", length = 20, nullable = true)
	private String rrn;

	@javax.persistence.Column(name = "CVResponseCode", length = 5, nullable = true)
	private String cvResponseCode;

	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public long getOrderRefNumber() {
		return orderRefNumber;
	}

	public void setOrderRefNumber(long orderRefNumber) {
		this.orderRefNumber = orderRefNumber;
	}

	public long getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(long invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	
	public Timestamp getStartTime() {
		return startTime;
	}

	public void setStartTime(Timestamp startTime) {
		this.startTime = startTime;
	}

	public Timestamp getEndTime() {
		return endTime;
	}

	public void setEndTime(Timestamp endTime) {
		this.endTime = endTime;
	}

	public boolean getComplete() {
		return complete;
	}

	public void setComplete(boolean complete) {
		this.complete = complete;
	}

	public boolean getRegistrationComplete() {
		return registrationComplete;
	}

	public void setRegistrationComplete(boolean registrationComplete) {
		this.registrationComplete = registrationComplete;
	}

	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	
	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	
	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	
	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	
	public int getSubscriptionModel() {
		return subscriptionModel;
	}

	public void setSubscriptionModel(int subscriptionModel) {
		this.subscriptionModel = subscriptionModel;
	}

	
	public int getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(int responseCode) {
		this.responseCode = responseCode;
	}

	
	public String getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}

	
	public String getEpgTransactionId() {
		return epgTransactionId;
	}

	public void setEpgTransactionId(String epgTransactionId) {
		this.epgTransactionId = epgTransactionId;
	}

	
	public Integer getAuthIdentityCode() {
		return authIdentityCode;
	}

	public void setAuthIdentityCode(Integer authIdentityCode) {
		this.authIdentityCode = authIdentityCode;
	}

	
	public String getRrn() {
		return rrn;
	}

	public void setRrn(String rrn) {
		this.rrn = rrn;
	}

	
	public String getCvResponseCode() {
		return cvResponseCode;
	}

	public void setCvResponseCode(String cvResponseCode) {
		this.cvResponseCode = cvResponseCode;
	}
}
