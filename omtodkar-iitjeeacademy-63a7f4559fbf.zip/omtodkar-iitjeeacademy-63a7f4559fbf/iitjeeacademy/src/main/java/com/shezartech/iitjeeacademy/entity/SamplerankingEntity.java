package com.shezartech.iitjeeacademy.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Created by shobhit on 3/26/2015.
 */
@Entity
@Table(name = "sampleranking")
public class SamplerankingEntity implements ModelEntity
{
	@Id
    @GeneratedValue
    private int id;
	
	@Column(name = "marks", nullable = false)
    private int marks;
	
	@Column(name = "students", nullable = false)
    private int students;

    public int getId()
    {
        return id;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    public int getMarks()
    {
        return marks;
    }

    public void setMarks(int marks)
    {
        this.marks = marks;
    }

    public int getStudents()
    {
        return students;
    }

    public void setStudents(int students)
    {
        this.students = students;
    }
}