package com.shezartech.iitjeeacademy.service;

import java.util.Map;

import com.shezartech.iitjeeacademy.config.WebSecurityConfig.ClientSecretsConfiguration.Provider;
import com.shezartech.iitjeeacademy.entity.StudentEntity;
import com.shezartech.iitjeeacademy.entity.TutorEntity;

public interface RegisterService {

	void registerTutor(TutorEntity tutor);

	boolean isEmailValidForTutor(String email);

	StudentEntity registerStudent(Map<String, Object> studentMap,
			Provider provider);

}
