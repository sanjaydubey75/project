package com.shezartech.iitjeeacademy.dao;

import com.shezartech.iitjeeacademy.entity.SubjectEntity;

public interface SubjectDao extends Dao<SubjectEntity, String>
{

}
