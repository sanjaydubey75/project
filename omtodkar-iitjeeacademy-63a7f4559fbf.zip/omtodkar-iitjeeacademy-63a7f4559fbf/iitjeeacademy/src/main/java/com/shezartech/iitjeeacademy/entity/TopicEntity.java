package com.shezartech.iitjeeacademy.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.validator.constraints.Length;

/**
 * @ORM\Entity
 * @ORM\Table(name="topics")
 */
@Entity
@Table(name = "topics")
public class TopicEntity implements ModelEntity{

	@Id
	@Length(max = 50)
	@Column(name = "topic_id", length = 50)
    private String id;

	@Length(max = 500)
	@Column(name = "name", length = 500, nullable = false)
    private String name;
    
	@Length(max = 1000)
	@Column(length = 1000, name = "info", nullable = false)
    private String info;
    
	@ManyToOne(targetEntity = SubjectEntity.class)
	@JoinColumn(name = "subject_id", referencedColumnName = "subject_id", nullable = false)
	private SubjectEntity subject;

	private int order;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	public SubjectEntity getSubject() {
		return subject;
	}

	public void setSubject(SubjectEntity subject) {
		this.subject = subject;
	}

	public int getOrder() {
		return order;
	}

	public void setOrder(int order) {
		this.order = order;
	}
}
