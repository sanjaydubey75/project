package com.shezartech.iitjeeacademy.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.shezartech.iitjeeacademy.entity.SubjectEntity;
import com.shezartech.iitjeeacademy.entity.TopicEntity;

@Repository
public class TopicDaoImpl extends DaoImpl<TopicEntity, String> implements TopicDao{

	@Override
	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		super.setSessionFactory(sessionFactory);
	}
	
	public TopicDaoImpl() {
		super(TopicEntity.class);
	}
	
	@Override
	public List<TopicEntity> findAll(SubjectEntity subject)
	{
		Criteria criteria = getCurrentSession().createCriteria(entityClass);
		criteria.add(Restrictions.eq("subject", subject));
		return criteria.list();
	}

}
