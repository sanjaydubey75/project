package com.shezartech.iitjeeacademy.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIdentityReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

/**
 * Created by shobhit on 3/26/2015.
 */
@Entity
@Table(name = "subjectglobalranks")
public class SubjectglobalranksEntity implements ModelEntity {

	@Id
	@ManyToOne
	@JsonIgnore // so that when returning a collection of globalranks for a user, 
	// we don't really need this
	private StudentEntity user;

	@Column(name = "rank", nullable = false)
	private int rank;

	@Id
	@ManyToOne
	@JoinColumn(name = "subjectId", referencedColumnName = "subject_id", nullable = false)
	@JsonIdentityReference(alwaysAsId = true)
	@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
	private SubjectEntity subject;

	public StudentEntity getUser() {
		return user;
	}

	public void setUser(StudentEntity userId) {
		this.user = userId;
	}

	public int getRank() {
		return rank;
	}

	public void setRank(int rank) {
		this.rank = rank;
	}

	public SubjectEntity getSubject() {
		return subject;
	}

	public void setSubject(SubjectEntity subjectId) {
		this.subject = subjectId;
	}
}
