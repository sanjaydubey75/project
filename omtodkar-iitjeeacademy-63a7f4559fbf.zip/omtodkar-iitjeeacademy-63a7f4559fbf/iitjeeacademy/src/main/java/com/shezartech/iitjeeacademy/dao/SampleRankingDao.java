package com.shezartech.iitjeeacademy.dao;

import com.shezartech.iitjeeacademy.entity.SamplerankingEntity;

public interface SampleRankingDao extends Dao<SamplerankingEntity, Integer>
{

}
