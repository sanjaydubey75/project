package com.shezartech.iitjeeacademy.entity;

import java.util.Collection;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.validator.constraints.Length;

/**
 * Created by shobhit on 3/26/2015.
 */
@Entity
@Table(name = "institute")
public class InstituteEntity implements ModelEntity{
	
	@Id
	@GeneratedValue
    @Column(name = "id")
    private int id;
	
	@Column(name = "name", unique = true, nullable = false)
    private String name;
	
	@Length(max = 255)
	@Column(nullable = false)
	private String email;
	
	@OneToMany(mappedBy = "instituteId")
    private Collection<CouponCodeEntity> institutecouponcodesById;

    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    public Collection<CouponCodeEntity> getInstitutecouponcodesById() {
        return institutecouponcodesById;
    }

    public void setInstitutecouponcodesById(Collection<CouponCodeEntity> institutecouponcodesById) {
        this.institutecouponcodesById = institutecouponcodesById;
    }
}
