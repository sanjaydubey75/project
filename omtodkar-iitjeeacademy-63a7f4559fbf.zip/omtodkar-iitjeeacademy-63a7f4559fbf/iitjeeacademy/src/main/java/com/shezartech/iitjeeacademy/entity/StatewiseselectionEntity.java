package com.shezartech.iitjeeacademy.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Created by shobhit on 3/26/2015.
 */
@Entity
@Table(name = "statewiseselection")
public class StatewiseselectionEntity implements ModelEntity{
	
	@Id
    @Column(name = "id")
	@GeneratedValue
    private int id;
	
	@Column(name = "name", length = 100, unique = true, nullable = false)
	private String name;
	
	@Column(name = "percentageSelected", nullable = false)
    private double percentageSelected;

    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    
    
    public double getPercentageSelected() {
        return percentageSelected;
    }

    public void setPercentageSelected(double percentageSelected) {
        this.percentageSelected = percentageSelected;
    }
}
