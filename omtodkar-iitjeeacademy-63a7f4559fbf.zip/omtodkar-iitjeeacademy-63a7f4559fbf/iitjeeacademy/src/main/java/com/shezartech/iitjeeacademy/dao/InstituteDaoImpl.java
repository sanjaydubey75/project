package com.shezartech.iitjeeacademy.dao;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.shezartech.iitjeeacademy.entity.InstituteEntity;

@Repository
public class InstituteDaoImpl extends DaoImpl<InstituteEntity, Integer> implements InstituteDao {

	public InstituteDaoImpl(){
		super(InstituteEntity.class);
	}
	
	@Override
	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		super.setSessionFactory(sessionFactory);
	}

	@Override
	public InstituteEntity find(String email) {
		
		Criteria criteria = getCurrentSession().createCriteria(InstituteEntity.class);
		criteria.add(Restrictions.eq("email", email));
		return (InstituteEntity) criteria.uniqueResult();
	}
}
