package com.shezartech.iitjeeacademy.entity;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by shobhit on 3/26/2015.
 */
@Entity
@Table(name = "tutor")
public class TutorEntity implements ModelEntity, UserDetails
{
	
	public static final String Type = "tutor";
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@Length(max=255)
	@Column(name = "name", nullable = false)
	@NotNull
	private String name;

	@Email
	@Length(max=255)
	@NotNull
	@Column(name = "Email", nullable = false)
	private String email;

	@Length(max=255)
	@NotNull
	@Column(name = "Password", nullable = false)
	@JsonIgnore
	private String password;
	
	@Length(max = 20)
	@NotNull
	@Column(nullable = false)
	private String mobileNumber;
	
	@Column(length = 1000)
	private String address;
	
	@JsonIgnore
	@OneToMany
	@JoinTable(
			name = "tutortostudent",
			joinColumns = @JoinColumn(name = "tutor"),
			inverseJoinColumns = @JoinColumn(name = "student")
	)
	@Cascade({CascadeType.ALL})
	private Set<StudentEntity> students = new HashSet<StudentEntity>();
	
	@Transient
	private Set<GrantedAuthority> authorities = new HashSet<GrantedAuthority>();

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@JsonIgnore
	public String getPassword() {
		return password;
	}

	@JsonProperty
	public void setPassword(String password) {
		this.password = password;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Set<StudentEntity> getStudents() {
		return students;
	}

	public void setStudents(Set<StudentEntity> students) {
		this.students = students;
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities()
	{
		// setup roles
		Set<String> roles = new HashSet<String>();
		roles.addAll(Arrays.<String> asList(new String(TutorEntity.Type)));

		// export them as part of authorities
		for (String r : roles)
		{
			authorities.add(new SimpleGrantedAuthority(role(r)));
		}
		return this.authorities;
	}
	
	private String role(String i)
	{
		return "ROLE_" + i;
	}

	@Override
	public String getUsername()
	{
		return this.getEmail();
	}

	@Override
	public boolean isAccountNonExpired()
	{
		return true;
	}

	@Override
	public boolean isAccountNonLocked()
	{
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired()
	{
		return true;
	}

	@Override
	public boolean isEnabled()
	{
		return true;
	}
}