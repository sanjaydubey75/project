package com.shezartech.iitjeeacademy.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.shezartech.iitjeeacademy.entity.StatewiseselectionEntity;

@Repository
public class StateDaoImpl extends DaoImpl<StatewiseselectionEntity, Integer>
	implements StateDao
{

	@Override
	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		super.setSessionFactory(sessionFactory);
	} 
	
	public StateDaoImpl()
	{
		super(StatewiseselectionEntity.class);
	}
}
