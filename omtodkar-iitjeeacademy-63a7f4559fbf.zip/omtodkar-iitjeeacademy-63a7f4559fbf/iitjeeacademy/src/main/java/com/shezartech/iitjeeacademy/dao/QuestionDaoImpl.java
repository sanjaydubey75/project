package com.shezartech.iitjeeacademy.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.shezartech.iitjeeacademy.entity.QuestionEntity;

@Repository
public class QuestionDaoImpl extends DaoImpl<QuestionEntity, String> implements QuestionDao{

	@Override
	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		super.setSessionFactory(sessionFactory);
	} 
	
	public QuestionDaoImpl() {
		super(QuestionEntity.class);
	}
	
	@Override
	public List<QuestionEntity> getAllQuestions(int level, String topicId){
		Criteria criteria = getCurrentSession().createCriteria(QuestionEntity.class);
		criteria.add(Restrictions.eq("topic.id", topicId));
		criteria.add(Restrictions.eq("level", level));
		return criteria.list();
	}

}
