package com.shezartech.iitjeeacademy.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shezartech.iitjeeacademy.dao.TopicDao;
import com.shezartech.iitjeeacademy.entity.TopicEntity;

@Service
public class TopicServiceImpl implements TopicService
{

	@Autowired
	private TopicDao topicDao;
	
	@Transactional
	@Override
	public List<TopicEntity> getTopics(String subjectId)
	{
		return filter(topicDao.findAll(), subjectId);
	}
	
	private List<TopicEntity> filter(List<TopicEntity> topics, String subjectId)
	{
		if(subjectId == null)
			return topics;
		
		List<TopicEntity> temp = new ArrayList<TopicEntity>();
		for(TopicEntity topic: topics)
		{
			if(topic.getSubject().getId().equals(subjectId))
				temp.add(topic);
		}
		return temp;
	}
	
	@Transactional
	@Override
	public TopicEntity getTopic(String id)
	{
		return topicDao.find(id);
	}
}
