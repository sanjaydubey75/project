package com.shezartech.iitjeeacademy.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.shezartech.iitjeeacademy.entity.SubjectEntity;

@Repository
public class SubjectDaoImpl extends DaoImpl<SubjectEntity, String> implements SubjectDao{

	@Override
	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		super.setSessionFactory(sessionFactory);
	} 
	
	public SubjectDaoImpl() {
		super(SubjectEntity.class);
	}

}
