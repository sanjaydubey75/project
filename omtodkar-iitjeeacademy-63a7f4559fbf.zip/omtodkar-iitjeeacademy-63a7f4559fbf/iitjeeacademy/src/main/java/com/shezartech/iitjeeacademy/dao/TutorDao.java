package com.shezartech.iitjeeacademy.dao;

import java.util.List;

import com.shezartech.iitjeeacademy.entity.TutorEntity;
import com.shezartech.iitjeeacademy.response.tutor.TutorResponse.StudentInfo;

public interface TutorDao extends Dao<TutorEntity, Integer>{

	public TutorEntity find(String email);

	List<StudentInfo> getStudentInfo(TutorEntity tutor);
}