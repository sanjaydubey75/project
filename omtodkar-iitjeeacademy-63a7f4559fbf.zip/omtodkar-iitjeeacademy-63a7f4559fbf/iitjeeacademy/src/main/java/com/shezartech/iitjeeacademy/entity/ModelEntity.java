package com.shezartech.iitjeeacademy.entity;

import java.io.Serializable;

public interface ModelEntity extends Serializable
{

}

