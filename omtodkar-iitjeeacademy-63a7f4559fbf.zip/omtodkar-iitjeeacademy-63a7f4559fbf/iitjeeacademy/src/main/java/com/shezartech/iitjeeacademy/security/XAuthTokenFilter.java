package com.shezartech.iitjeeacademy.security;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidParameterSpecException;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.filter.GenericFilterBean;

import com.google.gson.Gson;
import com.shezartech.iitjeeacademy.entity.StudentEntity;
import com.shezartech.iitjeeacademy.entity.TutorEntity;
import com.shezartech.iitjeeacademy.exception.InvalidMacException;
import com.shezartech.iitjeeacademy.exception.NullCookieException;
import com.shezartech.iitjeeacademy.service.StudentService;
import com.shezartech.iitjeeacademy.service.TutorService;

public class XAuthTokenFilter extends GenericFilterBean
{
	private TutorService tutorService;
	
	private StudentService studentService;

	private String xAuthTokenHeaderName = "auth-token";

	public XAuthTokenFilter(TutorService tutorService,
			StudentService studentService)
	{
		super();
		this.tutorService = tutorService;
		this.studentService = studentService;
	}

	@Override
	public void doFilter(ServletRequest arg0, ServletResponse arg1, FilterChain filterChain)
			throws IOException, ServletException
	{
		try
		{
			HttpServletRequest httpServletRequest = (HttpServletRequest) arg0;
			HttpServletResponse httpServletResponse = (HttpServletResponse) arg1;
			UserDetails details = getUserDetails(httpServletRequest, httpServletResponse);

			if (details != null)
			{
				UsernamePasswordAuthenticationToken token = 
						new UsernamePasswordAuthenticationToken(details, details.getPassword(), details.getAuthorities());
				SecurityContextHolder.getContext().setAuthentication(token);
			}
			filterChain.doFilter(arg0, arg1);
		}
		catch (Exception ex)
		{
			throw new RuntimeException(ex);
		}
	}
	
	public UserDetails getUserDetails(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse)
	{
		UserAuthCookie userAuthCookie = getAuthCookie(httpServletRequest);
		if (checkAuthToken(userAuthCookie))
		{
			UserDetails userDetails = null;
			if(userAuthCookie.getType().equals(StudentEntity.Type))
			{
				userDetails = studentService.findStudent(userAuthCookie.getUserEmail());
			}
			else if(userAuthCookie.getType().equals(TutorEntity.Type))
			{
				userDetails = tutorService.findTutor(userAuthCookie.getUserEmail());
			}
			
			if(userDetails != null)
				extendTokenValidity(httpServletResponse,  userAuthCookie);
			return userDetails;
		}
		
		return null;
	}
	
	private void extendTokenValidity(HttpServletResponse httpServletResponse, UserAuthCookie userAuthCookie)
	{
		userAuthCookie.setDatestampcreated(Long.toString((System.currentTimeMillis()/1000)));
		Gson gson = new Gson();
		String cookieValue = gson.toJson(userAuthCookie);
		Encrypter encrypter = new Encrypter();
		
			try
			{
				String cookieValueEncrypted = encrypter.encrypt(cookieValue);
				String cookieValueEncoded = URLEncoder.encode(cookieValueEncrypted, "UTF-8");
				Cookie cookie = new Cookie("auth-token", cookieValueEncoded);
				System.out.println(cookieValueEncrypted);
				cookie.setPath("/");
				cookie.setMaxAge(3600);
				cookie.setSecure(true);
				cookie.setHttpOnly(false); // so that the client just deletes this cookie on logout
				httpServletResponse.addCookie(cookie);
			}
			catch (InvalidKeyException | NoSuchAlgorithmException	| NoSuchPaddingException | InvalidParameterSpecException
					| IllegalBlockSizeException | BadPaddingException | InvalidAlgorithmParameterException
					| UnsupportedEncodingException e)
			{
				e.printStackTrace();
			}
		
	}
	
	private UserAuthCookie getAuthCookie(HttpServletRequest httpServletRequest)
	{
		Cookie[] cookies = httpServletRequest.getCookies();

		if(cookies != null){
			for (Cookie c:cookies)
			{
				if(c.getName().equals(this.xAuthTokenHeaderName))
				{
					Encrypter encrypter = new Encrypter();
					try
					{
						String decodedValue = URLDecoder.decode(c.getValue(), "UTF-8");
						String cookie = encrypter.decrypt(decodedValue);
						if(cookie == null) return null;
						Gson gson = new Gson();
						UserAuthCookie authCookie = gson.fromJson(cookie, UserAuthCookie.class);
						return authCookie;
						
					}
					catch (InvalidKeyException | NoSuchAlgorithmException | UnsupportedEncodingException | NoSuchPaddingException
							| InvalidAlgorithmParameterException | IllegalBlockSizeException | BadPaddingException
							| NullCookieException | InvalidMacException e)
					{

						e.printStackTrace();
					}
				}
			}
		}
		return null;
	}
	
	private boolean checkAuthToken(UserAuthCookie authCookie)
	{
		if(authCookie == null) return false;
		if((System.currentTimeMillis()/1000) -  Long.parseLong(authCookie.getDatestampcreated()) > 3600)
		{
			return false;
		}
		return true;
	}

}