package com.shezartech.iitjeeacademy.security;

import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidParameterSpecException;
import java.util.Arrays;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.Mac;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.Hex;

import com.google.gson.Gson;
import com.shezartech.iitjeeacademy.exception.InvalidMacException;
import com.shezartech.iitjeeacademy.exception.NullCookieException;

public class Encrypter {

	protected String key;

	protected String cipher = "MCRYPT_RIJNDAEL_128";

	protected String mode = "MCRYPT_MODE_CBC";

	protected int block = 16;

	public Encrypter() {
		this.key = "VXSBURAW1NUsuvDw2zz3zJTqwXoC3ZWI";
	}

	public String encrypt(String value) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, InvalidParameterSpecException,
			IllegalBlockSizeException, BadPaddingException, InvalidAlgorithmParameterException, UnsupportedEncodingException {

		// byte[] sessionKey = null; //Where you get this from is beyond the
		// scope of this post
		// byte[] iv = null ; //Ditto
		// byte[] plaintext = null; //Whatever you want to encrypt/decrypt

		Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding");
		// You can use ENCRYPT_MODE or DECRYPT_MODE

		cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(this.key.getBytes(), "AES"));
		IvParameterSpec spec = cipher.getParameters().getParameterSpec(IvParameterSpec.class);
		byte[] iv = spec.getIV();
		String ivString = Base64.encodeBase64String(iv);

		// cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(this.key.getBytes(), "AES"), new IvParameterSpec(iv));
		// byte[] ciphertext = cipher.doFinal(plaintext);

		// $iv = mcrypt_create_iv(this.getIvSize(), this.getRandomizer());
		//
		// $value = base64_encode($this->padAndMcrypt($value, $iv));
		byte[] ciphertext = this.padAndMcrypt(value, cipher);
		String ciphertextString = Base64.encodeBase64String(ciphertext);

		// Once we have the encrypted value we will go ahead base64_encode the
		// input vector and create the MAC for the encrypted value so we can verify
		// its authenticity. Then, we'll JSON encode the data in a "payload" array.
		// $mac = $this->hash($iv = base64_encode($iv), $value);
		String mac = this.hash(ivString, ciphertextString);
		
		AuthCookie authCookie = new AuthCookie();
		authCookie.setIv(ivString);
		authCookie.setMac(mac);
		authCookie.setValue(ciphertextString);
		
		Gson gson = new Gson();
		String jsonEncode = gson.toJson(authCookie, AuthCookie.class);
		String base64Encoded = Base64.encodeBase64String(jsonEncode.getBytes());
		//
		// return base64_encode(json_encode(compact('iv', 'value', 'mac')));
		return base64Encoded;

		// all useless
		// String iv1 = "c05ocTR1UFRWWEJvK1c0TURmNXFBdz09";
		// cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(this.key.getBytes(), "AES"), new IvParameterSpec(iv1.getBytes()));
		// byte[] a = cipher.doFinal(value.getBytes());
		// return new String(org.springframework.security.crypto.codec.Base64.encode(a));
	}

	/**
	 * Pad and use mcrypt on the given value and input vector.
	 *
	 * @param string $value
	 * @param string $iv
	 * @return string
	 * @throws BadPaddingException 
	 * @throws IllegalBlockSizeException 
	 */
	protected byte[] padAndMcrypt(String value, Cipher cipher) throws IllegalBlockSizeException, BadPaddingException {
		String value1 = this.addPadding(this.serialize(value));
		byte[] ciphertext = cipher.doFinal(value1.getBytes());
		// String value = $this->addPadding(serialize($value));
		//
		// return mcrypt_encrypt($this->cipher, $this->key, $value, $this->mode, $iv);
		return ciphertext;
	}

	/**
	 * Decrypt the given value.
	 *
	 * @param string $payload
	 * @return string
	 * @throws InvalidMacException 
	 * @throws NullCookieException 
	 * @throws UnsupportedEncodingException 
	 * @throws NoSuchAlgorithmException 
	 * @throws InvalidKeyException 
	 * @throws BadPaddingException 
	 * @throws IllegalBlockSizeException 
	 * @throws InvalidAlgorithmParameterException 
	 * @throws NoSuchPaddingException 
	 * @throws Exception 
	 */
	public String decrypt(String payload) throws InvalidKeyException, NoSuchAlgorithmException, UnsupportedEncodingException, NullCookieException, InvalidMacException, NoSuchPaddingException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
		// $payload = $this->getJsonPayload($payload);
		AuthCookie authCookie = this.getJsonPayload(payload);
		//
		// We'll go ahead and remove the PKCS7 padding from the encrypted
		// value before we decrypt it. Once we have the de-padded value, we will grab the vector
		// and decrypt the data, passing back the unserialized from of the value.
		// $value = base64_decode($payload['value']);
		//byte[] value = DatatypeConverter.parseBase64Binary(authCookie.getValue());
		byte[] value = Base64.decodeBase64(authCookie.getValue());

		// $iv = base64_decode($payload['iv']);
		//byte[] iv = DatatypeConverter.parseBase64Binary(authCookie.getIv());
		byte[] iv = Base64.decodeBase64(authCookie.getIv());
		//
		String decryptedText = this.mcryptDecrypt(value, iv);
		String removepadding = this.stripPadding(decryptedText);
		
		SerializedPhpParser serializedPhpParser = new SerializedPhpParser(removepadding);
		String result = (String) serializedPhpParser.parse();
		return result;
		// return unserialize($this->stripPadding($this->mcryptDecrypt($value, $iv)));
	}

	/**
	 * Run the mcrypt decryption routine for the value.
	 *
	 * @param string $value
	 * @param string $iv
	 * @return string
	 * @throws NoSuchPaddingException 
	 * @throws NoSuchAlgorithmException 
	 * @throws InvalidKeyException 
	 * @throws InvalidAlgorithmParameterException 
	 * @throws BadPaddingException 
	 * @throws IllegalBlockSizeException 
	 *
	 * @throws \Exception
	 */
	protected String mcryptDecrypt(byte[] value, byte[] iv) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
		Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding");
		
		SecretKeySpec secretKeySpecy = new SecretKeySpec(this.key.getBytes(), "AES");
		IvParameterSpec ivParameterSpec = new IvParameterSpec(iv);
		
		cipher.init(Cipher.DECRYPT_MODE, secretKeySpecy, ivParameterSpec);
		byte[] result = cipher.doFinal(value);
		return new String(result);
		// try
		// {
		// return mcrypt_decrypt($this->cipher, $this->key, $value, $this->mode, $iv);
		// }
		// catch (\Exception $e)
		// {
		// throw new DecryptException($e->getMessage());
		// }
	}

	/**
	 * Get the JSON array from the given payload.
	 *
	 * @param string $payload
	 * @return array
	 * @throws NullCookieException 
	 * @throws InvalidMacException 
	 * @throws UnsupportedEncodingException 
	 * @throws NoSuchAlgorithmException 
	 * @throws InvalidKeyException 
	 * @throws \Illuminate\Encryption\DecryptException
	 */
	protected AuthCookie getJsonPayload(String $payload) throws NullCookieException, InvalidMacException, InvalidKeyException, NoSuchAlgorithmException, UnsupportedEncodingException {
//		byte[] bytes = DatatypeConverter.parseBase64Binary($payload);
//		String payload = new String(bytes, "UTF-8");
		String payload = new String(Base64.decodeBase64($payload));
		Gson gson = new Gson();
		AuthCookie authCookie = gson.fromJson(payload, AuthCookie.class);

		// $payload = json_decode(base64_decode($payload), true);
		//
		// // If the payload is not valid JSON or does not have the proper keys set we will
		// // assume it is invalid and bail out of the routine since we will not be able
		// // to decrypt the given value. We'll also check the MAC for this encryption.
		if (authCookie == null || this.invalidPayload(authCookie)) {
			throw new NullCookieException();
		}
		if(!this.validMac(authCookie)){
			throw new InvalidMacException();
		}
		// if ( ! $payload || $this->invalidPayload($payload))
		// {
		// throw new DecryptException('Invalid data.');
		// }
		//
		// if ( ! $this->validMac($payload))
		// {
		// throw new DecryptException('MAC is invalid.');
		// }
		//
		// return $payload;
		return authCookie;
	}

	/**
	 * Determine if the MAC for the given payload is valid.
	 *
	 * @param array $payload
	 * @return bool
	 * @throws UnsupportedEncodingException 
	 * @throws NoSuchAlgorithmException 
	 * @throws InvalidKeyException 
	 *
	 * @throws \RuntimeException
	 */
	protected boolean validMac(AuthCookie authCookie) throws InvalidKeyException, NoSuchAlgorithmException, UnsupportedEncodingException {
		// if ( ! function_exists('openssl_random_pseudo_bytes'))
		// {
		// throw new \RuntimeException('OpenSSL extension is required.');
		// }
		SecureRandom random = new SecureRandom();
		byte bytes[] = new byte[16];
		random.nextBytes(bytes);
		
		byte[] calcMac = this.hashMacRaw("HmacSHA256", this.hash(authCookie.getIv(), authCookie.getValue()), new String(bytes));
		byte[] calcMac1 = this.hashMacRaw("HmacSHA256", authCookie.getMac(), new String(bytes));
		return Arrays.equals(calcMac, calcMac1);
		
		//
		// $bytes = (new SecureRandom)->nextBytes(16);
		//
		// $calcMac = hash_hmac('sha256', $this->hash($payload['iv'], $payload['value']), $bytes, true);
		//
		// return StringUtils::equals(hash_hmac('sha256', $payload['mac'], $bytes, true), $calcMac);
	}

	/**
	 * Create a MAC for the given value.
	 *
	 * @param string $iv
	 * @param string $value
	 * @return string
	 * @throws NoSuchAlgorithmException
	 * @throws InvalidKeyException
	 * @throws UnsupportedEncodingException
	 */
	// this is verified
	protected String hash(String iv, String value) throws NoSuchAlgorithmException, InvalidKeyException, UnsupportedEncodingException {
		// return hash_hmac('sha256', $iv.$value, $this->key);
		return this.hashMac("HmacSHA256", iv + value, this.key);
	}

	private String hashMac(String algorithm, String value, String key) throws NoSuchAlgorithmException, InvalidKeyException, UnsupportedEncodingException {

		// Get an hmac_sha1 Mac instance and initialize with the signing key
		Mac mac = Mac.getInstance(algorithm);
		mac.init(new SecretKeySpec(key.getBytes(), algorithm));

		// Compute the hmac on input data bytes
		byte[] rawHmac = mac.doFinal((value).getBytes());

		// Convert raw bytes to Hex
		byte[] hexBytes = new Hex().encode(rawHmac);

		// Covert array of Hex bytes to a String
		return new String(hexBytes, "UTF-8");
	}
	
	private byte[] hashMacRaw(String algorithm, String value, String key) throws NoSuchAlgorithmException, InvalidKeyException, UnsupportedEncodingException {

		// Get an hmac_sha1 Mac instance and initialize with the signing key
		Mac mac = Mac.getInstance(algorithm);
		mac.init(new SecretKeySpec(key.getBytes(), algorithm));

		// Compute the hmac on input data bytes
		byte[] rawHmac = mac.doFinal((value).getBytes());

		return rawHmac;
	}

	/**
	 * Add PKCS7 padding to a given value.
	 *
	 * @param string $value
	 * @return string
	 */
	protected String addPadding(String value) {
		int pad = this.block - (value.length() % this.block);
		// $pad = $this->block - (strlen($value) % $this->block);
		//
		//String temp1 = new String(new char[pad]).replace("\0", temp);
		//str_repeat(substr($value, -1), $pad)
		String temp = new String(new char[pad]).replace('\0', (char)pad);
		return value + temp;
		// return $value.str_repeat(chr($pad), $pad);
	}

	/**
	 * Remove the padding from the given value.
	 *
	 * @param string $value
	 * @return string
	 */
	protected String stripPadding(String value) {
		int pad = (int)value.charAt(value.length() - 1);
		return this.paddingIsValid(pad, value) ? value.substring(0, value.length() - pad) : value;
//		return value.substring(0, value.length() - pad);
		// $pad = ord($value[($len = strlen($value)) - 1]);
		//
		// return $this->paddingIsValid($pad, $value) ? substr($value, 0, $len - $pad) : $value;
	}

	/**
	 * Determine if the given padding for a value is valid.
	 *
	 * @param string $pad
	 * @param string $value
	 * @return bool
	 */
	protected boolean paddingIsValid(int pad, String value) {
		int beforePad = value.length() - pad;
		String temp = value.substring(value.length() - 2, value.length() - 1);
		String temp1 = new String(new char[pad]).replace("\0", temp);
		return value.substring(beforePad).equals(temp1);
		// $beforePad = strlen($value) - $pad;
		//
		// return substr($value, $beforePad) == str_repeat(substr($value, -1), $pad);
	}

	/**
	 * Verify that the encryption payload is valid.
	 *
	 * @param array |mixed $data
	 * @return bool
	 */
	protected boolean invalidPayload(AuthCookie authCookie) {
		return (authCookie.getClass() == null) || (authCookie.getMac() == null) || (authCookie.getValue() == null);
		// return ! is_array($data) || ! isset($data['iv']) || !
		// isset($data['value']) || ! isset($data['mac']);
	}

	protected int getIvSize() {
		return 16;
	}

	/**
	 * Get the random data source available for the OS.
	 */
	protected void getRandomizer() {
		// return MCRYPT_DEV_URANDOM;
	}

	/**
	 * Set the encryption key.
	 *
	 * @param string $key
	 * @return void
	 */
	public void setKey(String $key) {
		// $this->key = (string) $key;
	}

	/**
	 * Set the encryption cipher.
	 *
	 * @param string $cipher
	 * @return void
	 */
	public void setCipher(String $cipher) {
		// $this->cipher = $cipher;
		//
		// $this->updateBlockSize();
	}

	/**
	 * Set the encryption mode.
	 *
	 * @param string $mode
	 * @return void
	 */
	public void setMode(String $mode) {
		// $this->mode = $mode;
		//
		// $this->updateBlockSize();
	}

	/**
	 * Update the block size for the current cipher and mode.
	 *
	 * @return void
	 */
	protected void updateBlockSize() {
		// $this->block = mcrypt_get_iv_size($this->cipher, $this->mode);
	}

	private String serialize(String value){
		int size = value.length();
		String serializedString = "s:"+size+":\""+value+"\";";
		return serializedString;
	}
}