package com.shezartech.iitjeeacademy.dao;

import java.util.List;

import com.shezartech.iitjeeacademy.entity.SubjectEntity;
import com.shezartech.iitjeeacademy.entity.TopicEntity;

public interface TopicDao extends Dao<TopicEntity, String>{

	List<TopicEntity> findAll(SubjectEntity subject);

}
