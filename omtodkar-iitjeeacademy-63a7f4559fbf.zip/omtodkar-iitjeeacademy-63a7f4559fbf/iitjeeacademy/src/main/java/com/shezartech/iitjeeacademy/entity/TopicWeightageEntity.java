package com.shezartech.iitjeeacademy.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * Created by shobhit on 3/26/2015.
 */
@Entity
@Table(name = "topicweightage")
public class TopicWeightageEntity implements ModelEntity {

	@Id
	@GeneratedValue
	private Integer id;

	@Column(name = "name", length = 500, nullable = false)
	private String name;

	@Column(name = "subjectWeightage", nullable = true)
	private Double subjectWeightage;

	@Column(name = "globalWeightage", nullable = true)
	private Double globalWeightage;

	@OneToOne
	@JoinColumn(name = "topic_id", referencedColumnName = "topic_id", nullable = false, unique = true)
	private TopicEntity topicsByTopicId;

	@ManyToOne
	@JoinColumn(name = "subject_id", referencedColumnName = "subject_id", nullable = false, unique = false)
	private SubjectEntity subjectsBySubjectId;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Double getSubjectWeightage() {
		return subjectWeightage;
	}

	public void setSubjectWeightage(Double subjectWeightage) {
		this.subjectWeightage = subjectWeightage;
	}

	public Double getGlobalWeightage() {
		return globalWeightage;
	}

	public void setGlobalWeightage(Double globalWeightage) {
		this.globalWeightage = globalWeightage;
	}

	public TopicEntity getTopicsByTopicId() {
		return topicsByTopicId;
	}

	public void setTopicsByTopicId(TopicEntity topicsByTopicId) {
		this.topicsByTopicId = topicsByTopicId;
	}

	public SubjectEntity getSubjectsBySubjectId() {
		return subjectsBySubjectId;
	}

	public void setSubjectsBySubjectId(SubjectEntity subjectsBySubjectId) {
		this.subjectsBySubjectId = subjectsBySubjectId;
	}
}
