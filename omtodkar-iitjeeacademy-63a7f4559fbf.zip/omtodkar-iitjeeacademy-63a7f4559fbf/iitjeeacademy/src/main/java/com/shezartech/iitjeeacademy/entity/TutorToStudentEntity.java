package com.shezartech.iitjeeacademy.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "tutortostudent")
public class TutorToStudentEntity implements ModelEntity
{

	@Id
	@ManyToOne
	@JoinColumn(name = "tutor")
	private TutorEntity tutor;

	@Id
	@ManyToOne
	@JoinColumn(name = "student")
	private StudentEntity student;

	public TutorEntity getTutor()
	{
		return tutor;
	}

	public void setTutor(TutorEntity tutor)
	{
		this.tutor = tutor;
	}

	public StudentEntity getStudent()
	{
		return student;
	}

	public void setStudent(StudentEntity student)
	{
		this.student = student;
	}
}