package com.shezartech.iitjeeacademy.security;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.mindrot.jbcrypt.BCrypt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

import com.shezartech.iitjeeacademy.entity.StudentEntity;
import com.shezartech.iitjeeacademy.entity.TutorEntity;
import com.shezartech.iitjeeacademy.service.StudentService;
import com.shezartech.iitjeeacademy.service.TutorService;

public class CustomAuthenticationProvider implements AuthenticationProvider
{
	@Autowired
	private HttpServletResponse httpServletResponse;
	
	@Autowired
	private HttpServletRequest httpServletRequest;
	
	@Autowired
	private StudentService studentService;
	
	@Autowired
	private TutorService tutorService;

	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException
	{
		String username = String.valueOf(authentication.getPrincipal());
		String password = String.valueOf(authentication.getCredentials());
		String url = httpServletRequest.getServletPath();
		
		String type = (String) authentication.getDetails();
		Assert.hasLength(type);
		
		UserDetails details = null;
		
		if(type.equals(TutorEntity.Type)) //this is tutor
		{
			details = tutorService.findTutor(username);
			if(details == null)
				throw new BadCredentialsException("Username not found.");
		}
		else if(type.equals(StudentEntity.Type)) //this is student
		{
			details = studentService.findStudent(username);
			if(details == null)
				throw new BadCredentialsException("Username not found.");
		}
		else return null;
		
		if(!StringUtils.hasText(details.getPassword()))
			throw new BadCredentialsException("Username or Password do not match.");
		
		StringBuilder hashedPassword = new StringBuilder(details.getPassword());
		hashedPassword.setCharAt(2, 'a');
		if (BCrypt.checkpw(password, hashedPassword.toString()))
		{
			UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken(
					details, details.getPassword(), details.getAuthorities());
			SecurityContextHolder.getContext().setAuthentication(token);
			return token;
		}
		else
			throw new BadCredentialsException("Username or Password do not match.");
	}

	@Override
	public boolean supports(Class<?> authentication)
	{
		return authentication.equals(UsernamePasswordAuthenticationToken.class);
	}

}
