package com.shezartech.iitjeeacademy.service;

import org.springframework.security.core.userdetails.UserDetails;

public interface AuthenticationService {

	void setAuthenticationCookie(UserDetails details);

	String getUserType(UserDetails details);

	void setTimestamp(UserDetails details);

}
