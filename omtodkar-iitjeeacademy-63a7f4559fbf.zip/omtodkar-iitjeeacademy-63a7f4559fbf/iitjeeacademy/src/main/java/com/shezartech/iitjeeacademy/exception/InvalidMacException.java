package com.shezartech.iitjeeacademy.exception;

public class InvalidMacException extends Exception{

	public InvalidMacException() {
		super("MAC is invalid");
	}
}
