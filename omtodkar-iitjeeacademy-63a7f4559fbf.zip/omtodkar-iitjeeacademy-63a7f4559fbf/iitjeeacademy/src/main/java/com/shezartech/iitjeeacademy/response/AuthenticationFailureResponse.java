package com.shezartech.iitjeeacademy.response;

public class AuthenticationFailureResponse extends Response {

	public AuthenticationFailureResponse() {
		super();
		super.setResponse(new Status("token-expired", "Not Authorized", "failed"));
	}
}