package com.shezartech.iitjeeacademy.config;

import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.aspectj.EnableSpringConfigured;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.multipart.MultipartResolver;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.servlet.config.annotation.DefaultServletHandlerConfigurer;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

@Configuration
@EnableWebMvc
@ComponentScan(basePackages = { "com.shezartech.iitjeeacademy" })
//@EnableTransactionManagement
@EnableAspectJAutoProxy
@EnableSpringConfigured
public class WebConfig extends WebMvcConfigurerAdapter
{

//	@Override
//	public void configureViewResolvers(ViewResolverRegistry registry) {
//		registry.enableContentNegotiation(new MappingJackson2JsonView());
//		registry.freeMarker().cache(false);
//		super.configureViewResolvers(registry);
//	}

	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry)
	{
		registry.addResourceHandler("/resources/**").addResourceLocations("/resources/");
	}
	
	@Override
    public void configureDefaultServletHandling(DefaultServletHandlerConfigurer configurer)
	{
        configurer.enable();
    }
	
	@Override
    public void configureMessageConverters( List<HttpMessageConverter<?>> converters )
	{
        converters.add(converter());
    }

    @Bean
    MappingJackson2HttpMessageConverter converter()
    {
    	MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
    	converter.setJsonPrefix(")]}',\n"); //to take care of vulnerability as described http://haacked.com/archive/2008/11/20/anatomy-of-a-subtle-json-vulnerability.aspx/
    	// and https://docs.angularjs.org/api/ng/service/$http.
    	// this will not need to be done once the system uses JWT instead of cookies for authentication
    	return converter;
    }

	@Bean
	public InternalResourceViewResolver jspViewResolver()
	{
		InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
		viewResolver.setPrefix("/WEB-INF/views/");
		viewResolver.setSuffix(".jsp");
		viewResolver.setOrder(1);
		return viewResolver;
	}
	
//	@Bean(name = "simpleMappingExceptionResolver")
//	public SimpleMappingExceptionResolver createSimpleMappingExceptionResolver()
//	{
//		SimpleMappingExceptionResolver r = new SimpleMappingExceptionResolver();
//		return r;
//	}
	
	@Bean
	public RestResponseStatusExceptionResolver restResponseStatusExceptionResolver()
	{
		return new RestResponseStatusExceptionResolver();
	}
	
	@Bean
	public MultipartResolver multipartResolver()
	{
		return new CommonsMultipartResolver();
	}
}