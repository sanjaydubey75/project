package com.shezartech.iitjeeacademy.service;

import java.util.List;

import com.shezartech.iitjeeacademy.entity.TopicEntity;

public interface TopicService {

	TopicEntity getTopic(String id);

	List<TopicEntity> getTopics(String subjectId);

	

}
