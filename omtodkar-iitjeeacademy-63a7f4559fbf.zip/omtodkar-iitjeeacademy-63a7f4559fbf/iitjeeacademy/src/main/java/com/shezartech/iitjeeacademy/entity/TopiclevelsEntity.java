package com.shezartech.iitjeeacademy.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * Created by shobhit on 3/26/2015.
 */
@Entity
@Table(name = "topiclevels")
public class TopiclevelsEntity implements ModelEntity{
	
	@Id
	@ManyToOne
	@JsonIgnore
    private StudentEntity user;
	
	@Column(name = "level", nullable = false)
    private int level;
	
	@Column(name = "correctAttempts", nullable=true)
    private Integer correctAttempts;
	
	@Column(name = "wrongAttempts", nullable=true)
    private Integer wrongAttempts;
	
	@Column(name = "score", nullable = true)
    private Double score;
    
    @Id
	@ManyToOne
	@JoinColumn(name="topicId", nullable=false)
    @JsonIgnore
    private TopicEntity topicId;
    
    @Column(name = "levelTestAttempt", nullable = true)
    private Boolean levelTestAttempt;
    
    
    public StudentEntity getUserId() {
        return user;
    }

    public void setUserId(StudentEntity userId) {
        this.user = userId;
    }
    
    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    
    public Integer getCorrectAttempts() {
        return correctAttempts;
    }

    public void setCorrectAttempts(Integer correctAttempts) {
        this.correctAttempts = correctAttempts;
    }

    public Integer getWrongAttempts() {
        return wrongAttempts;
    }

    public void setWrongAttempts(Integer wrongAttempts) {
        this.wrongAttempts = wrongAttempts;
    }

    public Double getScore() {
        return score;
    }

    public void setScore(Double score) {
        this.score = score;
    }

    
    public TopicEntity getTopicId() {
        return topicId;
    }

    public void setTopicId(TopicEntity topicId) {
        this.topicId = topicId;
    }
    
    public Boolean getLevelTestAttempt() {
        return levelTestAttempt;
    }

    public void setLevelTestAttempt(Boolean levelTestAttempt) {
        this.levelTestAttempt = levelTestAttempt;
    }
}
