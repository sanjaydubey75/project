package com.shezartech.iitjeeacademy.security;

public class AuthCookie {
	
	private String iv = "abc";
	private String value = "abc";
	private String mac = "abc";
	
	AuthCookie() {
		// no-args constructor
	}

	public String getIv() {
		return iv;
	}

	public void setIv(String iv) {
		this.iv = iv;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getMac() {
		return mac;
	}

	public void setMac(String mac) {
		this.mac = mac;
	}
}