package com.shezartech.iitjeeacademy.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * Created by shobhit on 3/26/2015.
 */
@Entity
@Table(name = "institutecouponcode")
public class CouponCodeEntity implements ModelEntity{
	
	@Id
	@GeneratedValue
	private int id;
	
	@ManyToOne
	@JoinColumn(nullable = true)
	private TutorEntity tutor;
	
    @ManyToOne
    @JoinColumn(name = "instituteId_id", referencedColumnName = "id", nullable = true)
    private InstituteEntity instituteId;
	
	@Column(name = "value", nullable = false)
    private String value;
	
	@Column(name = "registered", nullable = false)
    private boolean registered;
    
	@Column(name = "subscriptionModel", nullable = false)
    private int subscriptionModel;
	
	@Column(name = "discount", nullable = false)
    private int discount;
	
	@Column(name = "email", length = 200, nullable = true)
    private String email;
    
    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public boolean getRegistered() {
        return registered;
    }

    public void setRegistered(Boolean registered) {
        this.registered = registered;
    }

    public int getSubscriptionModel() {
        return subscriptionModel;
    }

    public void setSubscriptionModel(int subscriptionModel) {
        this.subscriptionModel = subscriptionModel;
    }
    
    public int getDiscount() {
        return discount;
    }

    public void setDiscount(int discount) {
        this.discount = discount;
    }
    
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public InstituteEntity getInstituteIdId() {
        return instituteId;
    }

    public void setInstituteIdId(InstituteEntity instituteIdId) {
        this.instituteId = instituteIdId;
    }    
}