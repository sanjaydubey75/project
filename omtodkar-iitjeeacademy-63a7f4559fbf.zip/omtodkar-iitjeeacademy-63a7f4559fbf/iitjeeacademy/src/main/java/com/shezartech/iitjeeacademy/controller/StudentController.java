package com.shezartech.iitjeeacademy.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.shezartech.iitjeeacademy.config.URIConstants;
import com.shezartech.iitjeeacademy.entity.MotivatorEntity;
import com.shezartech.iitjeeacademy.entity.StudentEntity;
import com.shezartech.iitjeeacademy.entity.SubjectglobalranksEntity;
import com.shezartech.iitjeeacademy.entity.SubjectlevelsEntity;
import com.shezartech.iitjeeacademy.entity.SubjectstateranksEntity;
import com.shezartech.iitjeeacademy.entity.TopiclevelsEntity;
import com.shezartech.iitjeeacademy.service.StudentService;

@RestController
@RequestMapping(value = URIConstants.StudentController)
public class StudentController
{

	@Autowired
	private StudentService studentService;
	
	public static final ObjectMapper MAPPER = new ObjectMapper();
	
	@RequestMapping(method = RequestMethod.GET, value = "/me")
	@PreAuthorize("hasRole('student')")
	public StudentEntity getDetails(@AuthenticationPrincipal StudentEntity student)
	{
		return student;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/me")
	@PreAuthorize("hasRole('student')")
	public StudentEntity editProfile(
			@AuthenticationPrincipal StudentEntity studentPrincipal,
			@RequestParam(value = "file0", required = false) MultipartFile file,
			@RequestParam("model") String studentMap) throws JsonParseException, JsonMappingException, IOException
	{
		StudentEntity student = studentService.editProfile(studentPrincipal, getResponseEntity(studentMap), file);
		return student;
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/me/subjectLevels")
	@PreAuthorize("hasRole('student')")
	public List<SubjectlevelsEntity> getSubjectLevels(@AuthenticationPrincipal StudentEntity student)
	{
		return studentService.getSubjectlevelsEntities(student);
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/me/subjectGlobalRanks")
	@PreAuthorize("hasRole('student')")
	public List<SubjectglobalranksEntity> getSubjectGlobalRanks(@AuthenticationPrincipal StudentEntity student)
	{
		return studentService.getSubjectGlobalRanks(student);
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/me/subjectStateRanks")
	@PreAuthorize("hasRole('student')")
	public List<SubjectstateranksEntity> getSubjectStateRanks(@AuthenticationPrincipal StudentEntity student)
	{
		return studentService.getSubjectStateRanks(student);
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/me/emptyProfileFields")
	@PreAuthorize("hasRole('student')")
	public List<String> getEmptyProfileFields(@AuthenticationPrincipal StudentEntity student)
	{
		return studentService.getEmptyProfileFields(student);
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/me/motivator")
	@PreAuthorize("hasRole('student')")
	public MotivatorEntity getMotivator(@AuthenticationPrincipal StudentEntity student)
	{
		return studentService.getMotivator(student);
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/me/motivator")
	@PreAuthorize("hasRole('student')")
	public Response setMotivator(@AuthenticationPrincipal StudentEntity student, 
			@RequestBody MotivatorEntity motivator)
	{
		studentService.setMotivator(student, motivator);
		return Response.status(Status.OK).build();
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/me/topicLevel/{id}")
	@PreAuthorize("hasRole('student')")
	public TopiclevelsEntity getTopicLevel(@AuthenticationPrincipal StudentEntity student,
			@PathVariable(value="id") String id)
	{
		return studentService.getTopicLevel(student, id);
	}
	
	private Map<String, Object> getResponseEntity(final String string)
			throws JsonParseException, JsonMappingException, IOException {
		return MAPPER.readValue(string,
				new TypeReference<Map<String, Object>>() {
				});
	}
}
