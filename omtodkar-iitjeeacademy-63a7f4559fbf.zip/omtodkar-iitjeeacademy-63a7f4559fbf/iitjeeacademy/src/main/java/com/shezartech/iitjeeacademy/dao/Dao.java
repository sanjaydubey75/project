package com.shezartech.iitjeeacademy.dao;

import java.io.Serializable;
import java.util.List;

import org.hibernate.SessionFactory;

import com.shezartech.iitjeeacademy.entity.ModelEntity;

public interface Dao<T extends ModelEntity, I extends Serializable>
{

	List<T> findAll();

	T find(I id);

	T merge(T entity);

	void delete(I id);
	
	void delete(T entity);

	void setSessionFactory(SessionFactory sessionFactory);

	void persist(T entity);

}
