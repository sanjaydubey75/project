package com.shezartech.iitjeeacademy.service;

import java.util.List;

import com.shezartech.iitjeeacademy.entity.SubjectEntity;

public interface SubjectService {

	List<SubjectEntity> getSubjects();

	SubjectEntity getSubject(String id);

}
