package com.shezartech.iitjeeacademy.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * Created by shobhit on 3/26/2015.
 */
@Entity
@Table(name = "password_change_request")
public class PasswordChangeRequestEntity implements ModelEntity{
	
	@Id
	@OneToOne
	@JoinColumn(name = "user_id")
    private StudentEntity userId;
    
    @Column(name = "hash", nullable = false)
    private String hash;
    
    @Column(name = "time", nullable = false)
    private Timestamp time;

    
    
    public StudentEntity getUserId() {
        return userId;
    }

    public void setUserId(StudentEntity userId) {
        this.userId = userId;
    }

    
    
    public String getHash() {
        return hash;
    }

    public void setHash(String hash) {
        this.hash = hash;
    }

    
    
    public Timestamp getTime() {
        return time;
    }

    public void setTime(Timestamp time) {
        this.time = time;
    }  
}
