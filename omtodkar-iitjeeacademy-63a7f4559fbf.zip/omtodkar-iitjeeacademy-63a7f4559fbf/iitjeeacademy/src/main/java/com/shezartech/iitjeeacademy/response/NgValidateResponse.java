package com.shezartech.iitjeeacademy.response;

import com.fasterxml.jackson.annotation.JsonProperty;

public class NgValidateResponse extends Response {
	
	private boolean isValid;
	private String value; 

	public NgValidateResponse(boolean isValid, String value){
		super();
		this.isValid = isValid;
		this.value = value;
	}

	@JsonProperty("isValid")
	public boolean isValid() {
		return isValid;
	}

	public void setValid(boolean isValid) {
		this.isValid = isValid;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
}
