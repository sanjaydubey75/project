package com.shezartech.iitjeeacademy.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

import javax.annotation.PostConstruct;

import org.hibernate.mapping.Collection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.shezartech.iitjeeacademy.dao.QuestionDao;
import com.shezartech.iitjeeacademy.dao.SampleRankingDao;
import com.shezartech.iitjeeacademy.dao.StudentDao;
import com.shezartech.iitjeeacademy.entity.AccuracyEntity;
import com.shezartech.iitjeeacademy.entity.QuestionEntity;
import com.shezartech.iitjeeacademy.entity.SamplerankingEntity;
import com.shezartech.iitjeeacademy.entity.StudentEntity;
import com.shezartech.iitjeeacademy.entity.TopiclevelsEntity;

@Service
public class RankingServiceImpl implements RankingService
{
	@Autowired
	private SampleRankingDao sampleRankingDao;
	
	@Autowired
	private QuestionDao questionDao;
	
	@Autowired
	private StudentDao studentDao;
	
	private List<SamplerankingEntity> samplerankingEntities;
	
	@PostConstruct
	public void initialize()
	{
		this.samplerankingEntities = sampleRankingDao.findAll();
		
		Comparator<SamplerankingEntity> comparator = new Comparator<SamplerankingEntity>()
		{

			@Override
			public int compare(SamplerankingEntity o1, SamplerankingEntity o2)
			{
				return o1.getId() - o2.getId();
			}
		};
		
		Collections.sort(samplerankingEntities, comparator);
	}

	private int getStudentsBelowCurrentLevel(int level)
	{
		 int total = samplerankingEntities.size();
		 
		 int count = 0;
		 
		 for(int i = 0; i < (total/7.0)*(level - 1); i++)
		 {
			 count += samplerankingEntities.get(i).getStudents();
		 }
		 
		 return count;
	}
	
	private int getStudentsInCurrentLevel(int level)
	{
		 int total = samplerankingEntities.size();
		 
		 int count = 0;
		 
		 for(int i = (int) ((total/7.0)*(level - 1)); i < (total/7.0)*(level); i++)
		 {
			 count += samplerankingEntities.get(i).getStudents();
		 }
		 
		 return count;
	}
	
	private int getTotalStudents()
	{
		int count = 0;

		for (int i = 0; i < samplerankingEntities.size(); i++)
		{
			count += samplerankingEntities.get(i).getStudents();
		}

		return count;
	}
	
	/**
	 * 
	 * @param student
	 * @param questionId
	 * @param correct1 - signifies whether the question was correct in the time duration
	 * @param correct2 - signifies whether the question was correct irespective of when completed
	 * @throws IOException 
	 * @throws JsonMappingException 
	 * @throws JsonParseException 
	 */
	private void process(StudentEntity student, String questionId, boolean correct1, boolean correct2) throws JsonParseException, JsonMappingException, IOException
	{
		QuestionEntity question = questionDao.find(questionId);
		student = studentDao.find(student.getEmail());
		
		if(correct1)
			question.setCorrect(question.getCorrect() + 1);
		
		question.setAttempt(question.getAttempt() + 1);
		
		TopiclevelsEntity topiclevelsEntity = student.getTopiclevelsEntities().get(question.getTopic().getId());
		
		if(correct1)
			topiclevelsEntity.setCorrectAttempts(topiclevelsEntity.getCorrectAttempts() + 1);
		else
			topiclevelsEntity.setWrongAttempts(topiclevelsEntity.getWrongAttempts() + 1);
		
		AccuracyEntity accuracyEntity = student.getAccuracyEntities().get(question.getTopic().getId());
		
		ObjectMapper mapper = new ObjectMapper();
		List<Integer> accuracy = mapper.readValue(
				accuracyEntity.getAccuracy(), 
				new TypeReference<List<Integer>>() { });
		
		List<Integer> newAccuracy = new ArrayList<>(accuracy);
		newAccuracy.remove(newAccuracy.size() - 1);
		newAccuracy.add(correct1 ? 1 : 0);
		
		accuracyEntity.setAccuracy(mapper.writeValueAsString(newAccuracy));
		
		
	}
}