package com.shezartech.iitjeeacademy.response;

public class LoginSuccessResponse extends Response
{

	public static class Person
	{
		public String userFirstname;
		public String userEmail;
		
		Person(String userFirstname, String userEmail)
		{
			this.userEmail = userEmail;
			this.userFirstname = userFirstname;
		}
	}
	
	public Person person;
	
	public LoginSuccessResponse(String name, String email)
	{
		super();
		super.setResponse(new Status("", "Login Successful", "success"));
		this.person = new Person(name, email);
	}
}