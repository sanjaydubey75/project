package com.shezartech.iitjeeacademy.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shezartech.iitjeeacademy.dao.SubjectDao;
import com.shezartech.iitjeeacademy.entity.SubjectEntity;

@Service
public class SubjectServiceImpl implements SubjectService
{

	@Autowired
	private SubjectDao subjectDao;
	
	@Transactional
	@Override
	public List<SubjectEntity> getSubjects()
	{
		return subjectDao.findAll();
	}
	
	@Transactional
	@Override
	public SubjectEntity getSubject(String id)
	{
		return subjectDao.find(id);
	}
}
