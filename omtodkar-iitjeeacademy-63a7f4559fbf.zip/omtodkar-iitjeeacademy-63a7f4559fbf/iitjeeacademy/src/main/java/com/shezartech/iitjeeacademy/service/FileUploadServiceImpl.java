package com.shezartech.iitjeeacademy.service;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import org.springframework.web.multipart.MultipartFile;

public class FileUploadServiceImpl implements FileUploadService
{
	private String rootPath = "";

	public FileUploadServiceImpl(String... rootPath)
	{
		super();
		for (String string : rootPath)
		{
			this.rootPath += (string + File.separator);
		}
	}
	
	@Override
	public void upload(MultipartFile file, String name)
	{
		try
		{
			byte[] bytes = file.getBytes();
			BufferedOutputStream stream =
			        new BufferedOutputStream(new FileOutputStream(new File(rootPath + name)));
			stream.write(bytes);
			stream.close();
		}
		catch (IOException e)
		{
			throw new RuntimeException("Error uploading the file", e);
		}
	}
	
	@Override
	public void delete(String name)
	{
		if(!name.equals("0"))
		{
			File file = new File(rootPath + name);
			if(!file.delete())
			{
				throw new RuntimeException("Unable to delete file at " + rootPath + name);
			};
		}
	}
}
