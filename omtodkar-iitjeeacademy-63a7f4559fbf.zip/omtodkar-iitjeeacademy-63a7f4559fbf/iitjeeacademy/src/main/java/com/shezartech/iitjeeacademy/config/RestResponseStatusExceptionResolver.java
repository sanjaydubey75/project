package com.shezartech.iitjeeacademy.config;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.AbstractHandlerExceptionResolver;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.shezartech.iitjeeacademy.security.ErrorMessage;

public class RestResponseStatusExceptionResolver extends AbstractHandlerExceptionResolver
{

	private final ObjectWriter ow = new ObjectMapper().writer();
	
	@Override
	protected ModelAndView doResolveException(HttpServletRequest request,
			HttpServletResponse response, Object handler, Exception ex) {
		try {
            if (ex instanceof BadCredentialsException) {
            	return handleIllegalArgument((BadCredentialsException) ex, response);
            }
        } catch (Exception handlerException) {
            logger.warn("Handling of [" + ex.getClass().getName() + "]" +  
              "resulted in Exception", handlerException);
        }
        return null;
	}
	
	private ModelAndView handleIllegalArgument(BadCredentialsException ex, HttpServletResponse response) throws IOException
	{
		int status = HttpServletResponse.SC_UNAUTHORIZED;
		
		response.setContentType(MediaType.APPLICATION_JSON_VALUE);
		response.setStatus(status);
		
		ErrorMessage errorMessage = new ErrorMessage(status, HttpStatus.valueOf(status).getReasonPhrase(), ex.getMessage());
		response.getWriter().print(ow.writeValueAsString(errorMessage));
		
//		response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "{'a':'1'}".replace("'", "\""));
		return new ModelAndView();
	}
}
