package com.shezartech.iitjeeacademy.entity;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Transient;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIdentityReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

/**
 * Created by shobhit on 3/26/2015.
 */
@Entity
@javax.persistence.Table(name = "student")
public class StudentEntity implements ModelEntity, UserDetails
{
	
	public static final String Type = "student";

	@Id
	@javax.persistence.Column(name = "id")
	@GeneratedValue
	private int id;
	
	@JsonIgnore
	@javax.persistence.Column(name = "password", length = 1000, nullable = true)
	private String password;
	
	@javax.persistence.Column(name = "firstName", length = 500, nullable = false)
	private String firstName;
	
	@javax.persistence.Column(name = "lastName", length = 500, nullable = false)
	private String lastName;
	
	@javax.persistence.Column(name = "email", length = 200, unique = true, nullable = false)
	private String email;
	
	@javax.persistence.Column(name = "parentEmail", length = 200, nullable = true)
	private String parentEmail;
	
	@javax.persistence.Column(name = "institution", length = 500, nullable = true)
	private String institution;
	
	@javax.persistence.Column(name = "birthday", nullable = true)
	private Date birthday;
	
	@javax.persistence.Column(name = "transactionId", nullable = true)
	private Integer transactionId;
	
	@javax.persistence.Column(name = "globalrank", nullable = false)
	private int globalRank;
	
	@javax.persistence.Column(name = "stateRank", nullable = false)
	private int stateRank;
	
	@javax.persistence.Column(name = "SubscriptionLimit", nullable = true)
	private Timestamp subscriptionLimit;
	
	@javax.persistence.Column(name = "registration_date", nullable = true)
	private Timestamp registrationDate;
	
	@javax.persistence.Column(name = "LastLoginTime", nullable = true)
	private Timestamp lastLoginTime;
	
	@javax.persistence.Column(name = "TargetYear", length = 10, nullable = true)
	private Integer targetYear;
	
	@javax.persistence.Column(name = "photopath", length = 1000, nullable = false)
	private String photopath;
	
	@javax.persistence.Column(name = "mobileNumber", length = 20, nullable = true)
	private String mobileNumber;
	
	@javax.persistence.Column(name = "couponCode", nullable = true)
	private String couponCode;
	
	@javax.persistence.Column(name = "subscriptionModel", nullable = true)
	private int subscriptionModel;
	
	/**
	 * third party authentication providers
	 */
	
	private String facebookId;
	
	private String facebookLink;
	
	private String googleId;
	
	private String googleLink;
	
	@ManyToOne
	@JoinColumn(name="state", referencedColumnName="id", nullable=true)
	@JsonIdentityReference(alwaysAsId = true)
	@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
	private StatewiseselectionEntity state;
	
	@JsonIgnore
	@OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
	private List<SubjectglobalranksEntity> subjectglobalranksEntity = new ArrayList<>();
	
	@JsonIgnore
	@OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
	private List<SubjectstateranksEntity> subjectstateranksEntities = new ArrayList<>();
	
	@JsonIgnore
	@OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
	private Map<String, TopiclevelsEntity> topiclevelsEntities = new HashMap<>();
	
	@JsonIgnore
	@OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
	private List<SubjectlevelsEntity> subjectlevelsEntities = new ArrayList<>();
	
	@JsonIgnore
	@OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
	private Map<String, AccuracyEntity> accuracyEntities = new HashMap<>();
	
	@OneToOne(cascade = CascadeType.ALL)
	private MotivatorEntity motivator;
	
	@JsonIgnore
	@OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
	private Map<String, QuestionansweredEntity> questionAttempted = new HashMap<>();
	
	@Transient
	private Set<GrantedAuthority> authorities = new HashSet<GrantedAuthority>();

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public StatewiseselectionEntity getState() {
		return state;
	}

	public void setState(StatewiseselectionEntity state) {
		this.state = state;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getInstitution() {
		return institution;
	}

	public void setInstitution(String institution) {
		this.institution = institution;
	}

	public Date getBirthday() {
		return birthday;
	}

	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}

	public int getGlobalRank() {
		return globalRank;
	}

	public void setGlobalRank(int globalrank) {
		this.globalRank = globalrank;
	}

	public int getStateRank() {
		return stateRank;
	}

	public void setStateRank(int stateRank) {
		this.stateRank = stateRank;
	}

	public Timestamp getSubscriptionLimit() {
		return subscriptionLimit;
	}

	public void setSubscriptionLimit(Timestamp subscriptionLimit) {
		this.subscriptionLimit = subscriptionLimit;
	}

	public Timestamp getLastLoginTime() {
		return lastLoginTime;
	}

	public void setLastLoginTime(Timestamp lastLoginTime) {
		this.lastLoginTime = lastLoginTime;
	}

	public Integer getTargetYear() {
		return targetYear;
	}

	public void setTargetYear(Integer targetYear) {
		this.targetYear = targetYear;
	}

	public String getPhotopath() {
		return photopath;
	}

	public void setPhotopath(String photopath) {
		this.photopath = photopath;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getParentEmail() {
		return parentEmail;
	}

	public void setParentEmail(String parentEmail) {
		this.parentEmail = parentEmail;
	}

	public Integer getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Integer transactionId) {
		this.transactionId = transactionId;
	}

	public String getCouponCode() {
		return couponCode;
	}

	public void setCouponCode(String couponCode) {
		this.couponCode = couponCode;
	}

	public int getSubscriptionModel() {
		return subscriptionModel;
	}

	public void setSubscriptionModel(int subscriptionModel) {
		this.subscriptionModel = subscriptionModel;
	}

	public String getFacebookId() {
		return facebookId;
	}

	public void setFacebookId(String facebookId) {
		this.facebookId = facebookId;
	}

	public String getFacebookLink() {
		return facebookLink;
	}

	public void setFacebookLink(String facebookLink) {
		this.facebookLink = facebookLink;
	}

	public String getGoogleId() {
		return googleId;
	}

	public void setGoogleId(String googleId) {
		this.googleId = googleId;
	}

	public String getGoogleLink() {
		return googleLink;
	}

	public void setGoogleLink(String googleLink) {
		this.googleLink = googleLink;
	}

	public Timestamp getRegistrationDate() {
		return registrationDate;
	}

	public void setRegistrationDate(Timestamp registrationDate) {
		this.registrationDate = registrationDate;
	}

	public List<SubjectglobalranksEntity> getSubjectglobalranksEntity() {
		return subjectglobalranksEntity;
	}

	public void setSubjectglobalranksEntity(
			List<SubjectglobalranksEntity> subjectglobalranksEntity) {
		this.subjectglobalranksEntity = subjectglobalranksEntity;
	}

	public List<SubjectstateranksEntity> getSubjectstateranksEntities() {
		return subjectstateranksEntities;
	}

	public void setSubjectstateranksEntities(
			List<SubjectstateranksEntity> subjectstateranksEntities) {
		this.subjectstateranksEntities = subjectstateranksEntities;
	}

	public Map<String, TopiclevelsEntity> getTopiclevelsEntities() {
		return topiclevelsEntities;
	}

	public void setTopiclevelsEntities(Map<String, TopiclevelsEntity> topiclevelsEntities) {
		this.topiclevelsEntities = topiclevelsEntities;
	}

	public List<SubjectlevelsEntity> getSubjectlevelsEntities() {
		return subjectlevelsEntities;
	}

	public void setSubjectlevelsEntities(
			List<SubjectlevelsEntity> subjectlevelsEntities) {
		this.subjectlevelsEntities = subjectlevelsEntities;
	}

	public Map<String, AccuracyEntity> getAccuracyEntities() {
		return accuracyEntities;
	}

	public void setAccuracyEntities(Map<String, AccuracyEntity> accuracyEntities) {
		this.accuracyEntities = accuracyEntities;
	}

	public MotivatorEntity getMotivator() {
		return motivator;
	}

	public void setMotivator(MotivatorEntity motivator) {
		this.motivator = motivator;
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities()
	{
		// setup roles
		Set<String> roles = new HashSet<String>();
		
//		if(this.getSubscriptionModel() == 4)
//			roles.add("Student_Trial");
//		else
		roles.addAll(Arrays.<String> asList("Student_Trial", "Student_Unlimited", StudentEntity.Type));

		// export them as part of authorities
		for (String r : roles)
		{
			authorities.add(new SimpleGrantedAuthority(role(r)));
		}
		return this.authorities;
	}
	
	private String role(String i) {
        return "ROLE_" + i;
    }

	@Override
	public String getUsername()
	{
		return this.getEmail();
	}

	@Override
	public boolean isAccountNonExpired()
	{
		return true;
	}

	@Override
	public boolean isAccountNonLocked()
	{
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired()
	{
		return true;
	}

	@Override
	public boolean isEnabled()
	{
		return true;
	}

}
