package com.shezartech.iitjeeacademy.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.shezartech.iitjeeacademy.config.URIConstants;
import com.shezartech.iitjeeacademy.entity.TutorEntity;
import com.shezartech.iitjeeacademy.response.Response;
import com.shezartech.iitjeeacademy.response.tutor.TutorResponse;
import com.shezartech.iitjeeacademy.service.TutorService;

@RestController
@RequestMapping(value = URIConstants.TutorController)
public class TutorController
{
	
//	private UserAuthCookie userAuthCookie;
	
	@Autowired
	private TutorService tutorService;
	
//	public void setUserAuthCookie(UserAuthCookie userAuthCookie)
//	{
//		this.userAuthCookie = userAuthCookie;
//	}
	
	@RequestMapping(method = RequestMethod.GET)
	@PreAuthorize("hasRole('tutor')")
	public Response getDetails(@AuthenticationPrincipal TutorEntity tutor)
	{
		return new TutorResponse(tutorService.findTutor(tutor.getEmail()));
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/student")
	@PreAuthorize("hasRole('tutor')")
	public Response getStudents(
			@RequestParam(value = "targetYear", required = false) String targetYear,
			@AuthenticationPrincipal TutorEntity tutor)
	{
		return new TutorResponse(tutorService.getStudents(tutor.getEmail(), targetYear));
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/students/info")
	@PreAuthorize("hasRole('tutor')")
	public Response getStudentInformation(@AuthenticationPrincipal TutorEntity tutor)
	{
		TutorResponse tutorResponse = new TutorResponse(
				tutorService.getStudentInformation(tutor.getEmail()));
		return tutorResponse;
	}
	
	@PreAuthorize("hasRole('tutor')")
	@RequestMapping(method = RequestMethod.GET, value = "/account/summary")
	public Response getFinancialSummary(@AuthenticationPrincipal TutorEntity tutor)
	{
		TutorResponse tutorResponse = new TutorResponse();
		tutorResponse.setFinancialSummaries(tutorService.getFinancialSummaries(
				tutor.getEmail()
				));
		return tutorResponse;
	}
}
