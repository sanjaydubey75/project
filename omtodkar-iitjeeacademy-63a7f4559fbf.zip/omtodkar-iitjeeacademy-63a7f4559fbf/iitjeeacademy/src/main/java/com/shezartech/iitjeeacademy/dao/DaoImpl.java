package com.shezartech.iitjeeacademy.dao;

import java.io.Serializable;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.shezartech.iitjeeacademy.entity.ModelEntity;

public class DaoImpl<T extends ModelEntity, I extends Serializable> implements
		Dao<T, I> {

	private static final Logger logger = LoggerFactory
			.getLogger(DaoImpl.class);

	private SessionFactory sessionFactory;

	protected Class<T> entityClass;

	public DaoImpl(Class<T> entityClass) {
		this.entityClass = entityClass;
	}

	@Override
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	protected final Session getCurrentSession() {
		return sessionFactory.getCurrentSession();
	}

	@Override
	public List<T> findAll() {
		Session session = getCurrentSession();
		List<T> entities = session.createQuery("from " + this.entityClass.getName()).list();
		return entities;
	}

	@Override
	public T find(I id) {
		Session session = getCurrentSession();
		T entity = (T) session.get(this.entityClass, id);
		logger.info("find(id): " + entity);
		return entity;
	}

	/**
	 * This won't work until equals and hash methods are overloaded in the entities.
	 */
	@Override
	public T merge(T entity) {
		Session session = getCurrentSession();
		T attachedEntity = (T) session.merge(entity);
		logger.info("save(entity): " + attachedEntity);
		return attachedEntity;
	}
	
	@Override
	public void persist(T entity){
		Session session = getCurrentSession();
		session.persist(entity);
		logger.info("persist(entity): " + entity);
	}

	@Override
	public void delete(I id) {
		T entity = find(id);
		delete(entity);
	}
	
	@Override
	public void delete(T entity){
		Session session = getCurrentSession();
		session.delete(entity);
		logger.info("delete(entity): " + entity);
	}
}