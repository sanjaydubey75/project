package com.shezartech.iitjeeacademy.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.shezartech.iitjeeacademy.config.URIConstants;
import com.shezartech.iitjeeacademy.entity.StudentEntity;
import com.shezartech.iitjeeacademy.entity.TopicEntity;
import com.shezartech.iitjeeacademy.service.TopicService;

@RestController
@RequestMapping(value = URIConstants.TopicController)
public class TopicController
{

	@Autowired
	private TopicService topicService;
	
	@RequestMapping(method = RequestMethod.GET)
	@PreAuthorize(value = "hasRole('student')")
	public List<TopicEntity> getSubjects(@AuthenticationPrincipal StudentEntity student,
			@RequestParam(value = "subjectId", required = false) String subjectId)
	{
		return topicService.getTopics(subjectId);
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/{id}")
	@PreAuthorize(value = "hasRole('student')")
	public TopicEntity getSubject(@AuthenticationPrincipal StudentEntity student,
			@PathVariable(value="id") String id)
	{
		return topicService.getTopic(id);
	}
}
