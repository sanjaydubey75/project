package com.shezartech.iitjeeacademy.controller;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

import javax.validation.Valid;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;

import org.hibernate.validator.constraints.NotBlank;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Preconditions;
import com.shezartech.iitjeeacademy.config.URIConstants;
import com.shezartech.iitjeeacademy.config.WebSecurityConfig.ClientSecretsConfiguration;
import com.shezartech.iitjeeacademy.config.WebSecurityConfig.ClientSecretsConfiguration.Provider;
import com.shezartech.iitjeeacademy.entity.StudentEntity;
import com.shezartech.iitjeeacademy.service.AuthenticationService;
import com.shezartech.iitjeeacademy.service.RegisterService;
import com.shezartech.iitjeeacademy.service.StudentService;

@RestController
@RequestMapping(value = URIConstants.AuthenticationController)
public class AuthenticationController {
	
	private static final Logger logger = LoggerFactory
			.getLogger(AuthenticationController.class);

	public static final String CLIENT_ID_KEY = "client_id",
			REDIRECT_URI_KEY = "redirect_uri", CLIENT_SECRET = "client_secret",
			CODE_KEY = "code", GRANT_TYPE_KEY = "grant_type",
			AUTH_CODE = "authorization_code";

	@Autowired
	private AuthenticationService authenticationService;

	@Autowired(required = false)
	private AuthenticationManager authenticationManager;

	@Autowired
	private StudentService studentService;

	@Autowired
	private RegisterService registerService;

	@Autowired
	private ClientSecretsConfiguration secrets;

	public static final ObjectMapper MAPPER = new ObjectMapper();

	@RequestMapping(method = RequestMethod.POST)
	public UserInformation login(@RequestBody Map<String, String> params) {
		UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken(
				params.get("email"), params.get("password"));
		token.setDetails((String) params.get("type"));
		Authentication authentication = this.authenticationManager
				.authenticate(token);
		SecurityContextHolder.getContext().setAuthentication(authentication);

		UserDetails details = (UserDetails) authentication.getPrincipal();

		Map<String, Boolean> roles = new HashMap<String, Boolean>();
		for (GrantedAuthority authority : details.getAuthorities())
			roles.put(authority.toString(), Boolean.TRUE);

		authenticationService.setAuthenticationCookie(details);

		UserInformation userInformation = new UserInformation(details, roles,
				authenticationService.getUserType(details));

		authenticationService.setTimestamp(details);

		return userInformation;
	}

	@RequestMapping(method = RequestMethod.POST, value = "/facebook")
	public UserInformation loginFacebook(
			@RequestBody @Valid final Payload payload)
			throws JsonParseException, JsonMappingException, IOException
	{
		final String accessTokenUrl = "https://graph.facebook.com/v2.3/oauth/access_token";
		final String graphApiUrl = "https://graph.facebook.com/v2.3/me";

		Response response;

		// Step 1. Exchange authorization code for access token.

		Client client = ClientBuilder.newClient();

		response = client.target(accessTokenUrl)
				.queryParam(CLIENT_ID_KEY, payload.getClientId())
				.queryParam(REDIRECT_URI_KEY, payload.getRedirectUri())
				.queryParam(CLIENT_SECRET, secrets.getFacebook())
				.queryParam(CODE_KEY, payload.getCode()).request("text/plain")
				.accept(MediaType.TEXT_PLAIN).get();

		final String paramStr = Preconditions.checkNotNull(response
				.readEntity(String.class));

		Map<String, String> result = MAPPER.readValue(paramStr,
				new TypeReference<HashMap<String, String>>() {
				});

		response = client.target(graphApiUrl)
				.queryParam("access_token", result.get("access_token"))
				.queryParam("expires_in", result.get("expires_in"))
				.request("text/plain").get();

		final Map<String, Object> userInfo = getResponseEntity(response);

		// Step 3. Process the authenticated the user.
		return processUser(userInfo, Provider.FACEBOOK);
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/google")
	public UserInformation loginGoogle(
			@RequestBody @Valid final Payload payload) throws JsonParseException, JsonMappingException, IOException
	{
		final String accessTokenUrl = "https://accounts.google.com/o/oauth2/token";
		final String peopleApiUrl = "https://www.googleapis.com/plus/v1/people/me/openIdConnect";
//		final String peopleApiUrl = "https://www.googleapis.com/plus/v1/people/{{id of google user}}"; 
		Response response;

		Client client = ClientBuilder.newClient();
		
		// Step 1. Exchange authorization code for access token.
		final MultivaluedMap<String, String> accessData = new MultivaluedHashMap<String, String>();
		accessData.add(CLIENT_ID_KEY, payload.getClientId());
		accessData.add(REDIRECT_URI_KEY, payload.getRedirectUri());
		accessData.add(CLIENT_SECRET, secrets.getGoogle());
		accessData.add(CODE_KEY, payload.getCode());
		accessData.add(GRANT_TYPE_KEY, AUTH_CODE);
		response = client.target(accessTokenUrl).request()
				.post(Entity.form(accessData));
		accessData.clear();

		// Step 2. Retrieve profile information about the current user.
		Map<String, Object> temp = getResponseEntity(response);
		final String accessToken = (String) temp.get("access_token");
		response = client
				.target(peopleApiUrl)
				.request("text/plain")
				.header("Authorization",
						String.format("Bearer %s", accessToken)).get();
		final Map<String, Object> userInfo = getResponseEntity(response);
		
		//Map<String, Object> jwt = getResponseEntity(new String(BaseEncoding.base64().decode(((String)temp.get("id_token")).split("\\.")[1]), "UTF-8"));
		
		// Step 3. Process the authenticated the user.
		return processUser(userInfo, Provider.GOOGLE);
	}

	static class UserInformation
	{
		public String username;
		public Map<String, Boolean> roles;
		public String type;
		@JsonInclude(Include.NON_NULL)
		public Timestamp lastLogin;

		public String token = "123"; // this is dummy.

		// You'll need to change this to a proper JWT and change the
		// authentication from cookie to JWT
		// Also until you do that, take care of CSRF token
		// Also while authenticating token from cookie, make sure that you
		// receive the
		// plaintext values too, to match them with HASH-MAC value cookie(not
		// sure if this is
		// necessary; also this is only until you implement JWT solution)

		public UserInformation(UserDetails details, Map<String, Boolean> roles,
				String type) {
			super();
			this.username = details.getUsername();
			this.roles = roles;
			this.type = type;
			if (details instanceof StudentEntity)
				lastLogin = ((StudentEntity) details).getLastLoginTime();
		}
	}

	/*
	 * Inner classes for entity wrappers
	 */
	public static class Payload {
		@NotBlank
		String clientId;

		@NotBlank
		String redirectUri;

		@NotBlank
		String code;

		public String getClientId() {
			return clientId;
		}

		public String getRedirectUri() {
			return redirectUri;
		}

		public String getCode() {
			return code;
		}
	}

	/*
	 * Helper methods
	 */
	private Map<String, Object> getResponseEntity(final Response response)
			throws JsonParseException, JsonMappingException, IOException {
		return MAPPER.readValue(response.readEntity(String.class),
				new TypeReference<Map<String, Object>>() {
				});
	}
	
	private Map<String, Object> getResponseEntity(final String string)
			throws JsonParseException, JsonMappingException, IOException {
		return MAPPER.readValue(string,
				new TypeReference<Map<String, Object>>() {
				});
	}

	private UserInformation processUser(Map<String, Object> studentMap, Provider provider) {
		// check if student already exists
		StudentEntity student = studentService.findStudent((String) studentMap.get("email"));
		
		UserDetails details = null;

		if (student != null)
		{
			//this is registered user
			details = student;
			//here also check to link facebook account with google and vice versa
			studentService.linkAccount(studentMap, provider);
			//set login timestamp
			authenticationService.setTimestamp(details);
		}
		else
		{
			// this is new user. Create a new account
			details = registerService.registerStudent(studentMap, provider);
		}
		
		authenticationService.setAuthenticationCookie(details);

		Map<String, Boolean> roles = new HashMap<String, Boolean>();
		for (GrantedAuthority authority : details.getAuthorities())
			roles.put(authority.toString(), Boolean.TRUE);

		UserInformation userInformation = new UserInformation(details,
				roles, authenticationService.getUserType(details));

		if(student == null)
			userInformation.lastLogin = null;

		return userInformation;
	}
}