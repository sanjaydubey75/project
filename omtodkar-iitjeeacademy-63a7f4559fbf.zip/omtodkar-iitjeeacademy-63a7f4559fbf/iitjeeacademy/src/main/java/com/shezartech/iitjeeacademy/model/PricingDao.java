package com.shezartech.iitjeeacademy.model;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.springframework.stereotype.Repository;

@Repository
public class PricingDao
{
	private Set<Pricing> pricings = new HashSet<Pricing>(
			Arrays.asList(
					new Pricing(1, "6 Months", 2500, 6*30*24*60*60*1000L),
					new Pricing(2, "1 Year", 3000,    365*24*60*60*1000L),
					new Pricing(3, "2 Years", 5000, 2*365*24*60*60*1000L),
					new Pricing(4, "1 Day", 0,            24*60*60*1000L)
			));

	public Set<Pricing> findAll()
	{
		return this.pricings;
	}
	
	public Pricing find(int id)
	{
		for(Pricing pricing : pricings)
		{
			if(pricing.getId() == id)
				return pricing;
		}
		return null;
	}
}
