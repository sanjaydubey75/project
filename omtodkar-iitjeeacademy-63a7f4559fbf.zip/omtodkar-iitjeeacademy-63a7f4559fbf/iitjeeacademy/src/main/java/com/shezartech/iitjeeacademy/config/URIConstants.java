package com.shezartech.iitjeeacademy.config;

public class URIConstants
{
	protected static final String AbsoluteURI = "/api/v1";
	
	public static final String AuthenticationController = URIConstants.AbsoluteURI + "/login";
	
	public static final String TutorController = URIConstants.AbsoluteURI + "/tutor";
	public static final String StudentController = URIConstants.AbsoluteURI + "/student";
	
	public static final String Register = URIConstants.AbsoluteURI + "/register";
	
	public static final String SubjectGlobalRanksController = URIConstants.AbsoluteURI + "/subjectGlobalRanks";
	public static final String SubjectStateRanksController = URIConstants.AbsoluteURI + "/subjectStateRanks";
	
	public static final String SubjectController = URIConstants.AbsoluteURI + "/subject";
	public static final String TopicController = URIConstants.AbsoluteURI + "/topic";
	public static final String StateController = URIConstants.AbsoluteURI + "/state";
}
