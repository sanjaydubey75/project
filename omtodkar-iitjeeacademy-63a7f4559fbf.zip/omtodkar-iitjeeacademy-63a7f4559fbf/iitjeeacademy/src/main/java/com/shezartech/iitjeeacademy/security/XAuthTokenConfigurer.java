package com.shezartech.iitjeeacademy.security;

import org.springframework.security.config.annotation.SecurityConfigurerAdapter;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.DefaultSecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.shezartech.iitjeeacademy.service.StudentService;
import com.shezartech.iitjeeacademy.service.TutorService;

/**
 * @author Philip W. Sorst (philip@sorst.net)
 * @author Josh Long (josh@joshlong.com)
 */
public class XAuthTokenConfigurer extends SecurityConfigurerAdapter<DefaultSecurityFilterChain, HttpSecurity>
{
	private TutorService tutorService;
	
	private StudentService studentService;
	
	public XAuthTokenConfigurer(TutorService tutorService, StudentService studentService)
	{
		super();
		this.tutorService = tutorService;
		this.studentService = studentService;
	}

	@Override
	public void configure(HttpSecurity http) throws Exception
	{
		XAuthTokenFilter customFilter = new XAuthTokenFilter(tutorService, studentService);
		http.addFilterBefore(customFilter, UsernamePasswordAuthenticationFilter.class);
	}
}
