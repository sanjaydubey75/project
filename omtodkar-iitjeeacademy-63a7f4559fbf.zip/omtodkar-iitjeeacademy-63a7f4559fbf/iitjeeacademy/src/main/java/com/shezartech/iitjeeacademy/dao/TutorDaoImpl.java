package com.shezartech.iitjeeacademy.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.shezartech.iitjeeacademy.entity.TutorEntity;
import com.shezartech.iitjeeacademy.response.tutor.TutorResponse;
import com.shezartech.iitjeeacademy.response.tutor.TutorResponse.StudentInfo;

@Repository
public class TutorDaoImpl extends DaoImpl<TutorEntity, Integer> implements TutorDao {

	public TutorDaoImpl(){
		super(TutorEntity.class);
	}
	
	@Override
	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		super.setSessionFactory(sessionFactory);
	}

	@Override
	public TutorEntity find(String email)
	{
		
		Criteria criteria = getCurrentSession().createCriteria(TutorEntity.class);
		criteria.add(Restrictions.eq("email", email));
		return (TutorEntity) criteria.uniqueResult();
	}
	
	/**
	 * The raw sql query for students whose targetyear is known is
	 * select distinct s1.TargetYear as TargetYear, (select Count(*) from `student` as s2 where s1.TargetYear = s2.TargetYear and s2.id in (Select t2.student from `tutortostudent` t2 where t2.tutor = t1.tutor)) as numberOfStudents FROM `student` as s1 , `tutortostudent` as t1 where (t1.tutor = '1' and t1.student = s1.id and s1.TargetYear IS NOT NULL)
	 * 
	 * The raw sql query for students whose targetyear is not known is
	 * select distinct s1.TargetYear as TargetYear, (select Count(*) from `student` as s2 where s2.TargetYear is null and s2.id in (Select t2.student from `tutortostudent` t2 where t2.tutor = t1.tutor)) as numberOfStudents FROM `student` as s1 , `tutortostudent` as t1 where (t1.tutor = '1' and t1.student = s1.id and s1.TargetYear IS NULL)
	 */
	@Override
	public List<TutorResponse.StudentInfo> getStudentInfo(TutorEntity tutor)
	{
		List<TutorResponse.StudentInfo> list = new ArrayList<TutorResponse.StudentInfo>();
		
		String queryString = "select distinct s1.targetYear as targetYear, "
				+ "(select Count(*) from com.shezartech.iitjeeacademy.entity.StudentEntity as s2 "
				+ "where s1.targetYear = s2.targetYear and s2.id in "
				+ "(Select t2.student.id from com.shezartech.iitjeeacademy.entity.TutorToStudentEntity t2 where t2.tutor.id = t1.tutor.id)) "
				+ "as numberOfStudents "
				+ "FROM com.shezartech.iitjeeacademy.entity.StudentEntity as s1 "
				+ ", com.shezartech.iitjeeacademy.entity.TutorToStudentEntity as t1 "
				+ "where (t1.tutor.id = :id and t1.student.id = s1.id and s1.targetYear is not null)";
		Query query = getCurrentSession().createQuery(queryString).setParameter("id", tutor.getId());
		
		for(Object object : query.list())
		{
			list.add(new StudentInfo((String)((Object[])object)[0], (Long)((Object[])object)[1]));
		}
		
		String queryString2 = "select distinct s1.targetYear as targetYear, "
				+ "(select Count(*) from com.shezartech.iitjeeacademy.entity.StudentEntity as s2 "
				+ "where s2.targetYear is null and s2.id in "
				+ "(Select t2.student.id from com.shezartech.iitjeeacademy.entity.TutorToStudentEntity t2 where t2.tutor.id = t1.tutor.id)) "
				+ "as numberOfStudents "
				+ "FROM com.shezartech.iitjeeacademy.entity.StudentEntity as s1 "
				+ ", com.shezartech.iitjeeacademy.entity.TutorToStudentEntity as t1 "
				+ "where (t1.tutor.id = :id and t1.student.id = s1.id and s1.targetYear is null)";
		Query query2 = getCurrentSession().createQuery(queryString2).setParameter("id", tutor.getId());
		
		for(Object object : query2.list())
		{
			list.add(new StudentInfo((String)((Object[])object)[0], (Long)((Object[])object)[1]));
		}
		
		//Hiberate typed query failed
//		String queryString = "select distinct NEW com.shezartech.iitjeeacademy.response.tutor.TutorResponse.StudentInfo(  s1.targetYear, (select Count(*) from com.shezartech.iitjeeacademy.entity.StudentEntity as s2 where s1.targetYear = s2.targetYear) as numberOfStudents) FROM com.shezartech.iitjeeacademy.entity.StudentEntity as s1 , com.shezartech.iitjeeacademy.entity.TutorToStudentEntity as t1 where (t1.tutor.id = :id and t1.student.id = s1.id)";
		
		//SQL Query failed
//		String queryString = "select distinct s1.TargetYear as targetYear, (select Count(*) from `student` as s2 where s1.TargetYear = s2.TargetYear) as numberOfStudents FROM `student` as s1 , `tutortostudent` as t1 where (t1.tutor = :id and t1.student = s1.id)";
//		Query query = getCurrentSession().createSQLQuery(queryString).addEntity(StudentInfo.class).setParameter("id", tutor.getId());
//		List<TutorResponse.StudentInfo> list = query.list();
		
		return list;
	}
}
