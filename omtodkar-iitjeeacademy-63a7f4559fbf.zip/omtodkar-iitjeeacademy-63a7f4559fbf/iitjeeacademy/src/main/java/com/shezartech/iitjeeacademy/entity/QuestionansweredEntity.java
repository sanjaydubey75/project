package com.shezartech.iitjeeacademy.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * Created by shobhit on 3/26/2015.
 */
@Entity
@Table(name = "questionanswered")
public class QuestionansweredEntity implements ModelEntity
{
	@Id
	@ManyToOne
	@JoinColumn(name = "userId", referencedColumnName = "id", nullable = false)
	private StudentEntity user;

	@Id
	@ManyToOne
	@JoinColumn(name = "questionId", referencedColumnName = "id", nullable = false)
	private QuestionEntity questionId;

	private int status;

	public StudentEntity getUserId()
	{
		return user;
	}

	public void setUserId(StudentEntity userId)
	{
		this.user = userId;
	}

	public QuestionEntity getQuestionId()
	{
		return questionId;
	}

	public void setQuestionId(QuestionEntity questionId)
	{
		this.questionId = questionId;
	}
}