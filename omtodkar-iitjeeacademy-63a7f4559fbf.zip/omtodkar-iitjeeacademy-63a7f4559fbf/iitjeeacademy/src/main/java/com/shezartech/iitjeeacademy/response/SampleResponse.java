package com.shezartech.iitjeeacademy.response;

public class SampleResponse extends Response{

	public SampleResponse(){
		super();
		super.setResponse(new Status("success", "if you are able to see this then this is properly configured", "success"));
	}
}
