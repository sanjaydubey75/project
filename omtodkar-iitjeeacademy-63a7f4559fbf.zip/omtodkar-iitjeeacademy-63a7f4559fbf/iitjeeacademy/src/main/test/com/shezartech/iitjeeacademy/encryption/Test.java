package com.shezartech.iitjeeacademy.encryption;


public class Test {

//	public static void main(String args[]) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException{
//		Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding");
//		SecretKeySpec secretKeySpecy = new SecretKeySpec("VXSBURAW1NUsuvDw2zz3zJTqwXoC3ZWI".getBytes(), "AES");
//		IvParameterSpec ivParameterSpec = new IvParameterSpec(Base64.decodeBase64("ajEonP7DEAtbqWMrc+Gd4A=="));
//		
//		cipher.init(Cipher.DECRYPT_MODE, secretKeySpecy, ivParameterSpec);
//		byte[] result = cipher.doFinal(Base64.decodeBase64("cRK6t8XVRxDQ392mRNM7BA=="));
//		
//		System.out.println(new String(result));
//		System.out.println(Hex.encodeHexString(result));
//		
//		//to find the maximum encryption by policy 
//		//System.out.println(Cipher.getMaxAllowedKeyLength("AES"));
//	}

}
