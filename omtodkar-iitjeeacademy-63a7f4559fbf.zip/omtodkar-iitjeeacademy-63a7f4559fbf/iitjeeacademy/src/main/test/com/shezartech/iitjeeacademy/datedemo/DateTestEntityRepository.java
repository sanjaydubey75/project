package com.shezartech.iitjeeacademy.datedemo;

import java.util.List;
import java.util.concurrent.Future;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.scheduling.annotation.Async;

import com.google.common.base.Optional;

public interface DateTestEntityRepository extends CrudRepository<DateTestEntity, Integer>
{
	@Async
	@Query("SELECT t FROM com.shezartech.iitjeeacademy.datedemo.DateTestEntity t WHERE t.title = :searchTerm")
	Future<Optional<DateTestEntity>> findById(@Param("searchTerm") String searchTerm);
	
	@Async
	Future<List<DateTestEntity>> findByTitle(String title);
	
	public String findTitleById(Integer id);
	
	public List<DateTestEntity> findByTitleOrId(String title, Integer id);
	
	public long countByTitle(String title);
	
	public List<DateTestEntity> findDistinctByTitle(String title);
	
	public List<DateTestEntity> findFirst3ByTitleOrderByTitleAsc(String title);
	
	/**
	 * Named query
	 * @return
	 */
	public List<DateTestEntity> findByTitleIs(@Param("title") String title);
}
