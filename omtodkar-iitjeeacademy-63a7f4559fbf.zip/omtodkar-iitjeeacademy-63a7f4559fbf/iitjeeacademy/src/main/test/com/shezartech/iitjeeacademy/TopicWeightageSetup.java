package com.shezartech.iitjeeacademy;

import java.util.Arrays;
import java.util.List;

import javax.transaction.Transactional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;

import com.shezartech.iitjeeacademy.config.DatabaseConfig;
import com.shezartech.iitjeeacademy.dao.SubjectDao;
import com.shezartech.iitjeeacademy.dao.TopicDao;
import com.shezartech.iitjeeacademy.dao.TopicWeightageDao;
import com.shezartech.iitjeeacademy.entity.SubjectEntity;
import com.shezartech.iitjeeacademy.entity.TopicEntity;
import com.shezartech.iitjeeacademy.entity.TopicWeightageEntity;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { DatabaseConfig.class })
@TransactionConfiguration(transactionManager = "txManager", defaultRollback = false) // for diabling automatic rollback of transaction while running unit tests 
public class TopicWeightageSetup
{
	private static boolean isInitialized = false;
	@Autowired private TopicDao topicDao;
	@Autowired private SubjectDao subjectDao;
	@Autowired private TopicWeightageDao topicWeightageDao;
	private static final Logger logger = LoggerFactory.getLogger(TopicWeightageSetup.class);

//	@Before
//	@Transactional
	private void initializeTopicWeightageDatabase()
	{
		if (isInitialized) return;
		logger.info("Initializing TopicWeightage database");
		
//		List<String> newTopicIds = Arrays.asList("ST", "C", "PEHL", "CN", "QE", "AGPS", "MTR", "DR", "ODE", "PC", "PRO", "ELA",
//				"FM", "ES", "ELMT", "SBE", "TE", "COC");
		List<String> oldTopicIds = Arrays.asList("2D", "A", "DC", "P", "EFM", "EXM", "TRCC");
		
		List<TopicEntity> topics = topicDao.findAll();
		for (TopicEntity topic : topics)
		{
			if(!oldTopicIds.contains(topic.getId()))
			{
				TopicWeightageEntity topicWeightageEntity = new TopicWeightageEntity();
				topicWeightageEntity.setName(topic.getName());
				topicWeightageEntity.setSubjectsBySubjectId(topic.getSubject());
				topicWeightageEntity.setTopicsByTopicId(topic);
				topicWeightageDao.persist(topicWeightageEntity);
			}
		}

		List<SubjectEntity> subjects = subjectDao.findAll();
		
		for (SubjectEntity subject : subjects)
		{
			List<TopicWeightageEntity> topicWeightageEntities = topicWeightageDao.findAll(subject);
			double subjectWeightage = (double) (1.0/topicWeightageEntities.size());
			
			for (TopicWeightageEntity topicWeightageEntity : topicWeightageEntities)
			{
				topicWeightageEntity.setSubjectWeightage(subjectWeightage);
			}
		}
		
		List<TopicWeightageEntity> topicWeightageEntities = topicWeightageDao.findAll();
		double globalWeightage = 1.0/topicWeightageEntities.size();
		for (TopicWeightageEntity topicWeightageEntity : topicWeightageEntities)
		{
			topicWeightageEntity.setGlobalWeightage(globalWeightage);
		}
		
		isInitialized = true;
	} 
	
	@Test
	@Transactional
	public void TestDb()
	{
		initializeTopicWeightageDatabase();
	}
}