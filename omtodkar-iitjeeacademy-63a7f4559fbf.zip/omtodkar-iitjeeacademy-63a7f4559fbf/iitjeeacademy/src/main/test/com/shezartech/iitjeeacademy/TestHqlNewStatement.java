package com.shezartech.iitjeeacademy;

import javax.transaction.Transactional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;

import com.shezartech.iitjeeacademy.config.WebConfig;
import com.shezartech.iitjeeacademy.dao.TutorDao;
import com.shezartech.iitjeeacademy.entity.TutorEntity;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { WebConfig.class })
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = true) // for enabling automatic rollback of transaction while running unit tests 
public class TestHqlNewStatement
{
	private static final Logger logger = LoggerFactory.getLogger(TestHqlNewStatement.class);
	
	@Autowired
	private TutorDao tutorDao;
	
	@Test
	@Transactional
	public void TestHqlSelectNew()
	{
		TutorEntity tutor = tutorDao.find("ralph@ralph.ralph");
		tutorDao.getStudentInfo(tutor);
	}
}