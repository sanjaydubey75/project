package com.shezartech.iitjeeacademy;

import java.util.Arrays;
import java.util.Date;
import java.util.Locale;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.InputStreamSource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import com.shezartech.iitjeeacademy.config.MailConfig;
import com.shezartech.iitjeeacademy.config.MvcTemplateConfig;
import com.shezartech.iitjeeacademy.config.WebConfig;


@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { MailConfig.class, MvcTemplateConfig.class })
public class TestMail
{
	@Autowired
	private JavaMailSender mailSender;

	@Autowired
	private TemplateEngine templateEngine;
	
	public void sendMail(String phoneNumber, String senderEmail, String typeOfQuery, String feedback) throws MessagingException
	{
		final Context ctx = new Context(new Locale("English"));
		ctx.setVariable("phoneNumber", phoneNumber);
		ctx.setVariable("email", senderEmail);
		ctx.setVariable("typeOfQuery", typeOfQuery);
		ctx.setVariable("feedback", feedback);
		
		this.sendSimpleMail(MailConfig.recipientMail, senderEmail, "Godrej Guru Contact form", ctx, "email-support.html");
	}

	/*
	 * Send HTML mail (simple template)
	 */
	private void sendSimpleMail(
			final String recipientEmail,
			final String senderEmail,
			final String subject,
			Context ctx,
			String emailTemplate
			)
			throws MessagingException
	{

		// Prepare the evaluation context
		

		// Prepare message using a Spring helper
		final MimeMessage mimeMessage = this.mailSender.createMimeMessage();
		final MimeMessageHelper message = new MimeMessageHelper(mimeMessage, "UTF-8");
		message.setSubject(subject);
		message.setFrom(senderEmail);
		message.setReplyTo(senderEmail);
		message.setTo(recipientEmail);

		// Create the HTML body using Thymeleaf
		final String htmlContent = this.templateEngine.process(emailTemplate, ctx);
		message.setText(htmlContent, true /* isHtml */);

		// Send email
		this.mailSender.send(mimeMessage);

	}
	
	@Test
	public void sendMail() throws MessagingException
	{
		try{
			this.sendMail("dfg", "abcd@gmail.com", "dsfdfg", "feedback");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
