package com.shezartech.iitjeeacademy.datedemo;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import javax.transaction.Transactional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;

import com.google.common.base.Optional;

@RunWith(SpringJUnit4ClassRunner.class)
//@WebAppConfiguration
@ContextConfiguration(classes = { DatabaseConfig.class })
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = false) // for diabling automatic rollback of transaction while running unit tests
public class DateTestTest
{

	@Autowired
	private DateTestEntityRepository dateTestEntityRepository;
	
	@Test
	@Transactional
	public void test() throws InterruptedException, ExecutionException
	{
		Future<Optional<DateTestEntity>> future = dateTestEntityRepository.findById("hi");
		Optional<DateTestEntity> optional = future.get();
		
		System.out.println("hyfk");
	}
}
