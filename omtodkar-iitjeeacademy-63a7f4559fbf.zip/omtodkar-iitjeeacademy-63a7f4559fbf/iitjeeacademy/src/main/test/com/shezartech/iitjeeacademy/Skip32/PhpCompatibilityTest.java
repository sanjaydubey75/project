package com.shezartech.iitjeeacademy.Skip32;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.util.Base64Utils;

import com.google.common.primitives.Longs;
import com.google.common.primitives.UnsignedInts;
import com.google.common.primitives.UnsignedLong;
import com.google.common.primitives.UnsignedLongs;

public class PhpCompatibilityTest
{
	//this is obtained from php by 
	//base64_encode(pack("H20", '0123456789abcdef0123'));
	private final String base64EncodedKey = "ASNFZ4mrze8BIw==";
	
	@Test
	public void testPhpEncryptedString()
	{
		//200 is encrypted using Skip32 php implementation to 1855109947
		//214 is encrypted using Skip32 php implementation to 3874607447
		
		byte[] key = Base64Utils.decodeFromString(base64EncodedKey);

		long id = 200L;

		int c = Skip32.encrypt((int)id, key);
		
		long b = UnsignedInts.toLong(c);

		long decryptedValue = 1855109947L;
		
		Assert.assertEquals(b, decryptedValue);
	}
	
	@Test
	public void testPhpDecryptedString()
	{
		byte[] key = Base64Utils.decodeFromString(base64EncodedKey);
		
		long encryptedValue = 1855109947L;
		
		int d = Skip32.decrypt((int)encryptedValue, key);
		
		long z = UnsignedInts.toLong(d);
		
		long phpDecryptedValue = 200L;
		
		Assert.assertEquals(z, phpDecryptedValue);
	}
	
	//just for learning purpose. Use Guava UnsignedInts.toLong for production
	public long getUnsignedInt(int x)
	{
	    return x & 0x00000000ffffffffL;
	}
}
