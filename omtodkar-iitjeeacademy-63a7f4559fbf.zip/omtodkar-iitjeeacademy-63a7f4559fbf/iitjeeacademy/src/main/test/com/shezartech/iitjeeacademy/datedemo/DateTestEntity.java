package com.shezartech.iitjeeacademy.datedemo;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.NamedQuery;

@Entity
@javax.persistence.Table(name = "test")
@NamedQuery(
		name = "DateTestEntity.findByTitleIs", 
		query = "SELECT t FROM com.shezartech.iitjeeacademy.datedemo.DateTestEntity t WHERE t.title = :title"
)
public class DateTestEntity implements Serializable
{

	@javax.persistence.Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	private String title;
	
	
}
