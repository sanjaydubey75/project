package com.shezartech.iitjeeacademy.datedemo;

import java.util.Properties;
import java.util.TimeZone;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.orm.hibernate4.LocalSessionFactoryBuilder;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

@Configuration
//@ComponentScan(basePackages = { "com.shezartech.iitjeeacademy.datedemo" })
@EnableJpaRepositories(basePackages = {
		"com.shezartech.iitjeeacademy.datedemo"
})
@EnableTransactionManagement
public class DatabaseConfig
{

	public DatabaseConfig()
	{
		TimeZone.setDefault(TimeZone.getTimeZone("Etc/UTC"));
	}
	
	private static class Connection
	{
		private static final String Url = "jdbc:mysql://localhost:3306/test";
		private static final String Username = "root";
		private static final String Password = "";
		private static final String UseSqlComments = "true";
		private static final String DriverClassName = "com.mysql.jdbc.Driver";
		
		private static class Hibernate
		{
			private static final String Dialect = "org.hibernate.dialect.MySQLDialect";
			private static final String ShowSql = "true";
			private static final String FormatSql = "true";
			private static final String Hbm2ddl = "none";
			private static final String ConnectionProviderClass = "com.zaxxer.hikari.hibernate.HikariConnectionProvider";
		}
	}
	
	@Bean
	public HikariConfig hikariConfig()
	{
		HikariConfig hikariConfig = new HikariConfig();
		hikariConfig.setDriverClassName(Connection.DriverClassName);
		hikariConfig.setJdbcUrl(Connection.Url);
		hikariConfig.setUsername(Connection.Username);
		hikariConfig.setPassword(Connection.Password);
		return hikariConfig;
	}
	
	@Bean(destroyMethod = "close")
	public DataSource dataSource(HikariConfig hikariConfig)
	{
		HikariDataSource dataSource = new HikariDataSource(hikariConfig);
		return dataSource;
	}
	
//	@Bean(name = "SessionFactory")
//	public SessionFactory sessionFactory(DataSource dataSource)
//	{
//		LocalSessionFactoryBuilder localSessionFactoryBuilder = new LocalSessionFactoryBuilder(dataSource);
//		localSessionFactoryBuilder.scanPackages("com.shezartech.iitjeeacademy.datedemo");
//		localSessionFactoryBuilder.addProperties(hibernateProperties());
//		return localSessionFactoryBuilder.buildSessionFactory();
//	}
	
	Properties hibernateProperties()
	{
		return new Properties()// this is magic!!
		{
			{
				//Configures the used database dialect. This allows Hibernate to create SQL
		        //that is optimized for the used database.
				setProperty("hibernate.dialect", Connection.Hibernate.Dialect);
				//If the value of this property is true, Hibernate writes all SQL
		        //statements to the console.
				setProperty("hibernate.show_sql", Connection.Hibernate.ShowSql);
				//If the value of this property is true, Hibernate will format the SQL
		        //that is written to the console.
				setProperty("hibernate.format_sql", Connection.Hibernate.FormatSql);
				setProperty("use_sql_comments", Connection.UseSqlComments);
				//Specifies the action that is invoked to the database when the Hibernate
		        //SessionFactory is created or closed.
				setProperty("hibernate.hbm2ddl.auto", Connection.Hibernate.Hbm2ddl);
				
				//there is also a property hibernate.ejb.naming_strategy with a possible value of org.hibernate.cfg.ImprovedNamingStrategy
			}
		};
	}
	
//	@Bean(name = "txManager")
//	public HibernateTransactionManager transactionManager(SessionFactory sessionFactory)
//	{
//		HibernateTransactionManager manager = new HibernateTransactionManager(sessionFactory);
//		return manager;
//	}
	
	@Bean
    LocalContainerEntityManagerFactoryBean entityManagerFactory(DataSource dataSource)
	{
        LocalContainerEntityManagerFactoryBean entityManagerFactoryBean = new LocalContainerEntityManagerFactoryBean();
        entityManagerFactoryBean.setDataSource(dataSource);
        entityManagerFactoryBean.setJpaVendorAdapter(new HibernateJpaVendorAdapter());
        entityManagerFactoryBean.setPackagesToScan("com.shezartech.iitjeeacademy.datedemo");
        entityManagerFactoryBean.setJpaProperties(hibernateProperties());
 
        return entityManagerFactoryBean;
    }
	
	@Bean
    JpaTransactionManager transactionManager(EntityManagerFactory entityManagerFactory) {
        JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(entityManagerFactory);
        return transactionManager;
    }
}
