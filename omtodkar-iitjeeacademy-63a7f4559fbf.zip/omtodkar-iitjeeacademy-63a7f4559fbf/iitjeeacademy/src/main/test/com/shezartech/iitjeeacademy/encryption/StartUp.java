package com.shezartech.iitjeeacademy.encryption;


public class StartUp {
	
//	public static void main(String args[]) {
//		
//		String password1 = "abcd1234";
////		String hashed1 = BCrypt.hashpw(password1, BCrypt.gensalt());
//		String hashed2 = "$2a$10$PtxoAwuJxrk9xAHLUhjas.H/YJnpM5GiCa20IgjNayH7TmVrt38aq";
//		String hashed3 = "$2a$10$HSkDAfoih9QCd5T6dsHn..f0RRCGhEDiY7Z3KrXQHgarK5FuPgNMC";
//		String hashed4 = "$2a$10$HSkDAfoih9QCd5T6dsHn..f0RRCGhEDiY7Z3KrXQHgarK5FuPgNMC";
//		
//		String hashed1 = "$2a$10$cjxtRGOZ760I7h0PfYSdoOWznYidl6SMcAe1SfV1HN6hkrNa8oey2";
//		
//		String a[] = {
//				"$2a$10$uaNy1ihwy0w7ZQ0SQyGdMu6Kia6nFA4invb0g/hmvspg7wHoSHLYC",
//				"$2a$10$wwEyTk5/mXqz22JmuRCBkO6OjaZS14NfZ5swwfnBY6O8553lEcS6i",
//				"$2a$10$Iw2gyVaApXY4Z5P./sFHZed84OcahVe3JGdD.p/8/jP0fbDMnKbjK",
//				"$2a$10$Fw2H9Niujt.7BnhrT5CCjetgZnrvs6spdvavm67erxEB1F8M3O1pa",
//				"$2a$10$fUp2ZwNGHvpZP6NOX.w71ewuUEZfKfMj8EKC7VmcuvUPNu2ftCpLu",
//				"$2a$10$COQUqa0fsrHagS8bsBY2P.HqHHzG8IScjGlIqreQeMeiZVMHDwnyK",
//				"$2a$10$Sknq9vSvs1lNnjEtfGRWMuF/8QUKGvJjIe4tXjMUJF5lmdcZCxHHq",
//				"$2a$10$56xOTMKx1feCbD9.LhxnDucakDlhWG3DSFVN7pleDHhkjfrollB12",
//				"$2a$10$7Bb5hRh6k3CLgEjbGhmIk.6Sas7bqC8OR4.JjVlSEuL9mODT0N6ES",
//				"$2a$10$jFOly9lYu37c.yFXXU2xtu/sk3.W8ZWfY1dErIsHoPFDl9fOSvltW"
//		};
//		for(int i = 0; i < 10; i++){
//			if (BCrypt.checkpw(password1, a[i]))
//				System.out.println("It matches");
//			else
//				System.out.println("It does not match");			
//		}
//		
//		
//		
////		String hashed = "$2y$10$cgi4WaxkUT1qmJECdZPJF.QjpErD0ZOnwzYff3n82/JiXfrb/I376";
////		String candidate = "abcd1234";
////		
////		if (BCrypt.checkpw(candidate, hashed))
////			System.out.println("It matches");
////		else
////			System.out.println("It does not match");
//	}

//	public static void main(String args[]){
//		Long time = System.currentTimeMillis()/1000;
//		
//		Long oldTime = Long.parseLong("1428079061");
//		Long diff = time - oldTime;
//		
//		System.out.println(time);
//		System.out.println(oldTime);
//		System.out.println(diff);
//	}
}
