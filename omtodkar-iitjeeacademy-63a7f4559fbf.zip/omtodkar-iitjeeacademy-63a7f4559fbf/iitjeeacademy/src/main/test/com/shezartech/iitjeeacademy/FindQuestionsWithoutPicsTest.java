package com.shezartech.iitjeeacademy;

import java.io.IOException;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import javax.transaction.Transactional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;

import com.shezartech.iitjeeacademy.config.WebConfig;
import com.shezartech.iitjeeacademy.dao.QuestionDao;
import com.shezartech.iitjeeacademy.entity.QuestionEntity;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { WebConfig.class })
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = false) // for diabling automatic rollback of transaction while running unit tests
public class FindQuestionsWithoutPicsTest
{

	@Autowired
	private QuestionDao questionDao;
	
	@Test
	@Transactional
	public void TestFindQuestions() throws IOException
	{
		List<QuestionEntity> questions = questionDao.findAll();
		
		String filePath = "D:\\development\\questionpic.zip";
		ZipFile zipFile = new ZipFile(filePath);
		Enumeration<? extends ZipEntry> entries = zipFile.entries();
		
		Set<String> filenames = new HashSet<String>();
		
		while(entries.hasMoreElements())
		{
			ZipEntry entry = entries.nextElement();
			if(!entry.getName().equals("questionpic/"))
				filenames.add(entry.getName().substring(12));
		}
		
		for (QuestionEntity question : questions)
		{
			List<String> pics = Arrays.asList(question.getPic(), question.getPicA(), question.getPicB(), question.getPicC(), question.getPicD());
			
			boolean isFaulty = false;
			
			for(String pic : pics)
			{
				if(!pic.equals("0"))
				{
					String picName = pic.substring(18);
					if(!filenames.contains(picName))
						isFaulty = true;
				}
			}
			
			if(isFaulty)
				System.out.println(question.getId());
		}
	}
}
