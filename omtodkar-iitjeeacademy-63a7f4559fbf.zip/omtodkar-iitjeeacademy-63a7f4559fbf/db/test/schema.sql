-- phpMyAdmin SQL Dump
-- version 4.2.10.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 22, 2015 at 02:52 PM
-- Server version: 5.6.16
-- PHP Version: 5.6.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `shezartc_elearning1`
--

-- --------------------------------------------------------

--
-- Table structure for table `accuracy`
--
-- Creation: Jun 18, 2015 at 08:56 AM
--

CREATE TABLE IF NOT EXISTS `accuracy` (
  `user_id` int(11) NOT NULL,
  `topic_id` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `accuracy` varchar(1000) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- RELATIONS FOR TABLE `accuracy`:
--   `topic_id`
--       `topics` -> `topic_id`
--   `user_id`
--       `student` -> `id`
--

-- --------------------------------------------------------

--
-- Table structure for table `databasechangelog`
--
-- Creation: Jun 18, 2015 at 09:01 AM
--

CREATE TABLE IF NOT EXISTS `databasechangelog` (
  `ID` varchar(255) NOT NULL,
  `AUTHOR` varchar(255) NOT NULL,
  `FILENAME` varchar(255) NOT NULL,
  `DATEEXECUTED` datetime NOT NULL,
  `ORDEREXECUTED` int(11) NOT NULL,
  `EXECTYPE` varchar(10) NOT NULL,
  `MD5SUM` varchar(35) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `COMMENTS` varchar(255) DEFAULT NULL,
  `TAG` varchar(255) DEFAULT NULL,
  `LIQUIBASE` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `databasechangeloglock`
--
-- Creation: Jun 18, 2015 at 09:01 AM
--

CREATE TABLE IF NOT EXISTS `databasechangeloglock` (
  `ID` int(11) NOT NULL,
  `LOCKED` bit(1) NOT NULL,
  `LOCKGRANTED` datetime DEFAULT NULL,
  `LOCKEDBY` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `institute`
--
-- Creation: Jun 18, 2015 at 09:01 AM
--

CREATE TABLE IF NOT EXISTS `institute` (
`id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `institutecouponcode`
--
-- Creation: Jun 18, 2015 at 09:04 AM
--

CREATE TABLE IF NOT EXISTS `institutecouponcode` (
  `value` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `registered` tinyint(1) NOT NULL,
  `subscriptionModel` int(11) NOT NULL,
  `discount` int(11) NOT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `instituteId_id` int(11) DEFAULT NULL,
  `tutor_id` int(11) DEFAULT NULL,
`id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- RELATIONS FOR TABLE `institutecouponcode`:
--   `tutor_id`
--       `tutor` -> `id`
--   `instituteId_id`
--       `institute` -> `id`
--

-- --------------------------------------------------------

--
-- Table structure for table `password_change_request`
--
-- Creation: Jun 18, 2015 at 08:56 AM
--

CREATE TABLE IF NOT EXISTS `password_change_request` (
  `user_id` int(11) NOT NULL,
  `hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- RELATIONS FOR TABLE `password_change_request`:
--   `user_id`
--       `student` -> `id`
--

-- --------------------------------------------------------

--
-- Table structure for table `questionanswered`
--
-- Creation: Jun 18, 2015 at 08:56 AM
--

CREATE TABLE IF NOT EXISTS `questionanswered` (
  `userId` int(11) NOT NULL,
  `questionId` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- RELATIONS FOR TABLE `questionanswered`:
--   `questionId`
--       `questions` -> `id`
--   `userId`
--       `student` -> `id`
--

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--
-- Creation: Jun 18, 2015 at 08:56 AM
--

CREATE TABLE IF NOT EXISTS `questions` (
  `id` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `subject_id` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `topic_id` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(5500) COLLATE utf8_unicode_ci NOT NULL,
  `pic` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `cha` varchar(1500) COLLATE utf8_unicode_ci NOT NULL,
  `pica` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `chb` varchar(1500) COLLATE utf8_unicode_ci NOT NULL,
  `picb` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `chc` varchar(1500) COLLATE utf8_unicode_ci NOT NULL,
  `picc` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `chd` varchar(1500) COLLATE utf8_unicode_ci NOT NULL,
  `picd` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `answer` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `attempt` bigint(20) NOT NULL,
  `correct` bigint(20) NOT NULL,
  `level` int(11) NOT NULL,
  `checked` int(11) NOT NULL,
  `BookId` int(11) NOT NULL,
  `PageNumber` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `SolutionAvailable` tinyint(1) NOT NULL,
  `timelimit` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- RELATIONS FOR TABLE `questions`:
--   `topic_id`
--       `topics` -> `topic_id`
--   `subject_id`
--       `subjects` -> `subject_id`
--

-- --------------------------------------------------------

--
-- Table structure for table `sampleranking`
--
-- Creation: Jun 18, 2015 at 08:58 AM
--

CREATE TABLE IF NOT EXISTS `sampleranking` (
`id` int(11) NOT NULL,
  `marks` int(11) NOT NULL,
  `students` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=102 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `share_friend_request`
--
-- Creation: Jun 18, 2015 at 08:58 AM
--

CREATE TABLE IF NOT EXISTS `share_friend_request` (
  `Id` char(36) COLLATE utf8_unicode_ci NOT NULL COMMENT '(DC2Type:guid)',
  `friendEmail` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `time` datetime NOT NULL,
  `studentId` int(11) NOT NULL,
  `question_id` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- RELATIONS FOR TABLE `share_friend_request`:
--   `question_id`
--       `questions` -> `id`
--   `studentId`
--       `student` -> `id`
--

-- --------------------------------------------------------

--
-- Table structure for table `statewiseselection`
--
-- Creation: Jun 18, 2015 at 08:58 AM
--

CREATE TABLE IF NOT EXISTS `statewiseselection` (
`id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `percentageSelected` double NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `student`
--
-- Creation: Jun 18, 2015 at 08:58 AM
--

CREATE TABLE IF NOT EXISTS `student` (
`id` int(11) NOT NULL,
  `state` int(11) NOT NULL,
  `password` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `firstName` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `lastName` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `institution` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `globalrank` int(11) NOT NULL,
  `stateRank` int(11) NOT NULL,
  `SubscriptionLimit` datetime DEFAULT NULL,
  `LastLoginTime` datetime DEFAULT NULL,
  `TargetYear` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `photopath` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `mobileNumber` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `parentEmail` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `transactionId` int(10) unsigned DEFAULT NULL,
  `couponCode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `subscriptionModel` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `registration_date` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- RELATIONS FOR TABLE `student`:
--   `state`
--       `statewiseselection` -> `id`
--

-- --------------------------------------------------------

--
-- Table structure for table `subjectglobalranks`
--
-- Creation: Jun 18, 2015 at 08:58 AM
--

CREATE TABLE IF NOT EXISTS `subjectglobalranks` (
  `user_id` int(11) NOT NULL,
  `rank` int(11) NOT NULL,
  `subjectId` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- RELATIONS FOR TABLE `subjectglobalranks`:
--   `subjectId`
--       `subjects` -> `subject_id`
--   `user_id`
--       `student` -> `id`
--

-- --------------------------------------------------------

--
-- Table structure for table `subjectlevels`
--
-- Creation: Jun 18, 2015 at 08:58 AM
--

CREATE TABLE IF NOT EXISTS `subjectlevels` (
  `user_id` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `subjectId` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `started_practice` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- RELATIONS FOR TABLE `subjectlevels`:
--   `subjectId`
--       `subjects` -> `subject_id`
--   `user_id`
--       `student` -> `id`
--

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--
-- Creation: Jun 18, 2015 at 08:58 AM
--

CREATE TABLE IF NOT EXISTS `subjects` (
  `subject_id` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `info` varchar(1000) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subjectstateranks`
--
-- Creation: Jun 18, 2015 at 08:58 AM
--

CREATE TABLE IF NOT EXISTS `subjectstateranks` (
  `user_id` int(11) NOT NULL,
  `rank` int(11) NOT NULL,
  `subjectId` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- RELATIONS FOR TABLE `subjectstateranks`:
--   `subjectId`
--       `subjects` -> `subject_id`
--   `user_id`
--       `student` -> `id`
--

-- --------------------------------------------------------

--
-- Table structure for table `topiclevels`
--
-- Creation: Jun 18, 2015 at 08:58 AM
--

CREATE TABLE IF NOT EXISTS `topiclevels` (
  `user_id` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `correctAttempts` int(11) DEFAULT NULL,
  `wrongAttempts` int(11) DEFAULT NULL,
  `score` double DEFAULT NULL,
  `topicId` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `levelTestAttempt` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- RELATIONS FOR TABLE `topiclevels`:
--   `user_id`
--       `student` -> `id`
--   `topicId`
--       `topics` -> `topic_id`
--

-- --------------------------------------------------------

--
-- Table structure for table `topics`
--
-- Creation: Jun 18, 2015 at 08:58 AM
--

CREATE TABLE IF NOT EXISTS `topics` (
  `topic_id` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `subject_id` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `info` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `order` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- RELATIONS FOR TABLE `topics`:
--   `subject_id`
--       `subjects` -> `subject_id`
--

-- --------------------------------------------------------

--
-- Table structure for table `topicweightage`
--
-- Creation: Jun 18, 2015 at 08:58 AM
--

CREATE TABLE IF NOT EXISTS `topicweightage` (
`id` int(11) NOT NULL,
  `topic_id` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `subject_id` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `subjectWeightage` double DEFAULT NULL,
  `globalWeightage` double DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- RELATIONS FOR TABLE `topicweightage`:
--   `topic_id`
--       `topics` -> `topic_id`
--   `subject_id`
--       `subjects` -> `subject_id`
--

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--
-- Creation: Jun 18, 2015 at 08:58 AM
--

CREATE TABLE IF NOT EXISTS `transactions` (
`transactionId` int(10) unsigned NOT NULL,
  `orderRefNumber` int(10) unsigned DEFAULT NULL,
  `invoiceNumber` int(10) unsigned DEFAULT NULL,
  `startTime` datetime DEFAULT NULL,
  `endTime` datetime DEFAULT NULL,
  `complete` tinyint(1) DEFAULT NULL,
  `registrationComplete` tinyint(1) DEFAULT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `firstName` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastName` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobileNumber` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `subscriptionModel` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `responseCode` int(11) DEFAULT NULL,
  `responseMessage` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EPGTransactionId` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `authIdentityCode` int(11) DEFAULT NULL,
  `RRN` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CVResponseCode` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=240 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tutor`
--
-- Creation: Jun 18, 2015 at 09:01 AM
--

CREATE TABLE IF NOT EXISTS `tutor` (
`id` int(11) NOT NULL,
  `address` varchar(1000) DEFAULT NULL,
  `Email` varchar(255) NOT NULL,
  `mobileNumber` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tutortostudent`
--
-- Creation: Jun 18, 2015 at 01:18 PM
--

CREATE TABLE IF NOT EXISTS `tutortostudent` (
  `tutor` int(11) NOT NULL,
  `student` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELATIONS FOR TABLE `tutortostudent`:
--   `student`
--       `student` -> `id`
--   `tutor`
--       `tutor` -> `id`
--

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accuracy`
--
ALTER TABLE `accuracy`
 ADD PRIMARY KEY (`user_id`,`topic_id`), ADD KEY `IDX_93450383A76ED395` (`user_id`), ADD KEY `IDX_934503831F55203D` (`topic_id`);

--
-- Indexes for table `databasechangeloglock`
--
ALTER TABLE `databasechangeloglock`
 ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `institute`
--
ALTER TABLE `institute`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `UNIQ_CA55B5D05E237E06` (`name`);

--
-- Indexes for table `institutecouponcode`
--
ALTER TABLE `institutecouponcode`
 ADD PRIMARY KEY (`id`), ADD KEY `IDX_F3E07A7446BEA33D` (`instituteId_id`), ADD KEY `FK_6xuf483lygxpog3uj0s3usgtu` (`tutor_id`);

--
-- Indexes for table `password_change_request`
--
ALTER TABLE `password_change_request`
 ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `questionanswered`
--
ALTER TABLE `questionanswered`
 ADD PRIMARY KEY (`userId`,`questionId`), ADD KEY `IDX_17E2BE8864B64DCC` (`userId`), ADD KEY `IDX_17E2BE884B476EBA` (`questionId`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
 ADD PRIMARY KEY (`id`), ADD KEY `IDX_8ADC54D523EDC87` (`subject_id`), ADD KEY `IDX_8ADC54D51F55203D` (`topic_id`);

--
-- Indexes for table `sampleranking`
--
ALTER TABLE `sampleranking`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `share_friend_request`
--
ALTER TABLE `share_friend_request`
 ADD PRIMARY KEY (`Id`), ADD KEY `IDX_F21869AE98BF2F98` (`studentId`), ADD KEY `IDX_F21869AE1E27F6BF` (`question_id`);

--
-- Indexes for table `statewiseselection`
--
ALTER TABLE `statewiseselection`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `UNIQ_12E0E2BC5E237E06` (`name`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `UNIQ_B723AF33E7927C74` (`email`), ADD KEY `IDX_B723AF33A393D2FB` (`state`);

--
-- Indexes for table `subjectglobalranks`
--
ALTER TABLE `subjectglobalranks`
 ADD PRIMARY KEY (`user_id`,`subjectId`), ADD KEY `IDX_2F278859A76ED395` (`user_id`), ADD KEY `IDX_2F2788593E0C34EB` (`subjectId`);

--
-- Indexes for table `subjectlevels`
--
ALTER TABLE `subjectlevels`
 ADD PRIMARY KEY (`user_id`,`subjectId`), ADD KEY `IDX_481495DA76ED395` (`user_id`), ADD KEY `IDX_481495D3E0C34EB` (`subjectId`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
 ADD PRIMARY KEY (`subject_id`);

--
-- Indexes for table `subjectstateranks`
--
ALTER TABLE `subjectstateranks`
 ADD PRIMARY KEY (`user_id`,`subjectId`), ADD KEY `IDX_CED6CFEA76ED395` (`user_id`), ADD KEY `IDX_CED6CFE3E0C34EB` (`subjectId`);

--
-- Indexes for table `topiclevels`
--
ALTER TABLE `topiclevels`
 ADD PRIMARY KEY (`user_id`,`topicId`), ADD KEY `IDX_AE2124E7A76ED395` (`user_id`), ADD KEY `IDX_AE2124E7E2E0EAFB` (`topicId`);

--
-- Indexes for table `topics`
--
ALTER TABLE `topics`
 ADD PRIMARY KEY (`topic_id`), ADD KEY `IDX_91F6463923EDC87` (`subject_id`);

--
-- Indexes for table `topicweightage`
--
ALTER TABLE `topicweightage`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `UNIQ_2A8028381F55203D` (`topic_id`), ADD KEY `IDX_2A80283823EDC87` (`subject_id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
 ADD PRIMARY KEY (`transactionId`), ADD UNIQUE KEY `UNIQ_EAA81A4C2506B64E` (`orderRefNumber`), ADD UNIQUE KEY `UNIQ_EAA81A4C26DEA64B` (`invoiceNumber`);

--
-- Indexes for table `tutor`
--
ALTER TABLE `tutor`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tutortostudent`
--
ALTER TABLE `tutortostudent`
 ADD PRIMARY KEY (`tutor`,`student`), ADD KEY `FK_student_student_id` (`student`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `institute`
--
ALTER TABLE `institute`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `institutecouponcode`
--
ALTER TABLE `institutecouponcode`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `sampleranking`
--
ALTER TABLE `sampleranking`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=102;
--
-- AUTO_INCREMENT for table `statewiseselection`
--
ALTER TABLE `statewiseselection`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `topicweightage`
--
ALTER TABLE `topicweightage`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=62;
--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
MODIFY `transactionId` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=240;
--
-- AUTO_INCREMENT for table `tutor`
--
ALTER TABLE `tutor`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `accuracy`
--
ALTER TABLE `accuracy`
ADD CONSTRAINT `FK_934503831F55203D` FOREIGN KEY (`topic_id`) REFERENCES `topics` (`topic_id`),
ADD CONSTRAINT `FK_93450383A76ED395` FOREIGN KEY (`user_id`) REFERENCES `student` (`id`);

--
-- Constraints for table `institutecouponcode`
--
ALTER TABLE `institutecouponcode`
ADD CONSTRAINT `FK_6xuf483lygxpog3uj0s3usgtu` FOREIGN KEY (`tutor_id`) REFERENCES `tutor` (`id`),
ADD CONSTRAINT `FK_F3E07A7446BEA33D` FOREIGN KEY (`instituteId_id`) REFERENCES `institute` (`id`);

--
-- Constraints for table `password_change_request`
--
ALTER TABLE `password_change_request`
ADD CONSTRAINT `FK_AC3A261FA76ED395` FOREIGN KEY (`user_id`) REFERENCES `student` (`id`);

--
-- Constraints for table `questionanswered`
--
ALTER TABLE `questionanswered`
ADD CONSTRAINT `FK_17E2BE884B476EBA` FOREIGN KEY (`questionId`) REFERENCES `questions` (`id`),
ADD CONSTRAINT `FK_17E2BE8864B64DCC` FOREIGN KEY (`userId`) REFERENCES `student` (`id`);

--
-- Constraints for table `questions`
--
ALTER TABLE `questions`
ADD CONSTRAINT `FK_8ADC54D51F55203D` FOREIGN KEY (`topic_id`) REFERENCES `topics` (`topic_id`),
ADD CONSTRAINT `FK_8ADC54D523EDC87` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`subject_id`);

--
-- Constraints for table `share_friend_request`
--
ALTER TABLE `share_friend_request`
ADD CONSTRAINT `FK_F21869AE1E27F6BF` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`),
ADD CONSTRAINT `FK_F21869AE98BF2F98` FOREIGN KEY (`studentId`) REFERENCES `student` (`id`);

--
-- Constraints for table `student`
--
ALTER TABLE `student`
ADD CONSTRAINT `FK_B723AF33A393D2FB` FOREIGN KEY (`state`) REFERENCES `statewiseselection` (`id`);

--
-- Constraints for table `subjectglobalranks`
--
ALTER TABLE `subjectglobalranks`
ADD CONSTRAINT `FK_2F2788593E0C34EB` FOREIGN KEY (`subjectId`) REFERENCES `subjects` (`subject_id`),
ADD CONSTRAINT `FK_2F278859A76ED395` FOREIGN KEY (`user_id`) REFERENCES `student` (`id`);

--
-- Constraints for table `subjectlevels`
--
ALTER TABLE `subjectlevels`
ADD CONSTRAINT `FK_481495D3E0C34EB` FOREIGN KEY (`subjectId`) REFERENCES `subjects` (`subject_id`),
ADD CONSTRAINT `FK_481495DA76ED395` FOREIGN KEY (`user_id`) REFERENCES `student` (`id`);

--
-- Constraints for table `subjectstateranks`
--
ALTER TABLE `subjectstateranks`
ADD CONSTRAINT `FK_CED6CFE3E0C34EB` FOREIGN KEY (`subjectId`) REFERENCES `subjects` (`subject_id`),
ADD CONSTRAINT `FK_CED6CFEA76ED395` FOREIGN KEY (`user_id`) REFERENCES `student` (`id`);

--
-- Constraints for table `topiclevels`
--
ALTER TABLE `topiclevels`
ADD CONSTRAINT `FK_AE2124E7A76ED395` FOREIGN KEY (`user_id`) REFERENCES `student` (`id`),
ADD CONSTRAINT `FK_AE2124E7E2E0EAFB` FOREIGN KEY (`topicId`) REFERENCES `topics` (`topic_id`);

--
-- Constraints for table `topics`
--
ALTER TABLE `topics`
ADD CONSTRAINT `FK_91F6463923EDC87` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`subject_id`);

--
-- Constraints for table `topicweightage`
--
ALTER TABLE `topicweightage`
ADD CONSTRAINT `FK_2A8028381F55203D` FOREIGN KEY (`topic_id`) REFERENCES `topics` (`topic_id`),
ADD CONSTRAINT `FK_2A80283823EDC87` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`subject_id`);

--
-- Constraints for table `tutortostudent`
--
ALTER TABLE `tutortostudent`
ADD CONSTRAINT `FK_student_student_id` FOREIGN KEY (`student`) REFERENCES `student` (`id`),
ADD CONSTRAINT `FK_tutor_tutor_id` FOREIGN KEY (`tutor`) REFERENCES `tutor` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
