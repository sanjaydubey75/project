--  *********************************************************************
--  Update Database Script
--  *********************************************************************
--  Change Log: src/main/resources/liquibase/changelog.xml
--  Ran at: 6/29/15 1:49 PM
--  Against: root@localhost@jdbc:mysql://localhost:3306/shezartc_elearning1
--  Liquibase version: 3.3.0
--  *********************************************************************



--  Changeset src/main/resources/liquibase/changelog.xml::1435565589238-1::shobhit (generated)
CREATE TABLE SubscribedUser (id INT PRIMARY KEY AUTO_INCREMENT NOT NULL, email VARCHAR(200) NOT NULL);

--  Changeset src/main/resources/liquibase/changelog.xml::1435565589238-3::shobhit (generated)
ALTER TABLE SubscribedUser ADD UNIQUE (email);

