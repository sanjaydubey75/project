
CREATE TABLE tutor (
	`id` int NOT NULL AUTO_INCREMENT, 
	`address` VARCHAR(1000) DEFAULT NULL, 
	`Email` VARCHAR(255) NOT NULL, 
	`mobileNumber` VARCHAR(255) NOT NULL, 
	`name` VARCHAR(255) NOT NULL, 
	`Password` VARCHAR(255) NOT NULL,
	PRIMARY KEY (`id`)
);

ALTER TABLE institute ADD email VARCHAR(255) NOT NULL;

ALTER TABLE institutecouponcode ADD tutor_id INT NULL;

ALTER TABLE institutecouponcode ADD CONSTRAINT FK_6xuf483lygxpog3uj0s3usgtu FOREIGN KEY (tutor_id) REFERENCES tutor (id);

ALTER TABLE institutecouponcode MODIFY instituteId_id INT NULL;

ALTER TABLE institutecouponcode MODIFY value VARCHAR(255) NOT NULL;

ALTER TABLE institutecouponcode MODIFY instituteId_id INT NULL;

ALTER TABLE institutecouponcode ALTER instituteId_id DROP DEFAULT;

ALTER TABLE institutecouponcode ADD id INT NOT NULL;

ALTER TABLE institutecouponcode DROP PRIMARY KEY;

ALTER TABLE institutecouponcode ADD PRIMARY KEY (id);

ALTER TABLE institutecouponcode MODIFY id INT NOT NULL Auto_increment;

ALTER TABLE institutecouponcode MODIFY instituteId_id INT NULL;