Please always adhere to following conventions for angularjs javascript front-end code.

Naming conventions.

1. Never name anything Pascal casing. Always use camel casing unless stated otherwise.
2. To inject service anywhere use absolute naming 
  For instance if module name is "app.web" and service name is "abc" in the same module, then to inject it use the name "app.web_abc"
    Use similar absolute naming convention for controllers.
    For directive name, never ever insert a dot in middle. For instance a directive in "app.web" module can be named as "app.web.newDirective"
    and will be inserted in html template as "app.web.new-directive"
    
3. regarding filters I'm unable to provide namespaces. If you find a way to namespace filters, please do so and make all relevant changes.