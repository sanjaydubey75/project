angular.module('app.web.home')
    .controller('app.web.home_registerController', [
        "app.web.register_registerFactory", "$scope", "app.web.register_registerService",
        "app.web.register_registerDetailsFactory", "$state", "app.web.student.resource_stateFactory",
        "$auth", "app.security_principal",
        function (RegisterFactory, $scope, RegisterService,
                  RegisterDetailsFactory, $state, stateFactory,
                  $auth, principal)
        {
            RegisterFactory.getStates().then(function(result){
                $scope.states = result;
            });

            $scope.register1 = function () {
                if ($scope.RegisterFormTrial.$valid && !$scope.RegisterFormTrial.$pending) {
                    RegisterDetailsFactory.setUser($scope.user);
                    RegisterService.registertrial().then(function () {

                        $auth.login({
                            email: $scope.user.email,
                            password: $scope.user.password,
                            type: 'student'
                        }).then(function(result)
                        {
                            principal.authenticate(result.data);
                            $state.go('app.web.student.home');
                        });
                    });
                }
            };

            //make sure to handle the case when the user has revoked some permissions like email address
            $scope.authenticate = function(provider) {
                $auth.authenticate(provider)
                    .then(function(result) {
                        principal.authenticate(result.data);
                    })
                    .catch(function(response) {
                        console.log(response);
                    });
            };
        }
    ])
	.controller('app.web.home_whyiitjeeController', ['$scope', function ($scope) {
		$scope.points = [
			{
				"title": "Understands your Child",
				"content": "A Personalized Practice Management System designed by Experts to Gauge the student’s Preparation Level ! We optimize the student’s time for a Focused Preparation.",
				"color": 'yellow',
				'arrowcolor': 'yellowarrow'
			},
			{
				"title": "Value for Money",
				"content": "IITJEE Academy is a powerful supplement to the Classroom IITJEE Preparation. We complement the preparation in a nominal price and with multiple benefits.",
				"color": 'blue',
				'arrowcolor': 'bluearrow'
			},
			{
				"title": "Anytime Anywhere ( Practice on the Go)",
				"content": "Our Academy comes straight to your child, with a click where your child can practice on a Computer, Laptop, Tablet or simply on a mobile phone with our app.",
				"color": 'black',
				'arrowcolor': 'blackarrow'
			}

		];
	}])
	.controller('app.web.home_featuresController', function($scope){
		$scope.features = [{
			"title": "Balanced Preparation",
			"content": "The student can practice each topic in all the three subjects and get a collated report of their overall performance, ensuring a balanced preparation."
		}, {
			"title": "Social Learning",
			"content": "The student is never alone, they are competing  and interacting with their peers through IITJEE Practice Management System. They can interact with their Tutors, Inhouse Experts and Friends to share their problems and challenges."
		}, {
			"title": "Adaptive",
			"content": "IITJEE Academy is an intuitive Practice Management System that tracks the students past and current performance tracking a pattern and recommending sessions  as per their  current level."
		}, {
			"title": "Top of the Line Faculty",
			"content": "IITJEE Academy  has been developed by a team of  comprising of  IITians  and Professors available for advise and counseling to students."
		}, {
			"title": "Time Optimization",
			"content": "IITJEE Academy monitors and identifies the student’s weak areas and recommends practice plan accordingly."
		}, {
			"title": "Know your Rank",
			"content": "You can know your All India Rank and Your State Rank while Practicing on the platform."
		}];
	})
	.controller('app.web.home_testimonialsController', function($scope){
		$scope.testimonials=[{
			"content": "IITJEE Academy is a complete package. I found it very engaging and competitive. It is a must for every IIT aspiring student.",
			"name": "Harshit Maheshwari, IIT Kanpur"
		}, {
			"content": "IITJEE Academy creates an environment that is conducive to the IITJEE preparation. I liked their rank approach as it creates a sense of a real competition.",
			"name": "Akshay Kumar, IIT Bombay"
		}, {
			"content": "The practice sessions are exhaustive and excellent for a home preparation. IITJEE Academy ensures an indepth preparation. I wish I had this program while appearing for IIT.",
			"name": "Vinit Kataria, IIT Delhi"
		}];
	})
	.controller('app.web.home_howitworksController', function ($scope) {
		this.points = [
			{
				"title": "Level 1 (Beginner)",
				"content": "Solve entry level questions."
			},
			{
				"title": "Level 2 (Junior)",
				"content": "Solve Questions to build a Solid foundation  in each topic."
			},
			{
				"title": "Level 3 (Intermediate)",
				"content": "Gear you up for the real entrance examinations."
			},
			{
				"title": "Level 4 (Senior)",
				"content": "Now you are ready to compete with the most competitive brains in the country."
			},
			{
				"title": "Level 5 (AIEEE)",
				"content": "You are ready to qualify in JEE Mains."
			},
			{
				"title": "Level 6 (IIT JEE)",
				"content": "Get set to Qualify in IITJEE."
			},
			{
				"title": "Level 7 (Top 100)",
				"content": "Congratulations! You compete as an IIT JEE Topper!"
			},

		];
	})
	.controller('app.web.home_contactUsController', function($http, $scope, $modal, $timeout){
		$scope.send = function(){
			if($scope.ContactUsForm.$valid){
				$http.post('api/contactus', $scope.user).then(function(result){
                    if(result.data.response.status == 'success'){
                        var modalInstance =	$modal.open({
                            templateUrl: "contactUsModalContent.html",
                            size: 'sm'
                        });
                        $timeout(function(){
                            modalInstance.dismiss();
                        }, 3000);
                    }
				});
			}
		}
	})
;