angular.module('app.web.home')
	.factory('redirect', ['$rootScope', '$state', 'app.security_principal',
		function($rootScope, $state, principal)
		{
			return {
				redirectToHome: function()
				{
					return principal.identity()
						.then(function()
						{
							var isAuthenticated = principal.isAuthenticated();

							if(isAuthenticated)
							{
								var type = principal.getType();
								if(type == "student")
									$state.go("app.web.student.home");
								else if(type == "tutor")
									$state.go("app.web.tutor.dashboard");
							}
						});
				}
			};
		}
	])
;