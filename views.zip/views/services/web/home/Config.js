angular.module('app.web.home')
	.config(['$stateProvider', '$locationProvider', '$urlRouterProvider',
		function($stateProvider, $locationProvider, $urlRouterProvider)
		{
			$locationProvider.html5Mode(true);
			$urlRouterProvider.otherwise("/");
			$stateProvider
				.state('app.web.home',
				{
					url: "/",
					views:
					{
						"": {
							templateUrl: 'views/partials/home/home.html'
						},
                        "register@app.web.home": {
                            templateUrl: 'views/partials/home/register/register.html',
                            controller: 'app.web.home_registerController',
                            controllerAs: 'homeRegister'
                        },
						"main@app.web.home": {
							templateUrl: "views/partials/home/main/main.html"
						},
						"whyiitjee@app.web.home": {
							controller: 'app.web.home_whyiitjeeController',
							controllerAs: 'whyCtrl',
							templateUrl: 'views/partials/home/whyiitjee/whyiitjee.html'
						},
						"features@app.web.home": {
							templateUrl: 'views/partials/home/features/features.html',
							controller: 'app.web.home_featuresController'
						},
						"howitworks@app.web.home": {
							templateUrl: 'views/partials/home/howitworks/howitworks.html',
							controller: 'app.web.home_howitworksController',
							controllerAs: 'howitworks'
						},
                        "comparison@app.web.home":{
                            templateUrl:'views/partials/home/comparison/comparison.html'
                        },
						"testimonials@app.web.home": {
							templateUrl: 'views/partials/home/testimonials/testimonials.html',
							controller: "app.web.home_testimonialsController"
						}
					},
					resolve: {
						redirectToHome: ['app.web.home_redirect', function(redirect)
						{
							return redirect.redirectToHome();
						}]
					}
				})
				.state('app.web.privacypolicy',
				{
					url: '/privacypolicy',
					templateUrl: 'views/partials/home/privacypolicy.html'
				})
				.state('app.web.aboutus',
				{
					url: '/AboutUs',
					templateUrl: 'views/partials/home/aboutus.html'
				})
				.state('app.web.faqs',
				{
					url: '/faqs',
					templateUrl: 'views/partials/home/faqs.html'
				})
				.state('app.web.contactus',
				{
					url: '/ContactUs',
					templateUrl: 'views/partials/home/contactus.html',
					controller: 'app.web.home_contactUsController'
				})
				.state('app.web.help',
				{
					url: '/help',
					templateUrl: 'views/partials/home/help.html'
				})
			;
		}])
;