angular.module('app.web.feedback')
	.config(function($stateProvider, $locationProvider, $urlRouterProvider){
		$locationProvider.html5Mode(true);
		$urlRouterProvider.otherwise("/");
		$stateProvider
			.state('app.web.feedback', {
				url: '/feedback',
				templateUrl: 'views/partials/feedback/index.html',
				controller: 'app.web.feedback_feedbackController'
			})
		;

	})
;