angular.module('app.web.feedback', ['ui.router'])
	.namespace({
		delimiter: '_',
		methods: [
			'factory',
			'service',
			'provider',
			'constant',
			'value'
		]
	});