angular.module('app.web.feedback')
	.controller('app.web.feedback_feedbackController', [
		"$scope", "app.web.feedback_feedbackFactory", "$timeout",
		function($scope, FeedbackFactory, $timeout){
			$scope.sendFeedback = function(){
				if($scope.FeedbackForm.$valid){
					FeedbackFactory.sendFeedback($scope.user).then(function(message){
						$scope.message = message;
						$timeout(function(){
							$scope.message = null;
							$scope.user = null;
							$scope.FeedbackForm.$setPristine(true);
						}, 3000);
					});
				}
			}
		}
	])
;