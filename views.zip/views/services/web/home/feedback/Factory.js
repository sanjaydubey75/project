angular.module('app.web.feedback')
	.factory('feedbackFactory', function($q, $http){
		var sendFeedback = function($data){
			var defer = $q.defer();
			$http.post('api/auth/sendfeedback', $data, {}).then(function(result){
				if(result.data.response.status == 'success')defer.resolve(result.data.response.message);
				else defer.reject(result.data.response.message);
			});
			return defer.promise;
		};

		return {
			sendFeedback: sendFeedback
		};
	})
;