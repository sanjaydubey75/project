angular.module('app.web.home', ['ui.router', 'app.web.feedback', 'app.web.student.resource', 'app.web.register'])
	.namespace({
		delimiter: '_',
		methods: [
			'factory',
			'service',
			'provider',
			'constant',
			'value'
		]
	});