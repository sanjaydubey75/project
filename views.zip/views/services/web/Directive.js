angular.module('app.web')
	.directive('app.web.footer', function () {
		return {
			restrict: 'E',
			scope:{},
			//replace: true,
			templateUrl: "views/partials/footer.html",
			link:function(scope){
				scope.contents = [
					{'text':"About Us", 'link':'AboutUs'},
					{'text':"Privacy Policy", 'link':'privacypolicy'},
					{'text':"Contact Us", 'link':'ContactUs'},
					{'text':"FAQs", 'link':'faqs'}
					//{'text':"Copyright \u00A9 2014 - Shezar Edubox Pvt. Ltd.", 'link':""}
				];
			}
		};
	})
	.directive('app.web.menuBar', function(){
		return {
			restrict : 'E',
			scope : {
				principal : '=principal'
			},
			templateUrl: 'views/partials/menuBar.html'
		};
	})
    .directive('app.web.buyNow', ['$http','$q', function ($http) {
	    return {
	        restrict: 'E',
	        scope: {
	            principal: '=principal'
	        },
	        templateUrl: 'views/partials/buyNow.html',
	        link: function (scope, elem, attrs, ngModel) {
	            //console.log(scope);

	            scope.isTrail = function () {
	                var flag = false;
	                if (localStorage.getItem("app.identity.subscribe")) {
	                    var subscribe = angular.fromJson(localStorage.getItem("app.identity.subscribe"));

	                    var subscribeDate = new Date(parseInt(subscribe.Limit));
	                    var currentDate = new Date();
	                    var results = (subscribe.Model == 4) ? true : (currentDate <= subscribeDate ? false : true);

	                    return results;
	                }
	                return flag;
	            }
	        }
	    };
	}])
	.directive('equals', function() {
		return {
			restrict: 'A', // only activate on element attribute
			require: '?ngModel', // get a hold of NgModelController
			link: function(scope, elem, attrs, ngModel) {
				if(!ngModel) return; // do nothing if no ng-model

				// watch own value and re-validate on change
				scope.$watch(attrs.ngModel, function() {
					validate();
				});

				// observe the other value and re-validate on change
				attrs.$observe('equals', function (val) {
					validate();
				});

				var validate = function() {
					// values
					var val1 = ngModel.$viewValue;
					var val2 = attrs.equals;

					// set validity
					ngModel.$setValidity('equals', val1 === val2);
				};
			}
		}
	})
	.directive('focusme', function($timeout) {
		return {
			restrict: 'A',
			scope: { },
			link: function(scope, element) {
				$timeout(function(){
					element[0].focus();
				}, 0);
			}
		};
	})
;