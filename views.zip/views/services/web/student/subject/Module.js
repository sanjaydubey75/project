angular.module('app.web.student.subject', ['ui.router'])
	.namespace({
		delimiter: '_',
		methods: [
			'factory',
			'service',
			'provider',
			'constant',
			'value'
		]
	})
;