angular.module('app.web.student.subject')
	.controller('app.web.student.subject_subjectController', [
		"$scope", "app.web.student.resource_subjectFactory", "$stateParams", "app.topic_topicResource",
		"app.topic_topicService", "$filter", "$modal", "app.web.student.resource_studentFactory", "$state",
		function($scope, subjectFactory, $stateParams, topicResource,
		         topicService, $filter, $modal, studentFactory, $state){

			$scope.subjectController = {
				subject: subjectFactory.getSubject($stateParams.id),
				topics: topicResource.query({subjectId: $stateParams.id}, function(topics){
					topicService.sort(topics);
					topicService.filterTopicsForTrialStudent(topics);
				}),
				searchTopic: "",
				filter: function(topics){
					var a = $filter('filter')(topics, {name: $scope.subjectController.searchTopic});

					var begin = (($scope.subjectController.paginationSettings.currentPage - 1) *
						$scope.subjectController.paginationSettings.itemsPerPage),
						end = begin + $scope.subjectController.paginationSettings.itemsPerPage;

					$scope.subjectController.paginationSettings.totalItems = a.length;

					return a.slice(begin, end);
				},
				open: function(topic){
					$scope.subjectController.modalInstance = $modal.open({
						templateUrl: 'views/partials/subject/topicDetails.html',
						controller: 'app.web.student.subject_modalInstanceCtrl',
						resolve: {
							topic: function () {
								return topic;
							}
						}
					});
				},
				paginationSettings: {
					totalItems: 1,
					currentPage: 1,
					itemsPerPage: 6
				},
				getQuestion: function(topic){
					studentFactory.getTopicLevel({id: topic.id}).$promise.then(function(topicLevel){
						if (topicLevel.levelTestAttempt == false)
							$state.go('app.web.question', {
								subid: $stateParams.id,
								topicid: topic.id
							});
						else {
							$state.go('app.web.topicLevelTest', {topicId: topic.id});
						}
					});
				},
                checkVideo: function(topic){
                    if(topic.lecture == false){
                        return true;
                    }
                },
                getLecture: function (topic) {
                    $state.go('app.web.student.video', {
                        subId: $stateParams.id,
                        topicId: topic.id
                    });
                }
			};
		}
	])
	.controller('app.web.student.subject_modalInstanceCtrl', function ($scope, $modalInstance, topic) {
		$scope.topic = topic;
		$scope.ok = function () {
			$modalInstance.close();
		};
	})
;