angular.module('app.web.student.home')
	.controller('app.web.student.home_studentHomeController', [
		"$scope", "$state", "app.web.student.home_studentHomeService", "app.web.student.resource_subjectFactory",
		function($scope, $state, StudentService, subjectFactory)
		{
			$scope.chooseTopic = function (subject)
			{
				$state.go('app.web.student.subject', {id: subject.id});
			};

			$scope.formatDate =StudentService.formatDate;
			if (localStorage.getItem("app.identity.subscribe")) {
			    localStorage.removeItem("app.identity.subscribe");
			}

			var subscribe = {};
			subscribe.Limit = $scope.user.subscriptionLimit;
			subscribe.Model = $scope.user.subscriptionModel;

			localStorage.setItem("app.identity.subscribe", angular.toJson(subscribe));

			$scope.userProperties = {
				profilePhoto: 'iitjeeacademy/static/student/profilepics/' +
					($scope.user.photopath == '0' ? 'user.png' : $scope.user.photopath),
				lastLogin: angular.fromJson(localStorage.getItem("app.identity")).lastLogin,
				subjects: subjectFactory.getSubjects()
			};
		}
	])
;