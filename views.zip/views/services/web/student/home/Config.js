angular.module('app.web.student.home')
	.config(['$stateProvider', '$locationProvider', '$urlRouterProvider',
		function ($stateProvider, $locationProvider, $urlRouterProvider)
		{
			$locationProvider.html5Mode(true);
			$urlRouterProvider.otherwise("/");
			$stateProvider
				.state('app.web.student.home', {
					url: '',
					templateUrl: 'views/partials/student/home/index.html',
					controller: 'app.web.student.home_studentHomeController',
					resolve: {
						'app.web.student_studentProfileResolve': [
							"app.web.student_studentProfileResolve",
							function(studentProfileResolve)
							{
								return studentProfileResolve.validateIfProfileComplete();
							}
						]
					}
				})
			;
		}
	]);