angular.module('app.web.student.home', ['ui.router', 'app.subject', 'app.web.student.resource'])
	.namespace({
		delimiter: '_',
		methods: [
			'factory',
			'service',
			'provider',
			'constant',
			'value'
		]
	})
;