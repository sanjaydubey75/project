angular.module('app.web.student.home')
	.factory('studentHomeService', [
		function()
		{
			//this is for tip of iceberg. For the whole thing, consider using moment.js
			var formatDate = function(timestamp, fmt) {
				date = new Date(timestamp);
				function pad(value) {
					return (value.toString().length < 2) ? '0' + value : value;
				}
				var months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
				return fmt.replace(/%([a-zA-Z])/g, function (_, fmtCode) {
					switch (fmtCode) {
						case 'Y':
							return date.getFullYear();
						case 'M':
							return months[date.getMonth()];
						case 'd':
							return pad(date.getDate());
						case 'H':
							return pad(date.getHours());
						case 'm':
							return pad(date.getMinutes());
						case 's':
							return pad(date.getSeconds());
						default:
							throw new Error('Unsupported format code: ' + fmtCode);
					}
				});
			};

			return {
				formatDate: formatDate
			};
		}
	])
;