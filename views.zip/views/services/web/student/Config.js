angular.module('app.web.student')
	.config(['$stateProvider', '$locationProvider', '$urlRouterProvider',
		function ($stateProvider, $locationProvider, $urlRouterProvider)
		{
			$locationProvider.html5Mode(true);
			$urlRouterProvider.otherwise("/");
			$stateProvider
				.state('app.web.student', {
					url: '/iitjeeprogram',
					template: '<ui-view/>',
					abstract: true,
					controller: 'app.web.student_studentController',
					data: {
						allowedTypes: ['student']
					},
					resolve: {
						'app.web.student_studentResolve': [
							"app.web.student.resource_studentFactory",
							function(Student)
							{
								return Student.get().$promise;
							}
						]
					}
				})
				.state('app.web.student.pricing',
					{
						url: '/pricing',
						templateUrl: 'views/partials/register/pricing.html',
						controller: 'app.web.student_pricingController',
						controllerAs: 'pricing'
					})
				.state('app.web.student.posttransaction',
				{
					url: '/postTransaction',
					templateUrl: 'views/partials/register/posttransaction.html',
					controller: 'app.web.student_postTransactionController'
				})
			;
		}
	]);