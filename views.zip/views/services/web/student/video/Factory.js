/**
 * Created by Omkar on 25-Nov-15.
 */
angular.module('app.web.student.video');