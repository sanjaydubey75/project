/**
 * Created by Omkar on 25-Nov-15.
 */
angular.module('app.web.student.video', ['ui.router'])
    .namespace({
        delimiter: '_',
        methods: [
            'factory',
            'service',
            'provider',
            'constant',
            'value'
        ]
    })
;