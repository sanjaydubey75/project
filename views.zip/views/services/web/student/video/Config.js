/**
 * Created by Omkar on 25-Nov-15.
 */
angular.module('app.web.student.video')
    .config(['$stateProvider', '$locationProvider', '$urlRouterProvider',
        function ($stateProvider, $locationProvider, $urlRouterProvider)
        {
            $locationProvider.html5Mode(true);
            $urlRouterProvider.otherwise("/");
            $stateProvider
                .state('app.web.student.video', {
                    url: '/lectures/:subId/:topicId',
                    templateUrl: 'views/partials/student/video/playlist.html',
                    controller: 'app.web.student.video_lecturesController',
                    controllerAs:'playlist'
                })
            ;
        }
    ])
;