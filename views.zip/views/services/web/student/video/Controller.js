/**
 * Created by Omkar on 25-Nov-15.
 */
angular.module('app.web.student.video')
    .controller('app.web.student.video_lecturesController',
    ["$scope", "$state", "$window", "$modal", "$stateParams", "app.topic_topicResource", "app.topic_lectureResource",
        function ($scope, $state, $window, $modal, $stateParams, topicResource, lectureResource) {

            topicResource.get({id: $stateParams.topicId}).$promise.then(function(topic) {
                $scope.topic = topic;
                $scope.backToTopics = function (topic)
                {
                    $state.go('app.web.student.subject', {id: topic.subject.id});
                };
            }, function(errResponse){});



            $scope.videoListController = {
                lectures: lectureResource.query({id: $stateParams.topicId}),

                open: function(lecture){
                    $scope.subjectController.modalInstance = $modal.open({
                        templateUrl: 'views/partials/student/video/video.html',
                        controller: 'app.web.student.video_playController',
                        resolve: {
                            lecture: function () {
                                return lecture;
                            }
                        }
                    });
                }
            };
    }])
    .controller('app.web.student.video_playController', function ($scope, $modalInstance, lecture) {
        $scope.name = lecture.title;
        $scope.theBestVideo = lecture.video;

        $scope.playerVars = {
            controls: 1,
            autoplay: 1
        };

        $scope.info = lecture.info;
        $scope.subject = lecture.topic.subject.name;

        $scope.$on('youtube.player.playing', function($event, player){
            player.playVideo();
        });

        $scope.close = function () {
            $modalInstance.close();
        };
    })
;