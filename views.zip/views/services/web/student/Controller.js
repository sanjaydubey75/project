angular.module('app.web.student')
	.controller('app.web.student_studentController', [
		"app.web.student_studentResolve", "$scope",
		function (Student, $scope)
		{
			$scope.user = Student;

			$scope.setUser = function(user){
				$scope.user = user;
			};
		}
	])
	.controller('app.web.student_pricingController', [
		"$scope","app.web.student_studentResolve","app.web.student_registerDetailsFactory", "$location", "app.web.student_registerService", "$state",
		function ($scope,Student, RegisterDetailsFactory, $location, RegisterService, $state) {

			$scope.user = Student;

			$scope.models = [
				{'duration': 'Six months', 'price': '2,500', 'id': 1},
				{'duration': 'One year', 'price': '3,000', 'id': 2},
				{'duration': 'Two years', 'price': '5,000', 'id': 3}
			];

			
			
			$scope.canReload = true;
	
			$scope.subscribe = function (model) {
				RegisterDetailsFactory.setUser($scope.user);
				$scope.canReload = false;
				RegisterService.openPaymentGateway(model).then(function () {
					$scope.canReload = true;
					$state.go('app.web.student.posttransaction');
				}, function (error) {
					$scope.canReload = true;
					$state.go('app.web.student.posttransaction');
				});
				
			};
		}])
	.controller('app.web.student_postTransactionController', [
	"app.web.student_transaction", "$scope", "app.web.student_postTransactionService",
	function (Transaction, $scope, PostTransactionService) {
		Transaction.getResult().then(function (transaction) {
			$scope.txSuccess = transaction.status.transaction;
			$scope.regSuccess = transaction.status.registration;
			$scope.transactionDetails = PostTransactionService.sort(transaction.details);
		});
	}])
;