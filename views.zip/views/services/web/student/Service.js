angular.module('app.web.student')
	.factory('registerService', [
		"app.web.student_registerFactory", "app.web.student_registerDetailsFactory",
		"$window", "$cookieStore", "$q", "$timeout", /*"app.web.student_tutorEntity",*/
		function (RegisterFactory, RegisterDetailsFactory,
		          $window, $cookieStore, $q, $timeout/*, TutorEntity*/) {
			var register = function () {
				var defer = $q.defer();
				RegisterFactory.register(RegisterDetailsFactory.getUser())
					.finally(function () {
						RegisterDetailsFactory.setUser({});
						defer.resolve();
					});
				return defer.promise;
			};

			var registertrial = function () {
				var defer = $q.defer();
				RegisterFactory.registertrial(RegisterDetailsFactory.getUser())
					.then(function () {
						RegisterDetailsFactory.setUser({});
						defer.resolve();
					});
				return defer.promise;
			};

			var _paymentGatewayWindow;

			var _postTransaction = function () {
				var defer = $q.defer();
				var transactionStatus = $cookieStore.get('transactionDetails');
				if ((transactionStatus != null) && transactionStatus.status) {
					RegisterDetailsFactory.addProperty('transactionId', transactionStatus.transactionId);
					
					var user = RegisterDetailsFactory.getUser();
					var subscribe = {};
					subscribe.Model = user.model;
					subscribe.Limit =  transactionStatus.subscribeLimit; 
					
					localStorage.setItem("app.identity.subscribe", angular.toJson(subscribe));
					
					defer.resolve();
					//register().then(function () {
					//	defer.resolve();
					//});
				} else {
					$timeout(function () {
						defer.reject('transaction incomplete');
					}, 0);
				}
				return defer.promise;
			};

			var _createForm = function (verb, url, data, target) {
				var form = document.createElement("form");
				form.action = url;
				form.method = verb;
				form.target = target || "_self";
				if (data) {
					for (var key in data) {
						var input = document.createElement("textarea");
						input.name = key;
						input.value = typeof data[key] === "object" ? JSON.stringify(data[key]) : data[key];
						form.appendChild(input);
					}
				}
				form.style.display = 'none';
				return form;
			};

			var openPaymentGateway = function (model) {
				var deferred = $q.defer();

				if (model) {
					RegisterDetailsFactory.addProperty('model', model.id);
				}

				$cookieStore.remove('transactionDetails');
				var params = [
					'height=' + screen.height * .8,
					'width=' + screen.width * .8
					//'fullscreen = yes' // only works in IE, but here for completeness
				].join(',');
				if (_paymentGatewayWindow) {
					_paymentGatewayWindow.close();
				}
				_paymentGatewayWindow = $window.open('', 'pg', params);
				_paymentGatewayWindow.focus();

				var interval = window.setInterval(function () {
					try {
						if (_paymentGatewayWindow == null || _paymentGatewayWindow.closed) {
							window.clearInterval(interval);
							_postTransaction().then(function () {
								deferred.resolve();
							}, function (error) {
								deferred.reject(error);
							});
						}
					} catch (e) {
						console.log(e);
					}
				}, 1000);

				var user = RegisterDetailsFactory.getUser();
				var lowerCaseUserObj ={} ;
				
				angular.forEach(user, function(value, key) {
					lowerCaseUserObj[key.toLowerCase()] = value;
				});
				lowerCaseUserObj["subscribeupdate"] = true;
				
				delete lowerCaseUserObj["couponcode"];
				var form = _createForm('GET', '/PaymentGatewayUrl/start', lowerCaseUserObj, "pg");
				document.documentElement.appendChild(form);
				form.submit();
				return deferred.promise;
			};

			var registerTutor = function (tutor) {
				var deferred = $q.defer();

				RegisterFactory.registerTutor(new TutorEntity(tutor)).then(function () {
					deferred.resolve();
				}, function (error) {
					deferred.reject(error);
				});

				return deferred.promise;
			};

			return {
				register: register,
				registertrial: registertrial,
				openPaymentGateway: openPaymentGateway,
				registerTutor: registerTutor
			}
		}
	])
	.factory('validateFormService', ["app.web.student_registerFactory", "$timeout",
		function (RegisterFactory, $timeout)
		{
			var data = null;
			var timesValidated = 0;
			var response = null;

			var checkValidity = function (user) {
				if (angular.equals(user, data)) {
					return;
				}

				data = angular.copy(user);
				//first increment the counter
				timesValidated++;

				//now check if form is valid from server
				RegisterFactory.validate(data).then(function (result) {
					timesValidated--;
					if (result.response.status == "success") {
						if (result.redirectStatus == 'PG') response = 1;
						else if (result.redirectStatus == 'Pricing') response = 2;
						else if (result.redirectStatus == 'Register') response = 3;
					} else {
						response = null;
					}
				});
			};
			var getResponse = function () {
				if (timesValidated != 0)return null;
				return response;
			};

			var reset = function () {
				data = null;
				timesValidated = 0;
				response = null;
			};

			return {
				checkValidity: checkValidity,
				getResponse: getResponse,
				reset: reset
			};
		}])
	.factory('postTransactionService', function ()
	{
		var sort = function (transactiondetails)
		{
			var keyOrder = ['Name', 'Email', 'Invoice Number', 'Message', 'Amount Paid', 'Transaction Date', 'Subscription Duration', 'Coupon Code'];
			var arr = [];
			keyOrder.forEach(function (key)
			{
				if (transactiondetails[key])
				{
					arr.push({name: key, value: transactiondetails[key]});
				}
			});
			return arr;
		};

		return {
			sort: sort
		}
	})
;