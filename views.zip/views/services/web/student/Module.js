angular.module(
	'app.web.student', ['ui.router', 'app.web.student.home', 'app.web.student.setting',
	'app.web.student.resource', 'app.web.student.subject', 'app.web.student.video'])
	.namespace({
		delimiter: '_',
		methods: [
			'factory',
			'service',
			'provider',
			'constant',
			'value'
		]
	})
;