angular.module('app.web.student.resource')
	.factory('studentFactory', [
		"$resource",
		function ($resource)
		{
			return $resource('iitjeeacademy/api/v1/student/me', {},
				{
					'saved': {
						method: 'POST',
						url: 'iitjeeacademy/api/v1/student/me',

						//IMPORTANT!!! You might think this should be set to 'multipart/form-data'
						// but this is not true because when we are sending up files the request
						// needs to include a 'boundary' parameter which identifies the boundary
						// name between parts in this multi-part request and setting the Content-type
						// manually will not set this boundary parameter. For whatever reason,
						// setting the Content-type to 'false' will force the request to automatically
						// populate the headers properly including the boundary parameter.
						headers: { 'Content-Type': undefined },

						//This method will allow us to change how the data is sent up to the server
						// for which we'll need to encapsulate the model data in 'FormData'
						transformRequest: function (data) {

							var formData = new FormData();

							//need to convert our json object to a string version of json otherwise
							// the browser will do a 'toString()' on the object which will result
							// in the value '[Object object]' on the server.
							formData.append("model", angular.toJson(data.model));

							//now add all of the assigned files
							for (var i = 0; i < data.files.length; i++) {
								//add each file to the form data and iteratively name them
								formData.append("file" + i, data.files[i], data.files[i].name);
							}
							return formData;
						}
					},
					'getSubjectLevels': {
						method: 'GET',
						params: {},
						isArray: true,
						url: 'iitjeeacademy/api/v1/student/me/subjectLevels'
					},
					'getSubjectGlobalRanks': {
						method: 'GET',
						params: {},
						isArray: true,
						url: 'iitjeeacademy/api/v1/student/me/subjectGlobalRanks'
					},
					'getSubjectStateRanks': {
						method: 'GET',
						params: {},
						isArray: true,
						url: 'iitjeeacademy/api/v1/student/me/subjectStateRanks'
					},
					'getMotivator': {
						method: 'GET',
						params: {},
						isArray: false,
						url: 'iitjeeacademy/api/v1/student/me/motivator'
					},
					'createOrUpdateMotivator': {
						method: 'POST',
						params: {},
						isArray: false,
						url: 'iitjeeacademy/api/v1/student/me/motivator'
					},
					'getTopicLevel': {
						method: 'GET',
						params: {},
						isArray: false,
						url: 'iitjeeacademy/api/v1/student/me/topicLevel/:id'
					}
				});
		}
	])
	.factory('stateFactory', [
		"$resource",
		function($resource)
		{
			return $resource('iitjeeacademy/api/v1/state/:id');
		}
	])
	.factory('compulsoryFields', [
		"$resource",
		function($resource)
		{
			return $resource('iitjeeacademy/api/v1/student/me/emptyProfileFields', {}, {
				get: {method: 'GET', isArray: true}
			});
		}
	])
	.factory('subjectFactory', [
		"app.subject_subjectResource", "$q", "app.web.student.resource_studentFactory",
		function(subjectResource, $q, StudentFactory)
		{
			var find = function(array, id, key) {
				var temp = null;
				array.forEach(function(obj){
					if(obj[id] == key)
						temp = obj;
				});
				return temp;
			};

			return {
				getSubjects: function() {
					var temp = [];

					$q.all([
						subjectResource.query().$promise,
						StudentFactory.getSubjectLevels().$promise,
						StudentFactory.getSubjectGlobalRanks().$promise,
						StudentFactory.getSubjectStateRanks().$promise
					])
						.then(function(result)
						{
							var subjects = result[0];
							subjects.forEach(function(subject){
								subject.level = find(result[1], 'subject', subject.id).level;
								subject.globalRank = find(result[2], 'subject', subject.id).rank;
								subject.stateRank = find(result[3], 'subject', subject.id).rank;
								temp.push(subject);
							});
						});
					return temp;
				},
				getSubject: function(id){
					var subject = {};
					var defer = $q.defer();
					$q.all([
						subjectResource.get({id: id}).$promise,
						StudentFactory.getSubjectLevels().$promise,
						StudentFactory.getSubjectGlobalRanks().$promise,
						StudentFactory.getSubjectStateRanks().$promise
					])
						.then(function(result)
						{
							angular.copy(result[0], subject);
							subject.level = find(result[1], 'subject', subject.id).level;
							subject.globalRank = find(result[2], 'subject', subject.id).rank;
							subject.stateRank = find(result[3], 'subject', subject.id).rank;
							defer.resolve(subject);
						});
					return subject;
				}
			}
		}
	])

;