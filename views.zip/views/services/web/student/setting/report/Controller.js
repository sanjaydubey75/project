angular.module('app.web.student.setting.report')
	.controller('app.web.student.setting.report_reportController', [
		"$scope", "app.web.student.setting.report_correctAndWrongQuestionFactory",
		function($scope, correctAndWrongQuestionFactory)
		{
			$scope.reportController = {
				topicCorrectWrong: {
					getOptions: correctAndWrongQuestionFactory.getOptions,
					metaData: correctAndWrongQuestionFactory.getMetaData(),
					setSubject: correctAndWrongQuestionFactory.setSubject,
					topics: correctAndWrongQuestionFactory.getTopics()
				}
			};
		}
	])
;