angular.module('app.web.student.setting.report', ['ui.router', 'nvd3'])
	.namespace({
		delimiter: '_',
		methods: [
			'factory',
			'service',
			'provider',
			'constant',
			'value'
		]
	})
;