angular.module('app.web.student.setting')

	//this directive will hide or show stuff on small screen (col-xs-*)
	//and vice-versa for large screen (col-sm-*, col-md-*, col-lg-*)
	.directive('app.web.student.setting.hide', [
		"$window",
		function($window)
		{
			return {
				restrict: 'A',
				scope: {
					hide: "="
				},
				link: function(scope, elem, attrs)
				{
					var process = function()
					{
						var width = $window.innerWidth;
						if(width < 768)//small width device
						{
							if(scope.hide)//hide this object
							{
								elem.addClass('hidden');
							}
							else//show the object
							{
								elem.removeClass('hidden');
							}
						}
						else
						{
							if(scope.hide)//show the object
							{
								elem.removeClass('hidden');
							}
							else//hide the object
							{
								elem.addClass('hidden');
							}
						}
					};
					//watch the size of screen
					scope.$watch(function()
					{
						return $window.innerWidth;
					}, function(width)
					{
						process();
					});

					angular.element($window).bind('resize', function() {
						process();
					});
				}
			};
		}
	])

	//enable or disable snapper at runtime
	.directive('app.web.student.setting.snapConfig', [
		"snapRemote", "$window",
		function(snapRemote, $window)
		{
			return {
				restrict: 'A',
				scope:{},
				link: function(scope, elem, attrs)
				{
					var process = function()
					{
						var width = $window.innerWidth;
						snapRemote.getSnapper().then(function (snapper) {
							if (width < 768) //enable scrolling
								snapper.enable();
							else //disable scrolling
							{
								snapRemote.close();
								snapper.disable();
							}
						});
					};

					scope.$watch(function()
					{
						return $window.innerWidth;
					}, function(width)
					{
						process();
					});

					angular.element($window).bind('resize', function() {
						process();
					});
				}
			};
		}
	])
	//does not work
	.directive('app.web.student.setting.hideWhenSnapOpen', [
		"snapRemote",
		function(snapRemote)
		{
			return {
				restrict: 'A',
				link: function(scope, elem, attrs)
				{
					var state;
					var hideWhenSnapOpen = attrs['hideWhenSnapOpen'];
					if (hideWhenSnapOpen) {
						snapRemote.getSnapper().then(function (snapper) {
							state = snapper.state().state;
						});
						scope.$watch(function () {
							return state;
						}, function (result) {
							console.log(result);
						})
					}
				}
			};
		}
	])
;