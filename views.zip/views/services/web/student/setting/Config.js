angular.module('app.web.student.setting')
	.config(['$stateProvider', '$locationProvider', '$urlRouterProvider',
		function ($stateProvider, $locationProvider, $urlRouterProvider)
		{
			$locationProvider.html5Mode(true);
			$urlRouterProvider.otherwise("/");
			$stateProvider
				.state('app.web.student.setting', {
					url: '/setting',
					views: {
						"": {
							templateUrl: 'views/partials/student/setting/index.html'
						},
						"side-menu@app.web.student.setting": {
							templateUrl: 'views/partials/student/setting/side-menu.html'
						}
					}
				})
			;
		}
	]);