angular.module('app.web.student.setting.profile')
	.controller('app.web.student.setting.profile_profileDisplayController', [
		"$state", "app.web.student.resource_stateFactory", "$scope",
		function ($state, stateFactory, $scope) {
		    //get list of states
		    if ($scope.user.state)
		        $scope.state = stateFactory.get({ id: $scope.user.state });
		    $scope.edit = function () { $state.go('app.web.student.setting.profile.edit') };
		}
	])
	.controller('app.web.student.setting.profile_profileEditController', [
		"$state", "app.web.student.resource_stateFactory", "$scope", "app.web.student.resource_compulsoryFields",
		"app.web.student.setting.profile_profileFactory", 'dateFilter',
		function ($state, stateFactory, $scope, compulsoryFields,
		         profileFactory, dateFilter) {

		    $scope.format = 'yyyy-MM-dd';
		    $scope.dateOptions = {
		        formatYear: 'yy',
		        startingDay: 1
		    };
		    $scope.maxDate = new Date();
		    $scope.opened = false;
		    $scope.open = function ($event) {
		        $event.preventDefault();
		        $event.stopPropagation();

		        $scope.opened = true;
		    };
		    $scope.$watch('user.birthday', function (value) {
		        if (angular.isDefined(value)) {
		            var viewValue = new Date(value);
		            var date = viewValue ? dateFilter(viewValue, $scope.format) : '';
		            $scope.user.birthday = date;
		            //console.log($scope.user.birthday);
		        }
		    });

		    $scope.profileEditController = {
		        compulsoryFields: compulsoryFields.get(),
		        states: stateFactory.query(),
		        save: function () {
		            profileFactory.save($scope.user, $scope.profileEditController.stateName,
						$scope.profileEditController.states, $scope.profilePic)
						.then(function (newUser) {
						    $scope.setUser(newUser);
						});
		            $state.go('app.web.student.setting.profile.view');
		        },
		        cancel: function () {
		            $state.go('app.web.student.setting.profile.view');
		        }
		    };

		    var subscribe = {};
		    subscribe.Limit = $scope.user.subscriptionLimit;
		    subscribe.Model = $scope.user.subscriptionModel;

		    localStorage.setItem("app.identity.subscribe", angular.toJson(subscribe));

		    if ($scope.user.state) {
		        stateFactory.get({ id: $scope.user.state }).$promise.then(function (state) {
		            $scope.profileEditController.stateName = state.name;
		        });
		    }
		}
	]);