angular.module('app.web.student.setting.profile')
	.directive('app.web.student.setting.profile.isSubsetOf', function(){
		return{
			require: 'ngModel',
			restrict: 'A',
			scope:{
				model: '=ngModel',
				set: '=set'
			},
			link: function(scope, elem, attr, ngModel){
				ngModel.$validators.isNotSubsetOf = function(modelValue, viewValue){
					if(ngModel.$isEmpty(modelValue))
						return true;
					if(!scope.set.$resolved)
						return true;
					var temp = false;
					scope.set.forEach(function(state)
					{
						if(state.name === viewValue){
							temp = true;
						}
					});
					return temp;
				};
			}
		};
	})
	//.directive('app.web.student.setting.profile.uploadImage', [
	//	"$compile", "$q", "$http", "FileUploader", "$window", "app.interceptor_customHeadersFactory",
	//	function($compile, $q, $http, FileUploader, $window, customHeadersFactory){
	//
	//		var templateUrl = 'views/partials/student/setting/profile/uploadImage.html';
	//
	//		var directiveData, dataPromise;
	//		function loadData(){
	//			//if we already have a promise, just return that
	//			//so it doesn't run twice.
	//			if(dataPromise) {
	//				return dataPromise;
	//			}
	//			var deferred = $q.defer();
	//			dataPromise = deferred.promise;
	//			if(directiveData) {
	//				//if we already have data, return that.
	//				deferred.resolve(directiveData);
	//			}else{
	//				$http.get(templateUrl)
	//					.success(function(data) {
	//						directiveData = data;
	//						deferred.resolve(directiveData);
	//					}).error(function() {
	//						deferred.reject('Failed to load data');
	//					});
	//			}
	//			return dataPromise;
	//		}
	//
	//		//var e = angular.element(template);
	//		var link = function(scope, elem, attrs){
	//
	//			scope.uploader = new FileUploader({
	//				url: 'api/auth/photoupload',
	//				removeAfterUpload: true,
	//				queueLimit: 1,
	//				headers: {}
	//			});
	//
	//			scope.uploader.onBeforeUploadItem = function(fileItem){
	//				fileItem.headers = customHeadersFactory.getHeaders()
	//			};
	//
	//			scope.uploader.onAfterAddingFile = function(item){
	//				var fr = new FileReader();
	//				fr.onload = function () {
	//					var location = 'url('+fr.result+')';
	//					elem.css({
	//						backgroundImage: location,
	//						backgroundSize: 'cover',
	//						backgroundRepeat: 'no-repeat',
	//						backgroundPosition: 'center center'
	//					});
	//				};
	//				var file = document.querySelector('input[nv-file-select]').files[0];
	//				fr.readAsDataURL(file);
	//				scope.uploader.uploadAll();
	//			};
	//
	//			//scope.uploadFile = function(){
	//			//    scope.uploader.uploadAll();
	//			//};
	//
	//			scope.getFile = function getFile(){
	//				if(scope.uploader.queue.length > 0){
	//					scope.uploader.clearQueue();
	//				}
	//				document.getElementById("upfile").click();
	//			};
	//
	//			scope.$watch('src', function(){
	//				if(attrs.src){
	//					var location = 'url('+attrs.src+')';
	//					elem.css({
	//						backgroundImage: location,
	//						backgroundSize: 'cover',
	//						backgroundRepeat: 'no-repeat',
	//						backgroundPosition: 'center center'
	//					});
	//				}
	//			}, true);
	//
	//			loadData().then(function(data){
	//				template = data;
	//			});
	//
	//			elem.on('mouseenter', function(){
	//
	//				var a;
	//				if(a = elem[0].childNodes[0]){
	//					a.style.visibility = 'visible';
	//				}
	//				else{
	//					var content = $compile(template)(scope);
	//					elem.append(content);
	//				}
	//			});
	//			elem.on('mouseleave', function(){
	//				var a = elem[0].childNodes[0];
	//				a.style.visibility = 'hidden';
	//			})
	//		};
	//
	//		return {
	//			restrict: 'A',
	//			scope:{
	//				src: '@',
	//				uploadImage: '&'
	//			},
	//			link: link
	//		};
	//	}
	//]);
;