angular.module('app.web.student.setting.profile', ['ui.router', 'app.web.student.resource', 'ngFileUpload', 'ui.bootstrap.datepicker'])
	.namespace({
		delimiter: '_',
		methods: [
			'factory',
			'service',
			'provider',
			'constant',
			'value'
		]
	})
;