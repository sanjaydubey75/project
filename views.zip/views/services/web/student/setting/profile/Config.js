angular.module('app.web.student.setting.profile')
	.config(['$stateProvider', '$locationProvider', '$urlRouterProvider',
		function ($stateProvider, $locationProvider, $urlRouterProvider)
		{
			$locationProvider.html5Mode(true);
			$urlRouterProvider.otherwise("/");
			$stateProvider
				.state('app.web.student.setting.profile', {
					url: '/profile',
					views: {
						"": {
							template: '<ui-view/>'
						}
					},
					abstract: true
				})
				.state('app.web.student.setting.profile.view', {
					url: '',
					views: {
						"": {
							templateUrl: 'views/partials/student/setting/profile/index.html',
							controller: 'app.web.student.setting.profile_profileDisplayController'
						}
					}
				})
				.state('app.web.student.setting.profile.edit', {
					url: '/edit',
					views: {
						"": {
							templateUrl: 'views/partials/student/setting/profile/edit.html',
							controller: 'app.web.student.setting.profile_profileEditController'
						}
					}
				})
			;
		}
	]);