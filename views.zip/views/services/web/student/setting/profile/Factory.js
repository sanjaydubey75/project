angular.module('app.web.student.setting.profile')
	.factory('profileFactory', [
		"app.web.student.resource_studentFactory",
		function(studentFactory)
		{
			return {
				save: function(user, stateName, states, profilePic)
				{
					states.forEach(function(state)
					{
						if(state.name === stateName)
						{
							user.state = state.id;
						}
					});

					//Create an object that contains the model and files which will be transformed
					return studentFactory.saved({ model: user, files: profilePic == null ? [] : [profilePic] }).$promise;
				}
			};
		}
	]);