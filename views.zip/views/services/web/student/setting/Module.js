angular.module('app.web.student.setting',['ui.router',
	'app.web.student.setting.motivator',
	'app.web.student.setting.profile',
	'app.web.student.setting.report', 'snap'])
	.namespace({
		delimiter: '_',
		methods: [
			'factory',
			'service',
			'provider',
			'constant',
			'value'
		]
	})
;