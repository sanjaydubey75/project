angular.module('app.web.student.setting.motivator', ['ui.router'])
	.namespace({
		delimiter: '_',
		methods: [
			'factory',
			'service',
			'provider',
			'constant',
			'value'
		]
	})
;