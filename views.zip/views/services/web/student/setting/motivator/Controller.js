angular.module('app.web.student.setting.motivator')
	.controller('app.web.student.setting.motivator_motivatorDisplayController', [
		"$state", "app.web.student.resource_studentFactory", "$scope", "app.web.student.setting.motivator_motivatorFactory",
		function($state, studentFactory, $scope, motivatorFactory)
		{
			$scope.motivatorDisplayController = {
				motivator: motivatorFactory.getMotivator(),
				edit: function(){
					$state.go('app.web.student.setting.motivator.edit');
				}
			}
		}
	])
	.controller('app.web.student.setting.motivator_motivatorEditController', [
		"$state", "app.web.student.resource_studentFactory", "$scope", "app.web.student.setting.motivator_motivatorFactory",
		function($state, studentFactory, $scope, motivatorFactory)
		{
			$scope.motivatorEditController = {
				motivator: motivatorFactory.getMotivator(),
				save: function()
				{
					motivatorFactory.setMotivator($scope.motivatorEditController.motivator);
					$state.go('app.web.student.setting.motivator.view');
				},
				cancel: function()
				{
					$state.go('app.web.student.setting.motivator.view');
				}
			};
		}
	])
;