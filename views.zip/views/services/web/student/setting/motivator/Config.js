angular.module('app.web.student.setting.motivator')
	.config(['$stateProvider', '$locationProvider', '$urlRouterProvider',
		function ($stateProvider, $locationProvider, $urlRouterProvider)
		{
			$locationProvider.html5Mode(true);
			$urlRouterProvider.otherwise("/");
			$stateProvider
				.state('app.web.student.setting.motivator', {
					url: '/motivator',
					views: {
						"": {
							template: '<ui-view/>'
						}
					},
					abstract: true
				})
				.state('app.web.student.setting.motivator.view', {
					url: '',
					views: {
						"": {
							templateUrl: 'views/partials/student/setting/motivator/index.html',
							controller: 'app.web.student.setting.motivator_motivatorDisplayController'
						}
					}
				})
				.state('app.web.student.setting.motivator.edit', {
					url: '/edit',
					views: {
						"": {
							templateUrl: 'views/partials/student/setting/motivator/edit.html',
							controller: 'app.web.student.setting.motivator_motivatorEditController'
						}
					}
				})
			;
		}
	])
;