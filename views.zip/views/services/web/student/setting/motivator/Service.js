angular.module('app.web.student.setting.motivator')
	.factory('motivatorFactory', [
		"app.web.student.resource_studentFactory", "$q",
		function(studentFactory, $q){

			var motivator;

			return {
				getMotivator: function(){
					var defer = $q.defer();
					var temp = {};
					if(!motivator){
						studentFactory.getMotivator().$promise.then(function(result){
							motivator = result;
							angular.copy(motivator, temp);
							defer.resolve(temp);
						});
					} else{
						angular.copy(motivator, temp);
						defer.resolve(temp);
					}
					return temp;
				},
				setMotivator: function(motivator1){
					angular.copy(motivator1, motivator);

					studentFactory.createOrUpdateMotivator(motivator1);
				}
			}
		}
	])