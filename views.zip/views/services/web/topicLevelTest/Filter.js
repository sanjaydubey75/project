angular.module('app.web.topicLevelTest')
	.filter('formatAnswerFilter', function(){
		return function(array){
			var temp = angular.copy(array);
			temp.sort();
			var result = [];
			temp.forEach(function(item){
				result.push(item.toUpperCase());
			});
			return result.toString();
		}
	})
;