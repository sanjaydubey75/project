angular.module('app.web.topicLevelTest')
	.config(function ($stateProvider, $locationProvider, $urlRouterProvider, localStorageServiceProvider) {
		$locationProvider.html5Mode(true);
		$urlRouterProvider.otherwise("/");
		$stateProvider
			.state('app.web.topicLevelTest', {
				url: '/TopicLevelTest/:topicId',
				template: '<ui-view/>',
				controller: 'app.web.topicLevelTest_topicLevelTestAbstractController'
			})
			.state('app.web.topicLevelTest.promptTopicLevelTest', {
				url: "",
				views: {
					"": {
						templateUrl: "views/partials/TopicLevelTest/TopicLevelTest.prompt.html",
						controller: 'app.web.topicLevelTest_topicLevelTestPromptController'
					},
					"header@app.web.topicLevelTest.promptTopicLevelTest": {
						templateUrl: "views/partials/TopicLevelTest/TopicLevelTest.header.html"
					}
				}
			})
			.state('app.web.topicLevelTest.404TopicLevelTest', {
				url: "",
				views: {
					"": {
						templateUrl: "views/partials/TopicLevelTest/TopicLevelTest.404.html"
					},
					"header@app.web.topicLevelTest.404TopicLevelTest": {
						templateUrl: "views/partials/TopicLevelTest/TopicLevelTest.header.html"
					}
				}
			})
			.state('app.web.topicLevelTest.startTopicLevelTest', {
				url: "",
				views: {
					"": {
						templateUrl: 'views/partials/TopicLevelTest/TopicLevelTest.start.html',
						controller: 'app.web.topicLevelTest_topicLevelTestStartController'
					},
					"question@app.web.topicLevelTest.startTopicLevelTest": {
						templateUrl: 'views/partials/TopicLevelTest/question.html'
					},
					"choices@app.web.topicLevelTest.startTopicLevelTest": {
						templateUrl: 'views/partials/TopicLevelTest/choices.html'
					},
					"menubar@app.web.topicLevelTest.startTopicLevelTest": {
						templateUrl: 'views/partials/TopicLevelTest/questionsMenubar.html'
					},
					"tabbar@app.web.topicLevelTest.startTopicLevelTest": {
						templateUrl: 'views/partials/TopicLevelTest/tabbar.html'
					},
					"header@app.web.topicLevelTest.startTopicLevelTest": {
						templateUrl: "views/partials/TopicLevelTest/TopicLevelTest.header.html"
					}
				}
			})
			.state('app.web.topicLevelTest.reviewTopicLevelTest', {
				url: "",
				views: {
					"": {
						templateUrl: 'views/partials/TopicLevelTest/TopicLevelTest.review.html',
						controller: 'app.web.topicLevelTest_topicLevelTestReviewController'
					},
					"question@app.web.topicLevelTest.reviewTopicLevelTest": {
						templateUrl: 'views/partials/TopicLevelTest/question.html'
					},
					"choices@app.web.topicLevelTest.reviewTopicLevelTest": {
						templateUrl: 'views/partials/TopicLevelTest/choices.html'
					},
					"menubar@app.web.topicLevelTest.reviewTopicLevelTest": {
						templateUrl: 'views/partials/TopicLevelTest/questionsMenubar.html'
					},
					"tabbar@app.web.topicLevelTest.reviewTopicLevelTest": {
						templateUrl: 'views/partials/TopicLevelTest/tabbar.html'
					},
					"header@app.web.topicLevelTest.reviewTopicLevelTest": {
						templateUrl: "views/partials/TopicLevelTest/TopicLevelTest.header.html"
					}
				}
			})
			.state('app.web.topicLevelTest.submitTopicLevelTest', {
				url: "",
				views: {
					"": {
						templateUrl: 'views/partials/TopicLevelTest/TopicLevelTest.submit.html',
						controller: 'app.web.topicLevelTest_topicLevelTestSubmitController'
					},
					"header@app.web.topicLevelTest.submitTopicLevelTest": {
						templateUrl: "views/partials/TopicLevelTest/TopicLevelTest.header.html"
					}
				}
			})
		;
		localStorageServiceProvider.setPrefix('grevory');
	})
;