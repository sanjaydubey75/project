angular.module('app.web.topicLevelTest')
	.factory('topicLevelTestFactory', function($q, $http){
		var getQuestions = function(topicId){
			var defer = $q.defer();
			$http.get('api/auth/topicleveltest/getQuestions/'+topicId, {})
				.then(function(result){
					if(result.data.response.status == "success")
						defer.resolve(result.data.questions);
					else defer.reject(result.data.response.message);
				});
			return defer.promise;
		};

		var setLevel = function(level, topicId){
			var defer = $q.defer();
			$http.post('api/auth/topicleveltest/setLevel/'+topicId, {level: level}, {}).then(function(result){
				if(result.data.response.status == 'success')
					defer.resolve();
				else defer.reject(result.data.response.message);
			});
			return defer.promise;
		};

		var renewToken = function(){
			var defer = $q.defer();
			$http.get('api/auth/renewToken', {}).then(function(result){
				if(result.data.response.status == 'success'){
					defer.resolve();
				} else defer.reject();
			});
			return defer.promise;
		};

		var setAttemptStatus = function(status, topicId){
			var defer = $q.defer();
			$http.post('api/auth/topicleveltest/setAttemptStatus/'+topicId, {attemptStatus: status}, {}).then(function(result){
				if(result.data.response.status == 'success'){
					defer.resolve();
				} else defer.reject();
			});
			return defer.promise;
		};

		var getAttemptStatus = function(topicId){
			var defer = $q.defer();
			$http.get('api/auth/topicleveltest/getAttemptStatus/'+topicId, {}).then(function(result){
				if(result.data.response.status == 'success'){
					defer.resolve(result.data.attemptStatus);
				} else defer.reject();
			});
			return defer.promise;
		};

		return{
			getQuestions: getQuestions,
			setLevel: setLevel,
			renewToken: renewToken,
			setAttemptStatus: setAttemptStatus,
			getAttemptStatus: getAttemptStatus
		};
	})
;