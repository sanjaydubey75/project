angular.module('app.web.topicLevelTest')
	.directive('app.web.topicLevelTest.attemptStatus', [
		"$timeout", "app.web.topicLevelTest_topicLevelTestService",
		function ($timeout, TopicLevelTestService) {
			return {
				restrict: 'A',
				scope: {
					attempted: '=',
					questions: '='
				},
				link: function (scope, elem, attr) {
					if (!TopicLevelTestService.isTestComplete()) {
						scope.$watch('attempted', function () {
							$timeout(function () {
								var elems = elem[0].querySelectorAll('a');
								if (scope.questions) {
									for (var i = 0; i < scope.questions.length; i++) {
										if (scope.questions[i].attempted && !elems[i].querySelector('img')) {
											var img = document.createElement('img');
											img.src = "/views/partials/TopicLevelTest/content/tick.png";
											img.setAttribute('height', '20px');
											img.setAttribute('style', 'float:right');
											elems[i].appendChild(img);
										}
										if (!scope.questions[i].attempted && elems[i].querySelector('img')) {
											var imgChild = elems[i].querySelector('img');
											elems[i].removeChild(imgChild);
										}
									}
								}
							}, 0);
						});
					} else {
						$timeout(function () {
							var elems = elem[0].querySelectorAll('a');
							if (scope.questions) {
								for (var i = 0; i < scope.questions.length; i++) {
									if (scope.questions[i].attempted && !elems[i].querySelector('img')) {
										var img = document.createElement('img');
										if (TopicLevelTestService.isQuestionCorrect(scope.questions[i]))
											img.src = "/views/partials/TopicLevelTest/content/tick.png";
										else
											img.src = "/views/partials/TopicLevelTest/content/cross.png";
										img.setAttribute('height', '20px');
										img.setAttribute('style', 'float:right');
										elems[i].appendChild(img);
									}
								}
							}
						}, 0);
					}
				}
			};
		}])
	.directive('app.web.topicLevelTest.disableWhenTestOver', [
		"app.web.topicLevelTest_topicLevelTestService",
		function (TopicLevelTestService)
		{
			return {
				restrict: 'A',
				link: function (scope, elem, attr) {
					if (TopicLevelTestService.isTestComplete()) {
						elem.attr('disabled', 'disabled');
					}
				}
			};
		}])
;