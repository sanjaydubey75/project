angular.module('app.web.topicLevelTest', ['LocalStorageModule', 'ui.router', 'app.topic', 'app.question'])
	.namespace({
		delimiter: '_',
		methods: [
			'factory',
			'service',
			'provider',
			'constant',
			'value'
		]
	});