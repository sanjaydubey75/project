angular.module('app.web.topicLevelTest')
	.factory('topicLevelTestService', [
		"app.web.topicLevelTest_topicLevelTestFactory", "localStorageService", "$q", "$state",
		function (TopicLevelTestFactory, localStorageService, $q, $state) {

			var testData = null;

			var save = function () {
				localStorageService.set('test-data', testData);
			};

			/** Check if the localstorage contains the questions and responses and if it does load them
			 * otherwise download them from the server
			 */
			var initialize = function (topicId) {
				var defer = $q.defer();
				testData = localStorageService.get('test-data');
				var questions;
				if (!testData || testData.topicId != topicId) {
					TopicLevelTestFactory.getQuestions(topicId).then(function (questions) {
						testData = {questions: createFlags(questions), topicId: topicId};
						save();
						defer.resolve(testData.questions);
					}, function (error) {
						defer.reject(error);
					});
				} else {
					defer.resolve(testData.questions);
				}
				return defer.promise;
			};

			/**
			 *  the questions attempted status and questions choice's selected status
			 */
			var createFlags = function (questions) {
				questions.forEach(function (question) {
					//console.log(question.question.answer);
					question.attempted = false;
					question.correct = null;
					question.choices.forEach(function (choice) {
						choice.selected = false;
					});
				});
				return questions;
			};

			var isQuestionAttempted = function (question) {
				var attempted = false;
				question.choices.forEach(function (choice) {
					if (choice.selected == true)
						attempted = true;
				});
				return attempted;
			};

			var update = function (index) {
				testData.questions[index].attempted = isQuestionAttempted(testData.questions[index]);
				save();
			};

			var isQuestionCorrect = function (question) {
				var choices = angular.copy(question.choices);
				var answer = angular.copy(question.question.answer);
				answer.sort();
				var selectedAnswers = [];
				choices.forEach(function (choice) {
					if (choice.selected) {
						selectedAnswers.push(choice.id);
					}
				});
				if (answer.toString().toLowerCase() != selectedAnswers.toString().toLowerCase())
					return false;
				else return true;
			};

			var calculate = function () {

				var getStatus = function()
				{
					var temp = [];
					testData.questions.forEach(function (question, index) {
						if (question.attempted)
							if(isQuestionCorrect(question))
								temp.push(1);
							else
								temp.push(0);
						else
							temp.push(0);
					});
					return temp;
				};

				var status = getStatus();

				var checkForFailureInSuccessiveLevel = function(status) // this function will check for atleast 3 failures
				// in successive level and if found will return the lesser level
				{
					for(var i = 0; i <4; i++) // one less than total number of levels
					{
						var wrongCount = 0;
						if(status[2*i] == 0)wrongCount++;
						if(status[2*i+1]==0)wrongCount++;
						if(status[2*i+2]==0)wrongCount++;
						if(status[2*i+3]==0)wrongCount++;
						if(wrongCount>2)return i+1;//since i is zero based
					}
					return 5;//return highest level
				};

				var temp = 0;

				var y = function(i){
					return Math.pow(i, 1/3);
					//return Math.pow(20 - i,.5);
				};

				for(var i = 1; i<= 10; i++)
				{
					temp += y(i);
				}
				var normalizationFactor = 1/temp;
				var weight = [];
				for(var i = 1; i<=10; i+=2)
				{
					var temp = normalizationFactor*(y(i) + y(i+1))/2;
					weight.push(temp);
					weight.push(temp);
				}

				var sum = 0;
				for(var i = 0; i < 10; i++)
				{
					sum+= weight[i]*status[i];
				}
				var level;
				if(sum<1/5)level=1;
				else if(sum<2/5)level=2;
				else if(sum<3/5)level=3;
				else if(sum<4/5)level=4;
				else level=5;

				var temp = checkForFailureInSuccessiveLevel(status);
				return temp < level ? temp : level;
			};

			var submitTest = function () {
				var defer = $q.defer();
				if (!isTestComplete()) {
					var level = calculate();
					TopicLevelTestFactory.setLevel(level, testData.topicId).then(function () {
						// set submitted flag true
						testData.submitted = true;
						save();
						defer.resolve('Your current level for this topic is: ' + level);
					}, function (error) {
						defer.reject(error)
					});
				} else defer.reject('You have completed level determination test for this topic');
				return defer.promise;
			};

			var isTestComplete = function (topicId) {
				if (testData) {
					if (testData.submitted) {
						if (topicId) {
							if (testData.topicId == topicId)
								return true;
						} else
							return true;
					}
				}
				return false;
			};

			var renewToken = function () {
				TopicLevelTestFactory.renewToken()
			};

			var goToAppropriateChildState = function (topicid) {
				TopicLevelTestFactory.getAttemptStatus(topicid).then(function (status) {
					if (status == null)$state.go('app.web.topicLevelTest.promptTopicLevelTest');
					if (status == true)$state.go('app.web.topicLevelTest.startTopicLevelTest');
					if (status == false) {
						if (testData) {//the localstorage is filled
							if (testData.submitted)
								$state.go('app.web.topicLevelTest.reviewTopicLevelTest');
							else $state.go('app.web.topicLevelTest.404TopicLevelTest');//go to 404
						} else
							$state.go('app.web.topicLevelTest.404TopicLevelTest');//go to 404
					}
				});
			};

			var setAttemptStatus = function (status, topicId) {
				var defer = $q.defer();
				TopicLevelTestFactory.setAttemptStatus(status, topicId).then(function () {
					defer.resolve();
				});
				return defer.promise;
			};

			return {
				initialize: initialize,
				update: update,
				submit: submitTest,
				isTestComplete: isTestComplete,
				isQuestionCorrect: isQuestionCorrect,
				renewToken: renewToken,
				goToAppropriateChildState: goToAppropriateChildState,
				setAttemptStatus: setAttemptStatus
			};
		}])
;