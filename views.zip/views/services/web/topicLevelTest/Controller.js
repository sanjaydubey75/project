angular.module('app.web.topicLevelTest')
	.controller('app.web.topicLevelTest_topicLevelTestAbstractController', [
		"$state", "app.web.topicLevelTest_topicLevelTestService", "$scope",
		"app.topic_topicFactory", "$stateParams", "$timeout", "$interval",
		function ($state, TopicLevelTestService, $scope,
		          TopicFactory, $stateParams, $timeout, $interval) {

			$scope.status = {
				questionChange: false,
				questionIndex: 0,
				message: null,
				tabs: []
			};

			TopicLevelTestService.initialize($stateParams.topicId).then(function (questions) {
				$scope.questions = questions;
				$scope.status.questionChange = true;
				questions.forEach(function () {
					$scope.status.tabs.push({active: false});
				});
				$scope.status.tabs[0].active = true;
			}, function (error) {
				$scope.status.message = error;
			});

			$scope.setQuestion = function (index) {
				$scope.status.questionChange = false;
				$scope.status.questionIndex = index;
				$scope.status.tabs[index].active = true;
				$timeout(function () {
					$scope.status.questionChange = true;
				}, 0);
			};

			TopicFactory.getTopicDetails($stateParams.topicId).then(function (topic) {
				$scope.topic = topic;
			});

			var renewToken = $interval(function () {
				TopicLevelTestService.renewToken();
			}, 3600 * 1000 * .80);
			$scope.$on('$destroy', function () {
				$interval.cancel(renewToken);
			});

			TopicLevelTestService.goToAppropriateChildState($stateParams.topicId);
		}])
	.controller('app.web.topicLevelTest_topicLevelTestPromptController', [
		"$scope", "$state", "$stateParams", "app.web.topicLevelTest_topicLevelTestService",
		function ($scope, $state, $stateParams, TopicLevelTestService) {
			$scope.startTopicLevelTest = function () {
				TopicLevelTestService.setAttemptStatus(true, $stateParams.topicId).then(function (result) {
					$state.go('app.web.topicLevelTest.startTopicLevelTest');
				});
			};

			$scope.goToQuestionPage = function () {
				if ($scope.topic) {
					TopicLevelTestService.setAttemptStatus(false, $stateParams.topicId).then(function (result) {
						$state.go('app.web.question', {subid: $scope.topic.subject_id, topicid: $scope.topic.id});
					});
				}
			};
		}])
	.controller('app.web.topicLevelTest_topicLevelTestStartController', [
		"app.web.topicLevelTest_topicLevelTestService", "$scope", "$state",
		function (TopicLevelTestService, $scope, $state) {
			$scope.update = function () {
				TopicLevelTestService.update($scope.status.questionIndex);
			};
			$scope.submitPrompt = function () {
				$state.go('^.submitTopicLevelTest');
			};
		}])
	.controller('app.web.topicLevelTest_topicLevelTestSubmitController', [
		"$scope", "app.web.topicLevelTest_topicLevelTestService", "$state",
		function ($scope, TopicLevelTestService, $state) {
			$scope.goBackToTest = function () {
				$state.go('^.startTopicLevelTest');
			};
			$scope.submitTest = function () {
				TopicLevelTestService.submit().then(function (message) {
					$scope.status.message = message;
				}, function (error) {
					$scope.status.message = error;
				});
			};
			$scope.goToReview = function () {
				$state.go('^.reviewTopicLevelTest');
			};
			$scope.$on('$destroy', function () {
				$scope.status.message = null;
			});
		}])
	.controller('app.web.topicLevelTest_topicLevelTestReviewController', [
		"app.web.topicLevelTest_topicLevelTestService", "$scope", "$state",
		function (TopicLevelTestService, $scope, $state) {
			$scope.isCorrect = function () {
				return TopicLevelTestService.isQuestionCorrect($scope.questions[$scope.status.questionIndex]);
			};
			$scope.beginPractice = function () {
				$state.go('app.web.question', {subid: $scope.topic.subject_id, topicid: $scope.topic.id});
			};
		}])
;