angular.module('app.web.authentication')
	.config(['$stateProvider', '$locationProvider', '$urlRouterProvider',
		function ($stateProvider, $locationProvider, $urlRouterProvider)
		{
			$locationProvider.html5Mode(true);
			$urlRouterProvider.otherwise("/");
			$stateProvider
				.state('app.web.login',
				{
					abstract: true,
					template: '<ui-view/>'
				})
				.state('app.web.login.student',
				{
					url: '/login/student',
					views: {
						"": {
							templateUrl: 'views/partials/login/student/login.html',
							controller: 'app.security_loginController'
						},
						"login-provider@app.web.login.student": {
							templateUrl: 'views/partials/login/thirdPartyLogin.html'
						}
					},
				/*	data: {
						bannedTypes: ['student', 'tutor'] //this means that a user logged in with student or tutor
						                                    //role is not allowed
					}*/
				})
				.state('app.web.login.tutor',
				{
					url: '/login/tutor',
					templateUrl: 'views/partials/login/tutor/tutor.login.html',
					controller: 'app.security_loginController',
					data: {
						bannedTypes: ['student', 'tutor']
					}
				})
				.state('app.web.logout',
				{
					url: '/logout',
					template: '',
					controller: 'app.security_logoutController'
				})
			;

		}
	])
;