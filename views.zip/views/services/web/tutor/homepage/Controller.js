angular.module('app.web.tutor.dashboard')
	.controller('app.web.tutor.dashboard_homeController', ["$scope", "app.web.tutor.dashboard_dashboardService",
		function($scope, dashboardService)
	{
		dashboardService.getTutor().then(
			function(tutor)
			{
				$scope.tutor = tutor;
			}
		);
	}]
);