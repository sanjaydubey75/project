angular.module('app.web.tutor.dashboard', ['app.web.tutor.config', 'app.web.tutor.resource', 'app.web.tutor.dao'])
	.namespace({
		delimiter: '_',
		methods: [
			'factory',
			'service',
			'provider',
			'constant',
			'value'
		]
	});