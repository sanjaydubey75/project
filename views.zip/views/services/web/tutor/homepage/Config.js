angular.module('app.web.tutor.dashboard')
	.config(['$stateProvider', '$locationProvider', '$urlRouterProvider', "app.web.tutor.config_baseUrlForWebApp",
		function($stateProvider, $locationProvider, $urlRouterProvider, baseUrlForWebApp)
	{
		$locationProvider.html5Mode(true);
		$urlRouterProvider.otherwise("/");

		$stateProvider
			.state('app.web.tutor.dashboard',
			{
				url: "/home",
				templateUrl: 'views/partials/tutor/homepage/index.html',
				controller: 'app.web.tutor.dashboard_homeController'
			})
		;
	}
	]
);