angular.module('app.web.tutor.dashboard')
	.factory('dashboardService', ["app.web.tutor.dao_tutorDao", "$q", "app.web.tutor.resource_tutor",
		function(tutorDao, $q, Tutor)
	{
		var getTutor = function()
		{
			var deferred = $q.defer();
			tutorDao.get().then(function(tutor)
			{
				deferred.resolve(new Tutor(tutor));
			});
			return deferred.promise;
		};

		return {
			getTutor: getTutor
		};
	}]
);