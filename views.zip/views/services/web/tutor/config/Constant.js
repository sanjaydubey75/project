angular.module('app.web.tutor.config')
	.constant('baseUrlForWebApp', '/tutor')
	.constant('baseUrlForWebService', 'iitjeeacademy/api/v1/tutor')
	.constant('role', 'tutor');