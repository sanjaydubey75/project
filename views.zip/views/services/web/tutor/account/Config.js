angular.module('app.web.tutor.account')
	.config(['$stateProvider', '$locationProvider', '$urlRouterProvider', "app.web.tutor.config_baseUrlForWebApp",
		function($stateProvider, $locationProvider, $urlRouterProvider, baseUrlForWebApp)
		{
			$locationProvider.html5Mode(true);
			$urlRouterProvider.otherwise("/");

			$stateProvider
				.state('app.web.tutor.account',
				{
					url: "/account",
					template: '<ui-view/>',
					abstract: true
				})
				.state('app.web.tutor.account.summary',
				{
					url: "",
					templateUrl: 'views/partials/tutor/account/summary.html',
					controller: "app.web.tutor.account_financialSummaryController"
				})
			;
		}
	]
);