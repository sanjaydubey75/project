angular.module('app.web.tutor.account')
	.controller('app.web.tutor.account_financialSummaryController', [
		"$scope", "app.web.tutor.account_accountService",
		function($scope, AccountService)
		{
			AccountService.getFinancialSummary().then(function(financialSummaries)
			{
				$scope.financialSummaries = financialSummaries;
			});
		}
	])
;