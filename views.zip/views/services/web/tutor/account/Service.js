angular.module('app.web.tutor.account')
	.factory('accountService', [
		"app.web.tutor.dao_financeDao", "$q",
		function(FinanceDao, $q)
		{
			var getFinancialSummary = function()
			{
				var deferred = $q.defer();
				FinanceDao.getFinancialSummary().then(function(financialSummaries)
				{
					deferred.resolve(financialSummaries);
				})
				return deferred.promise;
			}

			return {
				getFinancialSummary: getFinancialSummary
			}
		}]
	)
;