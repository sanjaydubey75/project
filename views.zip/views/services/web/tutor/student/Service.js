angular.module('app.web.tutor.student')
	.factory('studentService', [
		"app.web.tutor.dao_tutorDao", "$q", "app.web.tutor.resource_student", "app.web.tutor.dao_studentDao",
		function(tutorDao, $q, Student, StudentDao)
		{
			var getStudents = function(targetYear)
			{
				return StudentDao.query({"targetYear": targetYear});
			};

			var getStudentsInfo = function()
			{
				var deferred = $q.defer();
				StudentDao.getInfo().then(function(studentInfos)
				{
					deferred.resolve(studentInfos);
				});
				return deferred.promise;
			};
			
			var getStudent = function(id)
			{
				return StudentDao.get({id: id});
			};

			return {
				getStudents: getStudents,
				getStudentsInfo: getStudentsInfo,
				getStudent: getStudent
			};
		}]
	)
;