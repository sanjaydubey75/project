angular.module('app.web.tutor.student')
	.factory('correctAndWrongQuestionFactory', [
		"$http", "$q",
		function($http, $q){

			var color = {
				"CHE": { correct: "#66FF66", wrong: "#d62728"},
				"MAT": { correct: "#66FF66", wrong: "#d62728"},
				"PHY": { correct: "#66FF66", wrong: "#d62728"}
			}

			var options = {
				chart: {
					type: 'multiBarHorizontalChart',
					height: 20,
					x: function (d) {
						return d.label;
					},
					y: function (d) {
						return d.value;
					},
					showControls: false,
					showValues: true,
					transitionDuration: 500,
					xAxis: {
						showMaxMin: false
					},
					yAxis: {
						axisLabel: '',
						tickFormat: function (d) {
							return (d);
						},
						ticks: 10
					},
					forceY: [], //to be defined when the data is obtained
					stacked: true,
					margin: {
						top: 0,
						right: 10,
						bottom: 0,
						left: 10
					},
					showLegend: false,
					showXAxis: true,
					showYAxis: true
				}
			};

            var metaData = {
                options: {
                    chart: {
                        type: 'multiBarHorizontalChart',
                        //height: 20,
                        x: function (d) {
                            return d.label;
                        },
                        y: function (d) {
                            return d.value;
                        },
                        showControls: false,
                        showValues: true,
                        transitionDuration: 500,
                        xAxis: {
                            showMaxMin: true
                        },
                        yAxis: {
                            axisLabel: '',
                            tickFormat: function (d) {
                                return d3.format(',.1f')(d);
                            },
                            ticks: 10
                        },
                        forceY: [], //to be defined when the data is obtained
                        stacked: true,
                        margin: {
                            //top: 0,
                            right: 10,
                            //bottom: 0,
                            left: 10
                        },
                        showLegend: true,
                        showXAxis: true,
                        showYAxis: true
                    }
                },
                data: [{
                    "key": "Correct",
                    "color": "#66FF66",
                    "values": [
                        {

                        }
                    ]
                },
                    {
                        "key": "Wrong",
                        "color": "#d62728",
                        "values": [
                            {

                            }
                        ]
                    }]
            };

			var topics = [];

			var setSubject = function(subjectId, studentId) {
				var deferred = $q.defer();
				$http.get("iitjeeacademy/api/v1/tutor/student/"+studentId+"/report/correctAndWrongQuestions/", 
						{params: {studentId: studentId, subjectId: subjectId}})
					.then(function(result) {
						setTopics(result.data, subjectId);
						deferred.resolve();
					}, function(error) {
						deferred.reject(error);
					});
				return deferred.promise;
			};

			var setTopics = function(object, subjectId){
				topics.length = 0;
				options.chart.forceY.length = 0;
				metaData.options.chart.forceY.length = 0;

				for (var key in object)
				{
					if (object.hasOwnProperty(key))
					{
						var data = [{
							"key": "Correct",
							"color": color[subjectId].correct,
							"values": [
								{
									"label" : "" ,
									"value" : object[key].correct
								}
							]
						},
						{
							"key": "Wrong",
							"color": color[subjectId].wrong,
							"values": [
								{
									"label" : "",
									"value" : object[key].wrong
								}
							]
						}]
						topics.push({name: key, data: data});

						options.chart.forceY.push(object[key].wrong + object[key].correct);
						metaData.options.chart.forceY.push(object[key].wrong + object[key].correct);
					}
				}
			};

			var getOptions = function() {
				return options;
			};

			var getTopics = function(){
				return topics;
			};

			return {
				getOptions: getOptions,
				getTopics: getTopics,
				setSubject: setSubject
			};
		}
	])
;