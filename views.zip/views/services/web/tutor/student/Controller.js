angular.module('app.web.tutor.student')
	.controller('app.web.tutor.student_studentInformationController', [
		"$scope", "app.web.tutor.student_studentService",
		function($scope, StudentService)
		{
			StudentService.getStudentsInfo().then(function(studentInfos)
			{
				$scope.studentInfos = studentInfos;
			});
		}
	])
	.controller('app.web.tutor.student_studentListController', [
		"$scope", "app.web.tutor.student_studentService", "$stateParams",
		function($scope, StudentService, $stateParams)
		{
			$scope.students = StudentService.getStudents($stateParams.targetYear);
		}
	])
	.controller('app.web.tutor.student_studentRevenueController', [
		"$scope", "app.web.tutor.student_studentService", "$stateParams", "app.web.tutor.dao_pricingDao",
		function($scope, StudentService, $stateParams, pricingDao)
		{
			$scope.students = StudentService.getStudents($stateParams.targetYear);

			$scope.pricingDao = pricingDao;
		}
	])
	.controller('app.web.tutor.student_studentReportController', [
		"$scope", "$stateParams", "app.web.tutor.student_studentService", "app.web.tutor.student_correctAndWrongQuestionFactory",
		function($scope, $stateParams, StudentService, correctAndWrongQuestionFactory){
			
			$scope.student = StudentService.getStudent($stateParams.id);
			
			$scope.reportController = {
					topicCorrectWrong: {
						getOptions: correctAndWrongQuestionFactory.getOptions,
						setSubject: correctAndWrongQuestionFactory.setSubject,
						topics: correctAndWrongQuestionFactory.getTopics()
					}
				};
		}
	])
;