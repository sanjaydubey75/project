angular.module('app.web.tutor.student', ['app.web.tutor.config', 'app.web.tutor.resource', 'app.web.tutor.dao'])
	.namespace({
		delimiter: '_',
		methods: [
			'factory',
			'service',
			'provider',
			'constant',
			'value'
		]
	});