angular.module('app.web.tutor.student')
	.config(['$stateProvider', '$locationProvider', '$urlRouterProvider', "app.web.tutor.config_baseUrlForWebApp",
		function($stateProvider, $locationProvider, $urlRouterProvider, baseUrlForWebApp)
		{
			$locationProvider.html5Mode(true);
			$urlRouterProvider.when('/student', '/student/info');
			$urlRouterProvider.otherwise("/");

			$stateProvider
				.state('app.web.tutor.student',
				{
					url: "/student",
					template: '<ui-view/>',
					abstract: true
				})
				.state('app.web.tutor.student.info',
				{
					url: "/info",
					templateUrl: 'views/partials/tutor/student/information/info.html',
					controller: "app.web.tutor.student_studentInformationController"
				})
				.state('app.web.tutor.student.list',
				{
					url: "?targetYear",
					templateUrl: 'views/partials/tutor/student/details/list.html',
					controller: "app.web.tutor.student_studentListController"
				})
				.state('app.web.tutor.student.revenue',
				{
					url: "/revenue?targetYear",
					templateUrl: 'views/partials/tutor/student/revenue/revenue.html',
					controller: "app.web.tutor.student_studentRevenueController"
				})
				.state('app.web.tutor.student.report', {
					url: "/:id",
					templateUrl: "views/partials/tutor/student/report/report.html",
					controller: "app.web.tutor.student_studentReportController"
				})
			;
		}
	]
);