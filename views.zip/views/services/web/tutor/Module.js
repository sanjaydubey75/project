angular.module('app.web.tutor', ['app.web.tutor.dashboard', 'app.web.tutor.student', 'app.web.tutor.account'])
	.namespace({
		delimiter: '_',
		methods: [
			'factory',
			'service',
			'provider',
			'constant',
			'value'
		]
	});