angular.module('app.web.tutor.resource')
	.factory('student', [
		function()
		{
			var Student = function(student)
			{
				this.targetYear = student.targetYear;
				this.firstName  = student.firstName;
				this.lastName = student.lastName;
				this.pricing = student.pricing;
				this.globalRank = student.globalRank;
			};

			return Student;
		}]
	);