angular.module('app.web.tutor.resource', ['app.web.tutor.config'])
	.namespace({
		delimiter: '_',
		methods: [
			'factory',
			'service',
			'provider',
			'constant',
			'value'
		]
	});