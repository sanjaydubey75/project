angular.module('app.web.tutor.resource')
	.factory('tutor', [
		function()
		{
			var Tutor = function(data)
			{

				this.id = data.id;
				this.name  = data.name;
				this.email = data.email;
				this.password = data.password;
				this.mobileNumber = data.mobileNumber;
				this.address = data.address;
			};

			return Tutor;
		}]
	);