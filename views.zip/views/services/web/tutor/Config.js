angular.module('app.web.tutor')
	.config(['$stateProvider', '$locationProvider', '$urlRouterProvider', "app.web.tutor.config_baseUrlForWebApp",
		function($stateProvider, $locationProvider, $urlRouterProvider, baseUrlForWebApp)
		{
			$locationProvider.html5Mode(true);
			$urlRouterProvider.otherwise("/");

			$stateProvider
				.state('app.web.tutor',
				{
					url: baseUrlForWebApp,
					abstract: true,
					template: '<ui-view/>',
					data: {
						allowedTypes: ['tutor']
					}
				}
			);
		}
	]
);