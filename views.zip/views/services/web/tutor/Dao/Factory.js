angular.module('app.web.tutor.dao')
	.factory('tutorDao', ["$http", "$q", "app.web.tutor.config_baseUrlForWebService",
		function($http, $q, baseUrlForWebService)
		{
			var get = function ()
			{
				var deferred = $q.defer();
				$http.get(baseUrlForWebService, {})
					.then(function (result)
					{
						deferred.resolve(result.data.tutor);
					},
					function (error)
					{
						deferred.reject();
					});
				return deferred.promise;
			};

			return {
				get: get
			};
		}
	])
	.factory('studentDao', ["$http", "$q", "app.web.tutor.config_baseUrlForWebService",
		function($http, $q, baseUrlForWebService)
		{
			var query = function (params) //as of now only {"targetYear": targetYear} is supported
			{
				var students = {};
				$http.get(baseUrlForWebService + "/student", {params: params})
					.then(function (result)
					{
						angular.extend(students, result.data);
					});
				return students;
			};

			var get = function(params) //as of now only {"id": id} is supported
			{
				var student = {};
				
				$http.get("iitjeeacademy/api/v1/tutor/student/" + params.id, {})
					.then(function(result){
						angular.extend(student, result.data);
				})

				return student;
			};

			var getInfo = function()
			{
				var deferred = $q.defer();
				$http.get(baseUrlForWebService + "/students/info", {})
					.then(function (result)
					{
						deferred.resolve(result.data.studentInfos);
					},
					function (error)
					{
						deferred.reject();
					});
				return deferred.promise;
			}

			return {
				query: query,
				get: get,
				getInfo: getInfo
			};
		}
	])
	.factory('financeDao', ["$http", "$q", "app.web.tutor.config_baseUrlForWebService",
		function($http, $q, baseUrlForWebService)
		{
			var getFinancialSummary = function ()
			{
				var deferred = $q.defer();
				$http.get(baseUrlForWebService + "/account/summary", {})
					.then(function (result)
					{
						deferred.resolve(result.data.financialSummaries);
					},
					function (error)
					{
						deferred.reject();
					});
				return deferred.promise;
			};

			return {
				getFinancialSummary: getFinancialSummary
			};
		}
	])
	.factory('pricingDao', [
		"$http",
		function($http){

			var pricings = {};

			$http.get("/iitjeeacademy/api/v1/pricing", {}).then(function (result){
				angular.extend(pricings, result.data);
			});

			var getPricing = function(id) {
				return pricings[id];
			};

			return {
				getPricing: getPricing
			};
		}
	])
;