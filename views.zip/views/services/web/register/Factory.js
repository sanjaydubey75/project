angular.module('app.web.register')
	.factory('registerFactory', function ($http, $q, $window, $location) {

		var register = function (registerData) {
			var deferred = $q.defer();
			$http.post("iitjeeacademy/api/v1/register/student", registerData, {})
				.then(function (result) {
					deferred.resolve('success');
				}, function (error) {
					deferred.reject(error);
				});
			return deferred.promise;
		};

		var registerTutor = function (tutor) {
			var deferred = $q.defer();

			$http.post("iitjeeacademy/api/v1/register/tutor", tutor, {})
				.then(function (result) {
					if (result.data.response.status == 'success')
						deferred.resolve();
					else
						deferred.reject(result.data.response.message);
				}, function (error) {
					deferred.reject('Oops! There is some problem with the internet connection.');
				});

			return deferred.promise;
		};

		var registertrial = function (registerData) {
			var deferred = $q.defer();
			$http.post("iitjeeacademy/api/v1/register/student/trial", registerData, {})
				.then(function (result) {
					deferred.resolve('success');
				}, function (error) {
					deferred.reject(error);
				});
			return deferred.promise;
		};

		var getStates = function () {
			var deferred = $q.defer();
			$http.get("api/state", {})
				.then(function (result) {
					if (result.data.response.status == 'success') {
						deferred.resolve(result.data.states);
					}
				}, function (error) {
					deferred.reject(error);
				});
			return deferred.promise;
		};

		var getInstitutes = function () {
			var deferred = $q.defer();
			$http.get("api/institute", {})
				.then(function (result) {
					if (result.data.response.status == 'success') {
						deferred.resolve(result.data.institutes);
					}
				}, function (error) {
					deferred.reject(error);
				});
			return deferred.promise;
		};

		var validate = function (registerData) {
			var deferred = $q.defer();
			$http.post("api/auth/register/validate", registerData, {})
				.then(function (result) {
					if (result.data.response.status == 'success') {
						deferred.resolve(result.data);
					} else
						deferred.reject(result.data);
				}, function (error) {
					deferred.reject(error);
				});
			return deferred.promise;
		};

		return {
			register: register,
			registerTutor: registerTutor,
			registertrial: registertrial,
			getStates: getStates,
			getInstitutes: getInstitutes,
			validate: validate
		};
	})
	.factory('registerDetailsFactory', function ($location) {
		this.user = {};

		var setUser = function (user) {
			this.user = user;
		};

		var getUser = function () {
			return this.user;
		};

		var addProperty = function (key, value) {
			this.user[key] = value;
		};

		return {
			setUser: setUser,
			getUser: getUser,
			addProperty: addProperty
		};
	})
	.factory('transaction', function ($q, $http) {
		var getResult = function () {
			var deferred = $q.defer();
			$http.get("api/PaymentGatewayUrl/end", {})
				.then(function (result) {
					if (result.data.response.status == 'success') {
						deferred.resolve(result.data.transactionDetails);
					}
				}, function (error) {
					deferred.reject(error);
				});
			return deferred.promise;
		};

		return {
			getResult: getResult
		};
	})
;