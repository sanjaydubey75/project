angular.module('app.web.register')
	.controller('app.web.register_registerController', [
		"$scope", "app.web.register_registerFactory", "$filter", "$location", "$interval", "$cookieStore",
		"app.web.register_registerDetailsFactory", "app.web.register_registerService",
		"app.web.register_validateFormService", "$state",
		function ($scope, RegisterFactory, $filter, $location, $interval, $cookieStore,
		          RegisterDetailsFactory, RegisterService,
		          ValidateFormService, $state) {

			$scope.user = RegisterDetailsFactory.getUser();

			$scope.register1 = function ()
			{
				if ($scope.RegisterForm.$valid && !$scope.RegisterForm.$pending)
				{
					$scope.canReload = false;
					$scope.user.role = 'student';
					RegisterDetailsFactory.setUser($scope.user);
					$state.go('app.web.register.pricing');
				}
			};
		}
	])

	.controller('app.web.register_pricingController', [
		"$scope", "app.web.register_registerDetailsFactory", "$location", "app.web.register_registerService", "$state",
		function ($scope, RegisterDetailsFactory, $location, RegisterService, $state) {

			$scope.models = [
				{'duration': 'Six months', 'price': '2,500', 'id': 1},
				{'duration': 'One year', 'price': '3,000', 'id': 2},
				{'duration': 'Two years', 'price': '5,000', 'id': 3}
			];

			$scope.canReload = true;

			$scope.subscribe = function (model) {

				if (RegisterDetailsFactory.getUser() == null) $state.go('app.web.register.student');

				else {
					$scope.canReload = false;
					RegisterService.openPaymentGateway(model).then(function () {
						$scope.canReload = true;
						$state.go('app.web.register.posttransaction');
					}, function (error) {
						$scope.canReload = true;

						$state.go('app.web.register.posttransaction');
					});
				}
			};
		}])

	.controller('app.web.register_postTransactionController', [
		"app.web.register_transaction", "$scope", "app.web.register_postTransactionService",
		function (Transaction, $scope, PostTransactionService) {
			Transaction.getResult().then(function (transaction) {
				$scope.txSuccess = transaction.status.transaction;
				$scope.regSuccess = transaction.status.registration;
				$scope.transactionDetails = PostTransactionService.sort(transaction.details);
			});
		}])

	.controller('app.web.register_trialRegisterController', [
		"app.web.register_registerFactory", "$scope", "app.web.register_registerService",
		"app.web.register_registerDetailsFactory", "$state",
		"$auth", "app.security_principal",
		function (RegisterFactory, $scope, RegisterService,
		          RegisterDetailsFactory, $state,
		          $auth, principal)
		{
            RegisterFactory.getStates().then(function(result){
                $scope.states = result;
            });

			$scope.register1 = function () {
				if ($scope.RegisterFormTrial.$valid && !$scope.RegisterFormTrial.$pending) {
					RegisterDetailsFactory.setUser($scope.user);
					RegisterService.registertrial().then(function () {

						$auth.login({
							email: $scope.user.email,
							password: $scope.user.password,
							type: 'student'
						}).then(function(result)
						{
							principal.authenticate(result.data);
						});
					});
				}
			};

            //make sure to handle the case when the user has revoked some permissions like email address
            $scope.authenticate = function(provider) {
                $auth.authenticate(provider)
                    .then(function(result) {
                        principal.authenticate(result.data);
                    })
                    .catch(function(response) {
                        console.log(response);
                    });
            };
		}
	])

	.controller('app.web.register_tutorRegisterController', [
		"$scope", "app.web.register_registerService", "$state",
		function ($scope, RegisterService, $state) {


			$scope.register = function () {
				if ($scope.RegisterForm.$valid && !$scope.RegisterForm.$pending) {
					RegisterService.registerTutor($scope.user).then(function () {
						$state.go('app.web.register.tutorsuccess');
					}, function (error) {
						$scope.message = error;
					});
				}
			};
		}])
;