angular.module('app.web.register')
    .directive('app.web.register.noDirtyCheck', function() {
        // Interacting with input elements having this directive won't cause the
        // form to be marked dirty.
        return {
            restrict: 'A',
            require: 'ngModel',
            link: function(scope, elm, attrs, ctrl) {
                ctrl.$pristine = false;
            }
        }
    })
	.directive('app.web.register.couponCodeValid', function($q, $http, $timeout){
		return {
			restrict: 'A',
			require: 'ngModel',
			link: function(scope, elm, attrs, ctrl){
				ctrl.$asyncValidators.invalid = function(modelValue, viewValue){
					if(ctrl.$isEmpty(modelValue)){
						return $q.when();
					}

					var def = $q.defer();

					if(attrs.institutes && attrs.institute){
						var institutes = attrs.institutes;
						var institute = attrs.institute;
						var couponcode = modelValue;
						if(institutes.indexOf(institute != -1)){
							$http.post('api/auth/register/validate/couponcode', {institution: institute, couponcode: couponcode}, {})
								.then(function(result){
									if(result.data.isValid){
										def.resolve();
									} else def.reject();
								});
						}
					}
					return def.promise;
				}
			}
		};
	})
    .directive('app.web.register.isSubsetOf', function(){
        return{
            require: 'ngModel',
            restrict: 'A',
            scope:{
                model: '=ngModel',
                set: '=set'
            },
            link: function(scope, elem, attr, ngModel){
                ngModel.$validators.isNotSubsetOf = function(modelValue, viewValue){
                    if(ngModel.$isEmpty(modelValue))
                        return true;
                    if(!scope.set.$resolved)
                        return true;
                    var temp = false;
                    scope.set.forEach(function(state)
                    {
                        if(state.name === viewValue){
                            temp = true;
                        }
                    });
                    return temp;
                };
            }
        };
    })
;