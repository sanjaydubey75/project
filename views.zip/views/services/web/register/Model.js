angular.module('app.web.register').factory('tutorEntity', function()
{
	var TutorEntity = function(data) {
		//set defaults properties and functions
		angular.extend(this, {
			id:null,
			name:"",
			email:"",
			password:"",
			mobileNumber:"",
			address:""
		});

		this.id = data.id;
		this.name  = data.name;
		this.email = data.email;
		this.password = data.password;
		this.mobileNumber = data.mobileNumber;
		this.address = data.address;
	};

	return TutorEntity;
});