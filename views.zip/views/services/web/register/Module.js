angular.module('app.web.register', ['ui.router', 'remoteValidation', 'ui.mask', 'app.security'])
	.namespace({
		delimiter: '_',
		methods: [
			'factory',
			'service',
			'provider',
			'constant',
			'value'
		]
	})
;