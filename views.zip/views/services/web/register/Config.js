angular.module('app.web.register')
	.config(['$stateProvider', '$locationProvider', '$urlRouterProvider',
		function ($stateProvider, $locationProvider, $urlRouterProvider)
		{
			$locationProvider.html5Mode(true);
			$urlRouterProvider.otherwise("/");
			$stateProvider
				.state('app.web.register',
				{
					url: '/register',
					template: '<ui-view/>',
					abstract: true,
					data: {
						bannedTypes: ['student', 'tutor']
					}
				})
				.state('app.web.register.student',
				{
					url: '/student',
					templateUrl: 'views/partials/register/register.html',
					controller: 'app.web.register_registerController',
					controllerAs: 'register'
				})
				.state('app.web.register.studenttrial',
				{
					url: '/trial',
                    views:{
                        "":{
                            templateUrl: 'views/partials/register/registertrial.html',
                            controller: 'app.web.register_trialRegisterController'
                        },
                        "login-provider@app.web.register.studenttrial": {
                            templateUrl: 'views/partials/login/thirdPartyLogin.html'
                        }
                    },
					controllerAs: 'register'
				})
				.state('app.web.register.pricing',
				{
					url: '/pricing',
					templateUrl: 'views/partials/register/pricing.html',
					controller: 'app.web.register_pricingController',
					controllerAs: 'pricing'
				})
				.state('app.web.register.tutor',
				{
					url: '/tutor',
					templateUrl: 'views/partials/register/tutorregister.html',
					controller: 'app.web.register_tutorRegisterController',
					controllerAs: 'tutorregister'
				})
				.state('app.web.register.tutorsuccess',
				{
					url: '/tutorregistersuccess',
					templateUrl: 'views/partials/register/tutorregistersuccess.html'
				})
				.state('app.web.register.posttransaction',
				{
					url: '/postTransaction',
					templateUrl: 'views/partials/register/posttransaction.html',
					controller: 'app.web.register_postTransactionController'
				})
			;
		}
	])
;