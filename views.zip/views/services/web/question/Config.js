angular.module('app.web.question', ['app.question'])
	.config(['$stateProvider', '$locationProvider', '$urlRouterProvider', function ($stateProvider, $locationProvider, $urlRouterProvider) {
		$locationProvider.html5Mode(true);
		$urlRouterProvider.otherwise("/");
		$stateProvider
			.state('app.web.question', {
				url: '/question/:subid/:topicid',
				views: {
					"": {
						templateUrl: 'views/partials/question.html',
						controller: 'app.question_questionController'
					},
					"question@app.web.question": {
						templateUrl: 'views/partials/question/question.html'
					},
					"choices@app.web.question": {
						templateUrl: 'views/partials/question/choices.html'
					},
					"menu@app.web.question": {
						templateUrl: 'views/partials/question/menu.html'
					},
					"solution@app.web.question": {
						templateUrl: 'views/partials/question/solution.html'
					}
				},
				data: {
					roles: ['studentTrial', 'studentUnlimited'],
					allowedTypes: ['student']
				}
			})
			.state('app.web.sharequestion', {
				url: '/question/:questionId?token&student&friend',
				views: {
					"": {
						templateUrl: 'views/partials/ShareQuestion.html',
						controller: 'app.question_shareQuestionController'
					},
					"question@app.web.sharequestion": {
						templateUrl: 'views/partials/question/question.html'
					},
					"choices@app.web.sharequestion": {
						templateUrl: 'views/partials/question/choices.html'
					}
				}
			})

	}])
;