angular.module('app.question')
	.factory('questionFactory', function($window, $q, $http, $location){
		var getQuestion = function(subid, topicid){
			var deferred = $q.defer();
			$http.get("api/auth/question/"+subid+"/"+topicid, {})
				.then(function(result) {
					if(result.data.response.status != "success"){
						deferred.reject(result.data);
					}
					deferred.resolve(result.data);
				}, function(error) {
					deferred.reject(error);
				});
			return deferred.promise;
		};
	
		var submitResponse = function(subid, topicid, questionId, correct, time){
			var deferred = $q.defer();
			$http.post("iitjeeacademy/api/v1/student/me/ranking/submit",
				{
					"questionId": questionId,
					"correct": correct,
					"withinTime": (time.getSeconds() + time.getMinutes()*60 != 0)
				},{}
			)
			.then(function(result) {
				deferred.resolve(result);
			}, function(error) {
				deferred.reject(error);
			});
			return deferred.promise;
		};

		var skipResponse = function(subid, topicid, questionId){
			var deferred = $q.defer();
			$http.post("iitjeeacademy/api/v1/student/me/ranking/skip",
				{"questionId": questionId},{})
				.then(function(result) {
					deferred.resolve(result);
				}, function(error) {
					deferred.reject(error);
				});
			return deferred.promise;
		};

		var share = function(email, question){
			var deferred = $q.defer();
			$http.post("api/auth/share", {
				"question": question,
				"email": email
			}, {})
				.then(function(result){
					if(result.data.response.status == "success")
						deferred.resolve(result.data.response.message);
					else
						deferred.reject(result.data.response.message);
				}, function(error){
					deferred.reject(error);
				});
			return deferred.promise;
		};
	
		var getQuestionById = function(questionId, token, friend, student){
			var deferred = $q.defer();
			$http.get("api/auth/question/"+questionId +"?token="+token + "&friend="+friend+"&student="+student, {})
				.then(function(result){
				if(result.data.response.status == "success"){
					deferred.resolve(result.data);
				}
			});
			return deferred.promise;
		};

		var reportQuestion = function(questionId){
			var deferred = $q.defer();
			$http.post("api/auth/report/error",{"questionId": questionId}, {})
				.then(function(result){
					if(result.data.response.status == "success"){
						deferred.resolve(result.data);
					}
				});
			return deferred.promise;
		}
	
		return {
			getQuestion: getQuestion,
			submitResponse: submitResponse,
			skipResponse: skipResponse,
			share: share,
			getQuestionById: getQuestionById,
			reportQuestion: reportQuestion
		};
	})
	.factory('questionControllerFactory', function(){
		var format = function(array){
			var result = [];
			array.forEach(function(item){
				result.push(item.toUpperCase());
			});
			return result;
		};

		var isSelected = function(choices){
			var selected = false;
			choices.forEach(function(choice){
				if(choice.selected){
					selected = true;
				}
			});
			return selected;
		};

		var isCorrect = function(choices, answer){
			answer.sort();
			var selectedAnswers=[];
			choices.forEach(function(choice){
				if(choice.selected){
					selectedAnswers.push(choice.id);
				}
			});
			if(answer.toString().toLowerCase() != selectedAnswers.toString().toLowerCase())
				return false;
			else return true;
		};

		return {
			format: format,
			isSelected: isSelected,
			isCorrect: isCorrect
		};
	})
;