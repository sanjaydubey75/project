angular.module('app.question')
	.controller('app.question_questionController', [
		"app.question_questionFactory", "$scope", "$stateParams", "$timeout", "$location", "$modal",
		"app.question_questionService", "app.subject_subjectFactory", "app.topic_topicFactory",
		"app.question_questionControllerFactory",
		function (QuestionFactory, $scope, $stateParams, $timeout, $location, $modal,
				  QuestionService, SubjectFactory, TopicFactory,
				  QuestionControllerFactory)
		{

			SubjectFactory.getSubjectDetails($stateParams.subid).then(function (subject)
			{
				$scope.subject = subject;
			});


			$scope.time = null;

			$scope.score = QuestionService.initialize($stateParams.topicid);

			//This is just to make the text area for question input visible. This is not required anymore
			//$scope.visible=false;

			$scope.submitted = false;

			$scope.submit = function () {
				$scope.dirtyForm = true;
				$scope.mustSelect = !QuestionControllerFactory.isSelected($scope.choices);
				if ($scope.mustSelect == true)return;
				if ($scope.submitted == true)return;
				$scope.submitted = true;
				$scope.correctAnswer = QuestionControllerFactory.isCorrect($scope.choices, $scope.question.answer);
				QuestionFactory.submitResponse($scope.subject.id, $scope.topic.id, $scope.question.id, $scope.correctAnswer, $scope.time)
					.then(function (result) {
						QuestionService.setScore($scope.correctAnswer);
					});
			};

			$scope.skip = function () {
				$scope.next();
				QuestionFactory.skipResponse($scope.subject.id, $scope.topic.id, $scope.question.id)
					.then(function (result) {
						QuestionService.setScore(false);
					});
			};

			$scope.next = function () {
				$scope.loaded = false;
				QuestionFactory.getQuestion($stateParams.subid, $stateParams.topicid)
					.then(function (result) {
						$scope.question = result.question;
						$scope.time = new Date();
						$scope.time.setMinutes(result.question.time.min, result.question.time.sec);
						$scope.choices = result.choices;
						$scope.formattedAnswer = QuestionControllerFactory.format($scope.question.answer.sort()).toString();
						$scope.loaded = true;
						$scope.submitted = false;

					}, function (error) {
						if (error.response.code == "subscription-over") {
							$scope.subscriptionOver = true;
							$scope.question = null;
							$scope.choices = null;
							$scope.loaded = true;
							$scope.submitted = false;
						}
						if (error.response.code == "level-over") {
							$scope.topicComplete = true;
							$scope.question = null;
							$scope.choices = null;
							$scope.loaded = true;
							$scope.submitted = false;
						}
					})
					.then(function () {
						TopicFactory.getTopicDetails($stateParams.topicid).then(function (topic) {
							$scope.topic = topic;
						});
					});
				$scope.dirtyForm = false;
			};

			//mostly this has no need
			//$scope.statusShareQuestion = {isFirstOpen: false};

			$scope.next();

			$scope.quit = function () {
				$location.path("/");
			};

			$scope.changeTopic = function (value) {
				$location.path('iitjeeprogram/subject/' + value);
			};

			//mostly this has no need
			//$scope.menu = {isFirstOpen: false};

			//$scope.friend = {'email': null};
			//$scope.emailSent = false;

			$scope.modal = {};
			$scope.modalInstance = {};
			$scope.modal.openShareModal = function (size) {
				$scope.modalInstance.shareModal = $modal.open({
					templateUrl: "views/partials/common/question/ShareQuestion.html",
					scope: $scope,
					size: size,
					controller: 'app.question_shareQuestionModalController'
				});
			};

			$scope.modal.reportError = function (size) {
				$scope.modalInstance.reportErrorModal = $modal.open({
					templateUrl: "views/partials/common/question/ReportError.html",
					scope: $scope,
					size: size
				});
				QuestionFactory.reportQuestion($scope.question.id).then(function (result) {
					$timeout(function () {
						$scope.modalInstance.reportErrorModal.dismiss();
					}, 3000);
				});
			};

			$scope.modal.topicLevelIncrease = function (size) {
				$scope.modalInstance.topicLevelIncreaseModal = $modal.open({
					templateUrl: "views/partials/common/question/topicLevelIncrease.html",
					scope: $scope,
					size: size
				});
			};

			$scope.$watch('topic.level', function (newValue, oldValue) {
				if (newValue > oldValue) {
					$scope.modal.topicLevelIncrease();
				}
			});

			$scope.cancelModal = function () {
				if ($scope.modalInstance.shareModal)
					$scope.modalInstance.shareModal.dismiss();
				if ($scope.modalInstance.reportErrorModal)
					$scope.modalInstance.reportErrorModal.dismiss();
				if ($scope.modalInstance.topicLevelIncreaseModal)
					$scope.modalInstance.topicLevelIncreaseModal.dismiss();
			};


		}])
	.controller('app.question_shareQuestionController', [
		"$scope", "$stateParams", "app.question_questionFactory", "app.question_questionControllerFactory",
		function ($scope, $stateParams, QuestionFactory, QuestionControllerFactory) {

			$scope.loaded = false;

			QuestionFactory.getQuestionById($stateParams.questionId, $stateParams.token, $stateParams.friend, $stateParams.student)
				.then(function (result) {
					$scope.question = result.question;
					$scope.choices = result.choices;
					$scope.formattedAnswer = QuestionControllerFactory.format($scope.question.answer.sort()).toString();
					$scope.loaded = true;
				});
		}
	])
	.controller('app.question_shareQuestionModalController', [
		"$scope", "$modalInstance", "app.question_questionFactory", "$timeout",
		function ($scope, $modalInstance, QuestionFactory, $timeout) {

		var states = {start: "start", progress: "progress", complete: "complete"};

		$scope.state = states.start;

		$scope.share1 = function () {
			if ($scope.friend.email) {

				$scope.state = states.progress;

				QuestionFactory.share($scope.friend.email, $scope.question.id)
					.then(function (message) {

						$scope.message = message;
						$scope.state = states.complete;

						$timeout(function () {
							$scope.message = null;
							$modalInstance.close();
						}, 2000);
					}, function (message) {
						$scope.state = states.start;
						$scope.message = message;
						$timeout(function () {
							$scope.message = null;
						}, 2000);
					});
			}
		};
	}])
;