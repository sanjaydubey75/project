angular.module('app.web.forgetPassword')
.factory('forgetPasswordFactory', function($http, $q, $location){
	var sendRequest = function (data) {
		var deferred = $q.defer();
		$http.post("api/forgetpassword", data, {})
		.then(function(result) {
			if(result.data.response.status=='success'){
				deferred.resolve(result.data.response.message);
			}
		}, function(error) {
			deferred.reject(error);
		});
		return deferred.promise;
	};
	
	var getToken = function(){
		return this.token;
	};
	
	var setToken = function(token){
		this.token = token;
	};
	
	var setEmail = function(email){
		this.email = email;
	}
	
	var changePassword = function(newPassword){
		var deferred = $q.defer();
		$http.post("api/changepassword", {
			'newPassword' : newPassword,
			'tokenId': this.token,
			'email' : this.email
		}, {})
		.then(function(result) {
			if(result.data.response.status=='success'){
				deferred.resolve(result.data.response.message);
			}
		}, function(error) {
			deferred.reject(error);
		});
		return deferred.promise;
	}
	
	return {
		sendRequest: sendRequest,
		getToken: getToken,
		setToken: setToken,
		setEmail: setEmail,
		changePassword: changePassword
	}
});