angular.module('app.web.forgetPassword')
	.controller('app.web.forgetPassword_forgetPasswordController',
	["$scope", "app.web.forgetPassword_forgetPasswordFactory", "$filter", "$stateParams", "$state", "$location",
		function($scope, ForgetPasswordFactory, $filter, $stateParams, $state, $location){

			$scope.$watch('dobmask', function()
			{

				if (!$scope.dobmask)return;
				var parts = $scope.dobmask.split("/");
				if(!$scope.user)$scope.user={};
				$scope.user.dateOfBirth = parts[1]+"/"+parts[0]+"/"+parts[2];

			});

			$scope.$watch('dobhidden', function(newValue, oldValue)
			{
				if(newValue !== oldValue)
					$scope.dobmask = $filter('date')($scope.dobhidden, 'dd/MM/yyyy');
			});

			$scope.submit = function ()
			{
				if($scope.ForgetPasswordForm.$valid)
				{
					ForgetPasswordFactory.sendRequest($scope.user)
						.then(function(msg)
						{
							$scope.message = msg;
						});
				}
			};

			$scope.change = function()
			{
				if($scope.ChangePasswordForm.$valid)
				{
					ForgetPasswordFactory.changePassword($scope.user.password)
						.then(function ()
						{
							$scope.passwordChanged = true;
						});
				}
			};

			if($stateParams.tokenId != "default" && $stateParams.tokenId)
			{
				ForgetPasswordFactory.setToken($stateParams.tokenId);
				ForgetPasswordFactory.setEmail($stateParams.email);
			}

			$scope.maxDate = new Date();
			$scope.format = 'd/M/yyyy';
			$scope.open = function($event)
			{
				$event.preventDefault();
				$event.stopPropagation();
				$scope.opened = true;
			};

			$scope.dateOptions = {
				formatYear: 'yy',
				startingDay: 1
			};

			if($scope.ForgetPasswordForm){
				$scope.$watch(function()
				{
					return $scope.ForgetPasswordForm.Email.$modelValue + $scope.ForgetPasswordForm.DateOfBirth.$modelValue;
				}, function()
				{
					$scope.message = null;
				});
			}

		}
	])
;