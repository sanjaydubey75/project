angular.module('app.web.forgetPassword')
	.config(['$stateProvider', '$locationProvider', '$urlRouterProvider', function($stateProvider, $locationProvider, $urlRouterProvider) {
		$locationProvider.html5Mode(true);
		$urlRouterProvider.otherwise("/");
		$stateProvider
			.state('app.web.forgetPassword', {
				abstract: true,
				template: "<ui-view/>",
				data: {
					bannedTypes: ['student', 'tutor']
				}
			})
			.state('app.web.forgetPassword.forgetPasswordForm', {
				url: '/forgetpassword',
				templateUrl: 'views/partials/forgetpassword.html',
				controller: 'app.web.forgetPassword_forgetPasswordController',
				controllerAs: 'forgetpassword'
			})
			.state('app.web.forgetPassword.changePasswordForm', {
				url: '/changePassword/{tokenId}/{email}',
				params: {
					tokenId: {
						value: "default"
					},
					email:{
						value: "default"
					}
				},
				templateUrl: 'views/partials/changePassword.html',
				controller: 'app.web.forgetPassword_forgetPasswordController',
				controllerAs: 'forgetpassword'
			});
	
}]);