angular.module('app.web', [
	'ui.router', 'app.web.home', 'app.web.forgetPassword', 'app.web.question',
	'app.web.register', 'app.web.student', 'app.web.topicLevelTest', 'app.web.tutor',
	'app.web.authentication'
])
	.namespace({
		delimiter: '_',
		methods: [
			'factory',
			'service',
			'provider',
			'constant',
			'value'
		]
	})
;