/**
 * Created by Omkar on 18-Dec-15.
 */
'use strict';
MathJax.Hub.Config({
    skipStartupTypeset: true,
    messageStyle: "none",
    "HTML-CSS": {
        showMathMenu: false
    },
    tex2jax: {
        inlineMath: [
            ["$", "$"],
            ["\\(", "\\)"]
        ]
    },
    TeX: {
        extensions: ["mhchem.js"]
    }
});
MathJax.Hub.Configured();
angular.module('app',
    [
        'ngCookies', 'ui.router',
        'ui.bootstrap', 'app.security',
        'app.android', 'app.interceptor',
        'app.question', 'app.topic',
        'app.subject'
    ])
    .namespace({
        delimiter: '_',
        methods: [
            'factory',
            'service',
            'provider',
            'constant',
            'value'
        ]
    })
;