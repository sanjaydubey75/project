'use strict'; 
MathJax.Hub.Config({
    skipStartupTypeset: true,
    messageStyle: "none",
    "HTML-CSS": {
        showMathMenu: false
    },
    tex2jax: {
        inlineMath: [
            ["$", "$"],
            ["\\(", "\\)"]
        ]
    },
    TeX: {
      extensions: ["mhchem.js"]
    }
});
MathJax.Hub.Configured();
angular.module('app',
	[
		'ngCookies', 'duScroll',
		'ui.router', 'ui.bootstrap',
		'app.web', 'app.security',
        'app.android', 'app.interceptor',
        'app.question', 'app.topic',
        'app.subject','youtube-embed'
	])
	.namespace({
		delimiter: '_',
		methods: [
			'factory',
			'service',
			'provider',
			'constant',
			'value'
		]
	})
;