angular.module('app.android')
	.config(['$stateProvider', '$locationProvider', '$urlRouterProvider',
		function($stateProvider, $locationProvider, $urlRouterProvider)
		{
            $locationProvider.html5Mode({
                enabled: true,
                requireBase: false
            });
            $urlRouterProvider.otherwise("/");

			$stateProvider
				.state('app.android', {
					url: "/mobile",
					abstract: true,
					templateUrl: "views/partials/android/android.index.html"
				})
				.state('app.android.initialize',
				{
					url: "/question/:subid/:topicid/:userFirstname/:userEmail/{password:.*}",
					controller: 'app.android_mobileInitializationController',
					data: {
						bannedTypes: ['student', 'tutor']
					}
				})
				.state('app.android.question', {
					url: "/question/:subid/:topicid",
					views: {
						"": {
							templateUrl: "views/partials/mobilequestion.html",
							controller: 'app.question_questionController'
						},
						"menu@app.android.question": {
							templateUrl: 'views/partials/mobilequestion/menu.html'
						}
					},
					data: {
						roles: ['studentTrial', 'studentUnlimited'], //careful this will overwrite it.
						allowedTypes: ['student']
					}
				}
            );
		}
	]);