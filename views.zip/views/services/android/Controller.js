angular.module('app.android')
	.controller('app.android_mobileInitializationController',  [
		"$scope", "$auth", "app.security_principal", "$stateParams", "$location",
        function ($scope, $auth, principal, $stateParams, $location)
	{            
            $auth.login({
                email: $stateParams.userEmail,
                password: $stateParams.password,
                type: "student"
            }).then(function(result)
            {
                principal.authenticate(result.data);
                $location.path('/mobile/question/' + $stateParams.subid + '/' + $stateParams.topicid);
            }, function(error){
                $scope.message.text = error.data.details;
            });		
	}]);