angular.module('app')
	.controller('mainAppController', [
		"$scope", "$rootScope", "app.security_principal",
		function ($scope, $rootScope, principal) {

			$scope.principal = principal;
		}
	])

;