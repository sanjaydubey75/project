angular.module('app.topic')
	.factory('topicService', [
		"$filter",
		function($filter){
			var initialOrder = {};

			var initialize = function(topics){
				for(i = 0; i < topics.length; i++){
					//var key = topics[i].id;
					//initialOrder.push({key: i});
					initialOrder[topics[i].id] = i;
				}
			};

			var cleanup = function(){
				initialOrder = {};
			};

			var setTestTopicsLastFilter = function(topics){
				initialize(topics);
				topics.sort(function(x, y){
					var testArray = ['PT', 'MT', 'KVP', 'oct', 'BXW'];
					if(testArray.indexOf(x.id) != -1 && testArray.indexOf(y.id) == -1){
						//make x last
						return 1;
					}
					if(testArray.indexOf(y.id) != -1 && testArray.indexOf(x.id) == -1){
						//make y last
						return -1;
					}
					return initialOrder[x.id] - initialOrder[y.id];
				});
				cleanup();
			};

			var sortAccordingToExplicitOrder = function(topics){
				initialize(topics);
				topics.sort(function(topic1, topic2){
					if(topic1.order == topic2.order){
						return initialOrder[topic1.id] - initialOrder[topic2.id];
					} else
						return (topic1.order - topic2.order);
				});
				cleanup();
			};

			var sortAlphabetically = function(topics){
				$filter('orderBy')(topics, function(topic){
					return topic.name.trim();
				});
			};

			var sort = function(topics){
				sortAlphabetically(topics);
				setTestTopicsLastFilter(topics);
				sortAccordingToExplicitOrder(topics);
			};

			var filterTopicsForTrialStudent = function(topics)
			{
                // removed 'ATS', 'Hyn', 'PBE', 'K', 'LM', 'T', '2D'
				var listOfOpenTopics = [];

				topics.forEach(function(topic)
				{
                    // reversed boolean values.
					if(listOfOpenTopics.indexOf(topic.id) == -1)
						topic.restricted = false;
					else
						topic.restricted = true;
				});
			};

			return {
				sort: sort,
				filterTopicsForTrialStudent: filterTopicsForTrialStudent
			};
		}
	])
;