angular.module('app.topic')
    .factory('topicFactory', function($window, $q, $http){
        function getTopics(subjectid){
            var deferred = $q.defer();
            $http.get("api/auth/topic/"+subjectid, {})
            .then(function(result){
                if(result.data.response.status != "success"){
                    deferred.reject(result.data.message);
                }
                deferred.resolve(result.data);
            }, function(error){
                deferred.reject(error);
            });
            return deferred.promise;
        }
        function getTopicDetails(topicId){
            var deferred = $q.defer();
            $http.get("api/auth/topic/details/" + topicId, {})
            .then(function(result){
                if(result.data.response.status != "success"){
                    deferred.reject(result.data.message);
                }
                deferred.resolve(result.data.topic);
            }, function(error){
                deferred.reject(error);
            });
            return deferred.promise;
        }
        return {
            getTopics: getTopics,
            getTopicDetails: getTopicDetails
        };
    })
;