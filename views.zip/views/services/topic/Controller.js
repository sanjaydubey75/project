angular.module('app.topic')
.controller('app.topic_topicController', function(){
	
});