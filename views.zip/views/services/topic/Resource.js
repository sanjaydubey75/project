angular.module('app.topic')
	.factory('topicResource', [
		"$resource",
		function($resource){
			return $resource('iitjeeacademy/api/v1/topic/:id');
		}
	])
    .factory('lectureResource', [
        "$resource",
        function($resource){
            return $resource('iitjeeacademy/api/v1/lecture/:id');
        }
    ])
;