angular.module('app.question', ['app.subject', 'ui.router', 'LocalStorageModule'])
	.namespace({
		delimiter: '_',
		methods: [
			'factory',
			'service',
			'provider',
			'constant',
			'value'
		]
	})
;