angular.module('app.question')
	.factory('questionService', function(localStorageService){
		var score;

		var _topicId;

		var initialize = function(topicId){
			_topicId = topicId;
			score = localStorageService.get('session.score');
			if(!score) score = {};
			return _getScore(_topicId);
		};

		var _getScore = function(){
			if(!score[_topicId])
				score[_topicId] = {correctAttempts: 0, totalAttempts: 0};
			_save();
			return score[_topicId];
		};

		var _save = function(){
			localStorageService.set('session.score', score);
		};

		var setScore = function(correct){
			if(correct)
				score[_topicId].correctAttempts++;
			score[_topicId].totalAttempts ++;
			_save();
		};

		return {
			initialize: initialize,
			setScore: setScore
		};
	})
;