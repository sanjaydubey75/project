angular.module('app.question')
    .directive('app.question.zoomAnimate', function($timeout){
        return {
            restrict: 'A',
            scope:{
                dirtyForm: '@dirtyForm',
                warning: '@'
            },
            link: function(scope, element, attrs){
                scope.$watch('dirtyForm', function(){
                    if(scope.warning){
                        if(scope.warning == 'true'){
                            element.css({
                                color: '#E32626'
                            });
                        }
                    }
                    if(scope.dirtyForm){
                        element.addClass('animated');
                        element.addClass('zoomIn');
                    } else {
                        element.removeClass('zoomIn');
                        element.removeClass('animated');
                    }
                });
            }
        };
    })

	.directive('app.question.mathjaxParse1', function($rootScope){
		var temp = 0;// to make sure that choices are centered after rendering
		var temp1 = 0;// to make sure that once all the html content has been put in the page, the choice labels are also hidden
						// this is to happen before rendering
		return {
			restrict: 'A',
			scope: {
				content: '=',
				loaded: '='
			},
			link: function(scope, element, attrs){
				scope.$watch('loaded', function(){
					if(scope.loaded == true){
						var x = angular.element(element)[0];
						if(scope.content)
							x.innerHTML = scope.content;
						else
							x.innerHTML = null;
						x.classList.add('hidden');
						MathJax.Hub.Queue(["Typeset",MathJax.Hub, x], function(){
							//var x = angular.element(element)[0];
							//x.classList.remove('hidden');

							temp++;
							if(temp == 5){
								//send event
								$rootScope.$broadcast("MathJax_Render", "complete");
								temp = 0;
							}
						});
						temp1++;
						if(temp1==5){
							$rootScope.$broadcast("MathJax_Render", "start");
							var labels = document.getElementsByTagName('label');
							[].forEach.call(labels, function(label){
								angular.element(label).addClass('hidden');
							});
							temp1 = 0;
						}
					}
				});
			}
		};
	})
	.directive('app.solution.mathjaxParse1', function($rootScope){
		return {
			restrict: 'A',
			scope: {
				content: '=',
				loaded: '=',
				solution: '='
			},
			link: function(scope, element, attrs){
				scope.$watch('loaded', function(){
					if(scope.loaded == true){
						var x = angular.element(element)[0];
						if(scope.content)
							x.innerHTML = scope.content;
						else
							x.innerHTML = null;
						MathJax.Hub.Queue(["Typeset",MathJax.Hub, x], function(){
                            $rootScope.$broadcast("MathJax_Render", "complete");
						});
                        $rootScope.$broadcast("MathJax_Render", "start");
                        var labels = document.getElementsByTagName('label');
                        [].forEach.call(labels, function(label){
                        });
					}
				});
			}
		};
	})

	.directive('app.question.choiceCenter', function($window, $rootScope){
		var getAllElementsWithAttribute = function (attribute)
		{
			var matchingElements = [];
			var allElements = document.getElementsByTagName('*');
			for (var i = 0, n = allElements.length; i < n; i++)
			{
				if (allElements[i].getAttribute(attribute) !== null)
				{
					// Element exists with attribute. Add to array.
					matchingElements.push(allElements[i]);
				}
			}
			return matchingElements;
		};
		return{
			restrict: 'A',
			scope:{
				loaded: '='
			},
			link: function(scope, element, attr){
				var setMargin = function(){
					var margin = (element.parent()[0].clientWidth - element[0].clientWidth)/2;
					element[0].style.marginLeft = margin+"px";
				};

				var makeDomVisible = function(){
					var labels = document.getElementsByTagName('label');
					[].forEach.call(labels, function(label){
						angular.element(label).removeClass('hidden');
					});
				};

				$rootScope.$on("MathJax_Render", function(event, message){
					if(message == 'complete'){
						var elems = getAllElementsWithAttribute("app.question.mathjax-parse1");
						elems.forEach(function(elem){
							var x = angular.element(elem)[0];
							x.classList.remove('hidden');
						});

						makeDomVisible();
						setMargin();setMargin();setMargin();
					}
				});

				scope.onResize = function(){
					setMargin();
				};

				angular.element($window).bind('resize', function() {
					scope.onResize();
				});
			}
		};
	})
	.directive('app.question.hideWhenQuestionChanges', function($rootScope){
		return {
			restrict: 'A',
			scope:{},
			link: function(scope, elem, attrs){
				$rootScope.$on('MathJax_Render', function(event, message){
					if(message == 'complete'){
						//show the div
						elem.removeClass('hidden');
					} else if(message=='start'){
						//hide the div
						elem.addClass('hidden');
					}
				});
			}
		};
	})
	.directive('app.question.questionClock', function($interval, $rootScope){
		return{
			restrict: 'E',
			scope: {
				loaded: '=',
				time: '=',
				submitted: '='
			},
			templateUrl: 'views/partials/question/directivetemplate/clock.html',
			link: function(scope, element, attrs){

				var timeoutId;

				function updateTime() {
					var timeLeft = scope.time.getSeconds() + scope.time.getMinutes()*60;
					scope.time = new Date();
					scope.time.setMinutes(0, 0);
					scope.time.setSeconds(timeLeft - 1);
					if(timeLeft == 1){
						element.css({color: 'red'});
						$interval.cancel(timeoutId);
					}
				}

				$rootScope.$on("MathJax_Render", function(event, message) {
					if (message == 'complete') {
						element.css({color: 'black'});
						//scope.time = new Date();
						//scope.time.setMinutes(0, 3);
						timeoutId = $interval(function() {
							updateTime(); // update DOM
						}, 1000);
					}
				});

				scope.$watch('submitted', function(){
					if(scope.submitted == true)
						$interval.cancel(timeoutId);
				});

				scope.$watch('loaded', function() {
					if (scope.loaded != true) {
						$interval.cancel(timeoutId);
					}
				});

				element.on('$destroy', function() {
					$interval.cancel(timeoutId);
				});
			}
		};
	})
	.directive('app.question.score', function(){
		return {
			restrict: 'E',
			scope: {
				score: "="
			},
			templateUrl: "views/partials/common/question/directivetemplate/score.html"
		};
	})
    //the following is partly kept for the fact that in a later stage, if there is a need to create
    //an interface for input of mathjax, this will prove to be a guiding step for next directive
    .directive("mathjaxBind", function() {
        return {
            restrict: "A",
            scope:{
                text: "@mathjaxBind"
            },
            controller: ["$scope", "$element", "$attrs", function($scope, $element, $attrs) {
                $scope.$watch('text', function(value) {
                    var $script = angular.element("<script type='math/tex'>")
                    .html(value == undefined ? "" : value);
                    $element.html("");
                    $element.append($script);
                    MathJax.Hub.Queue(["Reprocess", MathJax.Hub, $element[0]]);
                });
            }]
        };
    })
.directive('dynamic', function ($compile) {
        return {
            restrict: 'A',
            replace: true,
            link: function (scope, ele, attrs) {
                scope.$watch(attrs.dynamic, function(html) {
                    if(!html) return;
                    html = html.replace(/{{([^{}]+)}}/g, "{$1}");
                    html = html.replace(/\$\$([^$]+)\$\$/g, "<span class=\"display-block\" mathjax-bind=\"$1\"></span>");
                    html = html.replace(/\$([^$]+)\$/g, "<span class=\"display-inline\" mathjax-bind=\"$1\"></span>");
    //				html = html.replace(/^(.*)$/, "<span mathjax-bind=\"\">$1</span>");
                    ele.html(html);
                    $compile(ele.contents())(scope);
                });
            }
        };
    })
;