angular.module('app.security')
	.factory('401InterceptorFactory', [
		"app.security_handleErrorFactory", "$q",
		function(handleErrorFactory, $q)
		{
			return {
				responseError: function(rejection)
				{
					if(rejection.status == 401 && rejection.config.url != "/iitjeeacademy/api/v1/login")
					{
						handleErrorFactory.handle401();
					}
					return $q.reject(rejection);
				}
			};
		}
	])
;