angular.module('app.security')
	.factory('handleErrorFactory', [
		"$cookieStore", "$injector", "app.security_principal",
		function($cookieStore, $injector, principal)
		{
			//remember to never put $http or anything which has a dependency to $http (ex $state) in an interceptor

			return {
				handle401: function()
				{
					//if the user is authenticated (client-side)
					if(principal.isIdentityResolved())
					{
						var type = principal.getType();
						principal.identity(true);
						$cookieStore.remove("auth-token");
						localStorage.clear();
						switch(type){
							case 'student':
								$injector.get('$state').go('app.web.login.student');
								break;
							case 'tutor':
								$injector.get('$state').go('app.web.login.tutor');
								break;
						}
					}
					else
					{
						$cookieStore.remove("auth-token");
						$injector.get('$state').go('app.web.home');
					}
				}
			};
		}
	])
;