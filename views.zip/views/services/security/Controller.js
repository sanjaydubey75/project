angular.module('app.security')
	.controller('app.security_loginController', [
		"$scope", "$auth", "app.security_principal",
		function ($scope, $auth, principal)
		{
			$scope.$watch(function (){
				return $scope.LoginForm.Email.$modelValue + $scope.LoginForm.password.$modelValue;
			}, function (){
				$scope.message.text = null;
			});

			$scope.message = {text: null};

			$scope.login = function (type)
			{
				$auth.login({
					email: $scope.user.email,
					password: $scope.user.password,
					type: type
				}).then(function(result)
				{
					principal.authenticate(result.data);
				}, function(error){
					$scope.message.text = error.data.details;
				});
			};

			//make sure to handle the case when the user has revoked some permissions like email address
			$scope.authenticate = function(provider) {
				$auth.authenticate(provider)
					.then(function(result) {
						principal.authenticate(result.data);
					})
					.catch(function(response) {
						console.log(response);
					});
			};
		}])
	.controller('app.security_logoutController', [
		"$scope", "$state", "app.security_principal", "$cookieStore",
		function ($scope, $state, principal, $cookieStore){
			localStorage.clear();
			principal.identity(true);
			$cookieStore.remove("auth-token");
			localStorage.clear();
			$state.go('app.web.home');
		}
	])
;