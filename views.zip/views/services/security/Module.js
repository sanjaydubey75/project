angular.module('app.security', ['satellizer'])
	.namespace({
		delimiter: '_',
		methods: [
			'factory',
			'service',
			'provider',
			'constant',
			'value'
		]
	});