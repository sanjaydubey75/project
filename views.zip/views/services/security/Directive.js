//angular.module('app.security')
//	.directive('app.security.hideMessageOnInputChange', function()
//	{
//		return {
//			restrict: 'A',
//			scope: {
//				text: "=app.security.hideMessageOnInputChange"
//			},
//			link: function(scope, element, attrs)
//			{
//				var inputs = element.find('input');
//				var txt = "";
//				angular.forEach(inputs, function(input){
//
//				});
//				scope.$watch()
//			}
//		}
//	})
//;