angular.module('app.security')
	.factory('redirect', ['$rootScope', '$state', 'app.security_principal',
		function($rootScope, $state, principal)
		{
			return {
				preventRedirectIfNotAllowed: function()
				{
					var isAuthenticated = principal.isAuthenticated();
					if(isAuthenticated)
					{
						if($rootScope.toState.data.bannedTypes)
							return $rootScope.toState.data.bannedTypes.indexOf(principal.getType()) != -1;
						else return false;
					}
				}
			};
		}
	])
;