angular.module('app.security')
	.config([
		'$authProvider', "$httpProvider",
		function($authProvider, $httpProvider)
		{
			$authProvider.facebook({
				clientId: '1593029070984479'
			});

			$authProvider.google({
				clientId: '1087622139991-0kgcua9tqabdpm9vu01u4rshifsfebtf.apps.googleusercontent.com'
			});

			// Facebook
			$authProvider.facebook({
				url: '/api/v1/login/facebook',
				authorizationEndpoint: 'https://www.facebook.com/v2.3/dialog/oauth',
				redirectUri: (window.location.origin + "/") ||
				(window.location.protocol + '//' + window.location.host + '/'),
				scope: 'email',
				scopeDelimiter: ',',
				requiredUrlParams: ['display', 'scope'],
				display: 'popup',
				type: '2.3',
				popupOptions: { width: 481, height: 269 }
			});

			// Google
			//the relevant documentation can be found at https://developers.google.com/identity/protocols/OpenIDConnect
			$authProvider.google({
				url: '/api/v1/login/google',
				authorizationEndpoint: 'https://accounts.google.com/o/oauth2/auth',
				redirectUri: window.location.origin || window.location.protocol + '//' + window.location.host,
				scope: ['profile', 'email', 'https://www.googleapis.com/auth/plus.login', 'https://www.googleapis.com/auth/plus.me'],
				scopePrefix: 'openid',
				scopeDelimiter: ' ',
				requiredUrlParams: ['scope'],
				optionalUrlParams: ['display'],
				display: 'popup',
				type: '2.0',
				popupOptions: { width: 580, height: 400 }
			});

			$authProvider.baseUrl = '/iitjeeacademy';
			$authProvider.loginUrl = "/api/v1/login";

			$httpProvider.interceptors.push('app.security_401InterceptorFactory');
		}
	])
;