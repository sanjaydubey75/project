angular.module('app.security')
	.factory('authorization', ['$rootScope', '$state', 'app.security_principal',
		function($rootScope, $state, principal)
		{
			return {
				authorize: function()
				{
					return principal.identity()
						.then(function()
						{
							var isAuthenticated = principal.isAuthenticated();

							if ($rootScope.toState.data.allowedTypes && $rootScope.toState.data.allowedTypes.length > 0 &&
								!principal.isOfAnyType($rootScope.toState.data.allowedTypes))
							{
								if (isAuthenticated) $state.go('accessdenied'); // user is signed in but not authorized for desired state
							}
						});
				}
			};
		}
	])
;