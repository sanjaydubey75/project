angular.module('app.security')
	.factory('principal', ['$q', '$timeout',
		function($q, $timeout)
		{
			var _identity = undefined,
				_authenticated = false;

			return {
				isIdentityResolved: function()
				{
					return angular.isDefined(_identity);
				},
				isAuthenticated: function()
				{
					return _authenticated;
				},
				isInRole: function(role)
				{
					if (!_authenticated || !_identity.roles) return false;

					return _identity.roles.indexOf(role) != -1;
				},
				isInAnyRole: function(roles)
				{
					if (!_authenticated || !_identity.roles) return false;

					for (var i = 0; i < roles.length; i++) {
						if (this.isInRole(roles[i])) return true;
					}

					return false;
				},
				isOfType: function(type)
				{
					if (!_authenticated || !_identity.type) return false;

					return _identity.type == type;
				},
				isOfAnyType: function(types)
				{
					if (!_authenticated || !_identity.type) return false;

					for (var i = 0; i < types.length; i++) {
						if (this.isOfType(types[i])) return true;
					}

					return false;
				},
				getType: function () {
				    if (_identity)
					    return _identity.type;
				},
				authenticate: function(identity)
				{
					_identity = identity;
					_authenticated = identity != null;
					// for this demo, we'll store the identity in localStorage. For you, it could be a cookie, sessionStorage, whatever
					if (identity) localStorage.setItem("app.identity", angular.toJson(identity));
					else localStorage.removeItem("app.identity");
				},
				identity: function(force)
				{
					var deferred = $q.defer();

					if (force === true){
						_authenticated = false;
						_identity = undefined;
					}

					// check and see if we have retrieved the identity data from the server. if we have, reuse it by immediately resolving
					if (angular.isDefined(_identity))
					{
						deferred.resolve(_identity);

						return deferred.promise;
					}

					var self = this;

					$timeout(function () {
						_identity = angular.fromJson(localStorage.getItem("app.identity"));
						self.authenticate(_identity);
						deferred.resolve(_identity);
					}, 0);

					return deferred.promise;
				}
			};
		}
	])
;