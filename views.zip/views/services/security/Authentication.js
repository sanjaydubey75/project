angular.module('app.security')
	.factory('authentication', ['$rootScope', '$state', 'app.security_principal',
		function($rootScope, $state, principal)
		{
			return {
				authenticate: function()
				{
					return principal.identity()
						.then(function()
						{
							var isAuthenticated = principal.isAuthenticated();

							if ($rootScope.toState.data.allowedTypes && $rootScope.toState.data.allowedTypes.length > 0 &&
								!principal.isOfAnyType($rootScope.toState.data.allowedTypes))
							{
								if (!isAuthenticated)
								{
									// user is not authenticated. stow the state they wanted before you
									// send them to the signin state, so you can return them when you're done
									// this feature is to be implemented later
									$rootScope.returnToState = $rootScope.toState;
									$rootScope.returnToStateParams = $rootScope.toStateParams;

									// now, send them to the signin state so they can log in
									// how to find whether to defer to tutor login or student login?
									$state.go('app.web.home');
								}
							}
						});
				}
			};
		}
	])
;