angular.module('app.security')
	.run(['$rootScope', '$state', '$stateParams', 'app.security_authorization',
		'app.security_authentication', 'app.security_principal', "app.security_redirect",
		"app.security_handleErrorFactory",
		function($rootScope, $state, $stateParams, authorization,
		         authentication, principal, redirect,
		         handleErrorFactory)
		{
			$rootScope.$on('$stateChangeStart', function(event, toState, toStateParams, fromState, fromStateParams)
			{
				// track the state the user wants to go to; authorization service needs this
				$rootScope.toState = toState;
				$rootScope.toStateParams = toStateParams;
				// if the principal is resolved, do an authorization check immediately. otherwise,
				// it'll be done when the state it resolved.
				if (principal.isIdentityResolved()) {
					authentication.authenticate();
					authorization.authorize();
				}

				if(redirect.preventRedirectIfNotAllowed())
				{
					event.preventDefault();
				}
			});

			$rootScope.$on("$stateChangeError", function(event, toState, toParams, fromState, fromParams, error)
			{
				if(error.status == 401)
				{
					handleErrorFactory.handle401();
				}
			});
		}
	])
;