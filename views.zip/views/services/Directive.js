angular.module('app')
	.directive('app.minHeightCoverWindow', function($window, $timeout){
		return {
			restrict: 'A',
			scope: {},
			link: function(scope, elem, attrs){
				angular.element(document).ready(function() {
					var header = document.getElementsByTagName('header');
					var footer = document.getElementsByTagName('app.web.footer');
					var minHeight = $window.innerHeight;
					if(header[0])
						minHeight = minHeight - header[0].offsetHeight;
					if(footer[0])
					{
						var footer1 = footer[0].getElementsByClassName('footer');
						if(footer1[0])
							minHeight = minHeight - footer1[0].offsetHeight;
					}
					//var minHeight = $window.innerHeight - header[0].offsetHeight - footer[0].offsetHeight;
					elem.css('minHeight', minHeight+'px');
				});
			}
		};
	})
	.directive('app.customSmoothScrollTo', function($state, duScrollDuration, duScrollOffset, scrollContainerAPI, $timeout){
		var go = function($attr, $scope){
			var offset    = $attr.offset ? parseInt($attr.offset, 10) : duScrollOffset;
			var duration  = $attr.duration ? parseInt($attr.duration, 10) : duScrollDuration;
			var container = scrollContainerAPI.getContainer($scope);
			var target = document.getElementById($attr.href.replace(/.*(?=#[^\s]+$)/, '').substring(1));
			if(!target || !target.getBoundingClientRect) return;
			container.duScrollToElement(
				angular.element(target),
				isNaN(offset) ? 0 : offset,
				isNaN(duration) ? 0 : duration
			);
		};
		return {
			link: function($scope, $element, $attr){
				$element.on('click', function(e){
					if(!$attr.href || $attr.href.indexOf('#') === -1) return;

					if (e.stopPropagation) e.stopPropagation();// don't know what
					if (e.preventDefault) e.preventDefault();// these two are for

					if($state.current.name == 'app.web.home'){
						go($attr, $scope);
					} else {
						//first go to home page and after render is complete then do smooth scroll
						$state.go('app.web.home').then(function(){
							$timeout(function(){go($attr, $scope);}, 0);
						});
					}
				});
			}
		};
	})
;