angular.module('app')
	.config(['$stateProvider', '$locationProvider', '$urlRouterProvider', '$httpProvider',
		function($stateProvider, $locationProvider, $urlRouterProvider, $httpProvider)
		{
			$locationProvider.html5Mode(true);
			$urlRouterProvider.otherwise("/");
			$stateProvider
				.state('app',
				{
					abstract: true,
					template: "<ui-view/>",
					resolve: {
						authorize: ['app.security_authorization', function(authorization)
						{
							return authorization.authorize();
						}],
						authenticate: ['app.security_authentication', function(authentication)
						{
							return authentication.authenticate();
						}]
					},
					data: {}
				})
			;
			$httpProvider.interceptors.push('app.interceptor_customInterceptorFactory');
	}])
;