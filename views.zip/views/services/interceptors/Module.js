angular.module('app.interceptor', []).namespace({
	delimiter: '_',
	methods: [
		'factory',
		'service',
		'provider',
		'constant',
		'value'
	]
});