angular.module('app.interceptor')
	.factory('customInterceptorFactory', [
		"$window", "$rootScope", "$location", "app.interceptor_applicationStateFactory",
		function ($window, $rootScope, $location, applicationStateFactory)
		{
			var customInterceptorFactory = {
				request: function (config) {
					config.headers['X-XSRF-TOKEN'] = applicationStateFactory._getCookie('csrf-token');
					if (applicationStateFactory._getUserInfo()) {
						config.headers.userEmail = applicationStateFactory._getUserInfo().username;
						config.headers.role = applicationStateFactory._getUserInfo().type;
					}
					return config;
				},
				response: function (result) {
					if (result.data.response) {
						if (result.data.response.status == 'failed') {
							if (result.data.response.code == 'csrf-mismatch')
								//$window.location.reload();
							if (result.data.response.code == 'token-expired') {
								//localStorage.clear();
								//$location.path("/");
							}
						}
					}
					return result;
				}
			};
			return customInterceptorFactory;
		}])
	.factory('applicationStateFactory', function () {
		var _getCookie = function (name) {
			var regexp = new RegExp("(?:^" + name + "|;\\s*" + name + ")=(.*?)(?:;|$)", "g");
			var result = regexp.exec(document.cookie);
			return (result === null) ? null : result[1];
		};

		var _getUserInfo = function () {
			var temp = localStorage.getItem("app.identity");
			if (temp) {
				return angular.fromJson(temp);
			} else {
				return undefined;
			}
		};

		return {
			_getUserInfo: _getUserInfo,
			_getCookie: _getCookie
		}
	})
	.factory('customHeadersFactory', ["app.interceptor_applicationStateFactory", function (applicationStateFactory)
	{
		var getHeaders = function ()
		{
			var headers = {
				'X-XSRF-TOKEN': applicationStateFactory._getCookie('csrf-token')
			};

			if (applicationStateFactory._getUserInfo())
			{
				headers.userEmail = applicationStateFactory._getUserInfo().username;
				headers.role = applicationStateFactory._getUserInfo().type;
			}
			return headers;
		}

		return {
			getHeaders: getHeaders
		};
	}])
;