angular.module('app')
    .run(["$rootScope", "$state", '$stateParams', 'app.security_authorization', 'app.security_principal',
        function($rootScope, $state, $stateParams, authorization, principal)
        {
            //$rootScope.$on("$stateChangeError", function(event, toState, toParams, fromState, fromParams, error)
            //{
            //
            //});

	        $rootScope.$on("$stateChangeError", console.log.bind(console));

	        //this is required to load FB SDK. This is required to know if the user is logged in our app
	        //according to facebook, and if so, aomatically he should be given a token from the server.
	        //To be implemented later.
	        //On second thought, use ezfb angularjs module instead of this
	        (function(d, s, id) {
		        var js, fjs = d.getElementsByTagName(s)[0];
		        if (d.getElementById(id)) return;
		        js = d.createElement(s); js.id = id;
		        js.src = "//connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v2.3&appId=1593029070984479";
		        fjs.parentNode.insertBefore(js, fjs);
	        }(document, 'script', 'facebook-jssdk'));
        }
	])
;