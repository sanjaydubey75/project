angular.module('app.subject')
.factory('subjectFactory', function($window, $q, $http, $location){
	
	function getSubjects(){
		var deferred = $q.defer();
		$http.get("api/auth/subject", {})
		.then(function(result) {
			if(result.data.response.status != "success"){
				deferred.reject(result.data.message);
			}
			deferred.resolve(result.data.subjects);
		}, function(error) {
			deferred.reject(error);
		});
		return deferred.promise;
	}
	
	var getSubjectDetails = function(subid){
		var deferred = $q.defer();
		$http.get("api/auth/subject/details/" + subid, {})
		.then(function(result) {
			if(result.data.response.status != "success"){
				deferred.reject(result.data.message);
			}
			deferred.resolve(result.data.subject);
		}, function(error) {
			deferred.reject(error);
		});
		return deferred.promise;
	};
	
	return {
		getSubjects: getSubjects,
		getSubjectDetails: getSubjectDetails
	};
})