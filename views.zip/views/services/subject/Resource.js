angular.module('app.subject')
	.factory('subjectResource', [
		"$resource",
		function($resource)
		{
			return $resource('iitjeeacademy/api/v1/subject/:id');
		}
	])
;