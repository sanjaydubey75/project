The following is the dependency between the modules
.
        +---ngCookies, duScroll, ui.bootstrap, http-auth-interceptor
        |
        +---app.interceptor
        |
        |
app <---+------------------+
        |                  +----------------------------------------+------------- ui.router
        |---app.android <--+                                        |
        |                  +-- app.question                         |
        |                                                           |
        +---app.authentication <------------------------------------+
        |                                                           |
        |                                                           |
        +----------------------------------------+----app.topic <---+
        |                                        |                  |
        |                                        |                  |
        +-------------------+--app.subject <-----+------------------+
        |                   |                                       |
        +---app.question <--+---------------------------------------+
        |                   |
        |                   +---LocalStorageModule
        |
        +------------------------------------------app.security <----------------------------satellizer
        |
        |
        +---app.web <------ ui.router, 
                            app.web.home, app.web.forgetPassword, app.web.question,
                           	app.web.register, app.web.student, app.web.subject, app.web.topicLevelTest, app.web.tutor,
                           	app.web.authentication 
        
