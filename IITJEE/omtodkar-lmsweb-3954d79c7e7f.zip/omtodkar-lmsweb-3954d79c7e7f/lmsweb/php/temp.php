<?php
$a = str_replace("\\", "/", dirname(dirname(__FILE__)))."/";
$b = dirname(dirname(__FILE__));
echo dirname(__FILE__);
?>