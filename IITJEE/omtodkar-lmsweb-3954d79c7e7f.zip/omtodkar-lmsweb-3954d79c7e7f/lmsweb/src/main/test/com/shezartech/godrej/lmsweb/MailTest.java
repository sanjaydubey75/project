package com.shezartech.godrej.lmsweb;

import java.util.Locale;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.shezartech.godrej.lmsweb.config.MailConfig;
import com.shezartech.godrej.lmsweb.config.WebConfig;
import com.shezartech.godrej.lmsweb.service.MailService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { WebConfig.class, MailConfig.class, MailConfig.class })
public class MailTest
{

	@Autowired
	private MailService mailService;
	
	@Test
	public void testMail()
	{
		try
		{
			mailService.sendMail("345546", "Epre1928@armyspy.com", "dfg", "feedback");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("dfgrtf");
		}
		System.out.println("dfgrtf");
	}
}
