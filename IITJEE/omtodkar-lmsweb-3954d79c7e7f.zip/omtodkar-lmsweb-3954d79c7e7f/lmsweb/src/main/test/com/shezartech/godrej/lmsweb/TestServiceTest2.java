package com.shezartech.godrej.lmsweb;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.transaction.annotation.Transactional;

import com.shezartech.godrej.lmsweb.config.WebConfig;
import com.shezartech.godrej.lmsweb.dao.QuestionDao;
import com.shezartech.godrej.lmsweb.entity.core.Question;

import de.ailis.pherialize.Mixed;
import de.ailis.pherialize.Pherialize;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { WebConfig.class })
public class TestServiceTest2
{
	@Autowired
	private QuestionDao questionDao;
	
	@Test
	@Transactional(value = "txManagerNew")
	public void testQuestionMultipleOne()
	{
		
		Question question = questionDao.find(366); // the correct answer is 0
		
		Map<Integer, String> userAnswerCorrect = new HashMap<Integer, String>(){{
			put(0, "1");
			put(1, "0");
			put(2, "0");
			put(3, "0");
		}};
		
		Map<Integer, String> userAnswerWrong = new HashMap<Integer, String>(){{
			put(0, "0");
			put(1, "1");
			put(2, "0");
			put(3, "0");
		}};
		
		Object answer = unserialize2((String) question.getHashMap().get("answer"));
		Assert.assertEquals(true, isCorrectMultipleOne(userAnswerCorrect, answer));
		Assert.assertEquals(false, isCorrectMultipleOne(userAnswerWrong, answer));
		
		Question question2 = questionDao.find(367); // the correct answer is 1
		
		Map<Integer, String> userAnswerCorrect2 = new HashMap<Integer, String>(){{
			put(0, "0");
			put(1, "1");
			put(2, "0");
			put(3, "0");
		}};
		
		Map<Integer, String> userAnswerWrong2 = new HashMap<Integer, String>(){{
			put(0, "1");
			put(1, "0");
			put(2, "0");
			put(3, "0");
		}};
		
		Object answer2 = unserialize2((String) question2.getHashMap().get("answer"));
		Assert.assertEquals(true, isCorrectMultipleOne(userAnswerCorrect2, answer2));
		Assert.assertEquals(false, isCorrectMultipleOne(userAnswerWrong2, answer2));
		
		Question question3 = questionDao.find(368); // the correct answer is 2
		
		Map<Integer, String> userAnswerCorrect3 = new HashMap<Integer, String>(){{
			put(0, "0");
			put(1, "0");
			put(2, "1");
			put(3, "0");
		}};
		
		Map<Integer, String> userAnswerWrong3 = new HashMap<Integer, String>(){{
			put(0, "1");
			put(1, "0");
			put(2, "0");
			put(3, "0");
		}};
		
		Object answer3 = unserialize2((String) question3.getHashMap().get("answer"));
		Assert.assertEquals(true, isCorrectMultipleOne(userAnswerCorrect3, answer3));
		Assert.assertEquals(false, isCorrectMultipleOne(userAnswerWrong3, answer3));
	}
	
	@Test
	@Transactional(value = "txManagerNew")
	public void testQuestionMultipleMany()
	{
		Question question = questionDao.find(117); // the correct answer is 1 and 3
		
		Map<Integer, String> userAnswerCorrect = new HashMap<Integer, String>(){{
			put(0, "0");
			put(1, "1");
			put(2, "0");
			put(3, "1");
		}};
		
		Map<Integer, String> userAnswerWrong = new HashMap<Integer, String>(){{
			put(0, "0");
			put(1, "1");
			put(2, "0");
			put(3, "0");
		}};
		
		Object answer = unserialize2((String) question.getHashMap().get("answer"));
		Assert.assertEquals(true, isCorrectMultipleMany(userAnswerCorrect, answer));
		Assert.assertEquals(false, isCorrectMultipleMany(userAnswerWrong, answer));
		
		Question question2 = questionDao.find(375); // the correct answer is 2
		
		Map<Integer, String> userAnswerCorrect2 = new HashMap<Integer, String>(){{
			put(0, "0");
			put(1, "0");
			put(2, "1");
			put(3, "0");
		}};
		
		Map<Integer, String> userAnswerWrong2 = new HashMap<Integer, String>(){{
			put(0, "0");
			put(1, "1");
			put(2, "0");
			put(3, "0");
		}};
		
		Object answer2 = unserialize2((String) question2.getHashMap().get("answer"));
		Assert.assertEquals(true, isCorrectMultipleMany(userAnswerCorrect2, answer2));
		Assert.assertEquals(false, isCorrectMultipleMany(userAnswerWrong2, answer2));
		
	}
	
	@Test
	@Transactional(value = "txManagerNew")
	public void testQuestionTrueFalse()
	{
		Question questionTrueFalse = questionDao.find(75); // the correct answer is false
		
		Map<Integer, String> userAnswerCorrect = new HashMap<Integer, String>(){{
			put(0, "1");//0 corresponds to false
			put(1, "0");
			put(2, "0");
			put(3, "0");
		}};
		
		Map<Integer, String> userAnswerWrong = new HashMap<Integer, String>(){{
			put(0, "0");
			put(1, "1");// 1 corresponds to true
			put(2, "0");
			put(3, "0");
		}};
		
		Object answer = unserialize2((String) questionTrueFalse.getHashMap().get("answer"));
		Assert.assertEquals(true, isCorrectTrueFalse(userAnswerCorrect, answer));
		Assert.assertEquals(false, isCorrectTrueFalse(userAnswerWrong, answer));
		
		
		Question questionTrueFalse2 = questionDao.find(81); // the correct answer is true
		
		Map<Integer, String> userAnswerCorrect2 = new HashMap<Integer, String>(){{
			put(0, "0");
			put(1, "1");// 1 corresponds to true
			put(2, "0");
			put(3, "0");
		}};
		
		Map<Integer, String> userAnswerWrong2 = new HashMap<Integer, String>(){{
			put(0, "1");//0 corresponds to false
			put(1, "0");
			put(2, "0");
			put(3, "0");
		}};
		
		Object answer2 = unserialize2((String) questionTrueFalse2.getHashMap().get("answer"));
		Assert.assertEquals(true, isCorrectTrueFalse(userAnswerCorrect2, answer2));
		Assert.assertEquals(false, isCorrectTrueFalse(userAnswerWrong2, answer2));
	}
	
	private boolean isCorrectTrueFalse(Map<Integer, String> userAnswer, Object answer)
    {
//    	if(userAnswer.size() != 2) return false;
    	/*
    	 * "userAnswer" - user answer - return value 
    	 * (0,0), (1,0) - no answer - false;
    	 * (0,1), (1,1) - two answer - false;
    	 * (0,1), (1,0) - false - gotta check
    	 * (0,0), (1,1) - true - gotta check
    	 */
    	int a = Integer.parseInt(userAnswer.get(0));
    	int b = Integer.parseInt(userAnswer.get(1));
    	
    	if(a == 1 && b == 0 && answer.equals("0"))
    		return true;
    	if(a == 0 && b == 1 && answer.equals("1"))
    		return true;
    	return false;
    }
	
	private boolean isCorrectMultipleOne(Map<Integer, String> userAnswer, Object answer)
    {
    	Set<Integer> answerKey = new HashSet<Integer>();
    	for (Map.Entry<Integer, String> entry : ((Map<Integer, String>)answer).entrySet())
		{
			answerKey.add(Integer.parseInt(entry.getValue()));
		}
    	
    	boolean isCorrect = true;
    	for(Map.Entry<Integer, String> userAnswerEntry : userAnswer.entrySet())
    	{
    		int a = Integer.parseInt(userAnswerEntry.getValue());
    		if(a == 1 && !answerKey.contains(userAnswerEntry.getKey()))
    			isCorrect = false;
    		if(a == 0 && answerKey.contains(userAnswerEntry.getKey()))
    			isCorrect = false;
    	}
    	return isCorrect;
    }
	
	private boolean isCorrectMultipleMany(Map<Integer, String> userAnswer, Object answer)
    {
    	Set<Integer> answerKey = ((Map<Integer, String>)answer).keySet();
    	boolean isCorrect = true;
    	for(Map.Entry<Integer, String> userAnswerEntry : userAnswer.entrySet())
    	{
    		int a = Integer.parseInt(userAnswerEntry.getValue());
    		if(a == 1 && !answerKey.contains(userAnswerEntry.getKey()))
    			isCorrect = false;
    		if(a == 0 && answerKey.contains(userAnswerEntry.getKey()))
    			isCorrect = false;
    	}
    	return isCorrect;
    }
	
	private Object unserialize2(String string) //returns either Map<Integer, String> or String
    {
    	if(string != null && !string.equals(""))
    	{
    		Mixed temp = Pherialize.unserialize(string);
    		Map<Object, Object> tempMap = temp.toArray();
    		if(tempMap != null)
    		{
    			Map<Integer, String> tempMap2 = new HashMap<Integer, String>();
        		for (Map.Entry<Object, Object> entry : tempMap.entrySet())
        		{
        			tempMap2.put(((Mixed)entry.getKey()).toInt(), ((Mixed)entry.getValue()).toString());
        		}
        		return tempMap2;
    		}
    		else return String.valueOf(temp.toInt());
    	}
    	else return null;
    }
}