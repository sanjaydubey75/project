package com.shezartech.godrej.lmsweb;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.shezartech.godrej.lmsweb.config.WebConfig;
import com.shezartech.godrej.lmsweb.model.LessonSyncViewModel;
import com.shezartech.godrej.lmsweb.service.LessonService;
import com.shezartech.godrej.lmsweb.service.TestService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { WebConfig.class })
public class TestServiceTest
{
	@Autowired
	private TestService testService;
	
	@Autowired
	private LessonService lessonService;
	
//	@Test
	public void testEverything()
	{
		Map<String, Object> time = new HashMap<String, Object>(){{
			put("start", 1432796409);
			put("end", 1432891784);
			put("spent", 7200);
		}};
		
		Map<Integer, Map<Integer, String>> userAnswers = new HashMap<Integer, Map<Integer,String>>();
		userAnswers.put(203, new HashMap<Integer, String>(){{
			put(0, "1");
			put(1, "1");
			put(2, "1");
			put(3, "1");
		}});
		userAnswers.put(204, new HashMap<Integer, String>(){{
			put(0, "1");
			put(1, "1");
		}});
		userAnswers.put(205, new HashMap<Integer, String>(){{
			put(0, "1");
			put(1, "1");
			put(2, "1");
			put(3, "1");
		}});
		
		testService.setTestData("atiq", 35, userAnswers, time);
	}
	
//	@Test
	public void abcd()
	{
		List<LessonSyncViewModel> a = lessonService.getLessons(34, "testing1", false);
		
		System.out.println(a);
	}
	
	@Test
	public void testxkcd()
	{
		
	}
}