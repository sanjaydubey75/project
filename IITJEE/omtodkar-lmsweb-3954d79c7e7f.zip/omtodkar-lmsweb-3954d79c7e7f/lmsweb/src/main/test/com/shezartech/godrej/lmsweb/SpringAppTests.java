package com.shezartech.godrej.lmsweb;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

import javax.script.*;

import org.hibernate.SessionFactory;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.transaction.annotation.Transactional;

import com.shezartech.godrej.lmsweb.config.WebConfig;
import com.shezartech.godrej.lmsweb.dao.QuestionDao;
import com.shezartech.godrej.lmsweb.dao.QuestionDaoImpl;
import com.shezartech.godrej.lmsweb.entity.core.Question;
import com.shezartech.godrej.lmsweb.model.QuestionViewModel;
import com.shezartech.godrej.lmsweb.request.LoginForm;
import com.shezartech.godrej.lmsweb.service.Serialize;
import com.shezartech.godrej.lmsweb.service.Sync;

import php.java.bridge.*;
import php.java.script.*;
import php.java.servlet.*;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { WebConfig.class })
public class SpringAppTests {

	@Autowired
	@Qualifier("newSessionFactory")
	private SessionFactory sessionFactory;
	
	@Autowired
	private Sync sync;

//	@Test
	@Transactional(value = "txManagerNew")
	public void testSpringEncoder() throws FileNotFoundException
	{
		
		QuestionDao questionDao = new QuestionDaoImpl();
		questionDao.setSessionFactory(sessionFactory);

		Question question = questionDao.find(150);
		QuestionViewModel questionViewModel = new QuestionViewModel(question);

		// Assert.assertEquals("9fd04f4ec85ad884d030de7027f5dd03", );
	}
	
	public void testQuestions()
	{
		LoginForm loginForm = new LoginForm("atiq", "atiq@1234");
		Set<Question> questions = sync.getQuestions(29, loginForm);
		List<Question> questions2 = new ArrayList<Question>(questions);
		Collections.sort(questions2, new Comparator<Question>(){

			@Override
			public int compare(Question o1, Question o2)
			{
				return o1.comparePrimaryKey(o2);
			}
			
		});
		List<QuestionViewModel> questionsForTest = new ArrayList<QuestionViewModel>();
		for (Question question : questions2) 
		{
			questionsForTest.add(new QuestionViewModel(question));
		}
	}

	@Test
	public void testCompletedTestBlob()
	{
		try(BufferedReader bufferedReader = new BufferedReader(new FileReader(new File("D:\\completed_tests_blob-test.txt"))))
		{
			String line;
		    while ((line = bufferedReader.readLine()) != null)
		    {
		    	System.out.println(line);
//		    	SerializedPhpParser serializedPhpParser = new SerializedPhpParser(line);
//				Object temp = serializedPhpParser.parse();
//				Object temp = Pherialize.unserialize(line);
//				PHPSerialization serialization = new PHPSerialization() {};
//				Object temp = serialization.unserialize(line);
		    	String x = Serialize.phpToJson(line);
				System.out.println(x);
		    }
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
//	@Test
	public void TestPhpCode()
	{
		String code="function aa($a){return 2*$a;}"; //sample bit of code
		ScriptEngineManager manager = new ScriptEngineManager();
//		ScriptEngine engine = manager.getEngineByExtension("php");
//		ScriptEngine engine = manager.getEngineByName("php");
		ScriptEngine engine = (new ScriptEngineManager()).getEngineByName("php-interactive");
		try {
			//for php-interactive
			//http://php-java-bridge.sourceforge.net/doc/server/documentation/API/php/java/script/InteractivePhpScriptEngine.html
		    Object y = engine.eval("$v = 1+2");
		    Object k = engine.eval("echo $v");
		    System.out.println(k);
		    engine.eval((String)null);
		    engine.eval(code);
		    Object q = engine.eval("echo aa(2);");
		    System.out.println(q);
			
//			//for php	
//			//http://php-java-bridge.sourceforge.net/doc/server/documentation/API/php/java/script/PhpScriptEngine.html
//			Object y = engine.eval("<?php echo $v = 1+2; ?>");
//		    System.out.println(y);
		    
		} catch (ScriptException ex) {
		    //catch statement
			ex.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}