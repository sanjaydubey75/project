package com.shezartech.godrej.lmsweb.dao;

import java.util.List;

import com.shezartech.godrej.lmsweb.entity.core.LessonToCourse;

public interface LessonToCourseDao extends SyncEntityDao<LessonToCourse, Long> {

	List<LessonToCourse> find(int courseId);

}
