package com.shezartech.godrej.lmsweb.dao;

import com.shezartech.godrej.lmsweb.entity.core.Question;

public interface QuestionDao extends SyncEntityDao<Question, Integer> {

}
