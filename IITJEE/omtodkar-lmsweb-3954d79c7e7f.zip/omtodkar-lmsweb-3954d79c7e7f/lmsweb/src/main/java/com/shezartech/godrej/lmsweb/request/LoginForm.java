package com.shezartech.godrej.lmsweb.request;

public class LoginForm {
	
	public String username;
	public String password;
	
	public LoginForm(String username, String password) {
		super();
		this.username = username;
		this.password = password;
	}
}
