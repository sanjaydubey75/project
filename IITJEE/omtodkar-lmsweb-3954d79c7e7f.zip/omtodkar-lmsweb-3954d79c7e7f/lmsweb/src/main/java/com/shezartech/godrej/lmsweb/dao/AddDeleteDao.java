package com.shezartech.godrej.lmsweb.dao;

import java.io.Serializable;

import com.shezartech.godrej.lmsweb.entity.core.IAddDeleteEntity;
import com.shezartech.godrej.lmsweb.entity.core.SyncEntity;

public interface AddDeleteDao<T extends IAddDeleteEntity, I extends Serializable> extends BaseDao<T, I>{
	
	public void delete(IAddDeleteEntity entity);

	IAddDeleteEntity persist(SyncEntity course);

	IAddDeleteEntity find(SyncEntity entity);

}
