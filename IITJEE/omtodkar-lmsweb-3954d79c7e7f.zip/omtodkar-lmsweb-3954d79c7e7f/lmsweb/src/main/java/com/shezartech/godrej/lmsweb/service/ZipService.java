package com.shezartech.godrej.lmsweb.service;

import java.io.File;

public interface ZipService {

	/**
     * Traverse a directory and get all files,
     * and add the file into fileList  
     * @param node file or directory
     */
	void generateFileList(File node);
	
	/**
     * Format the file path for zip
     * @param file file path
     * @return Formatted file path
     */
	public String generateZipEntry(String file);

	/**
     * Zip it
     * @param zipFile output ZIP file location
     */
	void zipIt(String zipFile);

}
