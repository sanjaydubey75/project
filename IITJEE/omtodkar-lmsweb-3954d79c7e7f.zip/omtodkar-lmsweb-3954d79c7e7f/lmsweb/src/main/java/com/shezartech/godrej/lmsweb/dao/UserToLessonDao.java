package com.shezartech.godrej.lmsweb.dao;

import java.util.List;

import com.shezartech.godrej.lmsweb.entity.core.Lesson;
import com.shezartech.godrej.lmsweb.entity.core.User;
import com.shezartech.godrej.lmsweb.entity.core.UserToLesson;

public interface UserToLessonDao extends BaseDao<UserToLesson, Integer>
{

	UserToLesson find(User user, Lesson lesson);

	List<UserToLesson> findAllLessonsByUser(User user);

}
