package com.shezartech.godrej.lmsweb.dao;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.shezartech.godrej.lmsweb.entity.core.User;

@Repository
public class UserDaoImpl extends BaseDaoImpl<User, Long> implements
		UserDao {

	public UserDaoImpl() {
		super(User.class);
	}

	@Override
	@Autowired
	@Qualifier("newSessionFactory")
	public void setSessionFactory(SessionFactory sessionFactory) {
		super.setSessionFactory(sessionFactory);
	}

	@Override
	public User findByLogin(String login) {
		Session session = getCurrentSession();
		Criteria criteria = session.createCriteria(User.class);
		User user = (User) criteria.add(Restrictions.eq("login", login))
				.uniqueResult();
		return user;
	}

	@Override
	@Transactional
	public UserDetails loadUserByUsername(String username)
			throws UsernameNotFoundException {
		User user = this.findByLogin(username);
		if (null == user)
			throw new UsernameNotFoundException("The user with name "
					+ username + " was not found");
		return user;
	}
}