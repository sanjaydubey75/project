package com.shezartech.godrej.lmsweb.entity.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="lessons_to_courses")
public class LessonToCourse extends SyncEntity{
	
	@Id
//	@ManyToOne
//	@JoinColumn(name="courses_ID", referencedColumnName = "id")
	@NotNull
	@Column(columnDefinition = "mediumint(8) unsigned NOT NULL", name="courses_ID")
	private Integer courseId;
	
	@Id
//	@ManyToOne
//	@JoinColumn(name="lessons_ID", referencedColumnName = "id")
	@NotNull
	@Column(columnDefinition = "mediumint(8) unsigned NOT NULL", name="lessons_ID")
	private Integer lessonId;
	
	@Column(columnDefinition = "mediumint(8) unsigned DEFAULT '0'", name="previous_lessons_ID")
	private Integer previousLessonsId;
	
	@Column(columnDefinition = "int(10) unsigned DEFAULT NULL", name = "start_date")
	private Integer startDate;
	
	@Column(columnDefinition = "int(10) unsigned DEFAULT NULL", name = "end_date")
	private Integer endDate;
	
	@Column(columnDefinition = "int(10) unsigned DEFAULT NULL", name = "start_period")
	private Integer startPeriod;
	
	@Column(columnDefinition = "int(10) unsigned DEFAULT NULL", name = "end_period")
	private Integer endPeriod;

	public int getCourseId() {
		return courseId;
	}

	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}

	public int getLessonId() {
		return lessonId;
	}

	public void setLessonId(int lessonId) {
		this.lessonId = lessonId;
	}

	public Integer getPreviousLessonsId() {
		return previousLessonsId;
	}

	public void setPreviousLessonsId(Integer previousLessonsId) {
		this.previousLessonsId = previousLessonsId;
	}

	public Integer getStartDate() {
		return startDate;
	}

	public void setStartDate(Integer startDate) {
		this.startDate = startDate;
	}

	public Integer getEndDate() {
		return endDate;
	}

	public void setEndDate(Integer endDate) {
		this.endDate = endDate;
	}

	public Integer getStartPeriod() {
		return startPeriod;
	}

	public void setStartPeriod(Integer startPeriod) {
		this.startPeriod = startPeriod;
	}

	public Integer getEndPeriod() {
		return endPeriod;
	}

	public void setEndPeriod(Integer endPeriod) {
		this.endPeriod = endPeriod;
	}
	
	public LessonToCourse() { }

	@Override
	public int comparePrimaryKey(SyncEntity lessonToCourse) {
		if(this.getLessonId() != ((LessonToCourse) lessonToCourse).getLessonId())
			return this.getLessonId() - ((LessonToCourse) lessonToCourse).getLessonId();
		else
			return this.getCourseId() - ((LessonToCourse) lessonToCourse).getCourseId();
	}
}