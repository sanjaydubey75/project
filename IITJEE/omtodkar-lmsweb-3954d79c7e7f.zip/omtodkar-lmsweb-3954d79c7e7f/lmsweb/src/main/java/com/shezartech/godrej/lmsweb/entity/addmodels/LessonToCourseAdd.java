package com.shezartech.godrej.lmsweb.entity.addmodels;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.shezartech.godrej.lmsweb.entity.core.IAddDeleteEntity;
import com.shezartech.godrej.lmsweb.entity.core.LessonToCourse;

@Entity
@Table(name="lessons_to_courses_add")
public class LessonToCourseAdd implements IAddDeleteEntity{
	
	@NotNull
	private Integer hash;
	
	@Id
	@OneToOne
	@JoinColumns({
		@JoinColumn(name="course_lessons_ID", referencedColumnName = "lessons_ID"),
		@JoinColumn(name="course_courses_ID", referencedColumnName = "courses_ID")
	})
	private LessonToCourse course;

	@Override
	public int getHash() {
		return hash;
	}

	@Override
	public void setHash() {
		this.hash = course.hashCode();
	}

	public LessonToCourse getCourse() {
		return course;
	}

	public void setCourse(LessonToCourse course) {
		this.course = course;
	}
}