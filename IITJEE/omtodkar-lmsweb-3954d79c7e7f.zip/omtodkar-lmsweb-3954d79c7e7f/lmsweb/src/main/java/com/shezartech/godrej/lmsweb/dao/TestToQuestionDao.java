package com.shezartech.godrej.lmsweb.dao;

import com.shezartech.godrej.lmsweb.entity.core.Question;
import com.shezartech.godrej.lmsweb.entity.core.TestToQuestion;

public interface TestToQuestionDao extends SyncEntityDao<TestToQuestion, Long>
{
	TestToQuestion findByQuestion(Question question);
}
