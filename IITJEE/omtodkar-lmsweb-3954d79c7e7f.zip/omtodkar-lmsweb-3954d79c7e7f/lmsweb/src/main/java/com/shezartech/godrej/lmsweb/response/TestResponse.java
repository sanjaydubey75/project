package com.shezartech.godrej.lmsweb.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.shezartech.godrej.lmsweb.entity.core.Test;
import com.shezartech.godrej.lmsweb.model.SyncEntityView;

public class TestResponse extends BaseResponse
{
	
	@JsonInclude(Include.NON_NULL)
	public Test test;
	
	@JsonInclude(Include.NON_NULL)
	public List<SyncEntityView> tests;

	public TestResponse(String statusMessage)
	{
		super(false, statusMessage);
	}
	
	public TestResponse(Test test)
	{
		super(true, null);
		this.test = test;
	}
	
	public TestResponse(List<SyncEntityView> tests)
	{
		super(true, null);
		this.tests = tests;
	}
}
