package com.shezartech.godrej.lmsweb.entity.core;

import java.io.Serializable;

public interface BaseEntity extends Serializable
{
	
}
