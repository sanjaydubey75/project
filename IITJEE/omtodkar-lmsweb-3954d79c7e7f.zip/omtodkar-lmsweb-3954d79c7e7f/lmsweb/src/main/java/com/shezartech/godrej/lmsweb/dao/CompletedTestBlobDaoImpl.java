package com.shezartech.godrej.lmsweb.dao;

import java.sql.Blob;

import org.hibernate.Hibernate;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.shezartech.godrej.lmsweb.entity.core.CompletedTestBlob;

@Repository
public class CompletedTestBlobDaoImpl extends BaseDaoImpl<CompletedTestBlob, Integer> implements CompletedTestBlobDao
{
	public CompletedTestBlobDaoImpl()
	{
		super(CompletedTestBlob.class);
	}

	@Override
	@Autowired
	@Qualifier("newSessionFactory")
	public void setSessionFactory(SessionFactory sessionFactory)
	{
		super.setSessionFactory(sessionFactory);
	}

	@Override
	public void persist(CompletedTestBlob completedTestBlob, String string)
	{
		Blob blob = Hibernate.getLobCreator(getCurrentSession()).createBlob(string.getBytes());
		completedTestBlob.setTest(blob);
		persist(completedTestBlob);
	}
}