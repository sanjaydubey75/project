package com.shezartech.godrej.lmsweb.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.shezartech.godrej.lmsweb.dao.CourseDao;
import com.shezartech.godrej.lmsweb.dao.LessonDao;
import com.shezartech.godrej.lmsweb.dao.LessonToCourseDao;
import com.shezartech.godrej.lmsweb.dao.TestDao;
import com.shezartech.godrej.lmsweb.dao.UserDao;
import com.shezartech.godrej.lmsweb.dao.UserToLessonDao;
import com.shezartech.godrej.lmsweb.entity.core.Content;
import com.shezartech.godrej.lmsweb.entity.core.Course;
import com.shezartech.godrej.lmsweb.entity.core.Lesson;
import com.shezartech.godrej.lmsweb.entity.core.LessonToCourse;
import com.shezartech.godrej.lmsweb.entity.core.Test;
import com.shezartech.godrej.lmsweb.entity.core.User;
import com.shezartech.godrej.lmsweb.entity.core.UserToLesson;
import com.shezartech.godrej.lmsweb.model.LessonSyncViewModel;
import com.shezartech.godrej.lmsweb.model.LessonSyncViewModel.TestViewModel;

import de.ailis.pherialize.Mixed;
import de.ailis.pherialize.Pherialize;

@Service
public class LessonServiceImpl implements LessonService
{
	@Autowired
	private CourseDao courseDao;

	@Autowired
	private UserToLessonDao userToLessonDao;
	
	@Autowired
	private LessonToCourseDao lessonToCourseDao;

	@Autowired
	private UserDao userDao;

	@Autowired
	private TestDao testDao;
	
	@Autowired
	private LessonDao lessonDao;
	
	@Autowired
	private ModuleService moduleService;
	
	
	@Override
	@Transactional(value = "txManagerNew")
	public List<LessonSyncViewModel> getLessons(int courseId, String login, boolean specialLesson)
	{
		List<LessonSyncViewModel> lessonSyncViewModels = new ArrayList<LessonSyncViewModel>();
		User user = userDao.findByLogin(login);
		
		List<Lesson> temp = specialLesson ? filterInSpecialLesson(getSortedLessons(courseId)) : filterOutSpecialLesson(getSortedLessons(courseId));

		for (Lesson lesson : temp)
		{
			if (lesson.isActive())
			{
				Set<Content> content = lesson.getContents();
				if (content != null)
				{
					setStatus(user, lessonSyncViewModels, lesson);
				}
			}
		}

		return lessonSyncViewModels;
	}
	
	@Override
	@Transactional(value = "txManagerNew")
	public List<LessonSyncViewModel> getAllLessons(String login, boolean specialLesson)
	{
		List<LessonSyncViewModel> lessonSyncViewModels = new ArrayList<LessonSyncViewModel>();
		
		User user = userDao.findByLogin(login);
		
		List<Lesson> temp = specialLesson ? filterInSpecialLesson(getLessonsByUser(user)) : filterOutSpecialLesson(getLessonsByUser(user));

		for (Lesson lesson : temp)
		{
			if (lesson.isActive())
			{
				Set<Content> content = lesson.getContents();
				if (content != null)
				{
					setStatus(user, lessonSyncViewModels, lesson);
				}
			}
		}

		return lessonSyncViewModels;
	}
	
	private void setStatus(User user, List<LessonSyncViewModel> lessonSyncViewModels, Lesson lesson)
	{
		LessonSyncViewModel lessonSyncViewModel = new LessonSyncViewModel();
		lessonSyncViewModel.name = lesson.getName();
		lessonSyncViewModel.lessonId = lesson.getId();
		Set<Content> contents = lesson.getContents();
		
		UserToLesson userToLesson = userToLessonDao.find(user, lesson);

		List<Integer> contentsAttempted = new ArrayList<Integer>();
		Integer score = null;

		if (userToLesson != null)
		{
			if ((userToLesson.getDoneContent() != null)
					&& (!userToLesson.getDoneContent().isEmpty()))
			{
				Map<Object, Object> array =  
						Pherialize.unserialize(userToLesson.getDoneContent()).toArray();
				if(array != null)
				{
					for (Object i : array.keySet())
					{
						contentsAttempted.add(((Mixed) i).toInt());
					}
					score = userToLesson.getScore();
				}
			}
		}
		
		boolean isModuleExist = moduleService.isModuleExist(lesson.getId());

		for (Content content : contents)
		{
			switch (content.getCategoryType())
			{

			case "tests":
			{
				Test test = testDao.findByCourseId(content.getId());
				TestViewModel testViewModel = lessonSyncViewModel.new TestViewModel(test.getId(),
						contentsAttempted.contains(content.getId()), test.getName(), score);
				lessonSyncViewModel.tests.add(testViewModel);
				break;
			}
			
			case "scorm_test":
			{
				TestViewModel scormViewModel = lessonSyncViewModel.new TestViewModel(content.getId(), 
						contentsAttempted.contains(content.getId()), isModuleExist);
				lessonSyncViewModel.tests.add(scormViewModel);
				break;
			}
				
			case "scorm":
			{
				TestViewModel scormViewModel = lessonSyncViewModel.new TestViewModel(content.getId(), 
						contentsAttempted.contains(content.getId()), isModuleExist);
				lessonSyncViewModel.tests.add(scormViewModel);
				break;
			}

			default:
				break;
			}
		}
		
		if(contents.size() > 0)
		{
			lessonSyncViewModels.add(lessonSyncViewModel);
		}
	}
	
	private List<Lesson> getLessonsByUser(User user)
	{
		List<UserToLesson> userToLessons = userToLessonDao.findAllLessonsByUser(user);
		
		List<Lesson> lessons = new ArrayList<Lesson>();
		
		for (UserToLesson userToLesson : userToLessons)
		{
			lessons.add(userToLesson.getLesson());
		}
		
		return lessons;
	}
	
	private List<Lesson> getSortedLessons(int courseId)
	{
		List<LessonToCourse> lessonToCourses = lessonToCourseDao.find(courseId);
		
		Comparator<LessonToCourse> comparator = new Comparator<LessonToCourse>()
		{
			
			@Override
			public int compare(LessonToCourse l1, LessonToCourse l2)
			{
				return l1.getPreviousLessonsId() - l2.getPreviousLessonsId();
			}
		};
		
		Collections.sort(lessonToCourses, comparator);
		
		List<Lesson> lessons = new ArrayList<Lesson>();
		for (LessonToCourse lessonToCourse : lessonToCourses)
		{
			lessons.add(lessonDao.find(lessonToCourse.getLessonId()));
		}
		
		return lessons;
	}
	
	@Override
	public List<Lesson> filterOutSpecialLesson(List<Lesson> lessons)
	{
		List<Lesson> filteredOutList = new ArrayList<Lesson>();
		
		for (Lesson lesson : lessons)
		{
			if(!lesson.getName().contains(LessonService.specialLesson))
				filteredOutList.add(lesson);
		}
		
		return filteredOutList;
	}
	
	@Override
	public List<Lesson> filterInSpecialLesson(List<Lesson> lessons)
	{
		List<Lesson> filteredInList = new ArrayList<Lesson>();
		
		for (Lesson lesson : lessons)
		{
			if(lesson.getName().contains(LessonService.specialLesson))
				filteredInList.add(lesson);
		}
		
		return filteredInList;
	}
}
