package com.shezartech.godrej.lmsweb.entity.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;

@Entity
@Table(name="users_to_courses", indexes={
	@Index(columnList="from_timestamp", name="from_timestamp"),
	@Index(columnList="users_LOGIN", name="users_LOGIN"),
	@Index(columnList="courses_ID", name="courses_ID"),
	@Index(columnList="archive", name="archive")
})
public class UserToCourse extends SyncEntity{

	@Id
	@NotNull
//	@Column(columnDefinition = "varchar(100) NOT NULL", name="users_LOGIN")
	@ManyToOne
	@JoinColumn(name="users_LOGIN", referencedColumnName = "login")
//	@Length(max=100)
	private User userLogin;
	
	@Id
	@NotNull
//	@Column(columnDefinition = "mediumint(8) unsigned NOT NULL DEFAULT '0'", name="courses_ID")
	@ManyToOne
	@JoinColumn(name="courses_ID", referencedColumnName = "id")
	private Course courseId;
	
	@NotNull
	@Column(columnDefinition = "tinyint(1) NOT NULL DEFAULT '0'")
	private boolean active;
	
	@Column(columnDefinition = "int(10) unsigned DEFAULT '0'")
	private Integer archive;
	
	@Column(columnDefinition = "int(10) unsigned DEFAULT NULL", name = "from_timestamp")
	private Integer fromTimestamp;
	
	@Length(max = 50)
	@Column(columnDefinition = "varchar(50) DEFAULT NULL", name = "user_type")
	private String userType;
	
	@NotNull
	@Column(columnDefinition = "tinyint(1) NOT NULL DEFAULT '0'")
	private boolean completed;
	
	@NotNull
	@Column(columnDefinition = "int(11) NOT NULL DEFAULT '0'")
	private Integer score;
	
	@Column(columnDefinition = "text", name = "issued_certificate")
	private String issuedCertificate;
	
	@Column(columnDefinition = "text")
	private String comments;
	
	@Column(columnDefinition = "int(10) unsigned DEFAULT NULL", name = "to_timestamp")
	private Long toTimestamp;

	public User getUserLogin() {
		return userLogin;
	}

	public void setUserLogin(User userLogin) {
		this.userLogin = userLogin;
	}

	public Course getCourseId() {
		return courseId;
	}

	public void setCourseId(Course courseId) {
		this.courseId = courseId;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public Integer getArchive() {
		return archive;
	}

	public void setArchive(Integer archive) {
		this.archive = archive;
	}

	public Integer getFromTimestamp() {
		return fromTimestamp;
	}

	public void setFromTimestamp(Integer fromTimestamp) {
		this.fromTimestamp = fromTimestamp;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public boolean isCompleted() {
		return completed;
	}

	public void setCompleted(boolean completed) {
		this.completed = completed;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public String getIssuedCertificate() {
		return issuedCertificate;
	}

	public void setIssuedCertificate(String issuedCertificate) {
		this.issuedCertificate = issuedCertificate;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public Long getToTimestamp() {
		return toTimestamp;
	}

	public void setToTimestamp(Long toTimestamp) {
		this.toTimestamp = toTimestamp;
	}
	
	public UserToCourse(){}

	@Override
	public int comparePrimaryKey(SyncEntity userToCourse) {
		//It is assumed that only UserToCourse(s) of a particular user will be compared
		return this.getCourseId().getId() - ((UserToCourse) userToCourse).getCourseId().getId();
	}
}