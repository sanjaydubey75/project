package com.shezartech.godrej.lmsweb.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.shezartech.godrej.lmsweb.dao.CourseDao;
import com.shezartech.godrej.lmsweb.dao.UserDao;
import com.shezartech.godrej.lmsweb.dao.UserToCourseDao;
import com.shezartech.godrej.lmsweb.dao.UserToLessonDao;
import com.shezartech.godrej.lmsweb.entity.core.Course;
import com.shezartech.godrej.lmsweb.entity.core.Lesson;
import com.shezartech.godrej.lmsweb.entity.core.User;
import com.shezartech.godrej.lmsweb.entity.core.UserToCourse;
import com.shezartech.godrej.lmsweb.entity.core.UserToLesson;

@Service
public class UserToCourseServiceImpl implements UserToCourseService
{

	@Autowired
	private UserToCourseDao userToCourseDao;
	
	@Autowired
	private UserToLessonDao userToLessonDao;
	
	@Autowired
	private UserDao userDao;
	
	@Autowired
	private CourseDao courseDao;
	
	private static final Logger logger = LoggerFactory.getLogger(UserToCourseServiceImpl.class);
	
	@Override
	@Transactional(value="txManagerNew")
	public void setCourseCompletedIfAllLessonsComplete(int courseId, String login, Long timestamp)
	{
		Course course = courseDao.find(courseId);
		User user = userDao.findByLogin(login);
		
		if(isAllLessonsComplete(course, user))
		{
			setCourseAsCompleted(course, user, timestamp);
//			setCompletedCourseInUserTable(user, course);
		}
	}
	
	private boolean isAllLessonsComplete(Course course, User user)
	{
		Set<Lesson> lessons = course.getLessons();
		boolean courseComplete = true;
		for (Lesson lesson : lessons)
		{
			UserToLesson userToLesson = userToLessonDao.find(user, lesson);
			if(userToLesson.getCompleted() == 0)
			{
				courseComplete = false;
				break;
			}
		}
		return courseComplete;
	}
	
	private int calculateScore(Course course, User user)
	{
		int totScore = 0;
		int numberOfLessons = 0;
		
		for(Lesson lesson : course.getLessons())
		{
			totScore += userToLessonDao.find(user, lesson).getScore();
			numberOfLessons++;
		}
		return totScore/numberOfLessons;
	}
	
	private void setCourseAsCompleted(Course course, User user, long timestamp)
	{
		UserToCourse userToCourse = userToCourseDao.find(course, user);
		
		userToCourse.setCompleted(true);
		userToCourse.setScore(calculateScore(course, user));
		userToCourse.setComments("The course was automatically completed when all lessons were completed");
		userToCourse.setToTimestamp(timestamp);
		
	}
	
	private void setCompletedCourseInUserTable(User user, Course course)
	{
		String courseArrayAsString = user.getCoursesCompleted();
		ObjectMapper mapper = new ObjectMapper();
		try
		{
			List<String> courseIds = null;
			if(courseArrayAsString== null || courseArrayAsString.isEmpty())
				courseIds = new ArrayList<String>();
			else
				courseIds = mapper.readValue(courseArrayAsString, new TypeReference<List<String>>() {});
			
			String temp = "1_" + String.valueOf(course.getId());
			
			if(!courseIds.contains(temp))
				courseIds.add(temp);
			user.setCoursesCompleted(mapper.writeValueAsString(courseIds));
		}
		catch (IOException e)
		{
			logger.error("error in deserializing json string in UserToCourseServiceImpl.setCompletedCourseInUserTable", e);
			e.printStackTrace();
		}
	}
}
