package com.shezartech.godrej.lmsweb.entity.core;

public abstract class AddDeleteEntity implements IAddDeleteEntity{

}
