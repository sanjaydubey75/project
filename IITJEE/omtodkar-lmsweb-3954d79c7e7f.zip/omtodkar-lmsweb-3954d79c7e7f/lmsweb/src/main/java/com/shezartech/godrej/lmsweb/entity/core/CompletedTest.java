package com.shezartech.godrej.lmsweb.entity.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;

@Entity
@Table(name="completed_tests", indexes={
	@Index(columnList="pending", name="pending"),
	@Index(columnList="timestamp", name="timestamp"),
	@Index(columnList="users_LOGIN", name="users_login"),
	@Index(columnList="score", name="score"),
	@Index(columnList="tests_ID", name="tests_ID"),
	@Index(columnList="archive", name="archive"),
	@Index(columnList="status", name="status")
})
public class CompletedTest implements BaseEntity{

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer id;
	
	@Length(max = 100)
	@Column(name = "users_LOGIN")
	private String userLogin = null;
	
	@NotNull
	@Column(name = "tests_ID")
	private Integer testId = 0;
	
	@Length(max = 255)
	@Column(columnDefinition = "varchar(255) DEFAULT NULL")
	private String status;
	
	@NotNull
	@Column(columnDefinition = "int(10) unsigned NOT NULL DEFAULT '0'")
	private Integer timestamp;
	
	@NotNull
	@Column(columnDefinition = "tinyint(1) NOT NULL DEFAULT '0'")
	private boolean archive;
	
	@Column(columnDefinition = "int(10) unsigned DEFAULT NULL", name = "time_start")
	private Integer timeStart;
	
	@Column(columnDefinition = "int(10) unsigned DEFAULT NULL", name = "time_end")
	private Integer timeEnd;
	
	@Column(columnDefinition = "int(10) unsigned DEFAULT NULL", name = "time_spent")
	private Integer timeSpent;
	
	@Column(columnDefinition = "float DEFAULT NULL")
	private Float score;
	
	@NotNull
	@Column(columnDefinition = "tinyint(1) NOT NULL DEFAULT '0'")
	private boolean pending;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUserLogin() {
		return userLogin;
	}

	public void setUserLogin(String userLogin) {
		this.userLogin = userLogin;
	}

	public Integer getTestId() {
		return testId;
	}

	public void setTestId(Integer testId) {
		this.testId = testId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Integer getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Integer timestamp) {
		this.timestamp = timestamp;
	}

	public boolean isArchive() {
		return archive;
	}

	public void setArchive(boolean archive) {
		this.archive = archive;
	}

	public Integer getTimeStart() {
		return timeStart;
	}

	public void setTimeStart(Integer timeStart) {
		this.timeStart = timeStart;
	}

	public Integer getTimeEnd() {
		return timeEnd;
	}

	public void setTimeEnd(Integer timeEnd) {
		this.timeEnd = timeEnd;
	}

	public Integer getTimeSpent() {
		return timeSpent;
	}

	public void setTimeSpent(Integer timeSpent) {
		this.timeSpent = timeSpent;
	}

	public Float getScore() {
		return score;
	}

	public void setScore(Float score) {
		this.score = score;
	}

	public boolean isPending() {
		return pending;
	}

	public void setPending(boolean pending) {
		this.pending = pending;
	}

	
	
	public CompletedTest(){
		super();
	}
}