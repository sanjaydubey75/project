package com.shezartech.godrej.lmsweb.dao;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.shezartech.godrej.lmsweb.entity.core.User;

public interface UserDao extends BaseDao<User, Long>, UserDetailsService {
	
	public User findByLogin(String login);
}
