package com.shezartech.godrej.lmsweb.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.shezartech.godrej.lmsweb.entity.core.Question;
import com.shezartech.godrej.lmsweb.service.SerializedPhpParser;

public class QuestionViewModel
{
	private class Option
	{
		public String option;
		public Integer index;
		
		public Option(String option, Integer index)
		{
			this.option = option;
			this.index = index;
		}
	}
	
	private class Answer
	{
		public String answer;
		
		public Answer(String answer)
		{
			this.answer = answer;
		}
	}
	
	public int id;
	
	public String type = "";
	
	public String text = "";
	
	@JsonInclude(Include.NON_NULL)
	public List<Option> optionList = new ArrayList<Option>();
	
	@JsonInclude(Include.NON_NULL)
	public List<Answer> answerList = new ArrayList<Answer>();

	public QuestionViewModel(Question question)
	{
		this.id = question.getId();
		this.type = question.getType();
		this.text = question.getText();
		this.setOptionList(question.getOptions());
		this.setAnswerList(question.getAnswer());
	}
	
	public void setOptionList(String option)
	{
		if(option != null && !option.equals(""))
		{
			Map<Integer, String> options = new HashMap<Integer, String>();
			SerializedPhpParser serializedPhpParser = new SerializedPhpParser(option);
			Object temp = serializedPhpParser.parse();
			options = (Map<Integer, String>) temp;
			SortedSet<Integer> keys = new TreeSet<Integer>(options.keySet());
			
			for (Integer key : keys) {
				this.optionList.add(new Option(options.get(key), key));
			}
		}
		
		if(this.type.equals("true_false"))
		{
			this.optionList.add(new Option("false", 0));
			this.optionList.add(new Option("true", 1));
		}
	}
	
	public void setAnswerList(String answer)
	{
		if(this.type.equals("true_false"))
		{
			String temp = QuestionViewModel.getAnswerForTrueFalseQuestion(answer);
			this.answerList.add(new Answer(temp));
		}
		else if(this.type.equals("multiple_many"))
		{
			for (String temp : QuestionViewModel.getAnswerForMultipleManyQuestion(answer))
			{
				this.answerList.add(new Answer(temp));
			}
		}
		else
		{
			for (String temp : QuestionViewModel.getStringArray(answer))
			{
				this.answerList.add(new Answer(temp));
			}
		}
	}
	
	public void shuffleOptions()
	{
		// say options are initially Agra, Bombay, Calcutta, Delhi
		// say answer array was Bombay, Delhi or 1, 3
		List<Integer> indexArray = new ArrayList<Integer>();
		for(int i = 0; i < this.optionList.size(); i++)
			indexArray.add(i); // indexArray is 0,1,2,3
		Collections.shuffle(indexArray);
		// indexArray becomes 2,0,3,1. Options become Calcutta, Agra, Delhi, Bombay
		// answer array should become 3, 2 (1 -> 3, 3 -> 2) 
		
		List<QuestionViewModel.Answer> newAnswerArray = new ArrayList<QuestionViewModel.Answer>();
		
	}
	
	private static List<String> getStringArray(String string)
	{
		int arrayCount; String optionString;
		List<String> stringList = new ArrayList<String>();
		Matcher matcher = Pattern.compile("^a:(\\d+):\\{(.*)}$").matcher(string);
		
		if(matcher.find())
		{
			arrayCount = Integer.parseInt(matcher.group(1));
			optionString = matcher.group(2); // say optionstring is i:0;s:11:"55i:0;"s:2:";i:1;s:2:"66";i:2;s:2:"73";i:3;s:2:"77";
			
			while (arrayCount-- > 0)
			{
				Matcher matcher2 = Pattern.compile("^i:\\d+;s:(\\d+):\"(.+)$").matcher(optionString);
				if(matcher2.find())
				{
					int stringLength = Integer.parseInt(matcher2.group(1)); // stringLength is 11
					String tempString = matcher2.group(2); // tempString is 55i:0;"s:2:";i:1;s:2:"66";i:2;s:2:"73";i:3;s:2:"77";
					stringList.add(tempString.substring(0, stringLength));
					optionString = tempString.substring(stringLength + 2); // optionString is i:1;s:2:"66";i:2;s:2:"73";i:3;s:2:"77";
				}
			}
		}
		return stringList;
	}
	
	private static String getAnswerForTrueFalseQuestion(String string)
	{
		String answer = "";
		Matcher matcher = Pattern.compile("^s:(\\d+):\"(.+)$").matcher(string);
		if(matcher.find())
		{
			int stringLength = Integer.parseInt(matcher.group(1));
			String tempString = matcher.group(2);
			answer += tempString.substring(0, stringLength);
		}
		return answer;
	}
	
	private static List<String> getAnswerForMultipleManyQuestion(String string)
	{
		int arrayCount; String optionString;
		List<String> stringList = new ArrayList<String>();
		Matcher matcher = Pattern.compile("^a:(\\d+):\\{(.*)}$").matcher(string);
		
		if(matcher.find())
		{
			arrayCount = Integer.parseInt(matcher.group(1));
			optionString = matcher.group(2); // say optionstring is i:0;s:1:"1";i:1;s:1:"1";i:3;s:1:"1";
			while (arrayCount-->0)
			{
				Matcher matcher2 = Pattern.compile("^i:(\\d+);s:(\\d+):\"(.+)$").matcher(optionString);
				if(matcher2.find())
				{
					stringList.add(matcher2.group(1));
					int stringLength = Integer.parseInt(matcher2.group(2)); // stringLength is 1
					String tempString = matcher2.group(3); // tempString is 1";i:1;s:1:"1";i:3;s:1:"1";
					optionString = tempString.substring(stringLength + 2); //optionString is i:1;s:1:"1";i:3;s:1:"1";
				}
			}
		}
		
		return stringList;
	}
}