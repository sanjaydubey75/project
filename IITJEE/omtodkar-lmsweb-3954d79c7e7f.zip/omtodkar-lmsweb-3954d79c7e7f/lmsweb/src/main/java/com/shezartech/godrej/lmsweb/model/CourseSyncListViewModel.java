package com.shezartech.godrej.lmsweb.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

public class CourseSyncListViewModel
{

	public int id;
	
	@JsonInclude(Include.NON_NULL)
	public String name;
	
	public int hash;
	
	public int directionId;

	public CourseSyncListViewModel(int id, String name, int hash, int directionId)
	{
		super();
		this.id = id;
		this.name = name;
		this.hash = hash;
		this.directionId = directionId;
	}
}
