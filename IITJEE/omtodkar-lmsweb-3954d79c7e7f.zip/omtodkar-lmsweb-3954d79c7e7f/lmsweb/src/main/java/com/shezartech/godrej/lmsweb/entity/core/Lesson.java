package com.shezartech.godrej.lmsweb.entity.core;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;
import org.hibernate.validator.constraints.Length;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="lessons")
public class Lesson extends SyncEntity
{

	@Id
	@NotNull
	@Column(columnDefinition = "mediumint(8) unsigned NOT NULL AUTO_INCREMENT")
	private Integer id;
	
	@NotNull
	@Column(columnDefinition = "varchar(150) NOT NULL")
	@Length(max=150)
	private String name;
	
	@Column(columnDefinition = "mediumint(8) unsigned DEFAULT '0'", name = "directions_ID")
	private Integer directionsId;
	
	@Column(columnDefinition = "text")
	private String info;
	
	@Column(columnDefinition = "float DEFAULT '0'")
	private Float price;
	
	@NotNull
	@Column(columnDefinition = "tinyint(1) NOT NULL DEFAULT '1'")
	private boolean active;
	
	@NotNull
	@Column(columnDefinition = "tinyint(1) NOT NULL DEFAULT '1'", name="show_catalog")
	private boolean showCatalog;
	
	@Column(columnDefinition = "int(10) DEFAULT '0'")
	private Integer duration;
	
	@Column(columnDefinition = "int(10) DEFAULT '0'", name = "access_limit")
	private Integer accessLimit;
	
	@Column(columnDefinition = "text")
	private String options;
	
	@NotNull
	@Column(columnDefinition = "varchar(50) NOT NULL", name="languages_NAME")
	@Length(max=50)
	private String languagesName;
	
	@Column(columnDefinition = "text")
	private String metadata;
	
	@Column(columnDefinition = "tinyint(1) DEFAULT '0'", name = "course_only")
	private Boolean courseOnly;
	
	@Column(columnDefinition = "text")
	private String certificate;
	
	@Column(columnDefinition = "int(10) unsigned DEFAULT NULL", name = "from_timestamp")
	private Integer fromTimestamp;
	
	@Column(columnDefinition = "int(10) unsigned DEFAULT NULL", name = "to_timestamp")
	private Integer toTimestamp;
	
	@Column(columnDefinition = "tinyint(1) DEFAULT '0'")
	private Boolean shift;
	
	@Column(columnDefinition = "tinyint(1) DEFAULT '1'")
	private Boolean publish;
	
	@Column(columnDefinition = "int(10) DEFAULT '0'", name = "share_folder")
	private Integer shareFolder;
	
	@Column(columnDefinition = "int(10) unsigned DEFAULT NULL")
	private Integer created;
	
	@Column(columnDefinition = "int(10) unsigned DEFAULT NULL", name="max_users")
	private Integer maxUsers;
	
	@Column(columnDefinition = "int(10) unsigned DEFAULT '0'")
	private Integer archive;
	
	@Column(columnDefinition = "mediumint(8) unsigned DEFAULT '0'", name="instance_source")
	private Integer instanceSource;
	
	@Column(columnDefinition = "mediumint(8) unsigned DEFAULT '0'", name="originating_course")
	private Integer originatingSource;
	
	@Column(columnDefinition = "varchar(100) DEFAULT NULL", name="creator_LOGIN")
	@Length(max=100)
	private String creatorLogin;
	
	@JsonIgnore
	@OneToMany(mappedBy = "lesson")
	@Cascade({CascadeType.ALL})
	private Set<Test> tests = new HashSet<Test>();
	
	@OneToMany(mappedBy = "lesson")
	private Set<Content> contents;

	public Set<Test> getTests() {
		return tests;
	}

	public void setTests(Set<Test> tests) {
		this.tests = tests;
	}

	public Set<Content> getContents()
	{
		return contents;
	}

	public void setContents(Set<Content> contents)
	{
		this.contents = contents;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getDirectionsId() {
		return directionsId;
	}

	public void setDirectionsId(Integer directionsId) {
		this.directionsId = directionsId;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	public Float getPrice() {
		return price;
	}

	public void setPrice(Float price) {
		this.price = price;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public boolean isShowCatalog() {
		return showCatalog;
	}

	public void setShowCatalog(boolean showCatalog) {
		this.showCatalog = showCatalog;
	}

	public Integer getDuration() {
		return duration;
	}

	public void setDuration(Integer duration) {
		this.duration = duration;
	}

	public Integer getAccessLimit() {
		return accessLimit;
	}

	public void setAccessLimit(Integer accessLimit) {
		this.accessLimit = accessLimit;
	}

	public String getOptions() {
		return options;
	}

	public void setOptions(String options) {
		this.options = options;
	}

	public String getLanguagesName() {
		return languagesName;
	}

	public void setLanguagesName(String languagesName) {
		this.languagesName = languagesName;
	}

	public String getMetadata() {
		return metadata;
	}

	public void setMetadata(String metadata) {
		this.metadata = metadata;
	}

	public Boolean isCourseOnly() {
		return courseOnly;
	}

	public void setCourseOnly(Boolean courseOnly) {
		this.courseOnly = courseOnly;
	}

	public String getCertificate() {
		return certificate;
	}

	public void setCertificate(String certificate) {
		this.certificate = certificate;
	}

	public Integer getFromTimestamp() {
		return fromTimestamp;
	}

	public void setFromTimestamp(Integer fromTimestamp) {
		this.fromTimestamp = fromTimestamp;
	}

	public Integer getToTimestamp() {
		return toTimestamp;
	}

	public void setToTimestamp(Integer toTimestamp) {
		this.toTimestamp = toTimestamp;
	}

	public Boolean isShift() {
		return shift;
	}

	public void setShift(Boolean shift) {
		this.shift = shift;
	}

	public Boolean isPublish() {
		return publish;
	}

	public void setPublish(Boolean publish) {
		this.publish = publish;
	}

	public Integer getShareFolder() {
		return shareFolder;
	}

	public void setShareFolder(Integer shareFolder) {
		this.shareFolder = shareFolder;
	}

	public Integer getCreated() {
		return created;
	}

	public void setCreated(Integer created) {
		this.created = created;
	}

	public Integer getMaxUsers() {
		return maxUsers;
	}

	public void setMaxUsers(Integer maxUsers) {
		this.maxUsers = maxUsers;
	}

	public Integer getArchive() {
		return archive;
	}

	public void setArchive(Integer archive) {
		this.archive = archive;
	}

	public Integer getInstanceSource() {
		return instanceSource;
	}

	public void setInstanceSource(Integer instanceSource) {
		this.instanceSource = instanceSource;
	}

	public Integer getOriginatingSource() {
		return originatingSource;
	}

	public void setOriginatingSource(Integer originatingSource) {
		this.originatingSource = originatingSource;
	}

	public String getCreatorLogin() {
		return creatorLogin;
	}

	public void setCreatorLogin(String creatorLogin) {
		this.creatorLogin = creatorLogin;
	}
	
	public Lesson(){}
	
	@Override
	public int comparePrimaryKey(SyncEntity lesson) {
		
		return this.getId() - ((Lesson) lesson).getId();
	}
}