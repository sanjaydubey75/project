package com.shezartech.godrej.lmsweb.controller;

import java.io.File;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.shezartech.godrej.lmsweb.model.LessonSyncViewModel;
import com.shezartech.godrej.lmsweb.request.LoginForm;
import com.shezartech.godrej.lmsweb.response.AuthenticationFailureResponse;
import com.shezartech.godrej.lmsweb.response.BaseResponse;
import com.shezartech.godrej.lmsweb.response.LessonResponse;
import com.shezartech.godrej.lmsweb.response.SuccessResponse;
import com.shezartech.godrej.lmsweb.service.AuthenticationService;
import com.shezartech.godrej.lmsweb.service.LessonService;
import com.shezartech.godrej.lmsweb.service.ModuleService;
import com.shezartech.godrej.lmsweb.service.ScormService;

@RestController
@RequestMapping(value = "/api/lesson")
public class LessonController
{	
	@Autowired private ModuleService moduleService;
	
	@Autowired private AuthenticationService authenticationService;
	
	@Autowired
	private ScormService scormService;
	
	@Autowired
	private LessonService lessonService;
	
	private static final Logger logger = LoggerFactory.getLogger(LessonController.class);
	
	@RequestMapping(value = "/{courseId}", method = RequestMethod.GET)
	public BaseResponse getLessons(@PathVariable int courseId,
			@RequestParam(value = "specialLesson", defaultValue = "false") boolean specialLesson,
			@RequestHeader("X-Auth-Login") String login, 
			@RequestHeader("X-Auth-Password") String password) throws NoSuchAlgorithmException
	{
		
		try
		{
			LoginForm loginForm = new LoginForm(login, password);
			
			if(authenticationService.authenticate(loginForm))
			{
				List<LessonSyncViewModel> lessons = lessonService.getLessons(courseId, login, specialLesson);
				return new LessonResponse(lessons);
			}
			else
			{
				return new AuthenticationFailureResponse("Username or Password does not match");
			}
		}
		catch (Exception e)
		{
			logger.error("error in LessonController.getLessons for user login: " + login, e);
			e.printStackTrace();
			return null;
		}
	}

	@RequestMapping(value = "/all", method = RequestMethod.GET)
	public BaseResponse getAllLessons(
			@RequestHeader("X-Auth-Login") String login, 
			@RequestHeader("X-Auth-Password") String password,
			@RequestParam(value = "specialLesson", defaultValue = "false") boolean specialLesson) throws NoSuchAlgorithmException
	{
		try
		{
			LoginForm loginForm = new LoginForm(login, password);
			
			if(authenticationService.authenticate(loginForm))
			{
				List<LessonSyncViewModel> lessons = lessonService.getAllLessons(login, specialLesson);
				return new LessonResponse(lessons);
			}
			else
			{
				return new AuthenticationFailureResponse("Username or Password does not match");
			}
		}
		catch (Exception e)
		{
			logger.error("error in LessonController.getLessons for user login: " + login, e);
			e.printStackTrace();
			return null;
		}
	}

	@RequestMapping(value = "/{id}/module", method = RequestMethod.GET,
			produces = "application/zip")
	public Object getModule(@PathVariable Integer id,
			@RequestHeader("X-Auth-Login") String login, 
			@RequestHeader("X-Auth-Password") String password,
			HttpServletResponse response) throws NoSuchAlgorithmException
	{
		
//		String login = "atiq", password = "atiq@1234";
		
			try
			{
				LoginForm loginForm = new LoginForm(login, password);
				
				if(authenticationService.authenticate(loginForm))
				{
					
					File file = moduleService.getModule(id);
//					InputStream is = new FileInputStream(file);
//					org.apache.commons.io.IOUtils.copy(is, response.getOutputStream());
//					response.flushBuffer();
					response.setHeader( "Content-Disposition", "attachment;filename=" + file.getName());
					return new FileSystemResource(file);
				}
				else
				{
					return new AuthenticationFailureResponse("Username or Password does not match");
				}
			}
			catch (Exception e)
			{
				logger.error("error in LessonController.getModule for user login: " + login, e);
				e.printStackTrace();
				return null;
			}
	}
	
	@RequestMapping(value = "/{lessonId}/scorm", method = RequestMethod.POST)
	public BaseResponse setScormLessonCompleted(@PathVariable int lessonId,
			@RequestBody Map<String, Object> data,
			@RequestHeader("X-Auth-Login") String login, 
			@RequestHeader("X-Auth-Password") String password)
	{
		try
		{
			LoginForm loginForm = new LoginForm(login, password);
			
			logger.info("setting scorm data in LessonController.setScormLessonCompleted for user login: " + login);
			
			if(authenticationService.authenticate(loginForm))
			{
				scormService.setScormCompleted(lessonId, login, Long.parseLong((String) data.get("timestamp")));
				return new SuccessResponse();
			}
			else
			{
				return new AuthenticationFailureResponse("Username or Password does not match");
			}
		}
		catch (Exception e)
		{
			logger.error("error in LessonController.setScormLessonCompleted for user login: " + login, e);
			e.printStackTrace();
			return null;
		}
	}
}