package com.shezartech.godrej.lmsweb.dao;

import java.io.Serializable;

import com.shezartech.godrej.lmsweb.entity.core.SyncEntity;

public interface SyncEntityDao<T extends SyncEntity, I extends Serializable> extends BaseDao<T, I>{

//	List<T> findAll();
//
//	T find(I id);
//
//	T save(T entity);
//
//	void delete(I id);
//
//	void delete(T entity);
//
//	void setSessionFactory(SessionFactory sessionFactory);
//	
//	void persist(T entity);
}
