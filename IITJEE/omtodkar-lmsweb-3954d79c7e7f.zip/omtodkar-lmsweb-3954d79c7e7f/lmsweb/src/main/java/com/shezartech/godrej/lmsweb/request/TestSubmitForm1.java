package com.shezartech.godrej.lmsweb.request;

import java.util.HashMap;
import java.util.Map;

import com.shezartech.godrej.lmsweb.request.TestSubmitForm.UserAnswer.AnswerObject;

public class TestSubmitForm1
{
	public Map<Integer, Map<Integer, String>> userAnswers;
	
	public Map<String, Object> time;
	
	public TestSubmitForm1(TestSubmitForm testSubmitForm)
	{
		this.time = testSubmitForm.time;
		this.userAnswers = new HashMap<Integer, Map<Integer,String>>();
		
		for (TestSubmitForm.UserAnswer userAnswer : testSubmitForm.userAnswers)
		{
			Map<Integer, String> temp = new HashMap<Integer, String>();
			
			for (AnswerObject answerObject : userAnswer.answerObjects)
			{
				temp.put(answerObject.index, answerObject.selected);
			}
			
			this.userAnswers.put(userAnswer.questionId, temp);
		}
	}
}
