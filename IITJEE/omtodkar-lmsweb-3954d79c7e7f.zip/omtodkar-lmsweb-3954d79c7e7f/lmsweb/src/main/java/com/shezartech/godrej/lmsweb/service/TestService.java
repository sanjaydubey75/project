package com.shezartech.godrej.lmsweb.service;

import java.util.Map;

public interface TestService
{

	void setTestData(String login, int testId, Map<Integer, Map<Integer, String>> userAnswers, Map<String, Object> time);

}
