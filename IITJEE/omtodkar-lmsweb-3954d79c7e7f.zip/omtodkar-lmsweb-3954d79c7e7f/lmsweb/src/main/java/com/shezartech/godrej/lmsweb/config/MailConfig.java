package com.shezartech.godrej.lmsweb.config;

import java.util.Properties;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

@Configuration
@ComponentScan(basePackages = { "com.shezartech.godrej.lmsweb" })
public class MailConfig extends WebMvcConfigurerAdapter
{
	
	private static final String host = "mail.shezartech.com";
	private static final int port = 25;
	private static final String username = "shobhit@shezartech.com";
	private static final String password = "shobhit@1234";
	public static final String recipientMail = "Epre1911@armyspy.com";
	
//	private static final String username = "support@godrejguru.com";
//	private static final String password = "support@1234";
//	public static final String recipientMail = "helpdesk@godrejguru.com";
	
	private static final Properties javaMailProperties = new Properties()
	{
		{
			setProperty("mail.transport.protocol", "smtp");
			setProperty("mail.smtp.auth", "true");
			setProperty("mail.smtp.starttls.enable", "false");
			setProperty("mail.debug", "true");
		}
	};

	@Bean(name = "mailSender")
	public JavaMailSender newSessionFactory()
	{
		JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
		mailSender.setHost(host);
		mailSender.setPort(port);
		mailSender.setUsername(username);
		mailSender.setPassword(password);
		mailSender.setJavaMailProperties(javaMailProperties);
		
		return mailSender;
	}
}
