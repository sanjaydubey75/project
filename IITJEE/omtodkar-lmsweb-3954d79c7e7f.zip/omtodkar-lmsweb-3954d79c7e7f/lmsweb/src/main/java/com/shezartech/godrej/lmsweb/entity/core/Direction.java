package com.shezartech.godrej.lmsweb.entity.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.Range;

@Entity
@Table(name = "directions")
public class Direction implements BaseEntity
{
	@Id
	@Range(min = 0, max = 16777215)
	private Integer id;
	
	@Length(max = 150)
	@NotNull
	private String name;
	
	@NotNull
	private boolean active = true;
	
	@Range(min = 0, max = 16777215)
	@Column(name = "parent_direction_ID")
	private Integer parentDirectionId;

	public Integer getId()
	{
		return id;
	}

	public void setId(Integer id)
	{
		this.id = id;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public boolean isActive()
	{
		return active;
	}

	public void setActive(boolean active)
	{
		this.active = active;
	}

	public Integer getParentDirectionId()
	{
		return parentDirectionId;
	}

	public void setParentDirectionId(Integer parentDirectionId)
	{
		this.parentDirectionId = parentDirectionId;
	}
}
