package com.shezartech.godrej.lmsweb.php.model;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * MultipleManyQuestion Class
 *
 * This class is used to manipulate a multiple choice / many answers question
 * @package eFront
 */
class MultipleManyQuestion extends Question
{
	public MultipleManyQuestion(Map<String, String> question, Map<Integer, String> userAnswer)
	{
		super(question);
		this.results = this.isCorrect(userAnswer, answer);
        this.score = this.results ? 100 : 0;
        
        this.setUserAnser(userAnswer);
	}

	/**
     * Shuffle question options
     *
     * This function is used to shuffle the question options,
     * so that they are displayed in a random order.
     * <br/>Example:
     * <code>
     * $question = new MultipleManyQuestion(3);                                     //Instantiate question
     * $newOrder = $question -> shuffle();                                          //Shuffle question options
     * </code>
     *
     * @return array The new question options order
     * @since 3.5.0
     * @access public
     */
    public void shuffle() //TODO implement this
    {
//        $shuffleOrder = range(0, sizeof($this -> options) - 1);
//        shuffle($shuffleOrder);
//        $this -> order = $shuffleOrder;
//
//        return $shuffleOrder;
    }

    /**
     * Correct question
     *
     * This function is used to correct the question. In order to correct it,
     * setDone() must already have been called, so that the user answer
     * is present.
     * <br/>Example:
     * <code>
     * $question = new MultipleManyQuestion(3);                                     //Instantiate question
     * $question -> setDone($answer, $score, $order);                               //Set done question information
     * $results = $question -> correct();                                           //Correct question
     * </code>
     *
     * @return array The correction results
     * @since 3.5.0
     * @access public
     */
    public void correct() //TODO implement this
    {
//        $nc = 0; $nf = 0;
//        for ($i = 0; $i < sizeof($this -> userAnswer); $i++) {
//            $results['correct'][$i] = true;                                                //Use this variable in order for the template to know how to color the answers (green/red)
//            if (isset($this -> answer[$i]) && $this -> userAnswer[$i] == 1) {
//                $nc++;
//            } elseif (!isset($this -> answer[$i]) && $this -> userAnswer[$i] == 1) {
//                $results['correct'][$i] = false;                                                //Use this variable in order for the template to know how to color the answers (green/red)
//                $nf++;
//            } elseif (isset($this -> answer[$i]) && $this -> userAnswer[$i] == 0) {
//                $results['correct'][$i] = false;                                                //Use this variable in order for the template to know how to color the answers (green/red)
//            	//$nf++;			//Used for taking into account false questions as well
//            } elseif (!isset($this -> answer[$i]) && $this -> userAnswer[$i] == 0) {
//                //$nc++;			//Used for taking into account false questions as well
//            }
//        }
//        $c = sizeof($this -> answer);
//        $f = sizeof($this -> userAnswer) - sizeof($this -> answer);
//        //$results['score'] = max(0, $nc / ($c+$f) - $nf / max($c, $f));			//Used for taking into account false questions as well
//		if ($this -> settings['answers_logic'] == 'or' || $this -> settings['answers_or'] == 1) {		//$this -> settings['answers_or'] == 1 is here for compatibility reasons
//			$nc > 0 && $nf == 0 ? $results['score'] = 1 : $results['score'] = 0;
//		} else if ($this -> settings['answers_logic'] == 'and') {
//			$nc == $c && $nf == 0 ? $results['score'] = 1 : $results['score'] = 0;
//		} else {
//			$results['score'] = max(0, $nc / $c - $nf / max($c, $f));
//		}
//        return $results;
    }

    /**
     * Set question done information
     *
     * This question is used to set its done information. This information consists of
     * the user answer, the score and the answers order.
     * <br/>Example:
     * <code>
     * $question = new MultipleManyQuestion(3);                                     //Instantiate question
     * $question -> setDone($answer, $score, $order);                               //Set done question information
     * </code>
     *
     * @param array $userAnswer The user answer
     * @param float score The user's score in this question
     * @param array $order the question options order
     * @since 3.5.0
     * @access public
     */
    public void setDone(List<String> userAnswer, boolean score, boolean order) //TODO implement this
    {
//        $this -> userAnswer = $userAnswer;
//        $score !== false ? $this -> score = $score : null;
//        $order !=  false ? $this -> order = $order : null;
    }
    
    private boolean isCorrect(Map<Integer, String> userAnswer, Object answer)
    {
    	Set<Integer> answerKey = ((Map<Integer, String>)answer).keySet();
    	boolean isCorrect = true;
    	for(Map.Entry<Integer, String> userAnswerEntry : userAnswer.entrySet())
    	{
    		int a = Integer.parseInt(userAnswerEntry.getValue());
    		if(a == 1 && !answerKey.contains(userAnswerEntry.getKey()))
    			isCorrect = false;
    		if(a == 0 && answerKey.contains(userAnswerEntry.getKey()))
    			isCorrect = false;
    	}
    	return isCorrect;
    }
    
    private void setUserAnser(Map<Integer, String> userAnswer)
    {
    	for (Map.Entry<Integer, String> userAnswerEntry : userAnswer.entrySet())
		{
			this.userAnswer = userAnswerEntry.getKey();
		}
    }
}