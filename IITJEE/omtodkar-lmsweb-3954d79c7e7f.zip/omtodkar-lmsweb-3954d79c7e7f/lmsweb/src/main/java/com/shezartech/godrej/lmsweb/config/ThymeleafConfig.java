package com.shezartech.godrej.lmsweb.config;

import java.util.HashSet;
import java.util.Set;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.thymeleaf.spring4.SpringTemplateEngine;
import org.thymeleaf.spring4.view.ThymeleafViewResolver;
import org.thymeleaf.templateresolver.ClassLoaderTemplateResolver;
import org.thymeleaf.templateresolver.ITemplateResolver;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

@Configuration
@ComponentScan(basePackages = { "com.shezartech.godrej.lmsweb" })
@EnableWebMvc
public class ThymeleafConfig extends WebMvcConfigurerAdapter
{

	@Bean
	public ClassLoaderTemplateResolver emailTemplateResolver()
	{
		ClassLoaderTemplateResolver templateResolver = new ClassLoaderTemplateResolver();
		templateResolver.setPrefix("mail/");
		templateResolver.setTemplateMode("HTML5");
		templateResolver.setCharacterEncoding("UTF-8");
		templateResolver.setOrder(2);
		return templateResolver;
	}
	
	@Bean
	public ServletContextTemplateResolver webTemplateResolver()
	{
		ServletContextTemplateResolver templateResolver = new ServletContextTemplateResolver();
		templateResolver.setPrefix("/WEB-INF/templates/");
		templateResolver.setTemplateMode("HTML5");
		templateResolver.setCharacterEncoding("UTF-8");
		templateResolver.setOrder(3);
		return templateResolver;
	}
	
	@Bean
	public SpringTemplateEngine templateEngine(ClassLoaderTemplateResolver emailTemplateResolver, ServletContextTemplateResolver webTemplateResolver)
	{
		SpringTemplateEngine templateEngine = new SpringTemplateEngine();
		
		Set<ITemplateResolver> set = new HashSet<ITemplateResolver>();
		set.add(emailTemplateResolver);
		set.add(webTemplateResolver);
		
		templateEngine.setTemplateResolvers(set);
		return templateEngine;
	}
	
	@Bean
	public ThymeleafViewResolver viewResolver(SpringTemplateEngine templateEngine)
	{
		ThymeleafViewResolver viewResolver = new ThymeleafViewResolver();
		viewResolver.setTemplateEngine(templateEngine);
		viewResolver.setCharacterEncoding("UTF-8");
		return viewResolver;
	}
}
