package com.shezartech.godrej.lmsweb.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.shezartech.godrej.lmsweb.dao.CompletedTestBlobDao;
import com.shezartech.godrej.lmsweb.dao.CompletedTestDao;
import com.shezartech.godrej.lmsweb.dao.ContentDao;
import com.shezartech.godrej.lmsweb.dao.TestDao;
import com.shezartech.godrej.lmsweb.dao.TestToQuestionDao;
import com.shezartech.godrej.lmsweb.dao.UserDao;
import com.shezartech.godrej.lmsweb.dao.UserToLessonDao;
import com.shezartech.godrej.lmsweb.entity.core.CompletedTest;
import com.shezartech.godrej.lmsweb.entity.core.CompletedTestBlob;
import com.shezartech.godrej.lmsweb.entity.core.Content;
import com.shezartech.godrej.lmsweb.entity.core.Course;
import com.shezartech.godrej.lmsweb.entity.core.Lesson;
import com.shezartech.godrej.lmsweb.entity.core.Question;
import com.shezartech.godrej.lmsweb.entity.core.Test;
import com.shezartech.godrej.lmsweb.entity.core.TestToQuestion;
import com.shezartech.godrej.lmsweb.entity.core.User;
import com.shezartech.godrej.lmsweb.entity.core.UserToLesson;
import com.shezartech.godrej.lmsweb.php.model.EfrontCompletedTest;

import de.ailis.pherialize.Mixed;
import de.ailis.pherialize.Pherialize;

@Service
public class TestServiceImpl implements TestService
{
	@Autowired
	private UserDao userDao;
	
	@Autowired
	private TestDao testDao;
	
	@Autowired
	private CompletedTestDao completedTestDao;
	
	@Autowired
	private CompletedTestBlobDao completedTestBlobDao;
	
	@Autowired
	private TestToQuestionDao testToQuestionDao;
	
	@Autowired
	private ContentDao contentDao;
	
	@Autowired
	private UserToLessonDao userToLessonDao;
	
	@Autowired
	private UserToCourseService userToCourseService;
	
	@Override
	@Transactional(value = "txManagerNew")
	public void setTestData(String login, int testId, Map<Integer, Map<Integer, String>> userAnswers, Map<String, Object> time)
	{
		time.put("pause", "");
		time.put("resume", Integer.parseInt((String) time.get("start")));
		time.put("spent", Integer.parseInt((String) time.get("end")) - Integer.parseInt((String) time.get("start")));
		int completedTestId = setCompletedTest(login, time, testId);
		float score = setCompletedTestBlob(login, time, testId, completedTestId, userAnswers);
		updateCompletedTest(completedTestId, score);
		
		updateUserToLesson(completedTestId, login, testId);
		userToCourseService.setCourseCompletedIfAllLessonsComplete(getCourse(testId, login), login, Long.parseLong((String) time.get("end")));
	}
	
	
	private int setCompletedTest(String login, Map<String, Object> time, int testId)
	{
		CompletedTest completedTest = new CompletedTest();
		completedTest.setUserLogin(login);
		completedTest.setTestId(testId);
		
		completedTest.setTimestamp(Integer.parseInt((String) time.get("end")));
		completedTest.setArchive(false);
		completedTest.setTimeStart(Integer.parseInt((String) time.get("start")));
		completedTest.setTimeEnd(Integer.parseInt((String) time.get("end")));
		completedTest.setTimeSpent((Integer) time.get("spent"));
		
		completedTest.setPending(false);
		int x = completedTestDao.save(completedTest);
		return x;
	}
	
	private float setCompletedTestBlob(final String login, Map<String, Object> time, final int testId, final int completedTestId,
			Map<Integer, Map<Integer, String>> userAnswers)
	{
		Test test = testDao.find(testId);
		
		Map<String, Object> completedTest = new HashMap<String, Object>(){{
			put("id", completedTestId);
			put("login", login);
			put("testsId", Integer.toString(testId));
		}};
		
		Content content = contentDao.find(test.getContentId());
		
		List<Map<String, String>> questions = getQuestions(testId);
		
		EfrontCompletedTest efrontCompletedTest = new EfrontCompletedTest(test.getHashMap());
		
		efrontCompletedTest.start(time, completedTest, content.getHashMap(), questions, userAnswers);
		
		String x = Pherialize.serialize(efrontCompletedTest);
		
		CompletedTestBlob completedTestBlob = new CompletedTestBlob();
		completedTestBlob.setCompletedTestId(completedTestId);
		completedTestBlobDao.persist(completedTestBlob, x);
		
//		try (Writer writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("filename.txt"), "utf-8")))
//		{
//			writer.write(x);
//		}
//		catch (IOException e) {
//			logger.error("error", e);
//			e.printStackTrace();
//		}
		
		return (float) efrontCompletedTest.completedTest.get("score");
	}
	
	private Map<String, String> getQuestionHash(Question question)
	{
		Map<String, String> questionMap = question.getHashMap();
		TestToQuestion testToQuestion = testToQuestionDao.findByQuestion(question);
		if(testToQuestion != null)
		{
			questionMap.put("weight", Integer.toString(testToQuestion.getWeight()));
			questionMap.put("previous_question_ID", Integer.toString(testToQuestion.getQuestionId().getId()));
		}
		return questionMap;
	}
	
	private List<Map<String, String>> getQuestions(int testId)
	{
		Test test = testDao.find(testId);
		List<Map<String, String>> questionHashes = new ArrayList<Map<String,String>>();
		Set<Question> questions = test.getQuestions();
		for (Question question : questions) {
			questionHashes.add(getQuestionHash(question));
		}
		return questionHashes;
	}
	
	private void updateCompletedTest(int completedTestId, float score)
	{
		CompletedTest completedTest = completedTestDao.find(completedTestId);
		completedTest.setStatus(score >= 50 ? "passed" : "failed");
		completedTest.setScore(score);
	}
	
	private void updateUserToLesson(int completedTestId, String login, int testId)
	{
		CompletedTest completedTest = completedTestDao.find(completedTestId);
		
		User user = userDao.findByLogin(login);
		Test test = testDao.find(testId);
		Lesson lesson = test.getLesson();
		
		UserToLesson userToLesson = userToLessonDao.find(user, lesson);
		
		String doneContent = userToLesson.getDoneContent();
		
		Map<Integer, String> map = new HashMap<Integer, String>();
		
		if(doneContent != null && !doneContent.isEmpty())
		{
			Map<Object, Object> doneContents = Pherialize.unserialize(doneContent).toArray();
			
			if(doneContents != null)
			{
				for (Map.Entry<Object, Object> entry : doneContents.entrySet())
				{
					map.put(((Mixed)entry.getKey()).toInt(), ((Mixed)entry.getValue()).toString());
				}
			}
		}
		
		map.put(test.getContentId(), String.valueOf(test.getContentId()));
		
		userToLesson.setDoneContent(Pherialize.serialize(map));
		userToLesson.setToTimestamp((long)completedTest.getTimestamp());
		
		Date date = new java.util.Date (((long)completedTest.getTimestamp())*1000);
		String date1 = new java.text.SimpleDateFormat("yyyy/MM/dd").format(date);
		String time = new java.text.SimpleDateFormat("HH:mm:ss").format(date);
		String comments = "Auto completed at: " + date1 + ", " + time;
		
		userToLesson.setComments(comments);
		userToLesson.setCurrentUnit(test.getContentId());
		userToLesson.setCompleted(1);
		
		Float score = completedTest.getScore();
		userToLesson.setScore(score == null ? null : score.intValue());
	}
	
	private int getCourse(int testId, String login)
	{
		Test test = testDao.find(testId);
		
		User user = userDao.findByLogin(login);
		
		Course course = null;
		
		mainLoop:
		for (Course courseTemp : user.getCourses())
		{
			for(Lesson lesson : courseTemp.getLessons())
			{
				if(lesson.getId() == test.getLesson().getId())
				{
					course = courseTemp;
					break mainLoop;
				}
			}
		}
		
		return course.getId();
		
	}
}