package com.shezartech.godrej.lmsweb.controller;

import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.shezartech.godrej.lmsweb.entity.core.Question;
import com.shezartech.godrej.lmsweb.model.SyncEntityView;
import com.shezartech.godrej.lmsweb.request.LoginForm;
import com.shezartech.godrej.lmsweb.response.AuthenticationFailureResponse;
import com.shezartech.godrej.lmsweb.response.BaseResponse;
import com.shezartech.godrej.lmsweb.response.QuestionResponse;
import com.shezartech.godrej.lmsweb.service.AuthenticationService;
import com.shezartech.godrej.lmsweb.service.Sync;

@RestController
@RequestMapping(value = "/api/question")
public class QuestionController 
{
	
	@Autowired private Sync sync;
	@Autowired private AuthenticationService authenticationService;
	private static final Logger logger = LoggerFactory.getLogger(QuestionController.class);
	
	@RequestMapping(value = "/all", method = RequestMethod.GET)
	public BaseResponse getQuestions(@RequestHeader("X-Auth-Login") String login, 
			@RequestHeader("X-Auth-Password") String password) throws NoSuchAlgorithmException 
	{
		
		try 
		{
			LoginForm loginForm = new LoginForm(login, password);
			
			if(authenticationService.authenticate(loginForm))
			{
				List<SyncEntityView> questions = sync.getQuestions(loginForm);
				return new QuestionResponse(questions);
			}
			else
			{
				return	new AuthenticationFailureResponse("Username or Password does not match");
			}		
		}
		catch (Exception e) 
		{
			logger.error("error in QuestionController.getQuestions for user login: ", e);
			e.printStackTrace();
			return null;
		}
	}
	
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public BaseResponse getQuestions(@PathVariable Integer id,
			@RequestHeader("X-Auth-Login") String login, 
			@RequestHeader("X-Auth-Password") String password) throws NoSuchAlgorithmException
	{
		try 
		{
			LoginForm loginForm = new LoginForm(login, password);
			
			if(authenticationService.authenticate(loginForm))
			{
				Set<Question> questions = sync.getQuestions(id, loginForm);
				QuestionResponse response = new QuestionResponse(questions);
				return response;
			}
			else
			{
				return new AuthenticationFailureResponse("Username or Password does not match");
			}	
		} 
		catch (Exception e) 
		{
			logger.error("error in QuestionController.getQuestions for user login: ", e);
			e.printStackTrace();
			return null;
		}
	}
}