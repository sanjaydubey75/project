package com.shezartech.godrej.lmsweb.service;

import java.util.List;

import com.shezartech.godrej.lmsweb.entity.core.Lesson;
import com.shezartech.godrej.lmsweb.model.LessonSyncViewModel;

public interface LessonService
{
	public static final String specialLesson = "Assessment";

	List<LessonSyncViewModel> getLessons(int courseId, String login, boolean specialLesson);
	
	List<LessonSyncViewModel> getAllLessons(String login, boolean specialLesson);

	List<Lesson> filterOutSpecialLesson(List<Lesson> lessons);

	List<Lesson> filterInSpecialLesson(List<Lesson> lessons);

}
