package com.shezartech.godrej.lmsweb.dao;

import com.shezartech.godrej.lmsweb.entity.core.Content;

public interface ContentDao extends BaseDao<Content, Integer>
{

}