package com.shezartech.godrej.lmsweb.service;

public interface ScormService
{

	void setScormCompleted(int lessonId, String login, long timestamp);

}
