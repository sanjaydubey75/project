package com.shezartech.godrej.lmsweb.dao;

import com.shezartech.godrej.lmsweb.entity.core.Lesson;

public interface LessonDao extends SyncEntityDao<Lesson, Integer> {

}
