package com.shezartech.godrej.lmsweb.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.shezartech.godrej.lmsweb.entity.core.Lesson;

@Repository
public class LessonDaoImpl extends SyncEntityDaoImpl<Lesson, Integer> implements
		LessonDao {

	public LessonDaoImpl() {
		super(Lesson.class);
	}

	@Override
	@Autowired
	@Qualifier("newSessionFactory")
	public void setSessionFactory(SessionFactory sessionFactory) {
		super.setSessionFactory(sessionFactory);
	}

}