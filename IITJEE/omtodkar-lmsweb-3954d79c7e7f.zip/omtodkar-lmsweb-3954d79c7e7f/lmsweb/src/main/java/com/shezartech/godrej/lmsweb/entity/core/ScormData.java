package com.shezartech.godrej.lmsweb.entity.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.Range;

@Entity
@Table(name = "scorm_data")
public class ScormData implements BaseEntity
{

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer id;
	
	@Column(name = "content_ID")
	@NotNull
	@Range(min = 0, max = 16777215)
	private Integer contentId = 0;
	
	@Length(max = 100)
	@Column(name = "users_LOGIN")
	private String userLogin;
	
	@Range(min = 0, max = 4294967295L)
	private Long timestamp;
	
	@Column(name = "lesson_location", columnDefinition = "text")
	private String lessonLocation;
	
	@Column(name = "maxtimeallowed")
	@Length(max = 255)
	private String maxTimeAllowed;
	
	@Column(name = "timelimitaction")
	@Length(max = 255)
	private String timeLimitation;
	
	@Length(max = 255)
	@Column(name = "masteryScore")
	private String masteryScore;
	
	@Column(columnDefinition = "text", name = "datafromlms")
	private String dataFromLms;
	
	@NotNull
	@Length(max = 255)
	private String entry = "";
	
	@Column(name = "total_time")
	private String totalTime;
	
	@Length(max = 255)
	private String comments;
	
	@Column(columnDefinition = "text", name = "comments_from_lms")
	private String commentsFromLms;
	
	@Length(max = 255)
	@Column(name = "lesson_status")
	private String lessonStatus;
	
	@Length(max = 255)
	private String score;
	
	@Column(name = "scorm_exit")
	@Length(max = 255)
	private String scormExit;
	
	@Column(name = "minscore")
	@Length(max = 255)
	private String minScore;
	
	@Column(name = "maxscore")
	@Length(max = 255)
	private String maxScore;
	
	@Column(name = "suspend_data")
	private String suspendData;
	
	@Column(name = "completion_threshold", columnDefinition = "text")
	@Length(max = 255)
	private String completionThreshold;
	
	@Length(max = 255)
	@Column(name = "completion_status")
	private String completionStatus;

	public int getId()
	{
		return id;
	}

	public void setId(int id)
	{
		this.id = id;
	}

	public int getContentId()
	{
		return contentId;
	}

	public void setContentId(int contentId)
	{
		this.contentId = contentId;
	}

	public String getUserLogin()
	{
		return userLogin;
	}

	public void setUserLogin(String userLogin)
	{
		this.userLogin = userLogin;
	}

	public Long getTimestamp()
	{
		return timestamp;
	}

	public void setTimestamp(Long timestamp)
	{
		this.timestamp = timestamp;
	}

	public String getLessonLocation()
	{
		return lessonLocation;
	}

	public void setLessonLocation(String lessonLocation)
	{
		this.lessonLocation = lessonLocation;
	}

	public String getMaxTimeAllowed()
	{
		return maxTimeAllowed;
	}

	public void setMaxTimeAllowed(String maxTimeAllowed)
	{
		this.maxTimeAllowed = maxTimeAllowed;
	}

	public String getTimeLimitation()
	{
		return timeLimitation;
	}

	public void setTimeLimitation(String timeLimitation)
	{
		this.timeLimitation = timeLimitation;
	}

	public String getMasteryScore()
	{
		return masteryScore;
	}

	public void setMasteryScore(String masteryScore)
	{
		this.masteryScore = masteryScore;
	}

	public String getDataFromLms()
	{
		return dataFromLms;
	}

	public void setDataFromLms(String dataFromLms)
	{
		this.dataFromLms = dataFromLms;
	}

	public String getEntry()
	{
		return entry;
	}

	public void setEntry(String entry)
	{
		this.entry = entry;
	}

	public String getTotalTime()
	{
		return totalTime;
	}

	public void setTotalTime(String totalTime)
	{
		this.totalTime = totalTime;
	}

	public String getComments()
	{
		return comments;
	}

	public void setComments(String comments)
	{
		this.comments = comments;
	}

	public String getCommentsFromLms()
	{
		return commentsFromLms;
	}

	public void setCommentsFromLms(String commentsFromLms)
	{
		this.commentsFromLms = commentsFromLms;
	}

	public String getLessonStatus()
	{
		return lessonStatus;
	}

	public void setLessonStatus(String lessonStatus)
	{
		this.lessonStatus = lessonStatus;
	}

	public String getScore()
	{
		return score;
	}

	public void setScore(String score)
	{
		this.score = score;
	}

	public String getScormExit()
	{
		return scormExit;
	}

	public void setScormExit(String scormExit)
	{
		this.scormExit = scormExit;
	}

	public String getMinScore()
	{
		return minScore;
	}

	public void setMinScore(String minScore)
	{
		this.minScore = minScore;
	}

	public String getMaxScore()
	{
		return maxScore;
	}

	public void setMaxScore(String maxScore)
	{
		this.maxScore = maxScore;
	}

	public String getSuspendData()
	{
		return suspendData;
	}

	public void setSuspendData(String suspendData)
	{
		this.suspendData = suspendData;
	}

	public String getCompletionThreshold()
	{
		return completionThreshold;
	}

	public void setCompletionThreshold(String completionThreshold)
	{
		this.completionThreshold = completionThreshold;
	}

	public String getCompletionStatus()
	{
		return completionStatus;
	}

	public void setCompletionStatus(String completionStatus)
	{
		this.completionStatus = completionStatus;
	}
}
