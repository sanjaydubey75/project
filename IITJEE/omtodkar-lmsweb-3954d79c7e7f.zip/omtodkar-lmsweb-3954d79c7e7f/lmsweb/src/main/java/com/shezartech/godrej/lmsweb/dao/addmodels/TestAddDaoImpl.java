package com.shezartech.godrej.lmsweb.dao.addmodels;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.shezartech.godrej.lmsweb.dao.BaseDaoImpl;
import com.shezartech.godrej.lmsweb.entity.addmodels.TestAdd;
import com.shezartech.godrej.lmsweb.entity.core.IAddDeleteEntity;
import com.shezartech.godrej.lmsweb.entity.core.SyncEntity;
import com.shezartech.godrej.lmsweb.entity.core.Test;

@Repository
public class TestAddDaoImpl extends BaseDaoImpl<TestAdd, Long> implements TestAddDao{

	public TestAddDaoImpl() {
		super(TestAdd.class);
	}
	
	@Override
	@Autowired
	@Qualifier("oldSessionFactory")
	public void setSessionFactory(SessionFactory sessionFactory) {
		super.setSessionFactory(sessionFactory);
	}

	@Override
	public IAddDeleteEntity find(SyncEntity entity) {
		
		Criteria criteria = getCurrentSession().createCriteria(TestAdd.class);
//		criteria.add(Restrictions.eq("user", user));
		criteria.add(Restrictions.eq("test", entity));
		return (IAddDeleteEntity) criteria.uniqueResult();
	}
	
	@Override
	public TestAdd findById(int id){
		Criteria criteria = getCurrentSession().createCriteria(TestAdd.class);
		criteria.add(Restrictions.eq("test.id", id));
		return (TestAdd) criteria.uniqueResult();
	}
	
	@Override
	public TestAdd findByNameAssessment(String name){
		Criteria criteria = getCurrentSession().createCriteria(TestAdd.class);
		criteria.add(Restrictions.ilike("test.name", "%assessment%"));
		return (TestAdd) criteria.uniqueResult();
	}

	@Override
	public IAddDeleteEntity persist(SyncEntity test) {
		
		TestAdd testAdd = new TestAdd();
		testAdd.setTest((Test) test);
		testAdd.setHash();
		this.persist(testAdd);
		return testAdd;
	}

	@Override
	public void delete(IAddDeleteEntity entity) {
		super.delete((TestAdd)entity);
	}

}