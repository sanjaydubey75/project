package com.shezartech.godrej.lmsweb.dao;

import com.shezartech.godrej.lmsweb.entity.core.UserToContent;

public interface UserToContentDao extends BaseDao<UserToContent, Integer>
{

}
