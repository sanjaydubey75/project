package com.shezartech.godrej.lmsweb.dao.addmodels;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.shezartech.godrej.lmsweb.dao.BaseDaoImpl;
import com.shezartech.godrej.lmsweb.entity.addmodels.QuestionAdd;
import com.shezartech.godrej.lmsweb.entity.core.IAddDeleteEntity;
import com.shezartech.godrej.lmsweb.entity.core.Question;
import com.shezartech.godrej.lmsweb.entity.core.SyncEntity;

@Repository
public class QuestionAddDaoImpl extends BaseDaoImpl<QuestionAdd, Long> implements QuestionAddDao{

	public QuestionAddDaoImpl() {
		super(QuestionAdd.class);
	}
	
	@Override
	@Autowired
	@Qualifier("oldSessionFactory")
	public void setSessionFactory(SessionFactory sessionFactory) {
		super.setSessionFactory(sessionFactory);
	}

	@Override
	public IAddDeleteEntity find(SyncEntity entity) {
		
		Criteria criteria = getCurrentSession().createCriteria(QuestionAdd.class);
		criteria.add(Restrictions.eq("question", entity));
		return (IAddDeleteEntity) criteria.uniqueResult();
	}
	
	@Override
	public QuestionAdd findById(int id){
		Criteria criteria = getCurrentSession().createCriteria(QuestionAdd.class);
		criteria.add(Restrictions.eq("question.id", id));
		return (QuestionAdd) criteria.uniqueResult();
	}

	@Override
	public IAddDeleteEntity persist(SyncEntity entity) {
		
		QuestionAdd questionAdd = new QuestionAdd();
		questionAdd.setQuestion((Question) entity);
		questionAdd.setHash();
		this.persist(questionAdd);
		return questionAdd;
	}

	@Override
	public void delete(IAddDeleteEntity entity) {
		super.delete((QuestionAdd)entity);
	}
}