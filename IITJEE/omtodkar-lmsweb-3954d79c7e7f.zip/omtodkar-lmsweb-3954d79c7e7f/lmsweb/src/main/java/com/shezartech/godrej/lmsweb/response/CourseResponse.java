package com.shezartech.godrej.lmsweb.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.shezartech.godrej.lmsweb.entity.core.Course;
import com.shezartech.godrej.lmsweb.model.CourseSyncListViewModel;

public class CourseResponse extends BaseResponse{
	
	@JsonInclude(Include.NON_NULL)
	public Course course;
	
	@JsonInclude(Include.NON_NULL)
	public List<CourseSyncListViewModel> courses;

	public CourseResponse(String statusMessage) {
		super(false, statusMessage);
	}
	
	public CourseResponse(Course course){
		super(true, null);
		this.course = course;
	}
	
	public CourseResponse(List<CourseSyncListViewModel> courses){
		super(true, null);
		this.courses = courses;
	}
}
