package com.shezartech.godrej.lmsweb.service;

import java.util.List;

import com.shezartech.godrej.lmsweb.entity.core.Direction;

public interface DirectionService
{

	List<Direction> getDirections();

}
