package com.shezartech.godrej.lmsweb.entity.core;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;

@Entity
@Table(name="content")
public class Content implements BaseEntity
{
	@Id
	@NotNull
	@Column(columnDefinition = "mediumint(8) unsigned NOT NULL AUTO_INCREMENT")
	private Integer id;
	
	@NotNull
	@Column(columnDefinition = "varchar(255) NOT NULL")
	@Length(max=255)
	private String name;
	
	@Column(columnDefinition = "longtext")
	private String data;
	
	@Column(columnDefinition = "mediumint(8) unsigned DEFAULT '0'", name = "parent_content_ID")
	private Integer parentContentId;
	
	//@Column(columnDefinition = "mediumint(8) unsigned DEFAULT '0'", name = "lessons_ID")
	@ManyToOne
	@JoinColumn(name = "lessons_ID")
	private Lesson lesson;
	
	@NotNull
	@Column(columnDefinition = "int(10) unsigned NOT NULL")
	private Long timestamp;
	
	@Length(max=255)
	@Column(columnDefinition = "varchar(255) NOT NULL", name = "ctg_type")
	private String categoryType;
	
	@Column(columnDefinition = "tinyint(1) DEFAULT '1'")
	private Boolean active;
	
	@Column(columnDefinition = "mediumint(8) unsigned DEFAULT '0'", name = "previous_content_ID")
	private Integer previousContentId;
	
	@Column(columnDefinition = "text")
	private String options;
	
	@Column(columnDefinition = "text")
	private String metadata;
	
	@Length(max = 50)
	@Column(columnDefinition = "varchar(50) DEFAULT NULL", name = "scorm_version")
	private String scormVersion;
	
	@Column(columnDefinition = "tinyint(1) DEFAULT '1'")
	private Boolean publish;
	
	@NotNull
	@Length(max = 255)
	@Column(columnDefinition = "varchar(255) NOT NULL DEFAULT ''")
	private String identifier;
	
	@Column(columnDefinition = "mediumint(8) unsigned DEFAULT NULL", name = "linked_to")
	private Integer linkedTo;

	public int getId()
	{
		return id;
	}

	public void setId(int id)
	{
		this.id = id;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public String getData()
	{
		return data;
	}

	public void setData(String data)
	{
		this.data = data;
	}

	public Integer getParentContentId()
	{
		return parentContentId;
	}

	public void setParentContentId(Integer parentContentId)
	{
		this.parentContentId = parentContentId;
	}

	public Lesson getLesson()
	{
		return lesson;
	}

	public void setLesson(Lesson lessonId)
	{
		this.lesson = lessonId;
	}

	public long getTimestamp()
	{
		return timestamp;
	}

	public void setTimestamp(long timestamp)
	{
		this.timestamp = timestamp;
	}

	public String getCategoryType()
	{
		return categoryType;
	}

	public void setCategoryType(String categoryType)
	{
		this.categoryType = categoryType;
	}

	public Boolean isActive()
	{
		return active;
	}

	public void setActive(Boolean active)
	{
		this.active = active;
	}

	public Integer getPreviousContentId()
	{
		return previousContentId;
	}

	public void setPreviousContentId(Integer previousContentId)
	{
		this.previousContentId = previousContentId;
	}

	public String getOptions()
	{
		return options;
	}

	public void setOptions(String options)
	{
		this.options = options;
	}

	public String getMetadata()
	{
		return metadata;
	}

	public void setMetadata(String metadata)
	{
		this.metadata = metadata;
	}

	public String getScormVersion()
	{
		return scormVersion;
	}

	public void setScormVersion(String scormVersion)
	{
		this.scormVersion = scormVersion;
	}

	public Boolean isPublish()
	{
		return publish;
	}

	public void setPublish(Boolean publish)
	{
		this.publish = publish;
	}

	public String getIdentifier()
	{
		return identifier;
	}

	public void setIdentifier(String identifier)
	{
		this.identifier = identifier;
	}

	public Integer getLinkedTo()
	{
		return linkedTo;
	}

	public void setLinkedTo(Integer linkedTo)
	{
		this.linkedTo = linkedTo;
	}
	
	public Map<String, Object> getHashMap()
	{
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", Integer.toString(this.getId()));
		map.put("name", this.getName());
		map.put("data", this.getData());
		map.put("parent_content_ID", this.getParentContentId() != null ? Integer.toString(this.getParentContentId()) : null);
		map.put("lessons_ID", this.getLesson() != null ? Integer.toString(this.getLesson().getId()) : null);
		map.put("timestamp", Long.toString(this.getTimestamp()));
		map.put("ctg_type", this.getCategoryType());
		map.put("active", Integer.toString(this.isActive() ? 1 : 0));
		map.put("previous_content_ID", this.getPreviousContentId() != null ? Integer.toString(this.getPreviousContentId()) : null);
		map.put("options", this.getOptions());
		map.put("mnetadata", this.getMetadata());
		map.put("scorm_version", this.getScormVersion());
		map.put("publish", Integer.toString(this.isPublish() ? 1 : 0));
		map.put("identifier", this.getIdentifier());
		map.put("linked_to", this.getLinkedTo() != null ? Integer.toString(this.getLinkedTo()) : null);
		return map; 
	}
}