package com.shezartech.godrej.lmsweb.entity.core;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;
import org.hibernate.validator.constraints.Length;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="courses", indexes={
	@Index(columnList="instance_source", name="instance_source")
})
public class Course extends SyncEntity{

	@Id
	@NotNull
	@Column(columnDefinition = "mediumint(8) unsigned NOT NULL AUTO_INCREMENT")
	private Integer id;
	
	@NotNull
	@Column(columnDefinition = "varchar(150) NOT NULL")
	@Length(max=150)
	private String name;
	
	@NotNull
	@Column(columnDefinition = "tinyint(1) NOT NULL DEFAULT '1'")
	private boolean active;
	
	@Column(columnDefinition = "int(10) unsigned DEFAULT '0'")
	private Integer archive;
	
	@Column(columnDefinition = "int(10) unsigned DEFAULT NULL")
	private Integer created;
	
	@Column(columnDefinition = "int(10) unsigned DEFAULT NULL", name="start_date")
	private Integer startDate;
	
	@Column(columnDefinition = "int(10) unsigned DEFAULT NULL", name="end_date")
	private Integer endDate;
	
	@Column(columnDefinition = "text")
	private String options;
	
	@Column(columnDefinition = "text")
	private String metadata;
	
	@Column(columnDefinition = "text")
	private String description;
	
	@Column(columnDefinition = "text")
	private String info;
	
	@Column(columnDefinition = "float DEFAULT '0'")
	private Float price;
	
	@NotNull
	@Column(columnDefinition = "tinyint(1) NOT NULL DEFAULT '1'", name="show_catalog")
	private boolean showCatalog;
	
	@Column(columnDefinition = "tinyint(1) DEFAULT '1'")
	private Boolean publish;
	
	@Column(columnDefinition = "mediumint(8) unsigned DEFAULT NULL", name="directions_ID")
	private Integer directionsId;
	
	@NotNull
	@Column(columnDefinition = "varchar(50) NOT NULL", name="languages_NAME")
	@Length(max=50)
	private String languagesName;
	
	@NotNull
	@Column(columnDefinition = "tinyint(1) NOT NULL DEFAULT '0'")
	private boolean reset;
	
	@Column(columnDefinition = "int(10) unsigned DEFAULT NULL", name="certificate_expiration")
	private Integer certificateExpiration;
	
	@Column(columnDefinition = "int(10) unsigned DEFAULT NULL", name="reset_interval")
	private Integer resetInterval;
	
	@Column(columnDefinition = "int(10) unsigned DEFAULT NULL", name="max_users")
	private Integer maxUsers;
	
	@Column(columnDefinition = "text")
	private String rules;
	
	@Column(columnDefinition = "mediumint(8) unsigned DEFAULT '0'", name="instance_source")
	private Integer instanceSource;
	
	@Column(columnDefinition = "varchar(100) DEFAULT NULL", name="supervisor_LOGIN")
	@Length(max=100)
	private String supervisorLogin;
	
	@Column(columnDefinition = "mediumint(8) unsigned DEFAULT '0'", name="depends_on")
	private Integer dependsOn;
	
	@Column(columnDefinition = "int(10) unsigned DEFAULT NULL")
	private Integer ceu;
	
	@Column(columnDefinition = "varchar(100) DEFAULT NULL", name="creator_LOGIN")
	@Length(max=100)
	private String creatorLogin;
	
//	@OneToMany(mappedBy="courseId")
//	@Cascade({CascadeType.ALL})
//	private Set<LessonToCourse> lessonToCourses = new HashSet<LessonToCourse>();
//	
	@JsonIgnore
	@OneToMany
	@JoinTable(
			name="lessons_to_courses",
			joinColumns = @JoinColumn(name="courses_ID", referencedColumnName = "id"),
			inverseJoinColumns = @JoinColumn(name="lessons_ID", referencedColumnName = "id")
	)
	@Cascade({CascadeType.ALL})
	private Set<Lesson> lessons = new HashSet<Lesson>();
//
//	public Set<LessonToCourse> getLessonToCourses() {
//		return lessonToCourses;
//	}
//
//	public void setLessonToCourses(Set<LessonToCourse> lessonToCourses) {
//		this.lessonToCourses = lessonToCourses;
//	}
//
	public Set<Lesson> getActiveLessons()
	{
		Set<Lesson> lessons = new HashSet<Lesson>();
		for (Lesson lesson : this.lessons)
		{
			if(lesson.isActive())
				lessons.add(lesson);
		}
		return lessons;
	}
	
	public Set<Lesson> getLessons()
	{
		return lessons;
	}

	public void setLessons(Set<Lesson> lessons) {
		this.lessons = lessons;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public Integer getArchive() {
		return archive;
	}

	public void setArchive(Integer archive) {
		this.archive = archive;
	}

	public Integer getCreated() {
		return created;
	}

	public void setCreated(Integer created) {
		this.created = created;
	}

	public Integer getStartDate() {
		return startDate;
	}

	public void setStartDate(Integer startDate) {
		this.startDate = startDate;
	}

	public Integer getEndDate() {
		return endDate;
	}

	public void setEndDate(Integer endDate) {
		this.endDate = endDate;
	}

	public String getOptions() {
		return options;
	}

	public void setOptions(String options) {
		this.options = options;
	}

	public String getMetadata() {
		return metadata;
	}

	public void setMetadata(String metadata) {
		this.metadata = metadata;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	public Float getPrice() {
		return price;
	}

	public void setPrice(Float price) {
		this.price = price;
	}

	public boolean isShowCatalog() {
		return showCatalog;
	}

	public void setShowCatalog(boolean showCatalog) {
		this.showCatalog = showCatalog;
	}

	public Boolean isPublish() {
		return publish;
	}

	public void setPublish(Boolean publish) {
		this.publish = publish;
	}

	public Integer getDirectionsId() {
		return directionsId;
	}

	public void setDirectionsId(Integer directionsId) {
		this.directionsId = directionsId;
	}

	public String getLanguagesName() {
		return languagesName;
	}

	public void setLanguagesName(String languagesName) {
		this.languagesName = languagesName;
	}

	public boolean isReset() {
		return reset;
	}

	public void setReset(boolean reset) {
		this.reset = reset;
	}

	public Integer getCertificateExpiration() {
		return certificateExpiration;
	}

	public void setCertificateExpiration(Integer certificateExpiration) {
		this.certificateExpiration = certificateExpiration;
	}

	public Integer getResetInterval() {
		return resetInterval;
	}

	public void setResetInterval(Integer resetInterval) {
		this.resetInterval = resetInterval;
	}

	public Integer getMaxUsers() {
		return maxUsers;
	}

	public void setMaxUsers(Integer maxUsers) {
		this.maxUsers = maxUsers;
	}

	public String getRules() {
		return rules;
	}

	public void setRules(String rules) {
		this.rules = rules;
	}

	public Integer getInstanceSource() {
		return instanceSource;
	}

	public void setInstanceSource(Integer instanceSource) {
		this.instanceSource = instanceSource;
	}

	public String getSupervisorLogin() {
		return supervisorLogin;
	}

	public void setSupervisorLogin(String supervisorLogin) {
		this.supervisorLogin = supervisorLogin;
	}

	public Integer getDependsOn() {
		return dependsOn;
	}

	public void setDependsOn(Integer dependsOn) {
		this.dependsOn = dependsOn;
	}

	public Integer getCeu() {
		return ceu;
	}

	public void setCeu(Integer ceu) {
		this.ceu = ceu;
	}

	public String getCreatorLogin() {
		return creatorLogin;
	}

	public void setCreatorLogin(String creatorLogin) {
		this.creatorLogin = creatorLogin;
	}
	
	@Override
	public int comparePrimaryKey(SyncEntity course){
		return this.getId() - ((Course) course).getId();
	}
	
	public Course(){ }
}