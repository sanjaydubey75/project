package com.shezartech.godrej.lmsweb.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

public class SyncEntityView {

	public int Id;
	
	@JsonInclude(Include.NON_NULL)
	public String name;
	
	public int hash;

	public SyncEntityView(int id, String name, int hash) {
		super();
		Id = id;
		this.name = name;
		this.hash = hash;
	}
}