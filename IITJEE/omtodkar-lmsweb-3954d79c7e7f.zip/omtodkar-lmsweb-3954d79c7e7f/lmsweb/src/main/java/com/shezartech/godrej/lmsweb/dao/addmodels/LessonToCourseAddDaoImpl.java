package com.shezartech.godrej.lmsweb.dao.addmodels;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.shezartech.godrej.lmsweb.dao.BaseDaoImpl;
import com.shezartech.godrej.lmsweb.entity.addmodels.LessonToCourseAdd;
import com.shezartech.godrej.lmsweb.entity.core.IAddDeleteEntity;
import com.shezartech.godrej.lmsweb.entity.core.LessonToCourse;
import com.shezartech.godrej.lmsweb.entity.core.SyncEntity;

@Repository
public class LessonToCourseAddDaoImpl extends BaseDaoImpl<LessonToCourseAdd, Long> implements LessonToCourseAddDao{

	public LessonToCourseAddDaoImpl() {
		super(LessonToCourseAdd.class);
	}
	
	@Override
	@Autowired
	@Qualifier("oldSessionFactory")
	public void setSessionFactory(SessionFactory sessionFactory) {
		super.setSessionFactory(sessionFactory);
	}

	@Override
	public IAddDeleteEntity find(SyncEntity entity) {
		Criteria criteria = getCurrentSession().createCriteria(LessonToCourseAdd.class);
//		criteria.add(Restrictions.eq("user", user));
		criteria.add(Restrictions.eq("course", entity));
		return (IAddDeleteEntity) criteria.uniqueResult();
	}

	@Override
	public IAddDeleteEntity persist(SyncEntity entity) {
		LessonToCourseAdd questionAdd = new LessonToCourseAdd();
		questionAdd.setCourse((LessonToCourse) entity);
//		questionAdd.setUser(user);
		this.persist(questionAdd);
		return questionAdd;
	}

	@Override
	public void delete(IAddDeleteEntity entity) {
		super.delete((LessonToCourseAdd)entity);
	}
}