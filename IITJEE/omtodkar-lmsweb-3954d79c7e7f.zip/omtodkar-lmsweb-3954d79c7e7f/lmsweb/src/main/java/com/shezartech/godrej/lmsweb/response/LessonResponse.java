package com.shezartech.godrej.lmsweb.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.shezartech.godrej.lmsweb.entity.core.Lesson;
import com.shezartech.godrej.lmsweb.model.LessonSyncViewModel;
import com.shezartech.godrej.lmsweb.model.LessonSyncViewModel.TestViewModel;

public class LessonResponse extends BaseResponse{
	
	@JsonInclude(Include.NON_NULL)
	public Lesson lesson;
	
	@JsonInclude(Include.NON_NULL)
	public List<LessonSyncViewModel> lessons;

	public LessonResponse(String statusMessage) {
		super(false, statusMessage);
	}
	
	public LessonResponse(Lesson lesson){
		super(true, null);
		this.lesson = lesson;
	}
	
//	public LessonResponse(List<ModuleView> lessons){
//		super(true, null);
//		this.lessons = lessons;
//	}
	
	public LessonResponse(List<LessonSyncViewModel> lessons)
	{
		super(true, null);
		this.lessons = lessons;
	}
	
}
