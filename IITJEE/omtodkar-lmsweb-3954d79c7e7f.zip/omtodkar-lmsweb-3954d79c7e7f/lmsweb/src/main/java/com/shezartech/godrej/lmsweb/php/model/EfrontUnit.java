package com.shezartech.godrej.lmsweb.php.model;

import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.Map;

import de.ailis.pherialize.Mixed;
import de.ailis.pherialize.MixedArray;
import de.ailis.pherialize.Pherialize;
import de.ailis.pherialize.PhpSerializable;

public class EfrontUnit implements Serializable, PhpSerializable
{
	/**
     * The maximum length for unit names. After that, the names appear truncated
     */
    static int MAXIMUM_NAME_LENGTH = 40;

    static int COMPLETION_OPTIONS_DEFAULT = 0;
    static int COMPLETION_OPTIONS_AUTOCOMPLETE = 1;
    static int COMPLETION_OPTIONS_COMPLETEWITHQUESTION = 2;
    static int COMPLETION_OPTIONS_COMPLETEAFTERSECONDS = 3;
	static int COMPLETION_OPTIONS_HIDECOMPLETEUNITICON = 4;
	static int COMPLETION_OPTIONS_ACCEPTTERMSCOMPLETION = 5;
	
//	public String id;
//	public String name;
//	public String data;
//	public String parent_content_ID;
//	public String lessons_ID;
//	public String timestamp;
//	public String ctg_type;
//	public String active;
//	public String previous_content_ID;
//	public Object options;
//	public String metadata;
//	public Object scorm_version;
//	public String publish;
//	public String identifier;
//	public Object linked_to;
	
	public Map<String, Object> map;
	
	public EfrontUnit(Map<String, Object> map)
	{
		if(map.containsKey("options"))
		{
			Object options = getOptions((String) map.get("options"));
			map.put("options", options);
		}
		
		this.map = map;
		
//		this.id = (String) map.get("id");
//		this.name = (String) map.get("name");
//		this.data = (String) map.get("data");
//		this.parent_content_ID = (String) map.get("parent_content_ID");
//		this.lessons_ID = (String) map.get("lessons_ID");
//		this.timestamp = (String) map.get("timestamp");
//		this.ctg_type = (String) map.get("ctg_type");
//		this.active = (String) map.get("active");
//		this.previous_content_ID = (String) map.get("previous_content_ID");
//		this.options = map.get("options");
//		this.metadata = (String) map.get("metadata");
//		this.scorm_version = map.get("scorm_version");
//		this.publish = (String) map.get("publish");
//		this.identifier = (String) map.get("identifier");
//		this.linked_to = map.get("linked_to");
	}
	
	private Object getOptions(String options)
	{
		if(options != null && !options.equals(""))
		{
			Mixed temp = Pherialize.unserialize(options);
			MixedArray mixedArray = temp.toArray();
			
			if(mixedArray != null)
			{
				Map<String, Object> tempMap = new LinkedHashMap<String, Object>();
				
				if(mixedArray.containsKey("complete_unit_setting"))
					tempMap.put("complete_unit_setting", (new Mixed(mixedArray.get("complete_unit_setting"))).toString());
				if(mixedArray.containsKey("hide_navigation"))
					tempMap.put("hide_navigation", (new Mixed(mixedArray.get("hide_navigation"))).toString());
				if(mixedArray.containsKey("indexed"))
					tempMap.put("indexed", (new Mixed(mixedArray.get("indexed"))).toString());
				if(mixedArray.containsKey("maximize_viewport"))
					tempMap.put("maximize_viewport", (new Mixed(mixedArray.get("maximize_viewport"))).toString());
				if(mixedArray.containsKey("scorm_asynchronous"))
					tempMap.put("scorm_asynchronous", (new Mixed(mixedArray.get("scorm_asynchronous"))).toInt());
				if(mixedArray.containsKey("scorm_times")) //TODO find the type
					tempMap.put("scorm_times", (new Mixed(mixedArray.get("scorm_times"))).toString());
				if(mixedArray.containsKey("scorm_logging"))
					tempMap.put("scorm_logging", (new Mixed(mixedArray.get("scorm_logging"))).toInt());
				if(mixedArray.containsKey("object_ids"))
					tempMap.put("object_ids", (new Mixed(mixedArray.get("object_ids"))).toString());
				if(mixedArray.containsKey("no_before_unload"))
					tempMap.put("no_before_unload", (new Mixed(mixedArray.get("no_before_unload"))).toInt());
				if(mixedArray.containsKey("reentry_action"))
					tempMap.put("reentry_action", (new Mixed(mixedArray.get("reentry_action"))).toBoolean());
				if(mixedArray.containsKey("complete_question"))
					tempMap.put("complete_question", (new Mixed(mixedArray.get("complete_question"))).toString());
				if(mixedArray.containsKey("complete_time"))
					tempMap.put("complete_time", (new Mixed(mixedArray.get("complete_time"))).toString());
				return tempMap;
			}
			else
			{
				return temp;
			}
		}
		return null;
	}

	@Override
	public String serialize()
	{
		String serializedString = "x:i:0;";
		serializedString = serializedString + Pherialize.serialize(this.map) + ";m:a:0:{}";
		return serializedString;
	}
}
