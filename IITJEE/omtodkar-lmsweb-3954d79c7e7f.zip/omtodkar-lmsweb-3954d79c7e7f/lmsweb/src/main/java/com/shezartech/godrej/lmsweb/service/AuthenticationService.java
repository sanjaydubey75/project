package com.shezartech.godrej.lmsweb.service;

import java.security.NoSuchAlgorithmException;

import com.shezartech.godrej.lmsweb.entity.core.User;
import com.shezartech.godrej.lmsweb.request.LoginForm;

public interface AuthenticationService {

	boolean authenticate(LoginForm loginForm) throws NoSuchAlgorithmException;

	User getUser(LoginForm loginForm);

}
