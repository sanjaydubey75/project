package com.shezartech.godrej.lmsweb.service;

import java.io.File;

public interface ModuleService {

	File getModule(int id);

	/**
	 * Tells whether the folder exists for that lesson (which may be converted to zip if the folder does not already contain it)
	 */
	boolean isModuleExist(int id);

}