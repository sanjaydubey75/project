package com.shezartech.godrej.lmsweb.dao.addmodels;

import com.shezartech.godrej.lmsweb.dao.AddDeleteDao;
import com.shezartech.godrej.lmsweb.entity.addmodels.CourseAdd;
import com.shezartech.godrej.lmsweb.entity.core.Course;

public interface CourseAddDao extends AddDeleteDao<CourseAdd, Long> {

	CourseAdd findById(Course course);

}
