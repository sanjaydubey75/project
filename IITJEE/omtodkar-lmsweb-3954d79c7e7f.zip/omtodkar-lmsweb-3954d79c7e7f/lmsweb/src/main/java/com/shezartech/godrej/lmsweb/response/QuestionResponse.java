package com.shezartech.godrej.lmsweb.response;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.shezartech.godrej.lmsweb.entity.core.Question;
import com.shezartech.godrej.lmsweb.model.QuestionViewModel;
import com.shezartech.godrej.lmsweb.model.SyncEntityView;

public class QuestionResponse extends BaseResponse
{
	
	@JsonInclude(Include.NON_NULL)
	public List<SyncEntityView> questions;
	
	@JsonInclude(Include.NON_NULL)
	public Set<QuestionViewModel> questionsForTest = new HashSet<QuestionViewModel>();

	public QuestionResponse(String statusMessage) 
	{
		super(false, statusMessage);
	}
	
	public QuestionResponse(List<SyncEntityView> questions)
	{
		super(true, null);
		this.questions = questions;
	}
	
	public QuestionResponse(Set<Question> questions)
	{
		super(true, null);
		
		for (Question question : questions) 
		{
			questionsForTest.add(new QuestionViewModel(question));
		}
	}
}