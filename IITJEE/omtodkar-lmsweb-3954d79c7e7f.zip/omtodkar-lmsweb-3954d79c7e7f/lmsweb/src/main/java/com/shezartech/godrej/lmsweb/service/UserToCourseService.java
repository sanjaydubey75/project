package com.shezartech.godrej.lmsweb.service;

public interface UserToCourseService
{

	void setCourseCompletedIfAllLessonsComplete(int courseId, String login,
			Long timestamp);

}
