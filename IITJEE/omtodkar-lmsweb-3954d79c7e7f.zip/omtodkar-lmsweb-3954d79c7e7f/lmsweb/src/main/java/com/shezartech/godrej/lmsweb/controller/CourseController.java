package com.shezartech.godrej.lmsweb.controller;

import java.security.NoSuchAlgorithmException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.shezartech.godrej.lmsweb.entity.core.Course;
import com.shezartech.godrej.lmsweb.model.CourseSyncListViewModel;
import com.shezartech.godrej.lmsweb.request.LoginForm;
import com.shezartech.godrej.lmsweb.response.AuthenticationFailureResponse;
import com.shezartech.godrej.lmsweb.response.BaseResponse;
import com.shezartech.godrej.lmsweb.response.CourseResponse;
import com.shezartech.godrej.lmsweb.service.AuthenticationService;
import com.shezartech.godrej.lmsweb.service.Sync;

@RestController
@RequestMapping(value = "/api/course")
public class CourseController
{
	
	@Autowired private Sync sync;
	@Autowired private AuthenticationService authenticationService;
	private static final Logger logger = LoggerFactory.getLogger(CourseController.class);
	
	@RequestMapping(value = "/all/{directionId}", method = RequestMethod.GET)
	public BaseResponse getCourses(
			@PathVariable Integer directionId,
			@RequestParam(value = "specialLesson", defaultValue = "false") boolean specialLesson,
			@RequestHeader("X-Auth-Login") String login, 
			@RequestHeader("X-Auth-Password") String password) throws NoSuchAlgorithmException
	{
		
		try
		{
			LoginForm loginForm = new LoginForm(login, password);
			
			if(authenticationService.authenticate(loginForm))
			{
				List<CourseSyncListViewModel> courses = sync.getCourses(loginForm, specialLesson, directionId);
				return new CourseResponse(courses);
			}
			else
			{
				return new AuthenticationFailureResponse("Username or Password does not match");
			}
		}
		catch (Exception e)
		{
			logger.error("error in CourseController.getCourses for user login: " + login, e);
			e.printStackTrace();
			return null;
		}
	}
	
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public BaseResponse getCourse(@PathVariable Integer id,
			@RequestHeader("X-Auth-Login") String login, 
			@RequestHeader("X-Auth-Password") String password) throws NoSuchAlgorithmException
	{
		try
		{
			LoginForm loginForm = new LoginForm(login, password);
			
			if(authenticationService.authenticate(loginForm))
			{
				Course course = sync.getCourse(id);
				return new CourseResponse(course);
			}
			else
			{
				return new AuthenticationFailureResponse("Username or Password does not match");
			}
		}
		catch (Exception e)
		{
			logger.error("error in CourseController.getCourse for user login: " + login, e);
			e.printStackTrace();
			return null;
		}		
	}
}