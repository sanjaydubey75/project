package com.shezartech.godrej.lmsweb.dao;

import org.hibernate.SessionFactory;

import com.shezartech.godrej.lmsweb.entity.core.User;

public interface UserDataDao{
	
	void setSessionFactory(SessionFactory sessionFactory);

	public void deleteAllForUser(User user);
}
