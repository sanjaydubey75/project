package com.shezartech.godrej.lmsweb.service;

import java.util.Set;

import com.shezartech.godrej.lmsweb.entity.core.Course;

public interface CourseService
{
	Set<Course> filterOutCoursesWithSpecialLessons(Set<Course> courses);

	Set<Course> filterInCoursesWithSpecialLessons(Set<Course> courses);

}
