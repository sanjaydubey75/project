package com.shezartech.godrej.lmsweb.entity.addmodels;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.shezartech.godrej.lmsweb.entity.core.IAddDeleteEntity;
import com.shezartech.godrej.lmsweb.entity.core.Lesson;

@Entity
@Table(name="lessons_add")
public class LessonAdd implements IAddDeleteEntity{
	
	@NotNull
	private Integer hash;
	
	@OneToOne
	@Id
	private Lesson lesson;

	@Override
	public int getHash() {
		return hash;
	}

	@Override
	public void setHash() {
		this.hash = lesson.hashCode();
	}

	public Lesson getLesson() {
		return lesson;
	}

	public void setLesson(Lesson lesson) {
		this.lesson = lesson;
	}
}
