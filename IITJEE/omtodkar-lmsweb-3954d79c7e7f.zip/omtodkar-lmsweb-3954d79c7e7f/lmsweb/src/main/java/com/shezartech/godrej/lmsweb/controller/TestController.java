package com.shezartech.godrej.lmsweb.controller;

import java.security.NoSuchAlgorithmException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.shezartech.godrej.lmsweb.entity.core.Test;
import com.shezartech.godrej.lmsweb.model.SyncEntityView;
import com.shezartech.godrej.lmsweb.request.LoginForm;
import com.shezartech.godrej.lmsweb.request.TestSubmitForm;
import com.shezartech.godrej.lmsweb.request.TestSubmitForm1;
import com.shezartech.godrej.lmsweb.response.AuthenticationFailureResponse;
import com.shezartech.godrej.lmsweb.response.BaseResponse;
import com.shezartech.godrej.lmsweb.response.FailureResponse;
import com.shezartech.godrej.lmsweb.response.SuccessResponse;
import com.shezartech.godrej.lmsweb.response.TestResponse;
import com.shezartech.godrej.lmsweb.service.AuthenticationService;
import com.shezartech.godrej.lmsweb.service.Sync;
import com.shezartech.godrej.lmsweb.service.TestService;

@RestController
@RequestMapping(value = "/api/test")
public class TestController {
	
	@Autowired private Sync sync;
	@Autowired private AuthenticationService authenticationService;
	@Autowired private TestService testService;
	private static final Logger logger = LoggerFactory.getLogger(TestController.class);
	
	@RequestMapping(value = "/all", method = RequestMethod.GET)
	public BaseResponse getTests(
			@RequestHeader("X-Auth-Login") String login, 
			@RequestHeader("X-Auth-Password") String password) throws NoSuchAlgorithmException
	{
		try {
			LoginForm loginForm = new LoginForm(login, password);
			
			if(authenticationService.authenticate(loginForm)){
				List<SyncEntityView> tests = sync.getTests(loginForm);
				
				return new TestResponse(tests);
			}
			else{
				return new AuthenticationFailureResponse("Username or Password does not match");	
			}
		} catch (Exception e) {
			logger.error("error", e);
			e.printStackTrace();
			return null;
		}
	}
	
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public BaseResponse getCourse(@PathVariable Integer id,
			@RequestHeader("X-Auth-Login") String login, 
			@RequestHeader("X-Auth-Password") String password) throws NoSuchAlgorithmException
	{
		try {
			LoginForm loginForm = new LoginForm(login, password);
			
			if(authenticationService.authenticate(loginForm)){
				Test test =  sync.getTest(id);
				return new TestResponse(test);
			}
			else {
				return new AuthenticationFailureResponse("Username or Password does not match");
			}
		} catch (Exception e) {
			logger.error("error", e);
			e.printStackTrace();
			return null;
		}
	}
	
	@RequestMapping(value = "/{id}", method = RequestMethod.POST)
	public BaseResponse setTestResponse(
//			@RequestBody Map<Object, Object> params,
			@RequestBody TestSubmitForm testSubmitForm,
			@PathVariable Integer id,
			@RequestHeader("X-Auth-Login") String login,
			@RequestHeader("X-Auth-Password") String password)
	{
		try
		{
			LoginForm loginForm = new LoginForm(login, password);
			
//			Map<Integer, Map<Integer, String>> userAnswers = (Map<Integer, Map<Integer, String>>) params.get("userAnswers");
//			Map<String, Object> time = (Map<String, Object>) params.get("time");
			
			logger.info("the data received is " + testSubmitForm.toString());
			
			if(authenticationService.authenticate(loginForm))
			{
				TestSubmitForm1 testSubmitForm1 = new TestSubmitForm1(testSubmitForm);
				
				testService.setTestData(login, id, testSubmitForm1.userAnswers, testSubmitForm1.time);
				return new SuccessResponse();
			}
			else
				return new AuthenticationFailureResponse("Username or Password does not match");
		}
		catch (Exception e)
		{
			logger.error("error in TestController.setTestResponse for user login: " + login, e);
			e.printStackTrace();
			return new FailureResponse();
		}
	}
}