package com.shezartech.godrej.lmsweb.response;

public class SuccessResponse extends BaseResponse
{
	public SuccessResponse()
	{
		super(true, null);
	}
}