package com.shezartech.godrej.lmsweb.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.shezartech.godrej.lmsweb.entity.core.Course;
import com.shezartech.godrej.lmsweb.entity.core.User;
import com.shezartech.godrej.lmsweb.entity.core.UserToCourse;

@Repository
public class UserToCourseDaoImpl extends SyncEntityDaoImpl<UserToCourse, Long>
		implements UserToCourseDao, UserDataDao {

	public UserToCourseDaoImpl() {
		super(UserToCourse.class);
	}

	@Override
	@Autowired
	@Qualifier("newSessionFactory")
	public void setSessionFactory(SessionFactory sessionFactory) {
		super.setSessionFactory(sessionFactory);
	}
	
	@Override
	public List<UserToCourse> findAll(String userLogin)
	{
		
		Criteria criteria = getCurrentSession().createCriteria(UserToCourse.class);
		return criteria.add(Restrictions.eq("userLogin", userLogin)).list();
	}
	
	@Override
	public UserToCourse find(Course course, User userLogin)
	{
		Criteria criteria = getCurrentSession().createCriteria(UserToCourse.class);
		criteria.add(Restrictions.eq("userLogin", userLogin));
		criteria.add(Restrictions.eq("courseId", course));
		return (UserToCourse) criteria.uniqueResult();
	}

	@Override
	public void deleteAllForUser(User user) {
		
		String hql = String.format("delete from %1$s where userLogin = :userLogin", this.entityClass.getName());
		Query query = getCurrentSession().createQuery(hql);
		query.setParameter("userLogin", user.getLogin());
		query.executeUpdate();
	}
}