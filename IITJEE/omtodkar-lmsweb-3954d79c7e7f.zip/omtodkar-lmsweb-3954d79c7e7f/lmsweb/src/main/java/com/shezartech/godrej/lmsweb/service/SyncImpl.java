package com.shezartech.godrej.lmsweb.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.shezartech.godrej.lmsweb.dao.CourseDao;
import com.shezartech.godrej.lmsweb.dao.CourseDaoImpl;
import com.shezartech.godrej.lmsweb.dao.QuestionDao;
import com.shezartech.godrej.lmsweb.dao.QuestionDaoImpl;
import com.shezartech.godrej.lmsweb.dao.TestDao;
import com.shezartech.godrej.lmsweb.dao.TestDaoImpl;
import com.shezartech.godrej.lmsweb.dao.addmodels.CourseAddDao;
import com.shezartech.godrej.lmsweb.dao.addmodels.CourseAddDaoImpl;
import com.shezartech.godrej.lmsweb.dao.addmodels.QuestionAddDao;
import com.shezartech.godrej.lmsweb.dao.addmodels.QuestionAddDaoImpl;
import com.shezartech.godrej.lmsweb.dao.addmodels.TestAddDao;
import com.shezartech.godrej.lmsweb.dao.addmodels.TestAddDaoImpl;
import com.shezartech.godrej.lmsweb.entity.addmodels.CourseAdd;
import com.shezartech.godrej.lmsweb.entity.addmodels.QuestionAdd;
import com.shezartech.godrej.lmsweb.entity.addmodels.TestAdd;
import com.shezartech.godrej.lmsweb.entity.core.Course;
import com.shezartech.godrej.lmsweb.entity.core.Lesson;
import com.shezartech.godrej.lmsweb.entity.core.Question;
import com.shezartech.godrej.lmsweb.entity.core.Test;
import com.shezartech.godrej.lmsweb.entity.core.User;
import com.shezartech.godrej.lmsweb.model.CourseSyncListViewModel;
import com.shezartech.godrej.lmsweb.model.ModuleView;
import com.shezartech.godrej.lmsweb.model.SyncEntityView;
import com.shezartech.godrej.lmsweb.request.LoginForm;

@Service
public class SyncImpl implements Sync
{
	
	@Autowired private AuthenticationService authenticationService;
	@Autowired private ModuleService moduleService;

	@Qualifier(value="oldSessionFactory")
	@Autowired private SessionFactory oldSessionFactory;
	
	@Qualifier(value="newSessionFactory")
	@Autowired private SessionFactory newSessionFactory;
	
	@Autowired
	private CourseService courseService;
	
	@Override
	@Transactional(value="txManagerNew")
	public List<CourseSyncListViewModel> getCourses(LoginForm form, boolean specialLesson, int directionId) // user is from newSession Factory
	{
		
		User user = authenticationService.getUser(form);
		
		Set<Course> tempCourses = specialLesson ? courseService.filterInCoursesWithSpecialLessons(user.getCourses())
				: courseService.filterOutCoursesWithSpecialLessons(user.getCourses());
		
		Set<Course> courses = new HashSet<Course>();
		for(Course course : tempCourses)
		{
			if (course.getDirectionsId() != null)
				if (course.getDirectionsId() == directionId)
					courses.add(course);
		}
		
		CourseAddDao courseAddDao = new CourseAddDaoImpl();
		courseAddDao.setSessionFactory(oldSessionFactory);
		
		List<CourseSyncListViewModel> courses1 = new ArrayList<CourseSyncListViewModel>();
		for (Course course : courses)
		{
			CourseAdd courseAdd = courseAddDao.findById(course);
			if(courseAdd != null)
			{
				int hash = courseAdd.getHash();
				courses1.add(new CourseSyncListViewModel(course.getId(), course.getName(), hash, course.getDirectionsId()));		
			}
		}
		
		return courses1;
	}
	
	@Override
	@Transactional(value="txManagerNew")
	public List<SyncEntityView> getTests(LoginForm form)// user is from newSession Factory
	{
		
		User user = authenticationService.getUser(form);
		
		Set<Course> courses = user.getCourses();
		
		List<SyncEntityView> tests1 = new ArrayList<SyncEntityView>();
		
		Set<Lesson> lessons = new HashSet<Lesson>();
		for (Course course : courses)
		{
			lessons.addAll(course.getActiveLessons());
		}
		
		Set<Test> tests = new HashSet<Test>();
		for (Lesson lesson : lessons)
		{
			tests.addAll(lesson.getTests());
		}
		
		TestAddDao testAddDao = new TestAddDaoImpl();
		testAddDao.setSessionFactory(oldSessionFactory);
		
//		Session session = oldSessionFactory.getCurrentSession();
//		session.beginTransaction();
		
		for (Test test : tests)
		{
//			TestAdd testAdd = testAddDao.findById(test.getId());
//			if(testAdd != null)
//			{
//				int hash = testAdd.getHash();
//				tests1.add(new SyncEntityView(test.getId(), test.getName(), hash));
//				
//			}
			TestAdd testAdd = testAddDao.findByNameAssessment(test.getName());
			int hash = testAdd.getHash();
			tests1.add(new SyncEntityView(test.getId(), test.getName(), hash));
		}
//		session.getTransaction().commit();
		return tests1;
	}
	
	@Override
	@Transactional(value="txManagerNew")
	public List<SyncEntityView> getQuestions(LoginForm form) // user is from newSession Factory
	{
		
		User user = authenticationService.getUser(form);
		
		Set<Course> courses = user.getCourses();
		
		List<SyncEntityView> questions1 = new ArrayList<SyncEntityView>();
		
		Set<Lesson> lessons = new HashSet<Lesson>();
		for (Course course : courses)
		{
			lessons.addAll(course.getActiveLessons());
		}
		
		Set<Test> tests = new HashSet<Test>();
		for (Lesson lesson : lessons)
		{
			tests.addAll(lesson.getTests());
		}
		
		Set<Question> questions = new HashSet<Question>();
		for (Test test : tests)
		{
			questions.addAll(test.getQuestions());
		}
		
		QuestionAddDao questionAddDao = new QuestionAddDaoImpl();
		questionAddDao.setSessionFactory(oldSessionFactory);

		for (Question question : questions)
		{
			QuestionAdd questionAdd = questionAddDao.findById(question.getId());
			if(questionAdd != null)
			{
				int hash = questionAdd.getHash();
				questions1.add(new SyncEntityView(question.getId(), null, hash));				
			}
		}
		
		return questions1;
	}
	
	@Override
	@Transactional(value="txManagerNew")
	public List<ModuleView> getLessons(LoginForm form)// user is from newSession Factory
	{
		User user = authenticationService.getUser(form);
		
		Set<Course> courses = user.getCourses();
		
		List<ModuleView> lessons1 = new ArrayList<ModuleView>();
		
		Set<Lesson> lessons = new HashSet<Lesson>();
		for (Course course : courses)
		{
			lessons.addAll(course.getActiveLessons());
		}

		for (Lesson lesson : lessons)
		{
			if(!(Pattern.compile(Pattern.quote("Post-Test"), Pattern.CASE_INSENSITIVE).matcher(lesson.getName()).find()
					||Pattern.compile(Pattern.quote("Pre-Test"), Pattern.CASE_INSENSITIVE).matcher(lesson.getName()).find()))
			{
				lessons1.add(new ModuleView(lesson.getId(), lesson.getName(), moduleService.isModuleExist(lesson.getId())));
			}
		}
		
		return lessons1;
	}
	
	@Override
	@Transactional(value="txManagerNew")
	public Set<Question> getQuestions(int id, LoginForm form)// user is from newSession Factory
	{
		
		TestDao testDao = new TestDaoImpl();
		testDao.setSessionFactory(newSessionFactory);
		
		Test test = testDao.find(id);
		
		Set<Question> questions = new HashSet<Question>();
		questions.addAll(test.getQuestions());
		
		return questions;
	}
	
	@Override
	@Transactional(value="txManagerNew")
	public Course getCourse(int id)
	{
		CourseDao courseDao = new CourseDaoImpl();
		courseDao.setSessionFactory(newSessionFactory);
		Course course = courseDao.find(id);
		return course;
	}
	
	@Override
	@Transactional(value="txManagerNew")
	public Test getTest(int id)
	{
		TestDao testDao = new TestDaoImpl();
		testDao.setSessionFactory(newSessionFactory);
		Test test = testDao.find(id);
		return test;
	}
	
	@Override
	@Transactional(value="txManagerNew")
	public Question getQuestion(int id)
	{
		QuestionDao questionDao = new QuestionDaoImpl();
		questionDao.setSessionFactory(newSessionFactory);	
		Question question = questionDao.find(id);
		return question;
	}
}