package com.shezartech.godrej.lmsweb.response;


public class AuthenticationFailureResponse extends BaseResponse{

	public AuthenticationFailureResponse(String statusMessage) {
		super(false, statusMessage);
	}
}