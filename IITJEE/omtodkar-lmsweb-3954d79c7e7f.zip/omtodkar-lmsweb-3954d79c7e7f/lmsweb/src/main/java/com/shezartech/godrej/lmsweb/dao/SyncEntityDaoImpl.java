package com.shezartech.godrej.lmsweb.dao;

import java.io.Serializable;

import com.shezartech.godrej.lmsweb.entity.core.SyncEntity;

public class SyncEntityDaoImpl<T extends SyncEntity, I extends Serializable> extends BaseDaoImpl<T, I> implements SyncEntityDao<T, I>{

	public SyncEntityDaoImpl(Class<T> entityClass) {
		super(entityClass);
		
	}
}