package com.shezartech.godrej.lmsweb.service;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.shezartech.godrej.lmsweb.dao.UserDao;
import com.shezartech.godrej.lmsweb.dao.UserDaoImpl;
import com.shezartech.godrej.lmsweb.entity.core.User;
import com.shezartech.godrej.lmsweb.request.LoginForm;

@Service
public class AuthenticationServiceImpl implements AuthenticationService{

	@Qualifier(value="newSessionFactory")
	@Autowired private SessionFactory newSessionFactory;
	
	private final String G_MD5KEY = "cDWQR#$Rcxsc";
	
	@Override
	@Transactional(value="txManagerNew")
	public boolean authenticate(LoginForm loginForm) throws NoSuchAlgorithmException{
		UserDao dao = new UserDaoImpl();
		dao.setSessionFactory(newSessionFactory);
		
		User user = dao.findByLogin(loginForm.username);
		if (user != null) {
			if (this.hashMD5(loginForm.password + G_MD5KEY).equals(user.getPassword()))
				return true;
		}
		return false;
	}
	
	private String hashMD5(String input) throws NoSuchAlgorithmException{
		String result = input;
		if (input != null) {
			MessageDigest md = MessageDigest.getInstance("MD5"); // or "SHA-1"
			md.update(input.getBytes());
			BigInteger hash = new BigInteger(1, md.digest());
			result = hash.toString(16);
			while (result.length() < 32) { // 40 for SHA-1
				result = "0" + result;
			}
		}
		return result;
	}
	
	@Override
	@Transactional(value="txManagerNew")
	public User getUser(LoginForm loginForm){
		
		UserDao dao = new UserDaoImpl();
		dao.setSessionFactory(newSessionFactory);
		
		User user = dao.findByLogin(loginForm.username);
		return user;
	}
}
