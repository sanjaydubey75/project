package com.shezartech.godrej.lmsweb.model;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

public class LessonSyncViewModel
{
	public class TestViewModel
	{
		public int unitId;
		
		public String name;
		
		public boolean isComplete;
		
		@JsonInclude(Include.NON_NULL)
		public Integer score; // only for test
		
		@JsonInclude(Include.NON_NULL)
		public Boolean exists; // only for module
		
		public String type;

		public TestViewModel(int id, boolean isComplete, String name, Integer score)
		{
			super();
			this.unitId = id; //right now this id is test id, later i think it should be changed to content id
			              //after maintaining syncing of content table.
			this.isComplete = isComplete;
			this.name = name;
			this.score = score;
			this.type = "test";
		}
		
		public TestViewModel(int id, boolean isComplete, boolean exists)
		{
			super();
			this.unitId = id;
			this.isComplete = isComplete;
			this.exists = exists;
			this.type = "module";
		}
	}
	
//	public class ScormViewModel
//	{
//		public int id;
//		
//		public boolean isComplete;
//		
//		public boolean exists;
//		
//		public ScormViewModel(int id, boolean isComplete, boolean exists)
//		{
//			super();
//			this.id = id; //this is content id
//			this.isComplete = isComplete;
//			this.exists = exists;
//		}
//	}
	
	public int lessonId;
	
	public String name;
	
	@JsonInclude(Include.NON_EMPTY)
	public List<TestViewModel> tests;
	
//	@JsonInclude(Include.NON_EMPTY)
//	public List<ScormViewModel> scormViewModels;
	
	public LessonSyncViewModel()
	{
		this.tests = new ArrayList<LessonSyncViewModel.TestViewModel>();
//		this.scormViewModels = new ArrayList<ScormViewModel>();
	}
}
