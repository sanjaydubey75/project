package com.shezartech.godrej.lmsweb.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.shezartech.godrej.lmsweb.entity.core.Direction;
import com.shezartech.godrej.lmsweb.request.LoginForm;
import com.shezartech.godrej.lmsweb.response.AuthenticationFailureResponse;
import com.shezartech.godrej.lmsweb.response.BaseResponse;
import com.shezartech.godrej.lmsweb.response.DirectionResponse;
import com.shezartech.godrej.lmsweb.service.AuthenticationService;
import com.shezartech.godrej.lmsweb.service.DirectionService;

@RestController
@RequestMapping(value = "/api/direction")
public class DirectionController
{

	@Autowired
	private AuthenticationService authenticationService;

	@Autowired
	private DirectionService directionService;
	
	private static final Logger logger = LoggerFactory.getLogger(DirectionController.class);

	@RequestMapping(value = "/all", method = RequestMethod.GET)
	public BaseResponse getDirections(
			@RequestHeader("X-Auth-Login") String login,
			@RequestHeader("X-Auth-Password") String password)
	{
		try
		{
			LoginForm loginForm = new LoginForm(login, password);

			if (authenticationService.authenticate(loginForm))
			{
				List<Direction> directions = directionService.getDirections();
				return new DirectionResponse(directions);
			}
			else
			{
				return new AuthenticationFailureResponse("Username or Password does not match");
			}
		}
		catch (Exception e)
		{
			logger.error("error in DirectionController.getDirections for user login: " + login, e);
			e.printStackTrace();
			return null;
		}
	}
}
