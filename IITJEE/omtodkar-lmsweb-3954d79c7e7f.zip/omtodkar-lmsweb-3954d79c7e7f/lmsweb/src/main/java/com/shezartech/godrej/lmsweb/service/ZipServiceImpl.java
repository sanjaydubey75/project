package com.shezartech.godrej.lmsweb.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ZipServiceImpl implements ZipService {
	
	List<String> fileList;
	private final String sourceFolder;
	private static final Logger logger = LoggerFactory.getLogger(ZipServiceImpl.class);
	
	public ZipServiceImpl(String sourceFolder) {
		
		fileList = new ArrayList<String>();
		this.sourceFolder = sourceFolder;
	}

	@Override
	public void zipIt(String zipFile) {

		byte[] buffer = new byte[1024];

		try {

			FileOutputStream fos = new FileOutputStream(zipFile);
			ZipOutputStream zos = new ZipOutputStream(fos);

			logger.info("Output to Zip : " + zipFile);

			for (String file : this.fileList) {

				logger.info("File Added : " + file);
				ZipEntry ze = new ZipEntry(file);
				zos.putNextEntry(ze);

				FileInputStream in = new FileInputStream(this.sourceFolder + "/" + file);

				int len;
				while ((len = in.read(buffer)) > 0) {
					zos.write(buffer, 0, len);
				}

				in.close();
			}

			zos.closeEntry();
			// remember close it
			zos.close();

			logger.info("File" + " " + zipFile + " is zipped.");
		} catch (IOException ex) {
			logger.error("error creating zip file at {} with source directory at {}.", zipFile, this.sourceFolder, ex);
			ex.printStackTrace();
		}
	}

	@Override
	public void generateFileList(File node) {

		// add file only
		if (node.isFile()) {
			fileList.add(generateZipEntry(node.getAbsoluteFile().toString()));
		}

		if (node.isDirectory()) {
			String[] subNote = node.list();
			for (String filename : subNote) {
				generateFileList(new File(node, filename));
			}
//			if(subNote.length == 0){
//				fileList.add(node.getAbsolutePath().toString());
//			}
		}
	}

	@Override
	public String generateZipEntry(String file) {
		return file.substring(this.sourceFolder.length() + 1, file.length());
	}
}