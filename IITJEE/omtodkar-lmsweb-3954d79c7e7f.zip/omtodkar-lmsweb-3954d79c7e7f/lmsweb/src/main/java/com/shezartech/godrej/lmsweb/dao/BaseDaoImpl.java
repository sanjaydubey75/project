package com.shezartech.godrej.lmsweb.dao;

import java.io.Serializable;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.shezartech.godrej.lmsweb.entity.core.BaseEntity;

public class BaseDaoImpl<T extends BaseEntity, I extends Serializable> implements
		BaseDao<T, I> {

	private SessionFactory sessionFactory;

	protected Class<T> entityClass;

	public BaseDaoImpl(Class<T> entityClass) {
		this.entityClass = entityClass;
	}

	@Override
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	protected final Session getCurrentSession() {
		return sessionFactory.getCurrentSession();
	}

	@Override
	public List<T> findAll() {
		Session session = getCurrentSession();
		List<T> entities = session.createQuery(
				"from " + this.entityClass.getName()).list();
		return entities;
	}

	@Override
	public T find(I id) {
		Session session = getCurrentSession();
		T entity = (T) session.get(this.entityClass, id);
		return entity;
	}

	@Override
	public I save(T entity) {
		Session session = getCurrentSession();
//		T attachedEntity = (T) session.merge(entity);
		I id = (I) session.save(entity);
		return id;
	}

	@Override
	public void persist(T entity) {
		Session session = getCurrentSession();
		session.persist(entity);
	}

	@Override
	public void delete(I id) {
		T entity = find(id);
		delete(entity);
	}

	@Override
	public void delete(T entity) {
		Session session = getCurrentSession();
		session.delete(entity);
	}
}