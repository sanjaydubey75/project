package com.shezartech.godrej.lmsweb.service;

import java.util.List;
import java.util.Set;

import com.shezartech.godrej.lmsweb.entity.core.Course;
import com.shezartech.godrej.lmsweb.entity.core.Question;
import com.shezartech.godrej.lmsweb.entity.core.Test;
import com.shezartech.godrej.lmsweb.model.CourseSyncListViewModel;
import com.shezartech.godrej.lmsweb.model.ModuleView;
import com.shezartech.godrej.lmsweb.model.SyncEntityView;
import com.shezartech.godrej.lmsweb.request.LoginForm;

public interface Sync
{

	List<CourseSyncListViewModel> getCourses(LoginForm form, boolean specialLesson, int directionId);
	
	Course getCourse(int id);

	List<SyncEntityView> getTests(LoginForm form);
	
	Test getTest(int id);
	
	List<SyncEntityView> getQuestions(LoginForm form);

	Question getQuestion(int id);

	/*
	 * Get all questions of a particular test
	 */
	Set<Question> getQuestions(int id, LoginForm form);

	List<ModuleView> getLessons(LoginForm form);

}
