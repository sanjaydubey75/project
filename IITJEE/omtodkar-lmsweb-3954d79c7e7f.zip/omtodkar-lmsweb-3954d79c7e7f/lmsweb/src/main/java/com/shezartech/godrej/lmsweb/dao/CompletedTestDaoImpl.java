package com.shezartech.godrej.lmsweb.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.shezartech.godrej.lmsweb.entity.core.CompletedTest;

@Repository
public class CompletedTestDaoImpl extends BaseDaoImpl<CompletedTest, Integer> implements CompletedTestDao{

	public CompletedTestDaoImpl() {
		super(CompletedTest.class);
	}
	
	@Override
	@Autowired
	@Qualifier("newSessionFactory")
	public void setSessionFactory(SessionFactory sessionFactory) {
		super.setSessionFactory(sessionFactory);
	}
}