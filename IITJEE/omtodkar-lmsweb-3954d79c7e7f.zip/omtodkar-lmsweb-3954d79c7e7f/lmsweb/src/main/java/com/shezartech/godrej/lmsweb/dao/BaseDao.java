package com.shezartech.godrej.lmsweb.dao;

import java.io.Serializable;
import java.util.List;

import org.hibernate.SessionFactory;

import com.shezartech.godrej.lmsweb.entity.core.BaseEntity;

public interface BaseDao<T extends BaseEntity, I extends Serializable> {

	List<T> findAll();

	T find(I id);

	I save(T entity);

	void delete(I id);

	void delete(T entity);

	void setSessionFactory(SessionFactory sessionFactory);

	void persist(T entity);

}
