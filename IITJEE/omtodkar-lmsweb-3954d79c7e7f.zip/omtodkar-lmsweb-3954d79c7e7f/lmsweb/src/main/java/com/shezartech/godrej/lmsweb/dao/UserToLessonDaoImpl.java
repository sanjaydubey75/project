package com.shezartech.godrej.lmsweb.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.shezartech.godrej.lmsweb.entity.core.Lesson;
import com.shezartech.godrej.lmsweb.entity.core.LessonToCourse;
import com.shezartech.godrej.lmsweb.entity.core.User;
import com.shezartech.godrej.lmsweb.entity.core.UserToLesson;

@Repository
public class UserToLessonDaoImpl extends BaseDaoImpl<UserToLesson, Integer> implements UserToLessonDao
{

	public UserToLessonDaoImpl()
	{
		super(UserToLesson.class);
	}

	@Override
	@Autowired
	@Qualifier("newSessionFactory")
	public void setSessionFactory(SessionFactory sessionFactory)
	{
		super.setSessionFactory(sessionFactory);
	}
	
	@Override
	public UserToLesson find(User user, Lesson lesson)
	{
		Criteria criteria = getCurrentSession().createCriteria(entityClass);
		criteria.add(Restrictions.eq("user", user));
		criteria.add(Restrictions.eq("lesson", lesson));
		return (UserToLesson) criteria.uniqueResult();
	}
	
	@Override
	public List<UserToLesson> findAllLessonsByUser(User user){
		Criteria criteria = getCurrentSession().createCriteria(entityClass);
		criteria.add(Restrictions.eq("user", user));
		return criteria.list();
	}
}
