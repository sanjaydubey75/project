package com.shezartech.godrej.lmsweb.response;

public class FailureResponse extends BaseResponse
{
	public FailureResponse()
	{
		super(false, "An error occured at the server");
	}
	
	public FailureResponse(String error)
	{
		super(false, error);
	}
}
