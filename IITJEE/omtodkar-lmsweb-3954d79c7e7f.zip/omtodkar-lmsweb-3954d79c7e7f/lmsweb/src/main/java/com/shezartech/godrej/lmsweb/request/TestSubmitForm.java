package com.shezartech.godrej.lmsweb.request;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;

public class TestSubmitForm
{
	private static final Logger logger = LoggerFactory.getLogger(TestSubmitForm.class);
	
	public static class UserAnswer
	{
		public static class AnswerObject
		{
			public int index;
			public String selected;
		}
		
		public int questionId;
		
		public UserAnswer()
		{
			
		}
		
		public List<AnswerObject> answerObjects;
	}
	
//	public Map<Integer, Map<Integer, String>> userAnswers;
	
	public List<UserAnswer> userAnswers;
	
	public Map<String, Object> time;
	
	public TestSubmitForm()
	{
		
	}
	
	@Override
	public String toString()
	{
		ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
		try
		{
			String json = ow.writeValueAsString(this);
			return json;
		}
		catch (JsonProcessingException e)
		{
			logger.error("error in serializzing data", e);
		}
		return null;
	}
}
