package com.shezartech.godrej.lmsweb.entity.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="completed_tests_blob")
public class CompletedTestBlob implements BaseEntity
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer id;
	
	@Column(name = "completed_tests_ID", columnDefinition="mediumint(8) unsigned NOT NULL")
	private Integer completedTestId;
	
	@Column(columnDefinition = "longblob")
	private java.sql.Blob test;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getCompletedTestId() {
		return completedTestId;
	}

	public void setCompletedTestId(Integer completedTestId) {
		this.completedTestId = completedTestId;
	}

	public java.sql.Blob getTest() {
		return test;
	}

	public void setTest(java.sql.Blob test) {
		this.test = test;
	}
	
	public CompletedTestBlob(){
		super();
	}
}