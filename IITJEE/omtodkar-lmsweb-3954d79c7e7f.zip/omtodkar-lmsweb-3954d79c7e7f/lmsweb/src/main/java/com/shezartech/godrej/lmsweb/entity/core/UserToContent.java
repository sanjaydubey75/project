package com.shezartech.godrej.lmsweb.entity.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.Range;

@Entity
@Table(name = "users_to_content", uniqueConstraints = 
@UniqueConstraint(columnNames = {"users_LOGIN", "content_ID", "lessons_ID"}))
public class UserToContent implements BaseEntity
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer id;
	
	@Length(max = 100)
	@Column(name = "users_LOGIN")
	@NotNull
	private String userLogin;
	
	@NotNull
	@Range(min = 0, max = 16777215)
	@Column(name = "content_ID")
	private Integer contentId;
	
	@NotNull
	@Range(min = 0, max = 16777215)
	@Column(name = "lessons_ID")
	private Integer lessonId;
	
	@Column(name = "success_status")
	@Length(max = 15)
	private String successStatus = "unknown";
	
	@Range(min = 0, max = 4294967295L)
	private Long timestamp;
	
	private Float score = 0.0f;
	
	@Length(max = 15)
	private String entry = "";
	
	@Column(name = "total_time")
	@Range(min = 0, max = 4294967295L)
	@NotNull
	private Long totalTime;
	
	@Column(columnDefinition = "longtext", name = "suspend_data")
	private String suspendData;
	
	@Range(min = -128, max = 128)
	@NotNull
	private Integer archive = 0;
	
	@Range(min = 0, max = 4294967295L)
	@Column(name = "time_start")
	private Long timeStart;
	
	@Range(min = 0, max = 4294967295L)
	@Column(name = "time_end")
	private Long timeEnd;
	
	@NotNull
	@Range(min = -128, max = 128)
	private Integer pending = 0;
	
	private Integer visits;
	
	@Column(name = "attempt_identifier", columnDefinition = "char(32) DEFAULT NULL")
	private String attemptIdentifier;

	public int getId()
	{
		return id;
	}

	public void setId(int id)
	{
		this.id = id;
	}

	public String getUserLogin()
	{
		return userLogin;
	}

	public void setUserLogin(String userLogin)
	{
		this.userLogin = userLogin;
	}

	public int getContentId()
	{
		return contentId;
	}

	public void setContentId(int contentId)
	{
		this.contentId = contentId;
	}

	public int getLessonId()
	{
		return lessonId;
	}

	public void setLessonId(int lessonId)
	{
		this.lessonId = lessonId;
	}

	public String getSuccessStatus()
	{
		return successStatus;
	}

	public void setSuccessStatus(String successStatus)
	{
		this.successStatus = successStatus;
	}

	public Long getTimestamp()
	{
		return timestamp;
	}

	public void setTimestamp(Long timestamp)
	{
		this.timestamp = timestamp;
	}

	public Float getScore()
	{
		return score;
	}

	public void setScore(Float score)
	{
		this.score = score;
	}

	public String getEntry()
	{
		return entry;
	}

	public void setEntry(String entry)
	{
		this.entry = entry;
	}

	public long getTotalTime()
	{
		return totalTime;
	}

	public void setTotalTime(long totalTime)
	{
		this.totalTime = totalTime;
	}

	public String getSuspendData()
	{
		return suspendData;
	}

	public void setSuspendData(String suspendData)
	{
		this.suspendData = suspendData;
	}

	public int getArchive()
	{
		return archive;
	}

	public void setArchive(int archive)
	{
		this.archive = archive;
	}

	public Long getTimeStart()
	{
		return timeStart;
	}

	public void setTimeStart(Long timeStart)
	{
		this.timeStart = timeStart;
	}

	public Long getTimeEnd()
	{
		return timeEnd;
	}

	public void setTimeEnd(Long timeEnd)
	{
		this.timeEnd = timeEnd;
	}

	public int getPending()
	{
		return pending;
	}

	public void setPending(int pending)
	{
		this.pending = pending;
	}

	public Integer getVisits()
	{
		return visits;
	}

	public void setVisits(Integer visits)
	{
		this.visits = visits;
	}

	public String getAttemptIdentifier()
	{
		return attemptIdentifier;
	}

	public void setAttemptIdentifier(String attemptIdentifier)
	{
		this.attemptIdentifier = attemptIdentifier;
	}
}
