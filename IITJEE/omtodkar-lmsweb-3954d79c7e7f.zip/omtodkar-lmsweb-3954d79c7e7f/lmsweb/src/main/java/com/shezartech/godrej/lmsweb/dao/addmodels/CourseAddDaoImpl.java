package com.shezartech.godrej.lmsweb.dao.addmodels;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.shezartech.godrej.lmsweb.dao.BaseDaoImpl;
import com.shezartech.godrej.lmsweb.entity.addmodels.CourseAdd;
import com.shezartech.godrej.lmsweb.entity.core.Course;
import com.shezartech.godrej.lmsweb.entity.core.IAddDeleteEntity;
import com.shezartech.godrej.lmsweb.entity.core.SyncEntity;

@Repository
public class CourseAddDaoImpl extends BaseDaoImpl<CourseAdd, Long> implements CourseAddDao{

	public CourseAddDaoImpl() {
		super(CourseAdd.class);
	}
	
	@Override
	@Autowired
	@Qualifier("oldSessionFactory")
	public void setSessionFactory(SessionFactory sessionFactory) {
		super.setSessionFactory(sessionFactory);
	}

	@Override
	public IAddDeleteEntity find(SyncEntity entity) {
		
		Criteria criteria = getCurrentSession().createCriteria(CourseAdd.class);
		criteria.add(Restrictions.eq("course", entity));
		return (IAddDeleteEntity) criteria.uniqueResult();
	}
	
	@Override
	public CourseAdd findById(Course course){
		Criteria criteria = getCurrentSession().createCriteria(CourseAdd.class);
		criteria.add(Restrictions.eq("course.id", course.getId()));
		return (CourseAdd) criteria.uniqueResult();
	}

	@Override
	public IAddDeleteEntity persist(SyncEntity course) {
		
		CourseAdd courseAdd = new CourseAdd();
		courseAdd.setCourse((Course) course);
		courseAdd.setHash();
		this.persist(courseAdd);
		return courseAdd;
	}

	@Override
	public void delete(IAddDeleteEntity entity) {
		super.delete((CourseAdd)entity);
	}
}