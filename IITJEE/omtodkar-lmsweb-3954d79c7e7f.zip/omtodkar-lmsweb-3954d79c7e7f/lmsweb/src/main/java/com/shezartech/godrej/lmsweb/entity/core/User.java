package com.shezartech.godrej.lmsweb.entity.core;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

/**
 * Entity bean with JPA annotations
 * Hibernate provides JPA implementation
 *
 */

@Entity
@Table(name="users")
public class User extends SyncEntity implements UserDetails{
	
	@Id
	@NotNull
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(columnDefinition = "mediumint(8) unsigned NOT NULL AUTO_INCREMENT")
	private Integer id;
	
	@NotNull
	@Size(max=100)
	@Column(length = 100, nullable = false)
	private String login;
	
	@NotNull
	@Size(max = 32)
	@Column(length = 32, nullable = false, columnDefinition = "char(32) NOT NULL")
	private String password;
	
	@NotNull
	@Size(max = 150)
	@Column(length = 150, nullable = false)
	@Email
	private String email;
	
	@NotNull
	@Size(max = 100)
	@Column(length = 100, nullable = false)
	private String name;
	
	@NotNull
	@Size(max = 100)
	@Column(length = 100, nullable = false)
	private String surname;
	
	@NotNull
	@Column(columnDefinition = "tinyint(1) NOT NULL DEFAULT '1'")
	private boolean active;
	
	@Column(columnDefinition = "text")
	private String comments;
	
	@NotNull
	@Length(max = 50)
	@Column(columnDefinition = "varchar(50) NOT NULL", name = "languages_NAME")
	private String languagesName;
	
	@Length(max = 50)
	@Column(columnDefinition = "varchar(100) DEFAULT ''")
	private String timezone;
	
	@NotNull
	@Length(max = 50)
	@Column(columnDefinition = "varchar(50) NOT NULL DEFAULT 'student'", name = "user_type")
	private String userType;
	
	@NotNull
	@Column(columnDefinition = "int(10) unsigned NOT NULL")
	private Integer timestamp;
	
	@Length(max = 255)
	@Column(columnDefinition = "varchar(255) DEFAULT NULL")
	private String avatar;
	
	@NotNull
	@Column(columnDefinition = "tinyint(1) NOT NULL DEFAULT '0'")
	private boolean pending;
	
	@Column(columnDefinition = "mediumint(8) DEFAULT '0'", name = "user_types_ID")
	private Integer userTypeId;
	
	@Column(columnDefinition = "text", name = "additional_accounts")
	private String additionalAccounts;
	
	@Column(columnDefinition = "tinyint(1) DEFAULT '0'", name = "viewed_license")
	private Boolean viewedLicence;
	
	@Length(max = 255)
	@Column(columnDefinition = "varchar(255) DEFAULT ''")
	private String status;
	
	@Column(columnDefinition = "text", name = "short_description")
	private String shortDescription;
	
	@Column(columnDefinition = "float DEFAULT '0'")
	private Float balance;
	
	@Column(columnDefinition = "int(10) unsigned DEFAULT '0'")
	private Integer archive;
	
	@Column(columnDefinition = "text", name = "dashboard_positions")
	private String dashboardPositions;
	
	@Column(columnDefinition = "tinyint(1) DEFAULT '0'", name = "need_mod_init")
	private Boolean needModInit;
	
	@Column(columnDefinition = "char(32) DEFAULT NULL")
	private String autologin;
	
	@Column(columnDefinition = "tinyint(1) DEFAULT '0'", name = "need_pwd_change")
	private Boolean needPasswordChange;
	
	@NotNull
	@Column(columnDefinition = "int(10) unsigned NOT NULL DEFAULT '0'", name = "last_login")
	private Integer lastLogin;
	
	@Column(columnDefinition = "tinyint(1) DEFAULT '0'", name = "simple_mode")
	private Boolean simpleMode;
	
	@NotNull
	@Column(columnDefinition = "tinyint(1) NOT NULL DEFAULT '0'", name = "email_block")
	private boolean emailBlock;
	
	@Length(max = 255)
	@Column(columnDefinition = "varchar(255) DEFAULT NULL", name = "emp_code")
	private String employeeCode;
	
	@Length(max = 255)
	@Column(columnDefinition = "varchar(255) DEFAULT NULL")
	private String mobile;
	
	@Length(max = 255)
	@Column(columnDefinition = "varchar(255) DEFAULT NULL")
	private String city;
	
	@Length(max = 255)
	@Column(columnDefinition = "varchar(255) DEFAULT NULL")
	private String region;
	
	@Length(max = 255)
	@Column(columnDefinition = "varchar(255) DEFAULT NULL")
	private String area;
	
	@Column(columnDefinition = "int(11) DEFAULT NULL", name = "total_points")
	private Integer totalPoints;
	
	@Column(columnDefinition = "int(11) DEFAULT NULL", name = "current_points")
	private Integer currentPoints;
	
	@Column(columnDefinition = "varchar(10) DEFAULT NULL")
	private String approved;
	
	@Length(max = 255)
	@Column(columnDefinition = "varchar(255) DEFAULT NULL", name = "request_date")
	private String requestDate;
	
	@Column(columnDefinition = "int(11) DEFAULT NULL", name = "accepted_date")
	private Integer acceptedDate;
	
	@Length(max = 255)
	@Column(columnDefinition = "varchar(255) DEFAULT NULL", name = "approval_comment")
	private String approvalComment;
	
	@Length(max = 255)
	@Column(columnDefinition = "varchar(255) DEFAULT NULL", name = "first_login")
	private String firstLogin;
	
	@Column(columnDefinition = "int(11) DEFAULT NULL", name = "login_count")
	private Integer loginCount;
	
	@Column(name = "attempt_unit")
	private String attemptUnit;
	
	@Column(name = "courses_completed")
	private String coursesCompleted;
	
	@OneToMany(mappedBy="userLogin")
	@Cascade({CascadeType.ALL})
	private Set<UserToCourse> userToCourses = new HashSet<UserToCourse>();
	
	/*@OneToMany
	@JoinTable(
			name="users_to_courses",
			joinColumns = @JoinColumn(name="users_LOGIN", referencedColumnName = "login"),
			inverseJoinColumns = @JoinColumn(name="courses_ID")
	)
	@Cascade({CascadeType.ALL})
	private Set<Course> courses = new HashSet<Course>();*/
	
	public Set<UserToCourse> getUserToCourses() {
		return userToCourses;
	}

	public void setUserToCourses(Set<UserToCourse> coursesData) {
		this.userToCourses = coursesData;
	}

	public Set<Course> getCourses()
	{
		Set<Course> courses = new HashSet<Course>();
		for (UserToCourse userToCourse : this.userToCourses)
		{
			if(userToCourse.getArchive() == 0)
				courses.add(userToCourse.getCourseId());
		}
		return courses;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}
	
	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}
	
	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}
	
	public String getLanguagesName() {
		return languagesName;
	}

	public void setLanguagesName(String languagesName) {
		this.languagesName = languagesName;
	}

	public String getTimezone() {
		return timezone;
	}

	public void setTimezone(String timezone) {
		this.timezone = timezone;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public int getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(int timestamp) {
		this.timestamp = timestamp;
	}

	public String getAvatar() {
		return avatar;
	}

	public void setAvatar(String avatar) {
		this.avatar = avatar;
	}

	public boolean isPending() {
		return pending;
	}

	public void setPending(boolean pending) {
		this.pending = pending;
	}
	
	public Integer getUserTypeId() {
		return userTypeId;
	}

	public void setUserTypeId(Integer userTypeId) {
		this.userTypeId = userTypeId;
	}

	public String getAdditionalAccounts() {
		return additionalAccounts;
	}

	public void setAdditionalAccounts(String additionalAccounts) {
		this.additionalAccounts = additionalAccounts;
	}

	public Boolean isViewedLicence() {
		return viewedLicence;
	}

	public void setViewedLicence(Boolean viewedLicence) {
		this.viewedLicence = viewedLicence;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getShortDescription() {
		return shortDescription;
	}

	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription;
	}

	public Float getBalance() {
		return balance;
	}

	public void setBalance(Float balance) {
		this.balance = balance;
	}

	public Integer getArchive() {
		return archive;
	}

	public void setArchive(Integer archive) {
		this.archive = archive;
	}

	public String getDashboardPositions() {
		return dashboardPositions;
	}

	public void setDashboardPositions(String dashboardPositions) {
		this.dashboardPositions = dashboardPositions;
	}

	public Boolean isNeedModInit() {
		return needModInit;
	}

	public void setNeedModInit(Boolean needModInit) {
		this.needModInit = needModInit;
	}

	public String getAutologin() {
		return autologin;
	}

	public void setAutologin(String autologin) {
		this.autologin = autologin;
	}

	public Boolean isNeedPasswordChange() {
		return needPasswordChange;
	}

	public void setNeedPasswordChange(Boolean needPasswordChange) {
		this.needPasswordChange = needPasswordChange;
	}

	public int getLastLogin() {
		return lastLogin;
	}

	public void setLastLogin(int lastLogin) {
		this.lastLogin = lastLogin;
	}

	public Boolean isSimpleMode() {
		return simpleMode;
	}

	public void setSimpleMode(Boolean simpleMode) {
		this.simpleMode = simpleMode;
	}

	public boolean isEmailBlock() {
		return emailBlock;
	}

	public void setEmailBlock(boolean emailBlock) {
		this.emailBlock = emailBlock;
	}

	public String getEmployeeCode() {
		return employeeCode;
	}

	public void setEmployeeCode(String employeeCode) {
		this.employeeCode = employeeCode;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public Integer getTotalPoints() {
		return totalPoints;
	}

	public void setTotalPoints(Integer totalPoints) {
		this.totalPoints = totalPoints;
	}

	public Integer getCurrentPoints() {
		return currentPoints;
	}

	public void setCurrentPoints(Integer currentPoints) {
		this.currentPoints = currentPoints;
	}

	public String getApproved() {
		return approved;
	}

	public void setApproved(String approved) {
		this.approved = approved;
	}

	public String getRequestDate() {
		return requestDate;
	}

	public void setRequestDate(String requestDate) {
		this.requestDate = requestDate;
	}

	public Integer getAcceptedDate() {
		return acceptedDate;
	}

	public void setAcceptedDate(Integer acceptedDate) {
		this.acceptedDate = acceptedDate;
	}

	public String getApprovalComment() {
		return approvalComment;
	}

	public void setApprovalComment(String approvalComment) {
		this.approvalComment = approvalComment;
	}

	public String getFirstLogin() {
		return firstLogin;
	}

	public void setFirstLogin(String firstLogin) {
		this.firstLogin = firstLogin;
	}

	public Integer getLoginCount() {
		return loginCount;
	}

	public void setLoginCount(Integer loginCount) {
		this.loginCount = loginCount;
	}
	
	public String getAttemptUnit()
	{
		return attemptUnit;
	}

	public void setAttemptUnit(String attemptUnit)
	{
		this.attemptUnit = attemptUnit;
	}

	public String getCoursesCompleted()
	{
		return coursesCompleted;
	}

	public void setCoursesCompleted(String coursesCompleted)
	{
		this.coursesCompleted = coursesCompleted;
	}

	@Override
	public String toString() {
		return "id = "+id + ", login = " + login + ", email = " + email; 
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		/* Since no authories are implemented currently */ 
		//return Collections.emptyList();
		Set<GrantedAuthority> authorities = new HashSet<GrantedAuthority>();
		authorities.add(new SimpleGrantedAuthority("user"));
		return authorities;
	}

	@Override
	public String getUsername() {
		return getLogin();
	}

	@Override
	public boolean isAccountNonExpired() {
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		return true;
	}

	@Override
	public boolean isEnabled() {
		return true;
	}

	public User(){ }

	@Override
	public int comparePrimaryKey(SyncEntity user) {
		return this.getId() - ((User) user).getId();
	}
}