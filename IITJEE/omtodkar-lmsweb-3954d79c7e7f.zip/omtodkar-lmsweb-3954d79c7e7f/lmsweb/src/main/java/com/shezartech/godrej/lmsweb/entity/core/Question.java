package com.shezartech.godrej.lmsweb.entity.core;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;

@Entity
@Table(name="questions")
public class Question extends SyncEntity{

	@Id
	@NotNull
	@Column(columnDefinition = "mediumint(8) unsigned NOT NULL AUTO_INCREMENT")
	private Integer id;
	
	@NotNull
	@Column(columnDefinition = "text NOT NULL")
	private String text;
	
	@NotNull
	@Length(max = 255)
	@Column(columnDefinition = "varchar(255) NOT NULL")
	private String type;
	
	@NotNull
	@Column(columnDefinition = "mediumint(8) unsigned NOT NULL DEFAULT '0'", name = "content_ID")
	private Integer contentId;
	
	@NotNull
	@Column(columnDefinition = "mediumint(8) unsigned NOT NULL DEFAULT '0'", name = "lessons_ID")
	private Integer lessonId;
	
	@NotNull
	@Length(max = 255)
	@Column(columnDefinition = "varchar(255) NOT NULL")
	private String difficulty;
	
	@Column(columnDefinition = "text")
	private String options;
	
	@Column(columnDefinition = "text")
	private String answer;
	
	@Column(columnDefinition = "text")
	private String explanation;
	
	@Column(columnDefinition = "text", name = "answers_explanation")
	private String answerExplanation;
	
	@Column(columnDefinition = "int(10) unsigned DEFAULT NULL")
	private Integer estimate;
	
	@Column(columnDefinition = "text")
	private String settings;
	
	@Column(columnDefinition = "mediumint(8) unsigned DEFAULT NULL", name = "linked_to")
	private Integer linkedTo;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getContentId() {
		return contentId;
	}

	public void setContentId(int contentId) {
		this.contentId = contentId;
	}

	public int getLessonId() {
		return lessonId;
	}

	public void setLessonId(int lessonId) {
		this.lessonId = lessonId;
	}

	public String getDifficulty() {
		return difficulty;
	}

	public void setDifficulty(String difficulty) {
		this.difficulty = difficulty;
	}

	public String getOptions() {
		return options;
	}

	public void setOptions(String options) {
		this.options = options;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public String getExplanation() {
		return explanation;
	}

	public void setExplanation(String explanation) {
		this.explanation = explanation;
	}

	public String getAnswerExplanation() {
		return answerExplanation;
	}

	public void setAnswerExplanation(String answerExplanation) {
		this.answerExplanation = answerExplanation;
	}

	public Integer getEstimate() {
		return estimate;
	}

	public void setEstimate(Integer estimate) {
		this.estimate = estimate;
	}

	public String getSettings() {
		return settings;
	}

	public void setSettings(String settings) {
		this.settings = settings;
	}

	public Integer getLinkedTo() {
		return linkedTo;
	}

	public void setLinkedTo(Integer linkedTo) {
		this.linkedTo = linkedTo;
	}

	@Override
	public int comparePrimaryKey(SyncEntity question) {
		return this.getId() - ((Question) question).getId();
	}
	
	public Question() { }
	
	public Map<String, String> getHashMap()
	{
		Map<String, String> map = new HashMap<String, String>();
		map.put("id", Integer.toString(this.getId()));
		map.put("text", this.getText());
		map.put("type", this.getType());
		map.put("content_ID", Integer.toString(this.getContentId()));
		map.put("lessons_ID", Integer.toString(this.getLessonId()));
		map.put("difficulty", this.getDifficulty());
		map.put("options", this.getOptions());
		map.put("answer", this.getAnswer());
		map.put("explanation", this.getExplanation());
		map.put("answers_explanation", this.getAnswerExplanation());
		map.put("estimate", this.getEstimate() != null ? Integer.toString(this.getEstimate()) : null);
		map.put("settings", this.getSettings());
		map.put("linked_to", this.getLinkedTo() != null ? Integer.toString(this.getLinkedTo()) : null);
		return map;
	}
}