package com.shezartech.godrej.lmsweb.dao;

import java.util.List;

import com.shezartech.godrej.lmsweb.entity.core.Course;
import com.shezartech.godrej.lmsweb.entity.core.User;
import com.shezartech.godrej.lmsweb.entity.core.UserToCourse;

public interface UserToCourseDao extends SyncEntityDao<UserToCourse, Long> {

	List<UserToCourse> findAll(String userLogin);

	UserToCourse find(Course course, User userLogin);

}
