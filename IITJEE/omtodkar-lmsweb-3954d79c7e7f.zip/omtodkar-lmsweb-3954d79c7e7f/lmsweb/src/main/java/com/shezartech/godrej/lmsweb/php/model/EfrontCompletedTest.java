package com.shezartech.godrej.lmsweb.php.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Class representing a completed test
 *
 * @package eFront
 */
public class EfrontCompletedTest extends EfrontTest
{
    /**
     * Times for the test.
     *
     * This array holds important timestamps for the test:
     * <br/>- 'start': The time that the test started
     * <br/>- 'end': The time that the test ended
     * <br/>- 'spent': The total time that the user actually spent on this test (not including the time between pauses)
     * <br/>- 'resume': The time that the user last resumed the test
     * @var array
     * @since 3.5.2
     * @access public
     */
    public Map<String, Object> time = new HashMap<String, Object>(){{
    	put("start"  , "");
    	put("end"    , "");
    	put("spent"  , "");
    	put("pause"  , "");
    	put("resume" , "");
    }};

    public Map<String, Object> completedTest = new HashMap<String, Object>(){{
    	put("id"       , "");
    	put("login"    , "");
    	put("archive"  , "");
    	put("status"   , "");
    	put("pending"  , "");
    	put("testsId"  , "");
    	put("score"    , "");
    	put("feedback" , "");
    }};
    
    public String lesson;

    /**
     * Class constructor
     *
     * This class instantiates the object, based on an EfrontTest object and
     * the specified user
     * <br/>Example:
     * <code>
     * $test = new EFrontTest(34);
     * $testInstance = new EfrontCompletedTest($test, 'jdoe');
     * </code>
     *
     * @param EfrontTest $sourceTest The test that the object is based on
     * @param string $login The user login
     * @since 3.5.2
     * @access public
     */
    public EfrontCompletedTest(Map<String, String> test)
    {
    	super(test);
        
		//TODO find what is convertedDuration (public, private or protected)
    }
    
    public void start(Map<String, Object> time, Map<String, Object> completedTest, Map<String, Object> content, 
    		List<Map<String, String>> questions, Map<Integer, Map<Integer, String>> userAnswers)
    {
		this.time.putAll(time);
		this.completedTest.putAll(completedTest);
		this.unit = new EfrontUnit(content);
		this.lesson = (String) this.test.get("lessons_ID");
		this.setQuestions(questions, userAnswers);
		this.calculateScore();
    }
    
    private void setQuestions(List<Map<String, String>> questionMaps, Map<Integer, Map<Integer, String>> userAnswers)
    {
    	for (Map<String, String> questionMap : questionMaps)
    	{
			questionMap.put("content_name", (String) this.test.get("name"));
			Map<Integer, String> userAnswer = userAnswers.get(Integer.parseInt(questionMap.get("id")));
			
    		switch (questionMap.get("type"))
    		{
			case "multiple_one":
				this.questions.put(Integer.parseInt(questionMap.get("id")), new MultipleOneQuestion(questionMap, userAnswer));
				break;
			case "multiple_many":
				this.questions.put(Integer.parseInt(questionMap.get("id")), new MultipleManyQuestion(questionMap, userAnswer));
				break;
			case "true_false":
				this.questions.put(Integer.parseInt(questionMap.get("id")), new TrueFalseQuestion(questionMap, userAnswer));
				break;
			default:
				break;
			}
		}
    }
    
    private void calculateScore()
    {
    	int correct = 0;
    	for (com.shezartech.godrej.lmsweb.php.model.Question question : this.questions.values())
    	{
			if(question.results == true) correct++;
		}
    	float score = ((float)correct / this.questions.values().size())*100;
    	this.completedTest.put("score", score);
    	this.completedTest.put("status", score >= 50 ? "passed": "failed");
    }
}