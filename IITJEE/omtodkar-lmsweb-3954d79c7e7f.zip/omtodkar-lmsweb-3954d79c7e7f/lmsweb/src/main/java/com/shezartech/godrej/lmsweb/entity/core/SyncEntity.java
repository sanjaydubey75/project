package com.shezartech.godrej.lmsweb.entity.core;

public abstract class SyncEntity implements BaseEntity{

	public abstract int comparePrimaryKey(SyncEntity entity);
	
}