package com.shezartech.godrej.lmsweb.entity.addmodels;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.shezartech.godrej.lmsweb.entity.core.IAddDeleteEntity;
import com.shezartech.godrej.lmsweb.entity.core.TestToQuestion;

@Entity
@Table(name="tests_to_questions_add")
public class TestToQuestionAdd implements IAddDeleteEntity{
	
	@NotNull
	private Integer hash;
	
	@Id
	@OneToOne
	@JoinColumns({
		@JoinColumn(name="testToQuestion_tests_ID", referencedColumnName = "tests_ID"),
		@JoinColumn(name="testToQuestion_questions_ID", referencedColumnName = "questions_ID")
	})
	private TestToQuestion testToQuestion;

	@Override
	public int getHash() {
		return hash;
	}

	@Override
	public void setHash() {
		this.hash = testToQuestion.hashCode();
	}

	public TestToQuestion getTestToQuestion() {
		return testToQuestion;
	}

	public void setTestToQuestion(TestToQuestion testToQuestion) {
		this.testToQuestion = testToQuestion;
	}
}