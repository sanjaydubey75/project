package com.shezartech.godrej.lmsweb.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

public class UserResponse extends BaseResponse{

	@JsonInclude(Include.NON_NULL)
	public String name;
	
	@JsonInclude(Include.NON_NULL)
	public boolean isActive;

	public UserResponse(String name, boolean isActive) {
		super(true, null);
		this.name = name;
		this.isActive = isActive;
	}
	
	public UserResponse(String statusMessage){
		super(false, statusMessage);
	}
}
