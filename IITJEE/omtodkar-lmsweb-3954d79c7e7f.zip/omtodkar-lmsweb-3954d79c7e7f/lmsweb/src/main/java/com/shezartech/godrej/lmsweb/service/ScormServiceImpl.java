package com.shezartech.godrej.lmsweb.service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.shezartech.godrej.lmsweb.dao.LessonDao;
import com.shezartech.godrej.lmsweb.dao.UserDao;
import com.shezartech.godrej.lmsweb.dao.UserToLessonDao;
import com.shezartech.godrej.lmsweb.entity.core.Content;
import com.shezartech.godrej.lmsweb.entity.core.Course;
import com.shezartech.godrej.lmsweb.entity.core.Lesson;
import com.shezartech.godrej.lmsweb.entity.core.User;
import com.shezartech.godrej.lmsweb.entity.core.UserToLesson;

import de.ailis.pherialize.Mixed;
import de.ailis.pherialize.Pherialize;

@Service
public class ScormServiceImpl implements ScormService
{
	
	@Autowired
	private LessonDao lessonDao;
	
	@Autowired
	private UserDao userDao;
	
	@Autowired
	private UserToLessonDao userToLessonDao;
	
	@Autowired
	private UserToCourseService userToCourseService;

	@Transactional(value = "txManagerNew")
	@Override
	public void setScormCompleted(int lessonId, String login, long timestamp)
	{
		Lesson lesson = lessonDao.find(lessonId);
		User user = userDao.findByLogin(login);
		
		UserToLesson userToLesson = userToLessonDao.find(user, lesson);
		
		updateUserToLesson(lesson, userToLesson, timestamp);
		userToCourseService.setCourseCompletedIfAllLessonsComplete(getCourse(lessonId, login), login, timestamp);
	}
	
	private void updateUserToLesson(Lesson lesson, UserToLesson userToLesson, long timestamp)
	{
		
		String doneContent = userToLesson.getDoneContent();
		
		Map<Integer, String> map = new HashMap<Integer, String>();
		
		if(doneContent != null && !doneContent.isEmpty())
		{
			Map<Object, Object> doneContents = Pherialize.unserialize(doneContent).toArray();
			
			for (Map.Entry<Object, Object> entry : doneContents.entrySet())
			{
				map.put(((Mixed)entry.getKey()).toInt(), ((Mixed)entry.getValue()).toString());
			}
		}
		
		Set<Content> contents = lesson.getContents();
		for (Content content : contents)
		{
			map.put(content.getId(), String.valueOf(content.getId()));
			userToLesson.setCurrentUnit(content.getId());
		}
		
		userToLesson.setDoneContent(Pherialize.serialize(map));
		userToLesson.setCompleted(1);
		userToLesson.setScore(100);
		
		Date date = new java.util.Date (timestamp*1000);
		String date1 = new java.text.SimpleDateFormat("yyyy/MM/dd").format(date);
		String time = new java.text.SimpleDateFormat("HH:mm:ss").format(date);
		String comments = "Auto completed at: " + date1 + ", " + time;
		
		userToLesson.setComments(comments);
		userToLesson.setToTimestamp(timestamp);
	}
	
	private int getCourse(int lessonId, String login)
	{
		User user = userDao.findByLogin(login);
		
		Course course = null;
		
		mainLoop:
		for (Course courseTemp : user.getCourses())
		{
			for(Lesson lesson : courseTemp.getLessons())
			{
				if(lesson.getId() == lessonId)
				{
					course = courseTemp;
					break mainLoop;
				}
			}
		}
		
		return course.getId();
	}
}
