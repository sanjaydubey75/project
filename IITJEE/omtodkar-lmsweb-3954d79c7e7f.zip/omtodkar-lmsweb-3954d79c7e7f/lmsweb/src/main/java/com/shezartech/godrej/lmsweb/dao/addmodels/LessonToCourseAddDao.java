package com.shezartech.godrej.lmsweb.dao.addmodels;

import com.shezartech.godrej.lmsweb.dao.AddDeleteDao;
import com.shezartech.godrej.lmsweb.entity.addmodels.LessonToCourseAdd;


public interface LessonToCourseAddDao extends AddDeleteDao<LessonToCourseAdd, Long>{
    
}
