package com.shezartech.godrej.lmsweb.entity.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="tests_to_questions")
public class TestToQuestion extends SyncEntity{

	@Id
	@NotNull
//	@Column(columnDefinition = "mediumint(8) unsigned NOT NULL DEFAULT '0'", name = "tests_ID")
	@ManyToOne
	@JoinColumn(name="tests_ID", referencedColumnName = "id")
	private Test testId;
	
	@Id
	@ManyToOne
	@JoinColumn(name="questions_ID", referencedColumnName = "id")
	@NotNull
//	@Column(columnDefinition = "mediumint(8) unsigned NOT NULL DEFAULT '0'", name = "questions_ID")
	private Question questionId;
	
	@NotNull
	@Max(value = 255)
	@Column(columnDefinition = "tinyint(1) unsigned NOT NULL DEFAULT '1'")
	private Integer weight;
	
	@NotNull
	@Column(columnDefinition = "mediumint(8) unsigned NOT NULL DEFAULT '0'", name = "previous_question_ID")
	private Integer previousQuestionId;

	public Test getTestId() {
		return testId;
	}

	public void setTestId(Test testId) {
		this.testId = testId;
	}

	public Question getQuestionId() {
		return questionId;
	}

	public void setQuestionId(Question questionId) {
		this.questionId = questionId;
	}

	public int getWeight() {
		return weight;
	}

	public void setWeight(int weight)
	{
		this.weight = weight;
	}

	public int getPreviousQuestionId() {
		return previousQuestionId;
	}

	public void setPreviousQuestionId(int previousQuestionId) {
		this.previousQuestionId = previousQuestionId;
	}
	
	public TestToQuestion() {}

	@Override
	public int comparePrimaryKey(SyncEntity testToQuestion) {
		if(this.getTestId() != ((TestToQuestion) testToQuestion).getTestId()) 
			return this.getTestId().getId() - ((TestToQuestion) testToQuestion).getTestId().getId();
		else
			return this.getQuestionId().getId() - ((TestToQuestion) testToQuestion).getQuestionId().getId();
	}
}