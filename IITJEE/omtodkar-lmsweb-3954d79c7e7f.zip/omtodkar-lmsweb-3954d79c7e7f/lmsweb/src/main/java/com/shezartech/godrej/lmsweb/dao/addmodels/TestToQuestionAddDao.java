package com.shezartech.godrej.lmsweb.dao.addmodels;

import com.shezartech.godrej.lmsweb.dao.AddDeleteDao;
import com.shezartech.godrej.lmsweb.entity.addmodels.TestToQuestionAdd;

public interface TestToQuestionAddDao extends AddDeleteDao<TestToQuestionAdd, Long> {

}
