package com.shezartech.godrej.lmsweb.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.shezartech.godrej.lmsweb.dao.DirectionDao;
import com.shezartech.godrej.lmsweb.entity.core.Direction;

@Service
public class DirectionServiceImpl implements DirectionService
{
	@Autowired
	private DirectionDao directionDao;
	
	@Override
	@Transactional(value="txManagerNew")
	public List<Direction> getDirections()
	{
		return directionDao.findAll();
	}
}
