package com.shezartech.godrej.lmsweb.dao;

import com.shezartech.godrej.lmsweb.entity.core.ScormData;

public interface ScormDataDao extends BaseDao<ScormData, Integer>
{

}
