package com.shezartech.godrej.lmsweb.config;

import java.util.List;
import java.util.Properties;

import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.aspectj.EnableSpringConfigured;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.ResourceHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.orm.hibernate4.LocalSessionFactoryBuilder;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.servlet.config.annotation.DefaultServletHandlerConfigurer;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

@Configuration
@EnableWebMvc
@ComponentScan(basePackages = { "com.shezartech.godrej.lmsweb" })
@EnableTransactionManagement
@EnableAspectJAutoProxy
@EnableSpringConfigured
public class WebConfig extends WebMvcConfigurerAdapter {
	
//	public static final String WebAppBasePath = "D:/development/efront/efront_live/godrejtest";
	public static final String WebAppBasePath = "/home/shezartc/public_html/godrejtest";
	
	private static class Connection{
//		private static final String OldUrl = "jdbc:mysql://localhost:3306/shezartc_godrejtest2";
//		private static final String NewUrl = "jdbc:mysql://localhost:3306/shezartc_godrejtest";
//		private static final String Username = "root";
//		private static final String Password = "";
		private static final String OldUrl = "jdbc:mysql://shezartech.com:3306/shezartc_godrejsync";
		private static final String NewUrl = "jdbc:mysql://shezartech.com:3306/shezartc_godrejtest";
		private static final String Username = "shezartc_godrejt";
		private static final String Password = "shezartc_godrejt";
		private static final String UseSqlComments = "true";
		private static final String DriverClassName = "com.mysql.jdbc.Driver";
		
		private static class Hibernate{
			private static final String Dialect = "org.hibernate.dialect.MySQLDialect";
			private static final String ShowSql = "true";
			private static final String FormatSql = "true";
			private static final String Hbm2ddl = "none";
			private static final String ConnectionProviderClass = "com.zaxxer.hikari.hibernate.HikariConnectionProvider";
			
			private static class Hikari{
				private static final String MaximumPoolSize = "100";
				private static final String IdleTimeout = "30000";
				
			}
		}
	}

	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		registry.addResourceHandler("/resources/**").addResourceLocations(
				"/resources/");
	}
	
	@Override
    public void configureDefaultServletHandling(DefaultServletHandlerConfigurer configurer) {
        configurer.enable();
    }
	
	@Override
    public void configureMessageConverters( List<HttpMessageConverter<?>> converters ) {
        converters.add(converter());
        converters.add(new ResourceHttpMessageConverter());
    }

    @Bean
    MappingJackson2HttpMessageConverter converter() {
    	return new MappingJackson2HttpMessageConverter();
    }

	@Bean
	public InternalResourceViewResolver jspViewResolver()
	{
		InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
		viewResolver.setPrefix("/WEB-INF/views/");
		viewResolver.setSuffix(".jsp");
		viewResolver.setOrder(1);
		return viewResolver;
	}
	
	private HikariConfig oldHikariConfig(){
		HikariConfig hikariConfig = new HikariConfig();
		hikariConfig.setDriverClassName(Connection.DriverClassName);
		hikariConfig.setJdbcUrl(Connection.OldUrl);
		hikariConfig.setUsername(Connection.Username);
		hikariConfig.setPassword(Connection.Password);
		return hikariConfig;
	}
	
	private HikariConfig newHikariConfig(){
		HikariConfig hikariConfig = new HikariConfig();
		hikariConfig.setDriverClassName(Connection.DriverClassName);
		hikariConfig.setJdbcUrl(Connection.NewUrl);
		hikariConfig.setUsername(Connection.Username);
		hikariConfig.setPassword(Connection.Password);
		return hikariConfig;
	}

	@Bean(destroyMethod = "close")
	public DataSource oldDataSource() {
		HikariDataSource dataSource = new HikariDataSource(oldHikariConfig());
		return dataSource;
	}
	
	@Bean(destroyMethod = "close")
	public DataSource newDataSource() {
		HikariDataSource dataSource = new HikariDataSource(newHikariConfig());
		return dataSource;
	}

	@Bean(name = "newSessionFactory")
	public SessionFactory newSessionFactory(DataSource newDataSource) {
		
		LocalSessionFactoryBuilder localSessionFactoryBuilder = new LocalSessionFactoryBuilder(newDataSource);
		localSessionFactoryBuilder.scanPackages("com.shezartech.godrej.lmsweb.entity.core");
		localSessionFactoryBuilder.addProperties(hibernateProperties());
		return localSessionFactoryBuilder.buildSessionFactory();
	}
	
	@Bean(name = "oldSessionFactory")
	public SessionFactory oldSessionFactory(DataSource oldDataSource) {
		
		LocalSessionFactoryBuilder localSessionFactoryBuilder = new LocalSessionFactoryBuilder(oldDataSource);
		localSessionFactoryBuilder.scanPackages("com.shezartech.godrej.lmsweb.entity");
		localSessionFactoryBuilder.addProperties(hibernateProperties());
		return localSessionFactoryBuilder.buildSessionFactory();
	}

	Properties hibernateProperties() {
		return new Properties() { // this is magic!!
			{
				setProperty("hibernate.dialect", Connection.Hibernate.Dialect);
				setProperty("hibernate.show_sql", Connection.Hibernate.ShowSql);
				setProperty("hibernate.format_sql", Connection.Hibernate.FormatSql);
				setProperty("use_sql_comments", Connection.UseSqlComments);
				setProperty("hibernate.hbm2ddl.auto", Connection.Hibernate.Hbm2ddl);
			}
		};
	}

	@Bean(name = "txManagerOld")
	public HibernateTransactionManager transactionManager(SessionFactory oldSessionFactory){
		HibernateTransactionManager manager = new HibernateTransactionManager(oldSessionFactory);
		return manager;
	}
	
	@Bean(name = "txManagerNew")
	public HibernateTransactionManager transactionManagerNew(SessionFactory newSessionFactory){
		HibernateTransactionManager manager = new HibernateTransactionManager(newSessionFactory);
		return manager;
	}
}