package com.shezartech.godrej.lmsweb.entity.addmodels;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.shezartech.godrej.lmsweb.entity.core.IAddDeleteEntity;
import com.shezartech.godrej.lmsweb.entity.core.Question;

@Entity
@Table(name="questions_add")
public class QuestionAdd implements IAddDeleteEntity{
	
	@NotNull
	private Integer hash;
	
	@Id
	@OneToOne
	private Question question;

	@Override
	public int getHash() {
		return hash;
	}

	@Override
	public void setHash() {
		this.hash = question.hashCode();
	}

	public Question getQuestion() {
		return question;
	}

	public void setQuestion(Question question) {
		this.question = question;
	}
}