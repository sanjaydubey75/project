package com.shezartech.godrej.lmsweb.entity.addmodels;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.shezartech.godrej.lmsweb.entity.core.Course;
import com.shezartech.godrej.lmsweb.entity.core.IAddDeleteEntity;

@Entity
@Table(name="courses_add")
public class CourseAdd implements IAddDeleteEntity{
	
	@NotNull
	private Integer hash;
	
	@OneToOne
	@Id
	private Course course;
	
	@Override
	public int getHash() {
		return hash;
	}

	@Override
	public void setHash() {
		this.hash = course.hashCode();
	}

	public Course getCourse() {
		return course;
	}

	public void setCourse(Course course) {
		this.course = course;
	}
}