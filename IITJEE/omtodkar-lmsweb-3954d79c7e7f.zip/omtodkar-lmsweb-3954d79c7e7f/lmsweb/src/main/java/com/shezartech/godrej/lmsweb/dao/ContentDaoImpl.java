package com.shezartech.godrej.lmsweb.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.shezartech.godrej.lmsweb.entity.core.Content;

@Repository
public class ContentDaoImpl extends BaseDaoImpl<Content, Integer> implements ContentDao
{
	public ContentDaoImpl()
	{
		super(Content.class);
	}
	
	@Override
	@Autowired
	@Qualifier("newSessionFactory")
	public void setSessionFactory(SessionFactory sessionFactory)
	{
		super.setSessionFactory(sessionFactory);
	}
}