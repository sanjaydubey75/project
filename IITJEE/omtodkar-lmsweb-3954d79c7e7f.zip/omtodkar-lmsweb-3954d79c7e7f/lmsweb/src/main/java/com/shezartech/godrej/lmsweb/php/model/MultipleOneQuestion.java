package com.shezartech.godrej.lmsweb.php.model;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class MultipleOneQuestion extends Question
{
	public MultipleOneQuestion(Map<String, String> question, Map<Integer, String> userAnswer)
	{
		super(question);
		this.results = this.isCorrect(userAnswer, answer);
        this.score = this.results ? 100 : 0;
        
		this.setUserAnser(userAnswer);
	}

	/**
     * Shuffle question options
     *
     * This function is used to shuffle the question options,
     * so that they are displayed in a random order.
     * <br/>Example:
     * <code>
     * $question = new MultipleOneQuestion(3);                                      //Instantiate question
     * $newOrder = $question -> shuffle();                                          //Shuffle question options
     * </code>
     *
     * @return array The new question options order
     * @since 3.5.0
     * @access public
     */
    public void shuffle() //TODO implement this
    {
//        $shuffleOrder = range(0, sizeof($this -> options) - 1);
//        shuffle($shuffleOrder);
//        $this -> order = $shuffleOrder;
//
//        return $shuffleOrder;
    }

    /**
     * Correct question
     *
     * This function is used to correct the question. In order to correct it,
     * setDone() must already have been called, so that the user answer
     * is present.
     * <br/>Example:
     * <code>
     * $question = new MultipleOneQuestion(3);                                      //Instantiate question
     * $question -> setDone($answer, $score, $order);                               //Set done question information
     * $results = $question -> correct();                                           //Correct question
     * </code>
     *
     * @return array The correction results
     * @since 3.5.0
     * @access public
     */
    public void correct() //TODO implement this
    {
//        is_numeric($this -> answer[0]) && is_numeric($this -> userAnswer) && $this -> answer[0] == $this -> userAnswer ? $results = array('correct' => true, 'score' => 1) : $results = array('correct' => false, 'score' => 0);//We put the is_numeric() here, because the results might be strings or ints, which should be equal, or false or '', which are always wrong
//        return $results;
    }

    /**
     * Set question done information
     *
     * This function is used to set its done information. This information consists of
     * the user answer, the score and the answers order.
     * <br/>Example:
     * <code>
     * $question = new MultipleOneQuestion(3);                                      //Instantiate question
     * $question -> setDone($answer, $score, $order);                               //Set done question information
     * </code>
     *
     * @param array $userAnswer The user answer
     * @param float score The user's score in this question
     * @param array $order the question options order
     * @since 3.5.0
     * @access public
     * @deprecated
     */
    public void setDone(List<String> userAnswer, boolean score, boolean order) //TODO implement this
    {
//        $this -> userAnswer = $userAnswer;
//        $score !== false ? $this -> score = $score : null;
//        $order !=  false ? $this -> order = $order : null;
    }
    
    private boolean isCorrect(Map<Integer, String> userAnswer, Object answer)
    {
    	Set<Integer> answerKey = new HashSet<Integer>();
    	for (Map.Entry<Integer, String> entry : ((Map<Integer, String>)answer).entrySet())
		{
			answerKey.add(Integer.parseInt(entry.getValue()));
		}
    	boolean isCorrect = true;
    	for(Map.Entry<Integer, String> userAnswerEntry : userAnswer.entrySet())
    	{
    		int a = Integer.parseInt(userAnswerEntry.getValue());
    		if(a == 1 && !answerKey.contains(userAnswerEntry.getKey()))
    			isCorrect = false;
    		if(a == 0 && answerKey.contains(userAnswerEntry.getKey()))
    			isCorrect = false;
    	}
    	return isCorrect;
    }
    
    private void setUserAnser(Map<Integer, String> userAnswer)
    {
    	for (Map.Entry<Integer, String> userAnswerEntry : userAnswer.entrySet())
		{
			this.userAnswer = userAnswerEntry.getKey();
		}
    }
}