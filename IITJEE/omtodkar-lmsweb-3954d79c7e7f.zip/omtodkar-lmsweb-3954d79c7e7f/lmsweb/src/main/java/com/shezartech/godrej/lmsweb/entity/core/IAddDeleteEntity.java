package com.shezartech.godrej.lmsweb.entity.core;

public interface IAddDeleteEntity extends BaseEntity{
	
	public void setHash();
	public int getHash();
}
