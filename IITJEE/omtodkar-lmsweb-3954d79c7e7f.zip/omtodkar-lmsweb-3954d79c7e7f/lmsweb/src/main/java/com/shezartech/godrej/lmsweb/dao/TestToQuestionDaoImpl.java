package com.shezartech.godrej.lmsweb.dao;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.shezartech.godrej.lmsweb.entity.core.Question;
import com.shezartech.godrej.lmsweb.entity.core.TestToQuestion;

@Repository
public class TestToQuestionDaoImpl extends SyncEntityDaoImpl<TestToQuestion, Long>
		implements TestToQuestionDao {

	public TestToQuestionDaoImpl() {
		super(TestToQuestion.class);
	}

	@Override
	@Autowired
	@Qualifier("newSessionFactory")
	public void setSessionFactory(SessionFactory sessionFactory) {
		super.setSessionFactory(sessionFactory);
	}

	@Override
	public TestToQuestion findByQuestion(Question question)
	{
		Criteria criteria = getCurrentSession().createCriteria(entityClass);
		criteria.add(Restrictions.eq("questionId", question));
		return (TestToQuestion) criteria.uniqueResult();
	}

}