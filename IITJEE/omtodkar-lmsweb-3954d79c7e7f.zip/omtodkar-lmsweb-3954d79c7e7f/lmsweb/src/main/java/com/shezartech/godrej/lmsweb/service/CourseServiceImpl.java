package com.shezartech.godrej.lmsweb.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shezartech.godrej.lmsweb.entity.core.Course;
import com.shezartech.godrej.lmsweb.entity.core.Lesson;

@Service
public class CourseServiceImpl implements CourseService
{
	
	@Autowired
	private LessonService lessonService;

	@Override
	public Set<Course> filterOutCoursesWithSpecialLessons(Set<Course> courses)
	{
		Set<Course> filteredCourses = new HashSet<Course>();
		
		for(Course course : courses)
		{
			List<Lesson> lessons = new ArrayList<Lesson>();
			lessons.addAll(course.getLessons());
			
			if (lessonService.filterOutSpecialLesson(lessons).size() > 0)
				filteredCourses.add(course);
		}
		
		return filteredCourses;
	}
	
	@Override
	public Set<Course> filterInCoursesWithSpecialLessons(Set<Course> courses)
	{
		Set<Course> filteredCourses = new HashSet<Course>();
		
		for(Course course : courses)
		{
			List<Lesson> lessons = new ArrayList<Lesson>();
			lessons.addAll(course.getLessons());
			
			if (lessonService.filterInSpecialLesson(lessons).size() > 0)
				filteredCourses.add(course);
		}
		
		return filteredCourses;
	}
}
