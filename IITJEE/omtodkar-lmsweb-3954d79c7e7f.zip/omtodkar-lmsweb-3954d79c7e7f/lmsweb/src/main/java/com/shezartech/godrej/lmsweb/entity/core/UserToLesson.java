package com.shezartech.godrej.lmsweb.entity.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.Range;

@Entity
@Table(name = "users_to_lessons")
public class UserToLesson implements BaseEntity
{
	@Id
	@NotNull
	@ManyToOne
	@JoinColumn(name="users_LOGIN", referencedColumnName = "login")
	private User user;
	
	@Id
	@NotNull
	@ManyToOne
	@JoinColumn(name="lessons_ID", referencedColumnName = "id")
	private Lesson lesson;
	
	@NotNull
	@Range(max = 127, min = -128)
	private Integer active = 0;
	
	@Range(max = 4294967295L, min = 0)
	private Long archive = (long) 0;
	
	@Range(max = 4294967295L, min = 0)
	@Column(name = "from_timestamp")
	private Long fromTimestamp;
	
	@Length(max = 50)
	@Column(name = "user_type")
	private String userType;
	
	@Column(columnDefinition = "text")
	private String positions;
	
	@Column(columnDefinition = "text", name = "done_content")
	private String doneContent;
	
	@Column(name ="current_unit")
	@Range(max = 16777215, min = 0)
	private Integer currentUnit = 0;
	
	@NotNull
	@Range(max = 127, min = -128)
	private Integer completed = 0;
	
	@Range(max = 255, min = 0)
	@NotNull
	private Integer score = 0;
	
	@Lob
	@Column(columnDefinition = "blob", name = "issued_certificate")
	private String issuedCertificate;
	
	@Column(columnDefinition = "text")
	private String comments;
	
	@Range(max = 4294967295L, min = 0)
	@Column(name = "to_timestamp")
	private Long toTimestamp;
	
	@Column(name = "access_counter")
	private Integer accessCounter = 0;

	public User getUser()
	{
		return user;
	}

	public void setUser(User user)
	{
		this.user = user;
	}

	public Lesson getLesson()
	{
		return lesson;
	}

	public void setLesson(Lesson lesson)
	{
		this.lesson = lesson;
	}

	public int getActive()
	{
		return active;
	}

	public void setActive(int active)
	{
		this.active = active;
	}

	public Long getArchive()
	{
		return archive;
	}

	public void setArchive(Long archive)
	{
		this.archive = archive;
	}

	public Long getFromTimestamp()
	{
		return fromTimestamp;
	}

	public void setFromTimestamp(Long fromTimestamp)
	{
		this.fromTimestamp = fromTimestamp;
	}

	public String getUserType()
	{
		return userType;
	}

	public void setUserType(String userType)
	{
		this.userType = userType;
	}

	public String getPositions()
	{
		return positions;
	}

	public void setPositions(String positions)
	{
		this.positions = positions;
	}

	public String getDoneContent()
	{
		return doneContent;
	}

	public void setDoneContent(String doneContent)
	{
		this.doneContent = doneContent;
	}

	public Integer getCurrentUnit()
	{
		return currentUnit;
	}

	public void setCurrentUnit(Integer currentUnit)
	{
		this.currentUnit = currentUnit;
	}

	public int getCompleted()
	{
		return completed;
	}

	public void setCompleted(int completed)
	{
		this.completed = completed;
	}

	public int getScore()
	{
		return score;
	}

	public void setScore(int score)
	{
		this.score = score;
	}

	public String getIssuedCertificate()
	{
		return issuedCertificate;
	}

	public void setIssuedCertificate(String issuedCertificate)
	{
		this.issuedCertificate = issuedCertificate;
	}

	public String getComments()
	{
		return comments;
	}

	public void setComments(String comments)
	{
		this.comments = comments;
	}

	public Long getToTimestamp()
	{
		return toTimestamp;
	}

	public void setToTimestamp(Long toTimestamp)
	{
		this.toTimestamp = toTimestamp;
	}

	public Integer getAccessCounter()
	{
		return accessCounter;
	}

	public void setAccessCounter(Integer accessCounter)
	{
		this.accessCounter = accessCounter;
	}

}
