package com.shezartech.godrej.lmsweb.php.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import de.ailis.pherialize.Mixed;
import de.ailis.pherialize.Pherialize;

public abstract class Question implements Serializable
{
    /**
     * The available question types
     *
     * @var array
     * @since 3.5.0
     * @access public
     */
    public static Map<String, String> questionTypes = new HashMap<String, String>(){{
    	put("multiple_one"  , "Multiple choices - Single correct answer");
        put("multiple_many" , "Multiple choices - Many correct answers");
        put("true_false", "True/False");
    }};
    

    /**
     * The available question types icons
     *
     * @var array
     * @since 3.5.0
     * @access public
     */
    public static Map<String, String> questionTypesIcons = new HashMap<String, String>(){{
    	put("multiple_one", "images/16x16/question_type_one_correct.png");
    	put("multiple_many", "images/16x16/question_type_multiple_correct.png");
    	put("true_false", "images/16x16/question_type_true_false.png");
    }};
    		

    /**
     * The available question difficulties
     *
     * @var array
     * @since 3.5.0
     * @access public
     */
    public static Map<String, String> questionDifficulties = new HashMap<String, String>(){{
    	put("low","Low");
    	put("medium","Medium");
    	put("high","High");
    	put("very_high", "Very hard");
    }};
    
    /**
     * The available question difficulties icons
     *
     * @var array
     * @since 3.5.0
     * @access public
     */
    public static Map<String, String> questionDifficultiesIcons = new HashMap<String, String>(){{
    	put("low", "images/16x16/flag_green.png");
    	put("medium", "images/16x16/flag_blue.png");
    	put("high", "images/16x16/flag_yellow.png");
    	put("very_high", "images/16x16/flag_red.png");
    }}; 

    /**
     * The question fields
     *
     * @var array
     * @access public
     * @since 3.5.0
     */
    public Map<String, Object> question = new HashMap<String, Object>(); 

    /**
     * Question options
     *
     * @var array
     * @since 3.5.0
     * @access public
     */
    public Object options = new HashMap<String, Object>();


	public Object settings = new HashMap<String, String>(){{
		put("force_correct", "manual");
		put("answers_logic", "");
		put("exclude_shuffle", "0");
	}};

    /**
     * Question's answer(s)
     *
     * @var array
     * @since 3.5.0
     * @access public
     */
    public Object answer = new HashMap<String, Object>();

    /**
     * The user's answer, if the question is done
     *
     * @var array
     * @since 3.5.0
     * @access public
     */
    public Object userAnswer; // can be a string or a list of strings 

    /**
     * The user's score, if the question is done
     *
     * @var float
     * @since 3.5.0
     * @access public
     */
    public float score = 0;

    /**
     * The questions's answers order
     *
     * @var array
     * @since 3.5.0
     * @access public
     */
    public List<Object> order;


    /**
     * An array of file ids, that were uploaded along with the question
     *
     * @var array
     * @since 3.5.2
     * @access public
     */
    public List<Object> files = new ArrayList<Object>(); //TODO find the type

    /**
     * Whether this question should be corrected by the professor
     *
     * @var int
     * @since 3.5.2
     * @access public
     */
    public int pending = 0;

    /**
     * The maximum question text length, when displayed not in tests
     *
     * @since 3.5.0
     *@access public
     */
    static int maxQuestionText = 50;
    
    public Map<Integer, String> answers_explanation;
    
    public boolean results;

    /**
     * Class constructor
     *
     * This function is used to instantiate a test question object.
     * If an id is used, then the question is instantiate based on
     * database information. Alternatively, the question array itself
     * may be provided, thus overriding database query.
     * <br/>Example:
     * <code>
     * $question = QuestionFactory :: factory(4);                   //Instantiate question using question id
     * $result   = eF_getTableData("questions", "*", "id=4");
     * $question = QuestionFactory :: factory($result[0]);          //Instantiate question using question array
     * </code>
     *
     * @param mixed $question Either a question id or a question array
     * @param array $testOptions specific test options that have impact on the question rendering
     * @since 3.5.0
     * @access public
     */
    public Question(Map<String, String> question)
    {
    	this.question.putAll(question);

    	Map<Integer, String> tempOptions = unserialize((String) question.get("options"));
		this.options = (tempOptions != null) ? "" : (String)question.get("options");

    	Object tempAnswer = unserialize2((String) question.get("answer"));
    	this.answer = (tempAnswer != null) ? tempAnswer : (String)question.get("answer");

    	Map<String, String> tempSettings = unserialize1((String) question.get("settings"));
    	this.settings = (tempSettings != null) ? tempSettings : (String)question.get("settings");

    	if(this.options instanceof Map<?, ?>)
    	{
    		this.order = new ArrayList<Object>();
    		this.order.addAll(((Map<?, ?>) this.options).keySet());
    	}

        this.question.put("type_icon", Question.questionTypesIcons.get(this.question.get("type")));
        
        String plainText = ((String)this.question.get("text")).replaceAll("\\<.*?\\>", "").trim();
        if(plainText.length() > Question.maxQuestionText)
        	plainText = plainText.substring(0, Question.maxQuestionText) + "...";
        this.question.put("plain_text", plainText);
        
        this.convertIntervalToTime();
        
        if (this.question.get("answers_explanation") != null)
        {
        	
        	Map<Integer, String> temp = unserialize((String) this.question.get("answers_explanation"));
        	if(temp != null)
        	{
        		this.answers_explanation = new HashMap<Integer, String>();
            	this.answers_explanation.putAll(temp);        		
        	}
        }
    }
    
    private Map<Integer, String> unserialize(String string)
    {
    	if(string != null && !string.equals(""))
    	{
    		Mixed temp = Pherialize.unserialize(string);
    		
    		if(temp != null)
	    	{
    			Map<Object, Object> tempMap = temp.toArray();
	    		if(tempMap != null)
	    		{
	    			Map<Integer, String> tempMap2 = new HashMap<Integer, String>();
	        		for (Map.Entry<Object, Object> entry : tempMap.entrySet())
	        		{
	        			tempMap2.put(((Mixed)entry.getKey()).toInt(), ((Mixed)entry.getValue()).toString());
	        		}
	        		return tempMap2;
	    		}
	    		else
	    			return null;
    		}
    		else
    			return null;
    	}
    	else return null;
    }
    
    private Object unserialize2(String string) //returns either Map<Integer, String> or String
    {
    	if(string != null && !string.equals(""))
    	{
    		Mixed temp = Pherialize.unserialize(string);
    		Map<Object, Object> tempMap = temp.toArray();
    		if(tempMap != null)
    		{
    			Map<Integer, String> tempMap2 = new HashMap<Integer, String>();
        		for (Map.Entry<Object, Object> entry : tempMap.entrySet())
        		{
        			tempMap2.put(((Mixed)entry.getKey()).toInt(), ((Mixed)entry.getValue()).toString());
        		}
        		return tempMap2;
    		}
    		else return String.valueOf(temp.toInt());
    	}
    	else return null;
    }
    
    private Map<String, String> unserialize1(String string)
    {
    	if(string != null && !string.equals(""))
    	{
    		Map<Object, Object> tempMap = Pherialize.unserialize(string).toArray();
    		Map<String, String> tempMap2 = new HashMap<String, String>();
    		for (Map.Entry<Object, Object> entry : tempMap.entrySet())
    		{
    			tempMap2.put(((Mixed)entry.getKey()).toString(), ((Mixed)entry.getValue()).toString());
    		}
    		return tempMap2;
    	}
    	else return null;
    }
    
    private void convertIntervalToTime()
    {
    	Map<String, Integer> time = new HashMap<String, Integer>();
    	
    	if(this.question.get("estimate") != null)
    	{
    		long timestamp = (long) this.question.get("estimate");
    		Date date = new Date(timestamp*1000);
    		Calendar calendar = Calendar.getInstance();
    		calendar.setTime(date);
    		time.put("hours", calendar.get(Calendar.HOUR_OF_DAY));
    		time.put("minutes", calendar.get(Calendar.MINUTE));
    		time.put("seconds", calendar.get(Calendar.SECOND));
    	}
    	else
    	{
    		time.put("hours", 0);
    		time.put("minutes", 0);
    		time.put("seconds", 0);
    	}
    	
    	this.question.put("estimate_interval", time);
    }
}