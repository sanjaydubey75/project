package com.shezartech.godrej.lmsweb.service;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class Serialize
{
	private static final Logger logger = LoggerFactory.getLogger(Serialize.class);
	public static String phpToJson(String string)
	{
		String code="function jsonToPhp($a){return json_encode(unserialize($a));}"; //sample bit of unserialize code
		ScriptEngineManager manager = new ScriptEngineManager();
		ScriptEngine engine = (new ScriptEngineManager()).getEngineByName("php-interactive");
		try
		{
			engine.eval(code);
		    String json = (String) engine.eval("echo @jsonToPhp('"
		    		+string
		    		+ "');");
		    return json;
		    
		}
		catch (ScriptException ex)
		{
			logger.error("error", ex);
			ex.printStackTrace();
			return null;
		}
	}
}