package com.shezartech.godrej.lmsweb.service;

import javax.mail.MessagingException;

public interface MailService
{

	void sendMail(String phoneNumber, String senderEmail, String typeOfQuery,
			String feedback) throws MessagingException;

}
