package com.shezartech.godrej.lmsweb.service;

import java.io.File;
import java.io.FilenameFilter;

import org.springframework.stereotype.Service;

import com.shezartech.godrej.lmsweb.config.WebConfig;

@Service
public class ModuleServiceImpl implements ModuleService {

	private static String BasePath = WebConfig.WebAppBasePath + "/www/content/lessons";

	@Override
	public File getModule(int id){
		
		File innerDirectory = getInnerDirectory(id);
		
		return getZipFile(innerDirectory);
	}
	
	@Override
	public boolean isModuleExist(int id){
		
		File directory = getInnerDirectory(id);
		
		if(directory == null) return false;
		
		File[] modules = directory.listFiles(new FilenameFilter() {
			
			@Override
			public boolean accept(File dir, String name) {
				return name.toLowerCase().endsWith(".zip");
			}
		});
		
		return modules.length == 1;
	}
	
	private File getInnerDirectory(int id){
		String rootPathForModule = ModuleServiceImpl.BasePath + "/" + id;
		
		File file = new File(rootPathForModule);
		String[] names = file.list();
		
		if(names == null) return null;
		
		if(names.length == 1)
		{
			File innerDirectory = new File(rootPathForModule + "/" + names[0]);
			if(!innerDirectory.isDirectory()) return null;
			else return innerDirectory;
		}
		return null;
	}
	
	private File getZipFile(File directory){
		
		//find if a zip file exists
		File[] modules = directory.listFiles(new FilenameFilter() {
					
			@Override
			public boolean accept(File dir, String name) {
				return name.toLowerCase().endsWith(".zip");
			}
		});
		
		if(modules.length > 1) return null;
		if(modules.length == 0) return createZipFile(directory);
		
		return modules[0];
	}
	
	/**
	 * Create a zip of files within the 'directory' inside the 'directory' with the same name as that of 'directory'.
	 * Also it returns the newly created file.
	 */
	private File createZipFile(File sourceDirectory){
		
		ZipService zipService = new ZipServiceImpl(sourceDirectory.getAbsolutePath());
		zipService.generateFileList(sourceDirectory);
		zipService.zipIt(sourceDirectory.getPath() + "/" + "temp.zip");
		return new File(sourceDirectory.getAbsolutePath() + "/" + "temp.zip");
	}
}