package com.shezartech.godrej.lmsweb.dao.addmodels;

import com.shezartech.godrej.lmsweb.dao.AddDeleteDao;
import com.shezartech.godrej.lmsweb.entity.addmodels.TestAdd;

public interface TestAddDao extends AddDeleteDao<TestAdd, Long> {

	TestAdd findById(int id);

	TestAdd findByNameAssessment(String name);

}
