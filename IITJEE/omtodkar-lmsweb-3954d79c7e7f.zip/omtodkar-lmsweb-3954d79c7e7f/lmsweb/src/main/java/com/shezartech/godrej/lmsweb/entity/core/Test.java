package com.shezartech.godrej.lmsweb.entity.core;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;
import org.hibernate.validator.constraints.Length;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIdentityReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

@Entity
@Table(name="tests", indexes={
	@Index(columnList="lessons_ID", name="lessons_ID")
})
public class Test extends SyncEntity{

	@Id
	@NotNull
	@Column(columnDefinition = "mediumint(8) unsigned NOT NULL AUTO_INCREMENT")
	private Integer id;
	
	@NotNull
	@Column(columnDefinition = "tinyint(1) NOT NULL DEFAULT '1'")
	private boolean active;
	
	@NotNull
	@Column(columnDefinition = "mediumint(8) unsigned NOT NULL DEFAULT '0'", name = "content_ID")
	private Integer contentId;
	
//	@JsonProperty(value = "lessonId")
	@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
	@JsonIdentityReference(alwaysAsId = true)
	@NotNull
	@ManyToOne
	@JoinColumn(name="lessons_ID", referencedColumnName = "id")
//	@Column(columnDefinition = "mediumint(8) unsigned NOT NULL DEFAULT '0'", name = "lessons_ID")
	private Lesson lesson;
	
	@NotNull
	@Length(max=255)
	@Column(columnDefinition = "varchar(255) NOT NULL DEFAULT ''")
	private String name;
	
	@NotNull
	@Max(value = 255)
	@Column(columnDefinition = "tinyint(4) unsigned NOT NULL DEFAULT '0'", name = "mastery_score")
	private Integer masteryScore;
	
	@Column(columnDefinition = "text")
	private String description;
	
	@Column(columnDefinition = "text")
	private String options;
	
	@Column(columnDefinition = "tinyint(1) DEFAULT '1'")
	private Boolean publish;
	
	@Column(columnDefinition = "tinyint(1) DEFAULT '0'", name = "keep_best")
	private Boolean keepBest;
	
	@JsonIgnore
	@OneToMany(mappedBy = "testId")
	@Cascade({CascadeType.ALL})
	private Set<TestToQuestion> testToQuestions = new HashSet<TestToQuestion>();
	
	@JsonIgnore
	@OneToMany
	@JoinTable(
			name="tests_to_questions",
			joinColumns = @JoinColumn(name="tests_ID", referencedColumnName = "id"),
			inverseJoinColumns = @JoinColumn(name="questions_ID")
	)
	@Cascade({CascadeType.ALL})
	private Set<Question> questions = new HashSet<Question>();
//
//	public Set<TestToQuestion> getTestToQuestions() {
//		return testToQuestions;
//	}
//
//	public void setTestToQuestions(Set<TestToQuestion> testToQuestions) {
//		this.testToQuestions = testToQuestions;
//	}

	public Set<Question> getQuestions() {
		return questions;
	}

	public void setQuestions(Set<Question> questions) {
		this.questions = questions;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public int getContentId() {
		return contentId;
	}

	public void setContentId(int contentId) {
		this.contentId = contentId;
	}

	public Lesson getLesson() {
		return lesson;
	}

	public void setLesson(Lesson lessonId) {
		this.lesson = lessonId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getMasteryScore() {
		return masteryScore;
	}

	public void setMasteryScore(int masteryScore) {
		this.masteryScore = masteryScore;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getOptions() {
		return options;
	}

	public void setOptions(String options) {
		this.options = options;
	}

	public Boolean isPublish() {
		return publish;
	}

	public void setPublish(Boolean publish) {
		this.publish = publish;
	}

	public Boolean isKeepBest() {
		return keepBest;
	}

	public void setKeepBest(Boolean keepBest) {
		this.keepBest = keepBest;
	}

	@Override
	public int comparePrimaryKey(SyncEntity test) {
		return this.getId() - ((Test) test).getId();
	}
	
	public Test(){ }
	
	public Map<String, String> getHashMap()
	{
		Map<String, String> map = new HashMap<String, String>();
		map.put("id", Integer.toString(this.getId()));
		map.put("active", Integer.toString(this.isActive() ? 1 : 0));
		map.put("content_ID", Integer.toString(this.getContentId()));
		map.put("lessons_ID", Integer.toString(this.getLesson().getId()));
		map.put("name", this.getName());
		map.put("mastery_score", Integer.toString(this.getMasteryScore()));	
		map.put("description", this.getDescription());
		map.put("options", this.getOptions()); 
		map.put("publish", Integer.toString(this.isPublish() ? 1 : 0));
		map.put("keep_best", Integer.toString(this.isKeepBest() ? 1 : 0));
		return map; 
	}
}