package com.shezartech.godrej.lmsweb.dao;

import com.shezartech.godrej.lmsweb.entity.core.Course;

public interface CourseDao extends SyncEntityDao<Course, Integer> {

}
