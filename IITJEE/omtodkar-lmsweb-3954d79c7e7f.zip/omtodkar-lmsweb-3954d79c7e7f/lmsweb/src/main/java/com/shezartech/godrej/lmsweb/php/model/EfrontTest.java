package com.shezartech.godrej.lmsweb.php.model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import de.ailis.pherialize.Mixed;
import de.ailis.pherialize.Pherialize;

public class EfrontTest implements Serializable
{

	/**
     * The test fields
     *
     * @var array
     * @access public
     * @since 3.5.0
     */
    public Map<String, Object> test = new HashMap<String, Object>();

    /**
     * The content unit representing the test
     *
     * @var EfrontUnit
     * @access protected
     * @since 3.5.0
     */
    protected EfrontUnit unit;

    /**
     * The questions order
     *
     * @var array
     * @access protected
     * @since 3.5.0
     */
    protected boolean questionsOrder = false;

    /**
     * The questions in this test
     *
     * @var array
     * @access public
     * @since 3.5.0
     */
    public Map<Integer, Question> questions = new HashMap<Integer, Question>();

    /**
     * Information for done test
     *
     * @var array
     * @access protected
     * @since 3.5.0
     */
    public boolean doneInfo = false;


    public Map<String, Object> options = new HashMap<String, Object>(){{
    	put("duration", 0);
    	put("mastery_score"			, 50);
    	put("redoable"          	, 0);
    	put("onebyone"          	, 0);
    	put("answers"           	, 0);
    	put("shuffle_questions" 	, 0);
    	put("shuffle_answers"   	, 0);
    	put("given_answers"     	, 1);
    	put("show_answers_if_pass" 	, 1);
    	put("show_score"			, 1);
    	put("random_pool"       	, 0);
    	put("random_test"       	, 0);
    	put("random_test_subunits"	, 0);
    	put("random_test_common_pool", 0);
    	put("user_configurable" 	, 0);
    	put("show_incomplete"		, 0);
    	put("maintain_history"  	, 5);
    	put("display_list"      	, 0);
    	put("pause_test"        	, 1);
    	put("display_weights"   	, 1);
    	put("only_forward"			, 0);
    	put("answer_all"        	, 0);
    	put("test_password"     	, 0);
    	put("redo_wrong"			, 0);
    	put("redirect"				, 0);
    }};
    
    private static boolean auto_assigned = false;
    
    public EfrontTest(Map<String, String> test)
	{
		this.test.putAll(test);
		if(this.test.get("options") != null)
		{
			this.options.putAll(this.unserialize((String) this.test.get("options")));
		}
		
		//TODO find what is convertedDuration (public, private or protected)
	}
    
    private Map<String, Object> unserialize(String string)
    {
    	if(string != null && !string.equals(""))
    	{
    		Map<Object, Object> tempMap = Pherialize.unserialize(string).toArray();
    		Map<String, Object> tempMap2 = new HashMap<String, Object>();
    		for (Map.Entry<Object, Object> entry : tempMap.entrySet())
    		{
    			tempMap2.put(((Mixed)entry.getKey()).toString(), entry.getValue());
    		}
    		return tempMap2;
    	}
    	else return null;
    }
}