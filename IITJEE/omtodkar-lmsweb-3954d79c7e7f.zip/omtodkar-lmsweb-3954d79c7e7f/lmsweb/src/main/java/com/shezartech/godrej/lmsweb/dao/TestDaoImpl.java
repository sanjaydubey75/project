package com.shezartech.godrej.lmsweb.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.shezartech.godrej.lmsweb.entity.core.Test;

@Repository
public class TestDaoImpl extends SyncEntityDaoImpl<Test, Integer> implements
		TestDao {

	public TestDaoImpl() {
		super(Test.class);
	}

	@Override
	@Autowired
	@Qualifier("newSessionFactory")
	public void setSessionFactory(SessionFactory sessionFactory) {
		super.setSessionFactory(sessionFactory);
	}
	
	@Override
	public Test findByCourseId(int contentId)
	{
		Criteria criteria = getCurrentSession().createCriteria(entityClass);
		criteria.add(Restrictions.eq("contentId", contentId));
		return (Test) criteria.uniqueResult();
	}
	
//	@Override
//	public  getAllTests(){
//		Criteria criteria = getCurrentSession().createCriteria(Test.class);
//		Test results = criteria.list();
//		return results;
//	}

}