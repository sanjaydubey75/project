package com.shezartech.godrej.lmsweb.dao;

import com.shezartech.godrej.lmsweb.entity.core.CompletedTestBlob;

public interface CompletedTestBlobDao extends BaseDao<CompletedTestBlob, Integer>
{
	void persist(CompletedTestBlob completedTestBlob, String string);
}