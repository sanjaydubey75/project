package com.shezartech.godrej.lmsweb.entity.addmodels;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.shezartech.godrej.lmsweb.entity.core.IAddDeleteEntity;
import com.shezartech.godrej.lmsweb.entity.core.Test;

@Entity
@Table(name="tests_add")
public class TestAdd implements IAddDeleteEntity{
	
	@NotNull
	private Integer hash;
	
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(nullable = false)
	@Id
	private Test test;

	@Override
	public int getHash() {
		return hash;
	}

	@Override
	public void setHash() {
		this.hash = test.hashCode();
	}

	public Test getTest() {
		return test;
	}

	public void setTest(Test test) {
		this.test = test;
	}
}