package com.shezartech.godrej.lmsweb.entity.addmodels;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.shezartech.godrej.lmsweb.entity.core.IAddDeleteEntity;
import com.shezartech.godrej.lmsweb.entity.core.UserToCourse;

@Entity
@Table(name="users_to_courses_add")
public class UserToCourseAdd implements IAddDeleteEntity{
	
	@NotNull
	private Integer hash;
	
	@Id
	@OneToOne
	@JoinColumns({
		@JoinColumn(name="userToCourse_users_LOGIN", referencedColumnName = "users_LOGIN"),
		@JoinColumn(name="userToCourse_courses_ID", referencedColumnName = "courses_ID")
	})
	private UserToCourse userToCourse;

	@Override
	public int getHash() {
		return hash;
	}

	public void setHash() {
		this.hash = userToCourse.hashCode();
	}

	public UserToCourse getUserToCourse() {
		return userToCourse;
	}

	public void setUserToCourse(UserToCourse userToCourse) {
		this.userToCourse = userToCourse;
	}
}