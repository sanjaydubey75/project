package com.shezartech.godrej.lmsweb.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.shezartech.godrej.lmsweb.entity.core.UserToContent;

@Repository
public class UserToContentImpl extends BaseDaoImpl<UserToContent, Integer> implements UserToContentDao
{

	public UserToContentImpl()
	{
		super(UserToContent.class);
	}
	
	@Override
	@Autowired
	@Qualifier("newSessionFactory")
	public void setSessionFactory(SessionFactory sessionFactory)
	{
		super.setSessionFactory(sessionFactory);
	}

}
