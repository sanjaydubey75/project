package com.shezartech.godrej.lmsweb.controller;

import java.security.NoSuchAlgorithmException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.shezartech.godrej.lmsweb.entity.core.User;
import com.shezartech.godrej.lmsweb.request.LoginForm;
import com.shezartech.godrej.lmsweb.response.AuthenticationFailureResponse;
import com.shezartech.godrej.lmsweb.response.BaseResponse;
import com.shezartech.godrej.lmsweb.response.UserResponse;
import com.shezartech.godrej.lmsweb.service.AuthenticationService;

@RestController
@RequestMapping(value = "/api/user")
public class UserController
{
	
	@Autowired private AuthenticationService authenticationService;
	private static final Logger logger = LoggerFactory.getLogger(UserController.class);
	
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public BaseResponse getUserDetails(@RequestHeader("X-Auth-Login") String login, 
			@RequestHeader("X-Auth-Password") String password) throws NoSuchAlgorithmException
	{
		
		try
		{
			LoginForm loginForm = new LoginForm(login, password);
			if(authenticationService.authenticate(loginForm)){
				User user = authenticationService.getUser(loginForm);
				return new UserResponse(user.getName(), user.isActive());
				
			}
			else
				return new AuthenticationFailureResponse("Username or Password does not match");
		}
		catch (Exception e)
		{
			logger.error("error in UserController.getUserDetails for user login: " + login, e);
			e.printStackTrace();
			return null;
		}
	}
	
	@RequestMapping(value = "/detail", method = RequestMethod.GET)
	public BaseResponse getUserDetails1(@RequestHeader("X-Auth-Login") String login, 
			@RequestHeader("X-Auth-Password") String password) throws NoSuchAlgorithmException
	{
		
		try
		{
			LoginForm loginForm = new LoginForm(login, password);
			if(authenticationService.authenticate(loginForm)){
				User user = authenticationService.getUser(loginForm);
				return new UserResponse(user.getName(), user.isActive());
				
			}
			else
				return new AuthenticationFailureResponse("Username or Password does not match");
		}
		catch (Exception e)
		{
			logger.error("error in UserController.getUserDetails for user login: " + login, e);
			e.printStackTrace();
			return null;
		}
	}
}
