package com.shezartech.godrej.lmsweb.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.shezartech.godrej.lmsweb.entity.core.LessonToCourse;

@Repository
public class LessonToCourseDaoImpl extends
		SyncEntityDaoImpl<LessonToCourse, Long> implements LessonToCourseDao
{

	public LessonToCourseDaoImpl()
	{
		super(LessonToCourse.class);
	}

	@Override
	@Autowired
	@Qualifier("newSessionFactory")
	public void setSessionFactory(SessionFactory sessionFactory)
	{
		super.setSessionFactory(sessionFactory);
	}
	
	@Override
	public List<LessonToCourse> find(int courseId)
	{
		Criteria criteria = getCurrentSession().createCriteria(entityClass);
		criteria.add(Restrictions.eq("courseId", courseId));
		return criteria.list();
	}
}