package com.shezartech.godrej.lmsweb.php.model;

import java.util.List;
import java.util.Map;

/**
 * TrueFalseQuestion Class
 *
 * This class is used to manipulate a true / false answers question
 * @package eFront
 */
class TrueFalseQuestion extends Question
{
	public TrueFalseQuestion(Map<String, String> question, Map<Integer, String> userAnswer)
	{
		super(question);
		this.results = this.isCorrect(userAnswer, answer);
		this.score = this.results ? 100 : 0;
		
		this.setUserAnser(userAnswer);
	}

	/**
     * Correct question
     *
     * This function is used to correct the question. In order to correct it,
     * setDone() must already have been called, so that the user answer
     * is present.
     * <br/>Example:
     * <code>
     * $question = new TrueFalseQuestion(3);                                        //Instantiate question
     * $question -> setDone($answer, $score, $order);                               //Set done question information
     * $results = $question -> correct();                                           //Correct question
     * </code>
     *
     * @return array The correction results
     * @since 3.5.0
     * @access public
     */
    public void correct() //TODO implement this
    {
//    	this.userAnswer;
//        is_numeric($this -> answer) && is_numeric($this -> userAnswer) && $this -> answer == $this -> userAnswer ? $results = array('correct' => true, 'score' => 1) : $results = array('correct' => false, 'score' => 0);//We put the is_numeric() here, because the results might be strings or ints, which should be equal, or false or '', which are always wrong
//        return $results;
    }

    /**
     * Set question done information
     *
     * This question is used to set its done information. This information consists of
     * the user answer, the score and the answers order.
     * <br/>Example:
     * <code>
     * $question = new TrueFalseQuestion(3);                                        //Instantiate question
     * $question -> setDone($answer, $score);                                       //Set done question information
     * </code>
     *
     * @param array $userAnswer The user answer
     * @param float score The user's score in this question
     * @param array $order the question options order, not applicable to this question type
     * @since 3.5.0
     * @access public
     */
    public void setDone(List<String> userAnswer, boolean score, boolean order) //TODO implement this
    {
//        $this -> userAnswer = $userAnswer;
//        $score !== false ? $this -> score = $score : null;
    }
    
    private boolean isCorrect(Map<Integer, String> userAnswer, Object answer)
    {
//    	if(userAnswer.size() != 2) return false;
    	/*
    	 * "userAnswer" - user answer - return value 
    	 * (0,0), (1,0) - no answer - false;
    	 * (0,1), (1,1) - two answer - false;
    	 * (0,1), (1,0) - false - gotta check
    	 * (0,0), (1,1) - true - gotta check
    	 */
    	int a = Integer.parseInt(userAnswer.get(0));
    	int b = Integer.parseInt(userAnswer.get(1));
    	
    	if(a == 1 && b == 0 && answer.equals("0"))
    		return true;
    	if(a == 0 && b == 1 && answer.equals("1"))
    		return true;
    	return false;
    }
    
    private void setUserAnser(Map<Integer, String> userAnswer)
    {
    	if(userAnswer.get(0).equals("1"))
    	{
    		this.userAnswer = "1";
    	}
    	else if(userAnswer.get(1).equals("1"))
    	{
    		this.userAnswer = "0";
    	}
    }
}