package com.shezartech.godrej.lmsweb.controller;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailSendException;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.shezartech.godrej.lmsweb.request.LoginForm;
import com.shezartech.godrej.lmsweb.response.AuthenticationFailureResponse;
import com.shezartech.godrej.lmsweb.response.BaseResponse;
import com.shezartech.godrej.lmsweb.response.FailureResponse;
import com.shezartech.godrej.lmsweb.response.SuccessResponse;
import com.shezartech.godrej.lmsweb.service.AuthenticationService;
import com.shezartech.godrej.lmsweb.service.MailService;

@RestController
@RequestMapping(value = "/api/support")
public class SupportController
{
	private static final Logger logger = LoggerFactory
			.getLogger(SupportController.class);

	@Autowired
	private MailService mailService;

	@Autowired
	private AuthenticationService authenticationService;

	@RequestMapping(value = "/sendMail", method = RequestMethod.POST)
	public BaseResponse contact(@RequestBody Map<String, String> data,
			@RequestHeader("X-Auth-Login") String login,
			@RequestHeader("X-Auth-Password") String password)
	{
		LoginForm loginForm = new LoginForm(login, password);

		try
		{
			if (authenticationService.authenticate(loginForm))
			{
				mailService.sendMail(data.get("phoneNumber"), data.get("email"), data.get("typeOfQuery"),data.get("feedback"));
				return new SuccessResponse();
			}
			else
			{
				return new AuthenticationFailureResponse("Username or Password does not match");
			}
		}
		catch (MailSendException exception)
		{
			return new FailureResponse("Email could not be send. Please verify your email address.");
		}
		catch (Exception e)
		{
			logger.error("error in SupportController.contact for user login: " + login, e);
			e.printStackTrace();
			return null;
		}		
	}
}
