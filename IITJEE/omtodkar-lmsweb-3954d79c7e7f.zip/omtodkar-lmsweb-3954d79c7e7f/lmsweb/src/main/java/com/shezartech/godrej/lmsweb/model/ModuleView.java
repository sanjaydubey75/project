package com.shezartech.godrej.lmsweb.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

public class ModuleView {

	public int id;
	
	@JsonInclude(Include.NON_NULL)
	public String name;
	
	public boolean exists;

	public ModuleView(int id, String name, boolean exists) {
		super();
		this.id = id;
		this.name = name;
		this.exists = exists;
	}
}