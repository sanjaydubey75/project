package com.shezartech.godrej.lmsweb.dao;

import java.util.List;
import com.shezartech.godrej.lmsweb.entity.core.Test;
import com.shezartech.godrej.lmsweb.model.LessonSyncViewModel.TestViewModel;

public interface TestDao extends SyncEntityDao<Test, Integer>
{

	Test findByCourseId(int contentId);

//	List<TestViewModel> getAllTests();

}
