package com.shezartech.godrej.lmsweb.response;

import java.util.List;

import com.shezartech.godrej.lmsweb.entity.core.Direction;

public class DirectionResponse extends BaseResponse
{
	public List<Direction> directions;

	public DirectionResponse(List<Direction> directions)
	{
		super(true, "");
		this.directions = directions;
	}

}
