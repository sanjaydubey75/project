package com.shezartech.iitjeeacademy.ui.activity;

import java.util.ArrayList;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.TABLE_SUBJECTS_DETAILS;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.NAME;
import com.shezartech.iitjeeacademy.db.DBHelper;
import com.shezartech.iitjeeacademy.service.GetServiceConnector;
import com.shezartech.iitjeeacademy.util.AppUtil;
import com.shezartech.iitjeeacademy.util.DialogUtil;

public class HomeActivity extends Activity{

	//private String TAG = "HomeActivity-->";
	private TextView tvName;
	private TextView tvAIR;
	private TextView tvSR;
	private TextView tvPhyLevel;
	private TextView tvCheLevel;
	private TextView tvMathLevel;
	private Button btnStartPractice;
	private DialogUtil dialogUtil;
	
	private String userEmail = "";
	private String token = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_layout);
        tvName = (TextView)findViewById(R.id.tv_user_name);
        tvAIR = (TextView)findViewById(R.id.tv_current_all_india_rank);
        tvSR = (TextView)findViewById(R.id.tv_current_state_rank);
        tvPhyLevel = (TextView)findViewById(R.id.tv_physics_level);
        tvCheLevel = (TextView)findViewById(R.id.tv_chemistry_level);
        tvMathLevel = (TextView)findViewById(R.id.tv_mathematics_level);
        
        btnStartPractice = (Button)findViewById(R.id.btn_start_practice);
        dialogUtil = new DialogUtil(HomeActivity.this);
        Bundle extras = getIntent().getExtras(); 
        if (extras != null) {
        	tvName.setText(extras.getString("NAME"));
        	tvAIR.setText(extras.getString("AIR"));
        	tvSR.setText(extras.getString("SR"));
        	tvPhyLevel.setText(extras.getString("PHY_LEVEL"));
        	tvCheLevel.setText(extras.getString("CHE_LEVEL"));
        	tvMathLevel.setText(extras.getString("MATH_LEVEL"));
        	
        	userEmail = extras.getString("EMAIL");
        	token = extras.getString("TOKEN");
        	
        	AppUtil.saveDataInSharedPreferences(HomeActivity.this, NAME, tvName.getText().toString());
        }       
        addListnerOnButton();
        if(AppUtil.isOnline(HomeActivity.this)){
	    	GetServiceConnector serviceConnector = new GetServiceConnector(HomeActivity.this);
		   	serviceConnector.execute(getResources().getString(R.string.server_domain)+getResources().getString(R.string.get_subject_service), userEmail, token);
	    }else{
	    	dialogUtil.showAlert("Internet Error",getResources().getString(R.string.alert_internet_unavailable_message));
	    }
    }
    
    public void addListnerOnButton(){
    	btnStartPractice.setOnClickListener(new OnClickListener() {
    		@Override
 		   	public void onClick(View v) {
    			ArrayList<String> listOfSubjectName = new ArrayList<String>();
 			   	DBHelper dbHelper =new DBHelper(HomeActivity.this);
 			   	listOfSubjectName = dbHelper.selectSubjectName(TABLE_SUBJECTS_DETAILS);
 			   	DialogUtil dialogUtil = new DialogUtil(HomeActivity.this);
 			   	dialogUtil.showChoiceAlert(listOfSubjectName, tvCheLevel.getText().toString(), tvMathLevel.getText().toString(), tvPhyLevel.getText().toString());
 		   }
 	   });
    }
}