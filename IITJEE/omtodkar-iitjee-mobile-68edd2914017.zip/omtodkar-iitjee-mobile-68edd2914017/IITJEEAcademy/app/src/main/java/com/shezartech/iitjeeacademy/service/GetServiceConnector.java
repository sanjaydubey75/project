package com.shezartech.iitjeeacademy.service;

import static com.shezartech.iitjeeacademy.db.DBTablesColumns.CURRECT_ANSWER;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.OPTION_A;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.OPTION_A_PIC;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.OPTION_B;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.OPTION_B_PIC;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.OPTION_C;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.OPTION_C_PIC;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.OPTION_D;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.OPTION_D_PIC;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.QUESTION;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.QUESTION_PIC_URL;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.TABLE_SUBJECTS_DETAILS;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.TABLE_TOPIC_DETAILS;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.TOKEN;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.SocketTimeoutException;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.json.JSONArray;
import org.json.JSONObject;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import com.shezartech.iitjeeacademy.db.DBHelper;
import com.shezartech.iitjeeacademy.ui.activity.R;
import com.shezartech.iitjeeacademy.util.AppUtil;
import com.shezartech.iitjeeacademy.util.DialogUtil;

public class GetServiceConnector extends AsyncTask<String, Integer, String> {

	private static final String TAG = "GetServiceConnector-->";
	private Context context;
	private String message;
	private String status = "failed";
	private String response;
	
	private String userEmail;
	private String token;
	private DBHelper dbHelper;
	private DialogUtil dialogUtil;
	public GetServiceConnector(Context c){
		this.context = c;
		dialogUtil = new DialogUtil(context);
		
		dbHelper = new DBHelper(context);
	}
	
	@Override
	protected void onPreExecute() {
		super.onPreExecute();
		dialogUtil.showProgressDialog(context.getResources().getString(R.string.progress_dialog_title), context.getResources().getString(R.string.progress_dialog_message));
	}
	 
    @Override
	protected String doInBackground(String... urls) {        	
//		String url = urls[0];
//		String userEmail = urls[1];
//		String token = urls[2];
		if(urls[0].contains("subject")){
			dbHelper.deleteAllRowsFromTable(TABLE_SUBJECTS_DETAILS);
			dbHelper.deleteAllRowsFromTable(TABLE_TOPIC_DETAILS);
			if(executeGetMethodWithoutRequest(urls[0], urls[1], urls[2])){
				if(executeGetMethodWithoutRequest(context.getResources().getString(R.string.server_domain)+context.getResources().getString(R.string.get_topic_service)+"CHE", userEmail, token)){
					if(executeGetMethodWithoutRequest(context.getResources().getString(R.string.server_domain)+context.getResources().getString(R.string.get_topic_service)+"MAT", userEmail, token)){
						executeGetMethodWithoutRequest(context.getResources().getString(R.string.server_domain)+context.getResources().getString(R.string.get_topic_service)+"PHY", userEmail, token);
					}
				}
			}
		}else if(urls[0].contains("question")){
			executeGetMethodWithoutRequest(urls[0], urls[1], urls[2]);
		}else if(urls[0].contains("state")){
			executeGetMethod(urls[0],token);
		}else if(urls[0].contains("institute")){
			executeGetMethod(urls[0],token);
		}
		return message;
    }
    
    @Override
    protected void onPostExecute(String result) {
    	super.onPostExecute(result);
    	dialogUtil.hideProgressDialog();
    	Log.d(TAG, "onPostExecute =  result = "+result); 
    	if(status.equals("success")){
    		
    	}else{
    		dialogUtil.showAlert("Oops!",result);
    	}
    }
	
    public boolean executeGetMethodWithoutRequest(String url,  String email, String tok) {
		Log.d(TAG, "--In executeGetMethodWithoutRequest()--");
		Log.d(TAG, "url = "+url);
		boolean isResponseOK = false;		
		
		try {
			DefaultHttpClient httpClient = getHttpClient();
			HttpGet httpGet = new HttpGet(url);
			
			httpGet.setHeader("X-XSRF-TOKEN",context.getResources().getString(R.string.CSRF_TOKEN));
			httpGet.setHeader("Cookie","csrf-token="+context.getResources().getString(R.string.CSRF_TOKEN)+"; auth-token="+tok);
			httpGet.setHeader("role","student");
			httpGet.setHeader("userEmail",email);
			userEmail = email;
			HttpResponse httpResponse = httpClient.execute(httpGet);			
			Log.d(TAG, "status = " + httpResponse.getStatusLine().getStatusCode());
			Log.d(TAG, "status phrase = " + httpResponse.getStatusLine().getReasonPhrase());
			
			if (httpResponse.getStatusLine().getStatusCode() == 200) {
				HttpEntity entity = httpResponse.getEntity();
				if (entity != null) {
					isResponseOK = true;
					InputStream inputStream = entity.getContent();
					response = convertToString(inputStream);
					Log.d(TAG, "response = "+response);
					
					JSONObject objResponse = (new JSONObject(response)).getJSONObject("response");
		    		status = objResponse.getString("status");
					message = objResponse.getString("message");
					Log.d(TAG, "status = "+status);
					if(status.equals("success")){
						Header header[] = httpResponse.getHeaders("Set-Cookie");
						token = header[0].getValue().split("=")[1].split(";")[0];
						Log.e(TAG, "token = "+token);
						AppUtil.saveDataInSharedPreferences(context, TOKEN, token);
						parseResponse(response);
					}
				}else{
					Log.e(TAG, "Empty Resposne");  
					status = "failed";
					message = "Empty Response! Not able to communicate with Server Please try again after some time.";
				}
			}else{
				Log.e(TAG, "SERVICE_STATUS_ERROR: " + httpResponse.getStatusLine().getReasonPhrase());
				status = "failed";
				message = httpResponse.getStatusLine().getReasonPhrase();
			}
		}catch (SocketTimeoutException exp){
            Log.e(TAG, "Service connection time out Error: " + exp.getMessage());
            status = "failed";
            message = exp.getMessage();
        }catch(Throwable t){
			Log.e(TAG, "SERVICE_CONNECTION_ERROR = " + t.getMessage());
			status = "failed";
			message = "Service Connection Error! Please try again after some time.";
		}
		return isResponseOK;
	}
    
    public boolean executeGetMethod(String url,  String tok) {
		Log.d(TAG, "--In executeGetMethodWithoutRequest()--");
		Log.d(TAG, "url = "+url);
		boolean isResponseOK = false;		
		
		try {
			DefaultHttpClient httpClient = getHttpClient();
			HttpGet httpGet = new HttpGet(url);
			
			httpGet.setHeader("X-XSRF-TOKEN",context.getResources().getString(R.string.CSRF_TOKEN));
			httpGet.setHeader("Cookie","csrf-token="+context.getResources().getString(R.string.CSRF_TOKEN)+"; auth-token="+tok);
			HttpResponse httpResponse = httpClient.execute(httpGet);			
			Log.d(TAG, "status = " + httpResponse.getStatusLine().getStatusCode());
			Log.d(TAG, "status phrase = " + httpResponse.getStatusLine().getReasonPhrase());
			
			if (httpResponse.getStatusLine().getStatusCode() == 200) {
				HttpEntity entity = httpResponse.getEntity();
				if (entity != null) {
					isResponseOK = true;
					InputStream inputStream = entity.getContent();
					response = convertToString(inputStream);
					JSONObject objResponse = (new JSONObject(response)).getJSONObject("response");
		    		status = objResponse.getString("status");
					message = objResponse.getString("message");
					Log.d(TAG, "status = "+status);
					if(status.equals("success")){
						Log.e(TAG, "token = "+token);
						parseResponse(response);
					}
				} else {
					Log.e(TAG, "Empty Resposne");  
					status = "failed";
					message = "Empty Response! Not able to communicate with Server Please try again after some time.";
				}
			} else {
				Log.e(TAG, "SERVICE_STATUS_ERROR: " + httpResponse.getStatusLine().getReasonPhrase());
				status = "failed";
				message = httpResponse.getStatusLine().getReasonPhrase();
			}
		} catch (SocketTimeoutException exp) {
            Log.e(TAG, "time out error: " + exp.getMessage());
            status = "failed";
            message = exp.getMessage();
        } catch (Throwable t) {
			Log.e(TAG, "SERVICE_CONNECTION_ERROR = " + t.getMessage());
			status = "failed";
			message = "Service Connection Error! Please try again after some time.";
		}
		return isResponseOK;
	}
    
    private void parseResponse(String response){
    	try{
    		Log.d(TAG, "response = "+response);
			if(response.contains("subjects")){
				JSONObject objResponse = new JSONObject(response);
				JSONArray arrSubject = objResponse.getJSONArray("subjects");
				
				for(int i = 0; i < arrSubject.length(); i++){
					JSONObject objSubject = arrSubject.getJSONObject(i);
					String id = objSubject.getString("id");
					String name = objSubject.getString("name");
					dbHelper.insertSubjectDetails(id, name);
				}
			}else if(response.contains("topics")){
				JSONObject objResponse = new JSONObject(response);
				JSONArray arrSubject = objResponse.getJSONArray("topics");
				
				for(int i = 0; i < arrSubject.length(); i++){
					JSONObject objSubject = arrSubject.getJSONObject(i);
					String id = objSubject.getString("id");
					String name = objSubject.getString("name");
					String subjectId = objSubject.getString("subject_id");
					dbHelper.insertTopicDetails(id, name, subjectId);
				}
			}else if(response.contains("questionDescription")){
				JSONObject objQuestion = (new JSONObject(response)).getJSONObject("questionDescription");
	    		String id = objQuestion.getString("id");
				String question = objQuestion.getString("question");
				String questionPicURL = objQuestion.getString("pic");
				
				Log.d(TAG, "id = "+id);
				Log.d(TAG, "question = "+question);
				Log.d(TAG, "questionPicURL = "+questionPicURL);
				
				JSONObject objAnswer = (new JSONObject(response)).getJSONObject("answerArray");
				JSONObject objOptionA = objAnswer.getJSONObject("A");
				
				String optionA = objOptionA.getString("content");
				String optionAPic = objOptionA.getString("pic");
				Log.d(TAG, "optionA = "+optionA);
				Log.d(TAG, "optionAPic = "+optionAPic);
				
				JSONObject objOptionB = objAnswer.getJSONObject("B");
				
				String optionB = objOptionB.getString("content");
				String optionBPic = objOptionB.getString("pic");
				Log.d(TAG, "optionB = "+optionB);
				Log.d(TAG, "optionBPic = "+optionBPic);
				
				JSONObject objOptionC = objAnswer.getJSONObject("C");
				
				String optionC = objOptionC.getString("content");
				String optionCPic = objOptionC.getString("pic");
				Log.d(TAG, "optionC = "+optionC);
				Log.d(TAG, "optionCPic = "+optionCPic);
				
				JSONObject objOptionD = objAnswer.getJSONObject("D");
				
				String optionD = objOptionD.getString("content");
				String optionDPic = objOptionD.getString("pic");
				Log.d(TAG, "optionD = "+optionD);
				Log.d(TAG, "optionDPic = "+optionDPic);
				
				String correctAnswer = objAnswer.getString("correctAnswer");
				Log.d(TAG, "correctAnswer = "+correctAnswer);
				
				AppUtil.saveDataInSharedPreferences(context, QUESTION, question);
				AppUtil.saveDataInSharedPreferences(context, QUESTION_PIC_URL, questionPicURL);
				
				AppUtil.saveDataInSharedPreferences(context, OPTION_A, optionA);
				AppUtil.saveDataInSharedPreferences(context, OPTION_A_PIC, optionAPic);
				
				AppUtil.saveDataInSharedPreferences(context, OPTION_B, optionB);
				AppUtil.saveDataInSharedPreferences(context, OPTION_B_PIC, optionBPic);
				
				AppUtil.saveDataInSharedPreferences(context, OPTION_C, optionC);
				AppUtil.saveDataInSharedPreferences(context, OPTION_C_PIC, optionCPic);
				
				AppUtil.saveDataInSharedPreferences(context, OPTION_D, optionD);
				AppUtil.saveDataInSharedPreferences(context, OPTION_D_PIC, optionDPic);
				
				AppUtil.saveDataInSharedPreferences(context, CURRECT_ANSWER, correctAnswer.toUpperCase());
				Log.d(TAG, "correctAnswer.toUpperCase()--------->>"+correctAnswer.toUpperCase());
//				if(!context.toString().contains("MainActivity")){
//					Log.d(TAG, "!context.toString().contains(MainActivity) = "+!context.toString().contains("MainActivity"));
//					Intent i = new Intent(context, MainActivity.class);
//					context.startActivity(i);
//				}
			}else if(response.contains("states")){
				JSONArray jsonArrayStatus = (new JSONObject(response).getJSONArray("states"));	
				for(int i=0;i<jsonArrayStatus.length();i++){
					String stateName = jsonArrayStatus.getString(i);
					DBHelper dbHelper = new DBHelper(context);
					dbHelper.insertStates(stateName); 
				}    	
			}else if(response.contains("institutes")){
				JSONArray jsonArrayInstitutes = (new JSONObject(response).getJSONArray("institutes"));	
				for(int i=0;i<jsonArrayInstitutes.length();i++){
					String instituteName = jsonArrayInstitutes.getString(i);
					DBHelper dbHelper = new DBHelper(context);
					dbHelper.insertInstitute(instituteName);
				}    	
			}	
			
        }catch(Exception e){
        	e.printStackTrace(); 
        }
    }
   
    public String convertToString(InputStream inputStream){
        StringBuffer string = new StringBuffer();
        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
        String line;
        try {
            while ((line = reader.readLine()) != null) {
                string.append(line + "\n");
            }
        } catch (IOException e) {}
        
        return string.toString();
    }
    
	public static DefaultHttpClient getHttpClient() {
		HttpParams httpParams = new BasicHttpParams();
		HttpConnectionParams.setConnectionTimeout(httpParams, 40000);
		HttpConnectionParams.setSoTimeout(httpParams, 40000);
		DefaultHttpClient httpClient = new DefaultHttpClient(httpParams);	
		return httpClient;
	}
}