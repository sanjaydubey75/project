package com.shezartech.iitjeeacademy.db;

public class DBTablesColumns {

	/**Tables Name*/
	public static final String TABLE_SUBJECTS_DETAILS = "SubjectDetails";
	public static final String TABLE_TOPIC_DETAILS = "TopicDetails";
	public static final String TABLE_STATES = "States";
	public static final String TABLE_INSTITUTES = "Institutes";
	
	/**Column Name*/
	public static final String ID = "Id";
	public static final String NAME = "Name";
	public static final String SUBJECT = "Subject";
	public static final String STATES_NAME = "StatesName";
	
	/**SharedPreferences Name*/
	public static final String LOGIN_ID = "LoginId";
	public static final String PASSWORD = "Password";
	
	public static final String REMEMBER_OFF_LOGIN_ID = "LoginId";
	public static final String REMEMBER_OFF_PASSWORD = "Password";
	
	public static final String TOKEN = "Token";
	
	public static final String SUBJECT_ID = "SubjectId";
	public static final String TOPIC_ID = "TopicId";
	public static final String LEVEL = "Level";
	
	public static final String QUESTION = "Question";
	public static final String QUESTION_PIC_URL = "QuestionPic";
	
	public static final String OPTION_A = "OptionA";
	public static final String OPTION_A_PIC = "OptionAPic";
	
	public static final String OPTION_B = "OptionB";
	public static final String OPTION_B_PIC = "OptionBPic";
	
	public static final String OPTION_C = "OptionC";
	public static final String OPTION_C_PIC = "OptionCPic";
	
	public static final String OPTION_D = "OptionD";
	public static final String OPTION_D_PIC = "OptionDPic";
	
	public static final String CURRECT_ANSWER = "CurrectAnswer";
	
	////////////////////////////////////////////////////////////
	public static final String FIRST_NAME = "FristName";
	public static final String LAST_NAME = "LastName";
	public static final String INSTITUTE_NAME = "InstituteName";
	public static final String MOBILE_NO = "MobileNo";
	
	public static final String EMAIL_ID = "EmailId";
	public static final String DATE_OF_BIRTH = "DateOfBirth";
	public static final String TARGETED_YEAR = "TargetedYear";
	public static final String EMAIL_ID_OF_PARENTS = "ParentsEmailId";
	
	public static final String STATE = "State";
	public static final String CONFIRM_PASSWORD = "ConfirmPasswprd";
	
	public static final String SUBSCRIPTION_MODEL = "Model";
	
	public static final String USER_REGISTRATION_REQUEST = "RegistrationRequest";
	
	public static final String USER_REGISTRATION_FIELDS_VALIDATION_REQUEST = "ValidateRegistrationFields";
	
	public static final String TRANSACTION_ID = "TransactionId";

	public static final String TRANSACTION_STATUS = "TransactionStatus";
	public static final String INVOICE_NO = "InvoiceNo";
	public static final String TRANSACTION_DATE = "TransactionDate";
	public static final String AMOUNT_PAID = "AmountPaid";
	public static final String SUBSCRIPTION_DURATION = "SubscriptionDuration";
	public static final String COUPON_CODE = "CouponCode";
	
	public static final String REDIRECT_STATUS = "RedirectStatus";
}
