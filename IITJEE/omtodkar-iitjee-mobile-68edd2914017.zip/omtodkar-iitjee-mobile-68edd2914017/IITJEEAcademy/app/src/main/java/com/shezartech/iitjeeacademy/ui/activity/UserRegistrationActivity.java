package com.shezartech.iitjeeacademy.ui.activity;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.regex.Pattern;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import com.shezartech.iitjeeacademy.db.DBHelper;
import com.shezartech.iitjeeacademy.service.PostServiceConnector;
import com.shezartech.iitjeeacademy.util.AppUtil;
import com.shezartech.iitjeeacademy.util.DialogUtil;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.EMAIL_ID;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.FIRST_NAME;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.LAST_NAME;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.MOBILE_NO;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.INSTITUTE_NAME;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.COUPON_CODE;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.USER_REGISTRATION_REQUEST;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.USER_REGISTRATION_FIELDS_VALIDATION_REQUEST;

public class UserRegistrationActivity extends Activity implements  OnItemClickListener, OnItemSelectedListener{

	private String TAG = "UserRegistrationActivity-->";
	private EditText etFirstName;
	private EditText etLastName;
	private AutoCompleteTextView autoCompleteTVInstitute;
	private EditText etMobileNo;
	private EditText etEmail;
	private EditText etDateOfBirth;
	private EditText etTargetedYear;
	private EditText etParentsEmail;
	private EditText etPassword;
	private EditText etConfirmPassword;
	private EditText etCouponCode;
	
	private AutoCompleteTextView autoCompleteTVState;
	private Button btnSignUp;
	private DialogUtil dialogUtil;
	private ArrayAdapter<String> arrayAdapterInstitutes;
	private ArrayAdapter<String> arrayAdapterState;
	
	private ArrayList<String> listOfStates;
	private ArrayList<String> listOfInstitutes;
	private DBHelper dbHelper;
	private String stateName = "";
	
	private int year;
    private int month;
    private int day;
 
    static final int DATE_PICKER_ID = 1111;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_registration_layout);
        etFirstName = (EditText)findViewById(R.id.et_first_name);
        etLastName = (EditText)findViewById(R.id.et_last_name);
        autoCompleteTVInstitute = (AutoCompleteTextView)findViewById(R.id.tv_auto_complete_institute);
        etMobileNo = (EditText)findViewById(R.id.et_mobile_no);
        etEmail = (EditText)findViewById(R.id.et_email_id);
        etDateOfBirth = (EditText)findViewById(R.id.et_date_of_birth);
        etParentsEmail = (EditText)findViewById(R.id.et_parent_email_id);
        etTargetedYear = (EditText)findViewById(R.id.et_targeted_year);
        
        autoCompleteTVState = (AutoCompleteTextView)findViewById(R.id.tv_auto_complete_states);
        etPassword = (EditText)findViewById(R.id.et_password);
        etConfirmPassword = (EditText)findViewById(R.id.et_confirm_password);
        
        etCouponCode = (EditText)findViewById(R.id.et_coupon_code);
        
        btnSignUp = (Button)findViewById(R.id.btn_sign_up);
        dialogUtil = new DialogUtil(UserRegistrationActivity.this);
        
        dbHelper = new DBHelper(UserRegistrationActivity.this);
        
        listOfInstitutes = new ArrayList<String>();
        listOfInstitutes = dbHelper.selectInstitute();
        
        listOfStates = new ArrayList<String>();
        listOfStates = dbHelper.selectState();
        
        arrayAdapterInstitutes = new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line, listOfInstitutes);
        arrayAdapterState = new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line, listOfStates);
        
        autoCompleteTVInstitute.setThreshold(1);
        autoCompleteTVInstitute.setAdapter(arrayAdapterInstitutes);
        autoCompleteTVInstitute.setOnItemSelectedListener(UserRegistrationActivity.this);
        autoCompleteTVInstitute.setOnItemClickListener(UserRegistrationActivity.this);
        
        autoCompleteTVState.setThreshold(1);
        autoCompleteTVState.setAdapter(arrayAdapterState);
        autoCompleteTVState.setOnItemSelectedListener(UserRegistrationActivity.this);
        autoCompleteTVState.setOnItemClickListener(UserRegistrationActivity.this);
        
        etDateOfBirth.setOnClickListener(new OnClickListener()  {
			@SuppressWarnings("deprecation")
			@Override
			public void onClick(View arg0) {
				 showDialog(DATE_PICKER_ID);
			}
		});
        addListenerOnButton();
    }
    
    @Override
    protected Dialog onCreateDialog(int id){
        switch(id){
        case DATE_PICKER_ID:
        	Calendar c = Calendar.getInstance();
        	int mYear = c.get(Calendar.YEAR);
        	int mMonth = c.get(Calendar.MONTH);
        	int mDay = c.get(Calendar.DAY_OF_MONTH);
            return new DatePickerDialog(UserRegistrationActivity.this, pickerListener, mYear, mMonth,mDay);
        }
        return null;
    }
 
    private DatePickerDialog.OnDateSetListener pickerListener = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker view, int selectedYear,int selectedMonth, int selectedDay) {
        	year  = selectedYear;
            month = selectedMonth;
            day   = selectedDay;
 
            etDateOfBirth.setText(new StringBuilder()
            .append(month+1).append("/").append(day).append("/")
            .append(year));
            Log.d(TAG, "isAfterToday(year, month+1, day) = "+isAfterToday(year, month+1, day));
        }
    };
    
    private void addListenerOnButton(){
    	btnSignUp.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				if(validation()){
					String emailArr[] = etEmail.getText().toString().split("@");
					String email = emailArr[0]+"%40"+emailArr[1];
					
					AppUtil.saveDataInSharedPreferences(getApplicationContext(), EMAIL_ID, email);
					AppUtil.saveDataInSharedPreferences(getApplicationContext(), FIRST_NAME, etFirstName.getText().toString());
					AppUtil.saveDataInSharedPreferences(getApplicationContext(), LAST_NAME, etLastName.getText().toString());
					AppUtil.saveDataInSharedPreferences(getApplicationContext(), MOBILE_NO, etMobileNo.getText().toString());
					
					AppUtil.saveDataInSharedPreferences(getApplicationContext(), INSTITUTE_NAME, autoCompleteTVInstitute.getText().toString());
					AppUtil.saveDataInSharedPreferences(getApplicationContext(), COUPON_CODE, etCouponCode.getText().toString());
					
					
					AppUtil.saveDataInSharedPreferences(getApplicationContext(), USER_REGISTRATION_REQUEST, buildJSONRequestToRegisterUser());
					AppUtil.saveDataInSharedPreferences(getApplicationContext(), USER_REGISTRATION_FIELDS_VALIDATION_REQUEST, buildJSONRequestToValidateRegistrationFields());
					
               	 	if(AppUtil.isOnline(UserRegistrationActivity.this)){
				    	PostServiceConnector serviceConnector = new PostServiceConnector(UserRegistrationActivity.this);
					   	serviceConnector.execute(getResources().getString(R.string.server_domain)+getResources().getString(R.string.validate_registration_fields_service), buildJSONRequestToValidateRegistrationFields());
				    }else{
				    	dialogUtil.showAlert("Internet Error",getResources().getString(R.string.alert_internet_unavailable_message));
				    }
            
//					String request = buildJSONRequest();
//					if(AppUtil.isOnline(UserRegistrationActivity.this)){
//						PostServiceConnector serviceConnector = new PostServiceConnector(UserRegistrationActivity.this);
//						serviceConnector.execute(getResources().getString(R.string.server_domain)+getResources().getString(R.string.user_registration_service), request);
//					}else{
//						dialogUtil.showAlert("Internet Error",getResources().getString(R.string.alert_internet_unavailable_message));
//					}
				}
			}
		});
    }
    
    @Override
    public void onItemSelected(AdapterView<?> arg0, View arg1, int position,long arg3){
    }
 
    @Override
    public void onNothingSelected(AdapterView<?> arg0){
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
    }
 
    @Override
    public void onItemClick(AdapterView<?> arg0, View arg1, int position, long arg3){
    	stateName = autoCompleteTVState.getText().toString();
        Log.d(TAG, "stateName = "+stateName);
        
        autoCompleteTVInstitute.getText().toString();
    }
    
    private String buildJSONRequestToRegisterUser(){
    	String firstName = etFirstName.getText().toString();
    	String lastName = etLastName.getText().toString();
    	String instituteName = autoCompleteTVInstitute.getText().toString();
    	String mobileNo = etMobileNo.getText().toString();
    	String emailId = etEmail.getText().toString();
    	String dateOfBirth = etDateOfBirth.getText().toString();
    	String targetedYear = etTargetedYear.getText().toString();
    	String parentsEmail = etParentsEmail.getText().toString();
    	String password = etPassword.getText().toString();
    	String confirmPassword = etConfirmPassword.getText().toString();
    	String couponCode = etCouponCode.getText().toString();
    	stateName = autoCompleteTVState.getText().toString();
    	Log.d(TAG, "firstName = "+firstName);
    	Log.d(TAG, "lastName = "+lastName);
    	Log.d(TAG, "instituteName = "+instituteName);
    	Log.d(TAG, "mobileNo = "+mobileNo);
    	Log.d(TAG, "emailId = "+emailId);
    	Log.d(TAG, "dateOfBirth = "+dateOfBirth);
    	Log.d(TAG, "stateName = "+stateName);
    	Log.d(TAG, "password = "+password);
    	Log.d(TAG, "confirmPassword = "+confirmPassword);
    	Log.d(TAG, "couponCode = "+couponCode);
    	
    	String request = "{'firstname':'"+firstName+"','lastname':'"+lastName+"','institution':'"+instituteName+"','state':'"+stateName+"','mobilenumber':'"+mobileNo+"','email':'"+emailId+"','dateOfBirth':'"+dateOfBirth+"','year':'"+targetedYear+"','parentEmail':'"+parentsEmail+"','password':'"+password+"','confirmpassword':'"+confirmPassword+"','role':'student','couponcode':'"+couponCode+"'";
    	request = request.replace("'", "\"");                               
    	return request;
    }
    
    private String buildJSONRequestToValidateRegistrationFields(){
    	String firstName = etFirstName.getText().toString();
    	String lastName = etLastName.getText().toString();
    	String instituteName = autoCompleteTVInstitute.getText().toString();
    	String mobileNo = etMobileNo.getText().toString();
    	String emailId = etEmail.getText().toString();
    	String dateOfBirth = etDateOfBirth.getText().toString();
    	String targetedYear = etTargetedYear.getText().toString();
    	String parentsEmail = etParentsEmail.getText().toString();
    	String password = etPassword.getText().toString();
    	String confirmPassword = etConfirmPassword.getText().toString();
    	String couponCode = etCouponCode.getText().toString();
    	
    	Log.d(TAG, "firstName = "+firstName);
    	Log.d(TAG, "lastName = "+lastName);
    	Log.d(TAG, "instituteName = "+instituteName);
    	Log.d(TAG, "mobileNo = "+mobileNo);
    	Log.d(TAG, "emailId = "+emailId);
    	Log.d(TAG, "dateOfBirth = "+dateOfBirth);
    	Log.d(TAG, "stateName = "+stateName);
    	Log.d(TAG, "password = "+password);
    	Log.d(TAG, "confirmPassword = "+confirmPassword);
    	Log.d(TAG, "couponCode = "+couponCode);
    	
    	String request = "{'firstname':'"+firstName+"','lastname':'"+lastName+"','institution':'"+instituteName+"','state':'"+stateName+"','mobilenumber':'"+mobileNo+"','email':'"+emailId+"','dateOfBirth':'"+dateOfBirth+"','year':'"+targetedYear+"','parentEmail':'"+parentsEmail+"','password':'"+password+"','confirmpassword':'"+confirmPassword+"','role':'student','couponcode':'"+couponCode+"'}";
    	request = request.replace("'", "\"");                               
    	return request;
    }
    
    public static boolean isAfterToday(int year, int month, int day){
        Calendar today = Calendar.getInstance();
        Calendar myDate = Calendar.getInstance();

        myDate.set(year, month, day);

        if (myDate.after(today)) {
            return false;
        }
        return true;
    }
    
    private boolean validation(){
    	boolean isValidate = false;
    	if(etFirstName.length() <= 0){
    		dialogUtil.showAlert(getResources().getString(R.string.alert_title), getResources().getString(R.string.alert_first_name));
    	}else if(etLastName.length() <= 0){
    		dialogUtil.showAlert(getResources().getString(R.string.alert_title), getResources().getString(R.string.alert_last_name));
    	}else if(autoCompleteTVInstitute.length() <= 0){
    		dialogUtil.showAlert(getResources().getString(R.string.alert_title), getResources().getString(R.string.alert_institute_name));
    	}else if (!MOBILE_NO_PATTERN.matcher(etMobileNo.getText()).matches()){
    		dialogUtil.showAlert(getResources().getString(R.string.alert_title), getResources().getString(R.string.alert_mobile_no));
        }else if(!EMAIL_ADDRESS_PATTERN.matcher(etEmail.getText()).matches()){
    		dialogUtil.showAlert(getResources().getString(R.string.alert_title), getResources().getString(R.string.alert_email));
    	}else if(etDateOfBirth.length() <= 0){
    		dialogUtil.showAlert(getResources().getString(R.string.alert_title), getResources().getString(R.string.alert_date_of_birth));
    	}else if(etTargetedYear.length() <= 0){
    		dialogUtil.showAlert(getResources().getString(R.string.alert_title), getResources().getString(R.string.alert_targeted_year_blanck));
    	}else if(Integer.parseInt(etTargetedYear.getText().toString()) < AppUtil.currentSystemYear()){
    		dialogUtil.showAlert(getResources().getString(R.string.alert_title), getResources().getString(R.string.alert_targeted_year));
       	}else if(autoCompleteTVState.length() <= 0){
    		dialogUtil.showAlert(getResources().getString(R.string.alert_title), getResources().getString(R.string.alert_state));
    	}else if(etPassword.length() <= 6){
    		dialogUtil.showAlert(getResources().getString(R.string.alert_title), getResources().getString(R.string.alert_password1));
    	}else if(!ALFA_NUMERIC_PATTERN.matcher(etPassword.getText()).matches()){
    		dialogUtil.showAlert(getResources().getString(R.string.alert_title), getResources().getString(R.string.alert_password2));
    	}else if(!etPassword.getText().toString().equals(etConfirmPassword.getText().toString())){
    		dialogUtil.showAlert(getResources().getString(R.string.alert_title), getResources().getString(R.string.alert_confirm_password));
       	}else{
       		isValidate = true;
    	}
    	return isValidate;
    }
    
    public final Pattern ALFA_NUMERIC_PATTERN = Pattern.compile(
    		"^(?=.*[0-9])(?=.*[a-zA-Z]).{7,}$"
    );
    
    public final Pattern MOBILE_NO_PATTERN = Pattern.compile(
    		"[0-9]{10}"
    );
    
    public final Pattern EMAIL_ADDRESS_PATTERN = Pattern.compile(
    		"[a-zA-Z0-9+._%-+]{1,256}" +
	        "@" +
	        "[a-zA-Z0-9][a-zA-Z0-9-]{0,64}" +
	        "(" +
	        "." +
	        "[a-zA-Z0-9][a-zA-Z0-9-]{0,25}" +
	        ")+"
    );
}