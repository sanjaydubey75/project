package com.shezartech.iitjeeacademy.ui.activity;

import static com.shezartech.iitjeeacademy.db.DBTablesColumns.AMOUNT_PAID;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.EMAIL_ID;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.INVOICE_NO;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.SUBSCRIPTION_DURATION;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.TRANSACTION_DATE;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.TRANSACTION_STATUS;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.TRANSACTION_ID;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TextView;
import com.shezartech.iitjeeacademy.service.PostServiceConnector;
import com.shezartech.iitjeeacademy.util.AppUtil;
import com.shezartech.iitjeeacademy.util.DialogUtil;

public class PaymentConfirmationActivity extends Activity{
	private DialogUtil dialogUtil;
	private TextView tvTransactionStatus;
	private TextView tvInvoiceNo;
	private TextView tvTransactionDate;
	private TextView tvAmountPaid;
	private TextView tvSubscriptionDuration;
	private Button btnShowHideDetails;
	private TableLayout tablePaymentDetails; 

	public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
		setContentView(R.layout.payment_confirmation_layout);
		dialogUtil = new DialogUtil(PaymentConfirmationActivity.this);
		
		tvTransactionStatus = (TextView)findViewById(R.id.tv_transaction_status);
		tvInvoiceNo = (TextView)findViewById(R.id.tv_invoice_no);
		tvTransactionDate = (TextView)findViewById(R.id.tv_transaction_date);
		
		tvAmountPaid = (TextView)findViewById(R.id.tv_amount_paid);
		tvSubscriptionDuration = (TextView)findViewById(R.id.tv_subscription_duration);
		 
		btnShowHideDetails = (Button)findViewById(R.id.btn_show_hide_details);
		tablePaymentDetails = (TableLayout)findViewById(R.id.table_payment_details);
		
		String email = AppUtil.getDataFromSharedPreferences(PaymentConfirmationActivity.this, EMAIL_ID);
		String emailArr[] = email.split("%40"); 
		email = emailArr[0]+"@"+emailArr[1];
		
		String transactionId = AppUtil.getDataFromSharedPreferences(PaymentConfirmationActivity.this, TRANSACTION_ID);
		final String Url = getResources().getString(R.string.server_domain)+getResources().getString(R.string.payment_confirmation_service);
		String request = "{'email':'"+email+"','transactionId':'"+transactionId+"'}";
		request = request.replace("'", "\"");
		
		if(AppUtil.isOnline(PaymentConfirmationActivity.this)){
			PostServiceConnector serviceConnector = new PostServiceConnector(PaymentConfirmationActivity.this); 
			serviceConnector.execute(Url, request);
		}else{
			dialogUtil.showAlert("Internet Error",getResources().getString(R.string.alert_internet_unavailable_message));
		}
		//addListenerOnTextView(); 
		addListenerOnButton();
	}
	
	private void addListenerOnButton(){
		btnShowHideDetails.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v){
				String buttonText = btnShowHideDetails.getText().toString();
				if(buttonText.equals("Show Payment Details")){
					tablePaymentDetails.setVisibility(View.VISIBLE);
					btnShowHideDetails.setText("Hide Payment Details");
					 
					tvTransactionStatus.setText(AppUtil.getDataFromSharedPreferences(PaymentConfirmationActivity.this, TRANSACTION_STATUS));
					tvInvoiceNo.setText(AppUtil.getDataFromSharedPreferences(PaymentConfirmationActivity.this, INVOICE_NO));
					tvTransactionDate.setText(AppUtil.getDataFromSharedPreferences(PaymentConfirmationActivity.this, TRANSACTION_DATE));
					tvAmountPaid.setText(AppUtil.getDataFromSharedPreferences(PaymentConfirmationActivity.this, AMOUNT_PAID));
					tvSubscriptionDuration.setText(AppUtil.getDataFromSharedPreferences(PaymentConfirmationActivity.this, SUBSCRIPTION_DURATION));
				}else{
					tablePaymentDetails.setVisibility(View.INVISIBLE);
					btnShowHideDetails.setText("Show Payment Details");
				}
			}
		});
	}
}