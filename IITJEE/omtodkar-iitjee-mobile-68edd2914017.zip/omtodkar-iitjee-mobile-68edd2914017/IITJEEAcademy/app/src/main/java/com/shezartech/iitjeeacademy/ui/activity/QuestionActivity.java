package com.shezartech.iitjeeacademy.ui.activity;

import static com.shezartech.iitjeeacademy.db.DBTablesColumns.NAME;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.REMEMBER_OFF_LOGIN_ID;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.REMEMBER_OFF_PASSWORD;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.SUBJECT_ID;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.TOPIC_ID;
import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.shezartech.iitjeeacademy.util.AppUtil;
import com.shezartech.iitjeeacademy.util.DialogUtil;

public class QuestionActivity extends Activity{
	private static final String TAG = "QuestionActivity-->";
	private WebView webView;
	private DialogUtil dialogUtil;
	@Override		
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.webview_layout);
		dialogUtil = new DialogUtil(QuestionActivity.this);
		dialogUtil.showToast("Please wait for a moment");
		webView = (WebView)findViewById(R.id.webView1);
		webView.setWebViewClient(new MyBrowser());
		open();
	}

	public void open(){
		String loginId = AppUtil.getDataFromSharedPreferences(QuestionActivity.this, REMEMBER_OFF_LOGIN_ID);
		String pwd = AppUtil.getDataFromSharedPreferences(QuestionActivity.this, REMEMBER_OFF_PASSWORD);
		String subjectId = AppUtil.getDataFromSharedPreferences(QuestionActivity.this, SUBJECT_ID);
		String topicId = AppUtil.getDataFromSharedPreferences(QuestionActivity.this, TOPIC_ID);
		String name = AppUtil.getDataFromSharedPreferences(QuestionActivity.this, NAME);
		
		Log.d(TAG, "loginId = "+loginId);
		Log.d(TAG, "pwd = "+pwd);
		Log.d(TAG, "subjectId = "+subjectId);
		Log.d(TAG, "topicId = "+topicId);
		Log.d(TAG, "name = "+name);
		String urlDetails = subjectId+"/"+topicId+"/"+name+"/"+loginId+"/"+pwd;
		String url = getResources().getString(R.string.server_domain) + getResources().getString(R.string.get_question_page_url_service)+urlDetails;
		Log.d(TAG, "url = "+url);
		//String url = "http://192.168.1.53/iitjeeacademy/mobile/question/MAT/AEA/Shobhit/abcd@abcd.com/aA12!@";
		webView.getSettings().setLoadsImagesAutomatically(true);
		webView.getSettings().setJavaScriptEnabled(true);
		webView.getSettings().setDomStorageEnabled(true);
		webView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
		webView.loadUrl(url);
	    
	    Log.d(TAG, "url1--> = "+url);
	}

	private class MyBrowser extends WebViewClient {
		@Override
		public boolean shouldOverrideUrlLoading(WebView view, String url){
			view.loadUrl(url);
			return true;
		}
	}
}