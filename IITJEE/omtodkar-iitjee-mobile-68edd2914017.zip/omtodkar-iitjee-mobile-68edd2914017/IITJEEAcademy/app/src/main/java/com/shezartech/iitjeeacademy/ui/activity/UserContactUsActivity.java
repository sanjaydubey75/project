package com.shezartech.iitjeeacademy.ui.activity;
import android.app.TabActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;

@SuppressWarnings("deprecation")
public class UserContactUsActivity extends TabActivity{

	@Override
    public void onCreate(Bundle savedInstanceState){
    	super.onCreate(savedInstanceState);
        setContentView(R.layout.user_contact_us_layout);

        TabHost tabHost = (TabHost)findViewById(android.R.id.tabhost);


        TabSpec tab1 = tabHost.newTabSpec("First Tab");
        TabSpec tab2 = tabHost.newTabSpec("Second Tab");

        tab1.setIndicator("Tell Us");
        tab1.setContent(new Intent(this,UserTellUsActivity.class));
        
        tab2.setIndicator("Meet Us");
        tab2.setContent(new Intent(this,UserMeetUsActivity.class));

        tabHost.addTab(tab1);
        tabHost.addTab(tab2);
    }
}
//	private TextView tvWebSiteIITJEEAcademy;
//	private TextView tvWebSiteShezartech;
	
//	public void onCreate(Bundle savedInstanceState){
//        super.onCreate(savedInstanceState);
//		setContentView(R.layout.contact_us_layout);
		
//		tvWebSiteIITJEEAcademy = (TextView)findViewById(R.id.tv_web_site_iitjeeacademy);
//		tvWebSiteShezartech = (TextView)findViewById(R.id.tv_web_site_shezartech);
		//addListenerTextView();
	//}
	
//	private void addListenerTextView(){
//		tvWebSiteIITJEEAcademy.setOnClickListener(new OnClickListener() {
//			@Override
//			public void onClick(View v) {
//				String url = "http://"+tvWebSiteIITJEEAcademy.getText().toString();
//				Intent i = new Intent(Intent.ACTION_VIEW);
//				i.setData(Uri.parse(url)); 
//				startActivity(i); 
//			}
//		});
//		  
//		tvWebSiteShezartech.setOnClickListener(new OnClickListener() {
//			@Override
//			public void onClick(View v) {
//				String url = "http://"+tvWebSiteShezartech.getText().toString();
//				Intent i = new Intent(Intent.ACTION_VIEW);
//				i.setData(Uri.parse(url)); 
//				startActivity(i); 
//			}
//		});
//	}
//}