package com.shezartech.iitjeeacademy.ui.activity;

import static com.shezartech.iitjeeacademy.db.DBTablesColumns.USER_REGISTRATION_FIELDS_VALIDATION_REQUEST;

import com.shezartech.iitjeeacademy.service.PostServiceConnector;
import com.shezartech.iitjeeacademy.util.AppUtil;
import com.shezartech.iitjeeacademy.util.DialogUtil;

import android.app.Activity;
import android.os.Bundle;

public class BlanckActivityToRegister extends Activity{

	private DialogUtil dialogUtil;
	
	protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.blanck_layout);

        dialogUtil = new DialogUtil(BlanckActivityToRegister.this);
        if(AppUtil.isOnline(BlanckActivityToRegister.this)){
			String request = AppUtil.getDataFromSharedPreferences(BlanckActivityToRegister.this, USER_REGISTRATION_FIELDS_VALIDATION_REQUEST);
	    	PostServiceConnector serviceConnector = new PostServiceConnector(BlanckActivityToRegister.this);
		   	serviceConnector.execute(getResources().getString(R.string.server_domain)+getResources().getString(R.string.user_registration_service), request);
        }else{
	    	dialogUtil.showAlert("Internet Error",getResources().getString(R.string.alert_internet_unavailable_message));
	    }
	}
}
