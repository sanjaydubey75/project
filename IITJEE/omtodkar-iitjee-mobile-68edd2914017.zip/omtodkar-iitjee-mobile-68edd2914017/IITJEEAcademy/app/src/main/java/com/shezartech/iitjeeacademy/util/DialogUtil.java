package com.shezartech.iitjeeacademy.util;

import static com.shezartech.iitjeeacademy.db.DBTablesColumns.SUBJECT_ID;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.TOPIC_ID;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.LEVEL;
import java.util.ArrayList;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;
import com.shezartech.iitjeeacademy.db.DBHelper;
import com.shezartech.iitjeeacademy.ui.activity.QuestionActivity;
import com.shezartech.iitjeeacademy.ui.activity.R;

public class DialogUtil {
	private final static String TAG = "DialogUtil-->";
	private ProgressDialog pDlg;
	private Dialog dialog;
	private Context context;
	private Spinner spinnerSubject;
	private Spinner spinnerTopic;
	private String selectedSubject = "";
	private String selectedTopic = "";
	private String level;
	private ArrayList<String> listOfTopicsName = new ArrayList<String>();
	private DBHelper dbHelper;
	
	public DialogUtil(Context c){
		this.context = c;
		dialog=new Dialog(context);
		dbHelper = new DBHelper(context);
	}
	
	public void showProgressDialog(String title, String msg){
		pDlg = new ProgressDialog(context);
		pDlg.setTitle(title);
		pDlg.setMessage(msg);
		pDlg.setCancelable(false);
		pDlg.setIndeterminate(true);
		pDlg.show();
	}
	
	public void hideProgressDialog(){
		pDlg.dismiss();
	}
	
	public void showToast(String toastMsg){
		Toast toast = Toast.makeText(context,toastMsg, Toast.LENGTH_LONG);
		toast.setGravity(Gravity.CENTER, 0, 0);
		toast.show();
	}

	public void showAlert(String title, String message){
		AlertDialog.Builder alertDialog = new AlertDialog.Builder(context);
        alertDialog.setTitle(title);
        alertDialog.setMessage(message);
        //alertDialog.setIcon(R.drawable.ic_delete);
        alertDialog.setCancelable(false);
        alertDialog.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog,int which) {
            	dialog.dismiss();
            }
        });
        alertDialog.show();
	}
	
	public void showChoiceAlert(final ArrayList<String> listOfSubjectsName, final String cheLevel, final String matLevel, final String phyLevel) {
		
		dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		dialog.setContentView(R.layout.test_choice_alert_layout);
		dialog.setCancelable(false);
		
		spinnerSubject = (Spinner) dialog.findViewById(R.id.spinner_subject);
		spinnerTopic = (Spinner) dialog.findViewById(R.id.spinner_topic);
		
		@SuppressWarnings({ "rawtypes", "unchecked" })
		ArrayAdapter subjectAdapter = new ArrayAdapter(context,android.R.layout.simple_spinner_dropdown_item, listOfSubjectsName);
		spinnerSubject.setAdapter(subjectAdapter);
			        
		spinnerSubject.setOnItemSelectedListener(new OnItemSelectedListener() {
		    @SuppressWarnings("unchecked")
			@Override
		    public void onItemSelected(AdapterView<?> arg0, View arg1, int position, long id) {
		    	selectedSubject = String.valueOf(spinnerSubject.getSelectedItem());
		    	Log.d(TAG, "position = "+position);
		        Log.d(TAG, "selectedSubject = "+selectedSubject);
		        
		        if(position > 0){
		        	if(selectedSubject.equalsIgnoreCase("Chemistry")){
		        		level = cheLevel;
		        		listOfTopicsName = dbHelper.selectTopicName("CHE");
		        	}else if(selectedSubject.equalsIgnoreCase("Mathematics")){
		        		level = matLevel;
		        		listOfTopicsName = dbHelper.selectTopicName("MAT");
		        	}else if(selectedSubject.equalsIgnoreCase("Physics")){
		        		level = phyLevel;
		        		listOfTopicsName = dbHelper.selectTopicName("PHY");
		        	}
		    		@SuppressWarnings("rawtypes")
					ArrayAdapter topicAdapter = new ArrayAdapter(context,android.R.layout.simple_spinner_dropdown_item, listOfTopicsName);
		    		spinnerTopic.setAdapter(topicAdapter);
		        }
		    }
		    @Override
		    public void onNothingSelected(AdapterView<?> arg0) {
		    }
		});
		
		spinnerTopic.setOnItemSelectedListener(new OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1, int position, long id) {
				selectedTopic = String.valueOf(spinnerTopic.getSelectedItem());
			    Log.d(TAG, "selectedTopic = "+selectedTopic);
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
			}
		});
		
		Button btnQuit=(Button)dialog.findViewById(R.id.btn_quit);
		Button btnStart=(Button)dialog.findViewById(R.id.btn_start);
		
		btnQuit.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				dialog.dismiss();
			}
		});
		
		btnStart.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if(selectedSubject.equals("") || selectedSubject.equalsIgnoreCase("Select Subject")||selectedTopic.equals("") || selectedTopic.equalsIgnoreCase("Select Topic")){
					DialogUtil dialogUtil = new DialogUtil(context);
					dialogUtil.showToast("Please select subject and topic");
				}else{
					String subjectId = dbHelper.selectSubjectId(selectedSubject);
					String topicId = dbHelper.selectTopicId(selectedTopic);

					AppUtil.saveDataInSharedPreferences(context, LEVEL, level);
					AppUtil.saveDataInSharedPreferences(context, SUBJECT_ID, subjectId);
					AppUtil.saveDataInSharedPreferences(context, TOPIC_ID, topicId);
					
					Intent intent = new Intent(context, QuestionActivity.class);
					context.startActivity(intent);
					
//					if(AppUtil.isOnline(context)){
//				    	GetServiceConnector serviceConnector = new GetServiceConnector(context);
//					   	serviceConnector.execute((context.getResources().getString(R.string.server_domain)+context.getResources().getString(R.string.get_question_service))+subjectId+"/"+topicId.replace(" ", "%20"), AppUtil.getDataFromSharedPreferences(context, LOGIN_ID), AppUtil.getDataFromSharedPreferences(context, TOKEN));
//				    }else{
//				    	DialogUtil dialogUtil = new DialogUtil(context);
//				    	dialogUtil.showAlert("Internet Error",context.getResources().getString(R.string.alert_internet_unavailable_message));
//				    }
				}
			}
		});
		dialog.show();
	}
}