package com.shezartech.iitjeeacademy.ui.activity;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager.NameNotFoundException;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;

public class AboutUsActivity extends Activity{
	private final static String TAG = "AboutUsActivity-->";
	private TextView tvWebSiteIITJEEAcademy;
	private TextView tvAppVersionName;
	
	public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
		setContentView(R.layout.about_us_layout);
		
		tvWebSiteIITJEEAcademy = (TextView)findViewById(R.id.tv_web_site_iitjeeacademy);
		tvAppVersionName = (TextView)findViewById(R.id.tv_app_version_name);
		tvAppVersionName.setText("Version: "+getVersionNameOfApp());
		addListenerTextView();
	}
	
	private String getVersionNameOfApp(){
		String appVersionName = "";
		try{
			appVersionName = this.getPackageManager().getPackageInfo(this.getPackageName(), 0).versionName;
		}catch (NameNotFoundException e){
		    Log.v(TAG, e.getMessage());
		}
		return appVersionName;
	}
	
	private void addListenerTextView(){
		tvWebSiteIITJEEAcademy.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				String url = "http://"+tvWebSiteIITJEEAcademy.getText().toString();
				Intent i = new Intent(Intent.ACTION_VIEW);
				i.setData(Uri.parse(url)); 
				startActivity(i); 
			}
		});
	}
}