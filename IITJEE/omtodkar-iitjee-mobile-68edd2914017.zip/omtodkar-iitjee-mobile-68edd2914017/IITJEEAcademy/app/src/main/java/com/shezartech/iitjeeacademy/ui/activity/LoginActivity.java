package com.shezartech.iitjeeacademy.ui.activity;

import static com.shezartech.iitjeeacademy.db.DBTablesColumns.LOGIN_ID;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.PASSWORD;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.REMEMBER_OFF_LOGIN_ID;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.REMEMBER_OFF_PASSWORD;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.STATES_NAME;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.TABLE_STATES;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.INSTITUTE_NAME;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.TABLE_INSTITUTES;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import com.shezartech.iitjeeacademy.db.DBHelper;
import com.shezartech.iitjeeacademy.service.GetServiceConnector;
import com.shezartech.iitjeeacademy.service.PostServiceConnector;
import com.shezartech.iitjeeacademy.util.AppUtil;
import com.shezartech.iitjeeacademy.util.DialogUtil;

public class LoginActivity extends Activity {

	private final static String TAG = "LoginActivity-->";
	private EditText etLoginId;
    private EditText etPassword;
    private Button btnLogin;
    private Button btnRegister;
    private Switch switchRememberMe;
    private String loginId = "";
    private String password = "";
    private boolean isSwitchOn = false;
    private DialogUtil dialogUtil;
    private static int CAPTURE_IMAGE_REQUEST_CODE = 1;
    private AlertDialog.Builder alertDialog;
    
    protected void onCreate(Bundle savedInstanceState) {
    	super.onCreate(savedInstanceState);
		setContentView(R.layout.login_layout);
		
		etLoginId = (EditText)findViewById(R.id.et_login_id);
	    etPassword = (EditText)findViewById(R.id.et_password);
	    switchRememberMe = (Switch)findViewById(R.id.switch_remember_me);
	    btnLogin = (Button)findViewById(R.id.btn_login);
	    btnRegister = (Button)findViewById(R.id.btn_register);
   	
	    etLoginId.setText(AppUtil.getDataFromSharedPreferences(LoginActivity.this, LOGIN_ID));
	    etPassword.setText(AppUtil.getDataFromSharedPreferences(LoginActivity.this, PASSWORD));

	    dialogUtil = new DialogUtil(LoginActivity.this);
	    addListnerOnSwithc();
	    addListnerOnButton();               
	    
	    if(AppUtil.isOnline(LoginActivity.this)){
	    	DBHelper dbHelper = new DBHelper(LoginActivity.this);
	    	int rows = dbHelper.checkTableEmpty(TABLE_STATES, STATES_NAME);
	    	Log.d(TAG, "rows = "+rows);
	    	if(rows <= 0){
		    	GetServiceConnector serviceConnector = new GetServiceConnector(LoginActivity.this);
			   	serviceConnector.execute(getResources().getString(R.string.server_domain)+getResources().getString(R.string.get_state_service));
	    	}
	    }else{
	    	dialogUtil.showAlert("Internet Error",getResources().getString(R.string.alert_internet_unavailable_message));
	    }
	    
	    if(AppUtil.isOnline(LoginActivity.this)){
	    	DBHelper dbHelper = new DBHelper(LoginActivity.this);
	    	dbHelper.deleteAllRowsFromTable(TABLE_INSTITUTES);
	    	GetServiceConnector serviceConnector = new GetServiceConnector(LoginActivity.this);
		   	serviceConnector.execute(getResources().getString(R.string.server_domain)+getResources().getString(R.string.get_institute_service));
	    }else{
	    	dialogUtil.showAlert("Internet Error",getResources().getString(R.string.alert_internet_unavailable_message));
	    }
	}

	public boolean addListnerOnSwithc(){
		switchRememberMe.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				Log.v(TAG, "isChecked = "+isChecked);
				isSwitchOn = isChecked;
			}       
		});
		return isSwitchOn;
	}
	
	public void addListnerOnButton(){
		btnLogin.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) { 
				loginId = etLoginId.getText().toString();
			    password = etPassword.getText().toString();
			    Log.d(TAG, "Button clicked");
			    if(validate()){
				    if(isSwitchOn){
				    	AppUtil.saveDataInSharedPreferences(LoginActivity.this, LOGIN_ID, loginId);
				    	AppUtil.saveDataInSharedPreferences(LoginActivity.this, PASSWORD, password);
				    	
				    	Log.v(TAG, "AppUtil.getDataFromSharedPreferences(LoginActivity.this, LOGIN_ID) = "+AppUtil.getDataFromSharedPreferences(LoginActivity.this, LOGIN_ID));
				    	Log.v(TAG, "AppUtil.getDataFromSharedPreferences(LoginActivity.this, PASSWORD) = "+AppUtil.getDataFromSharedPreferences(LoginActivity.this, PASSWORD));
				    }else{
				    	AppUtil.removeDataFromSharedPreferences(LoginActivity.this);
				    }
				    if(AppUtil.isOnline(LoginActivity.this)){
				    	PostServiceConnector serviceConnector = new PostServiceConnector(LoginActivity.this);
					   	serviceConnector.execute(getResources().getString(R.string.server_domain)+getResources().getString(R.string.login_service), buildJSONRequest());
				    }else{
				    	dialogUtil.showAlert("Internet Error",getResources().getString(R.string.alert_internet_unavailable_message));
				    }
				    AppUtil.saveDataInSharedPreferences(LoginActivity.this, REMEMBER_OFF_LOGIN_ID, loginId);
			    	AppUtil.saveDataInSharedPreferences(LoginActivity.this, REMEMBER_OFF_PASSWORD, password);
			    }else{
			    	dialogUtil.showToast(getResources().getString(R.string.toast_enter_user_id_pwd));
			    }
			}
		});
		
		btnRegister.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent i = new Intent(LoginActivity.this, UserRegistrationActivity.class);
			   	startActivity(i);
//				if(AppUtil.isOnline(LoginActivity.this)){
////			    	DBHelper dbHelper = new DBHelper(LoginActivity.this);
////			    	dbHelper.deleteAllRowsFromTable(TABLE_INSTITUTES);
////			    	GetServiceConnector serviceConnector = new GetServiceConnector(LoginActivity.this);
////				   	serviceConnector.execute(getResources().getString(R.string.server_domain)+getResources().getString(R.string.get_institute_service));
////			    	
//			    	
//			    }else{
//			    	dialogUtil.showAlert("Internet Error",getResources().getString(R.string.alert_internet_unavailable_message));
//			    }
			}
	   });
	}
	
	private boolean validate(){
		boolean isValidate = false;
		if(etLoginId.getText().length() > 0 && etPassword.getText().length() > 0){
			isValidate = true;
		}
		return isValidate;
	}
	
	private String buildJSONRequest(){
		String request = "{'userEmail':'"+loginId+"','password':'"+password+"','role':'student'}";
		request = request.replace("'", "\"");
		return request;
	}
	
	public void sendEmailWithAttachment(String imgPath) {
		Intent intent = new Intent(Intent.ACTION_SEND_MULTIPLE);
		intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		intent.setType("text/plain");
		intent.setClassName("com.google.android.gm","com.google.android.gm.ComposeActivityGmail");
		intent.putExtra(Intent.EXTRA_EMAIL, new String[] { "info@iitjeeacademy.com" });
		intent.putExtra(Intent.EXTRA_SUBJECT, "IIT-JEE Question");
		intent.putExtra(Intent.EXTRA_TEXT, "PFA image of IIT-JEE Question");
		intent.putExtra(Intent.EXTRA_STREAM,Uri.parse(imgPath));
	    ArrayList<String> fileList = new ArrayList<String>();
	    fileList.add(imgPath);
	    ArrayList<Uri> uris = new ArrayList<Uri>();

	    for (int i=0;i<fileList.size();i++){
	    	File fileIn = new File(fileList.get(i));
	    	Uri u = Uri.fromFile(fileIn);
	    	uris.add(u);
	    }
	    intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
	    startActivity(intent);
	}
	
	public void openCamera(){
		Intent intent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
		startActivityForResult(intent, CAPTURE_IMAGE_REQUEST_CODE);
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		Log.d(TAG, "requestCode = "+requestCode);
		Log.d(TAG, "resultCode = "+resultCode);
	   
		if (requestCode == CAPTURE_IMAGE_REQUEST_CODE && resultCode == RESULT_OK) {
			super.onActivityResult(requestCode, resultCode, data);
			showAlert(getResources().getString(R.string.alert_upload_image_title), getResources().getString(R.string.alert_upload_image_message));
			saveImageInSDCard(data);
          
		} else if ( resultCode == RESULT_CANCELED) {
			Toast.makeText(this, " Picture was not taken ", Toast.LENGTH_SHORT).show();
		} else {       
			Toast.makeText(this, " Picture was not taken ", Toast.LENGTH_SHORT).show();
		}
	}
   
	private void saveImageInSDCard(Intent imageData){
		Bitmap thumbnail = (Bitmap) imageData.getExtras().get("data");  
		ByteArrayOutputStream bytes = new ByteArrayOutputStream();
		thumbnail.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
		File file = new File(Environment.getExternalStorageDirectory()+File.separator + "iitjee_question.jpg");
		Log.d(TAG, "file.getPath() = "+file.getPath());
		try {
//			if(file.exists()){
//				boolean isFileDeleted = file.delete();
//				Log.d(TAG, "File Deleted Successfully isFileDeleted = "+isFileDeleted);
//			}else{
				file.createNewFile();
				FileOutputStream fo = new FileOutputStream(file);
				fo.write(bytes.toByteArray());
				fo.close();
				sendEmailWithAttachment(file.getPath());
			//}
		}catch (IOException e) {
			e.printStackTrace();
		}
	}
   
	public void showAlert(String title, String message){
		alertDialog = new AlertDialog.Builder(LoginActivity.this);
		alertDialog.setTitle(title);
		alertDialog.setMessage(message);
		alertDialog.setCancelable(false);
		alertDialog.setPositiveButton(getResources().getString(R.string.btn_capture_image), new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog,int which) {
				dialog.dismiss();
				openCamera();
			}
		});
		alertDialog.setNegativeButton(getResources().getString(R.string.btn_cancel), new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog,int which) {
				dialog.dismiss();
			}
		});
		alertDialog.show();
	}
  
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
	    MenuInflater inflater = getMenuInflater();
	    inflater.inflate(R.menu.main, menu);
	    return true;
	}
	 
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		Intent i;
	    switch (item.getItemId()) {
	   
	    case R.id.menu_about_iitjee_academy:
	    	i = new Intent(LoginActivity.this, AboutUsActivity.class);
			startActivity(i);
	        return true;
	    case R.id.menu_contact_us:
	    	i = new Intent(LoginActivity.this, UserContactUsActivity.class);
			startActivity(i);
	        return true;
	    case R.id.menu_send_question:
//	    	i = new Intent(LoginActivity.this, SendQuestionActivity.class);
//			startActivity(i);
	    	showAlert("Capture Image", "Capture image of Question and Mail Us");
	        return true;
	    default:
	        return super.onOptionsItemSelected(item);
	    }
	}
}