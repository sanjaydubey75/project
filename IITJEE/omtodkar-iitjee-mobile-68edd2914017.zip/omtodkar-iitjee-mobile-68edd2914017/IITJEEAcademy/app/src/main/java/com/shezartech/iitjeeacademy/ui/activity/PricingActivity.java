package com.shezartech.iitjeeacademy.ui.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.SUBSCRIPTION_MODEL;;

public class PricingActivity extends Activity{
	//private final static String TAG = "PricingActivity-->";
	private TextView tvSubscribeForSixMonths;
	private TextView tvSubscribeForOneYear;
	private TextView tvSubscribeForTwoYears;
	
	public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
		setContentView(R.layout.pricing_layout);
		tvSubscribeForSixMonths = (TextView)findViewById(R.id.tv_subscribe_for_six_months);
		tvSubscribeForOneYear = (TextView)findViewById(R.id.tv_subscribe_for_one_year);
		tvSubscribeForTwoYears = (TextView)findViewById(R.id.tv_subscribe_for_two_years);
	
		addListenerOnTextView();
	}
	
	private void addListenerOnTextView(){
		tvSubscribeForSixMonths.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				Intent intent = new Intent(PricingActivity.this, MakePaymentActivity.class);
				intent.putExtra(SUBSCRIPTION_MODEL, "1");
				startActivity(intent);
			}
		});
		
		tvSubscribeForOneYear.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				Intent intent = new Intent(PricingActivity.this, MakePaymentActivity.class);
				intent.putExtra(SUBSCRIPTION_MODEL, "2");
				startActivity(intent);
			}
		});
		
		tvSubscribeForTwoYears.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				Intent intent = new Intent(PricingActivity.this, MakePaymentActivity.class);
				intent.putExtra(SUBSCRIPTION_MODEL, "3");
				startActivity(intent);
			}
		});
	}
}