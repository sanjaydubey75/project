package com.shezartech.iitjeeacademy.ui.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class ResultActivity extends Activity{

	//private final static String TAG = "ResultActivity-->>";
	
	private TextView tvLevel;
	private TextView tvSubject;
	private TextView tvTopic;
	
	private TextView tvQuestionAttempted;
	private TextView tvRightAnswer;
	private TextView tvWrongAnswer;
	private Button btnPracticeAgain;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	    setContentView(R.layout.result_layout);
	    
	    tvLevel = (TextView)findViewById(R.id.tv_level);
	    tvSubject = (TextView)findViewById(R.id.tv_subject);
	    tvTopic = (TextView)findViewById(R.id.tv_topic);
	    
	    tvQuestionAttempted = (TextView)findViewById(R.id.tv_question_attempted);
	    tvRightAnswer = (TextView)findViewById(R.id.tv_right_answer);
	    tvWrongAnswer = (TextView)findViewById(R.id.tv_wrong_answer);
	    
	    btnPracticeAgain = (Button)findViewById(R.id.btn_practice_again);
	    Bundle extras = getIntent().getExtras();
	    if (extras != null) {
	    	tvLevel.setText(extras.getString("LEVEL"));
	    	tvSubject.setText(extras.getString("SUBJECT"));
	    	tvTopic.setText(extras.getString("TOPIC"));
	    	
	    	tvQuestionAttempted.setText(String.valueOf(extras.getInt("QUESTION_ATTEMPTED")));
	    	tvRightAnswer.setText(String.valueOf(extras.getInt("RIGHT_ANSWER")));
	    	tvWrongAnswer.setText(String.valueOf(extras.getInt("WRONG_ANSWER")));
	    }
	    
	    addListenerOnButton();
	}
	
	private void addListenerOnButton(){
		btnPracticeAgain.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent i = new Intent(ResultActivity.this, HomeActivity.class);
				startActivity(i);
			}
		});
	}
}
