package com.shezartech.iitjeeacademy.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.SocketTimeoutException;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicHeader;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.protocol.HTTP;
import org.json.JSONObject;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.util.Log;
import com.shezartech.iitjeeacademy.ui.activity.BlanckActivityToRegister;
import com.shezartech.iitjeeacademy.ui.activity.HomeActivity;
import com.shezartech.iitjeeacademy.ui.activity.MakePaymentActivity;
import com.shezartech.iitjeeacademy.ui.activity.PaymentConfirmationActivity;
import com.shezartech.iitjeeacademy.ui.activity.PricingActivity;
import com.shezartech.iitjeeacademy.ui.activity.R;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.TRANSACTION_STATUS;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.INVOICE_NO;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.TRANSACTION_DATE;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.AMOUNT_PAID;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.NAME;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.EMAIL_ID;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.SUBSCRIPTION_DURATION;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.REDIRECT_STATUS;
import com.shezartech.iitjeeacademy.util.AppUtil;
import com.shezartech.iitjeeacademy.util.DialogUtil;

public class PostServiceConnector extends AsyncTask<String, Integer, String> {

	private static final String TAG = "PostServiceConnector-->";
	private Context context;
	private DialogUtil dialogUti;
	private String token;
	private String message = "";
	private String status = "failed";
	
	
	public PostServiceConnector(Context c){
		this.context = c;
		dialogUti = new DialogUtil(context);
	}
	
	@Override
	protected void onPreExecute() {
		super.onPreExecute();
		dialogUti.showProgressDialog(context.getResources().getString(R.string.progress_dialog_title), context.getResources().getString(R.string.progress_dialog_message));
	}
	 
    @Override
	protected String doInBackground(String... urls) {
		String url = urls[0];
		String request = urls[1];
		if(url.contains("validate")){
			executePostMethodToValidateRegistrationFields(url, request);
		}else {
			executePostMethod(url, request);
		}
		return message;
    }
    
    @Override
    protected void onPostExecute(String message) {
    	super.onPostExecute(message);
    	dialogUti.hideProgressDialog();
    	Log.d(TAG, "onPostExecute =  message--->"+message); 
    	
    	if(!status.equals("success")){
    		dialogUti.showAlert("Alert",message);
    	}
    	
    	if(message.contains("Register")){
    		dialogUti.showAlert("Alert","Welcome! "+message);
//    		Intent intent = new Intent(context, LoginActivity.class);
//			context.startActivity(intent);
		}  
    }
	
    public boolean executePostMethod(String url, String request){
		Log.d(TAG, "--In executePostMethod()--");
		Log.d(TAG, "url = "+url);
		Log.d(TAG, "request = "+request);
		boolean isResponseOK = false;		
		
		try {
			DefaultHttpClient httpClient = getHttpClient();
			HttpPost httpPost = new HttpPost(url);

			httpPost.setHeader("X-XSRF-TOKEN",context.getResources().getString(R.string.CSRF_TOKEN));
			httpPost.setHeader("Cookie","csrf-token="+context.getResources().getString(R.string.CSRF_TOKEN));
					 
			StringEntity reqEntity = new StringEntity(request, "UTF-8");
			BasicHeader basicHeader = new BasicHeader(HTTP.CONTENT_TYPE,"application/json");
			
			httpPost.setEntity(reqEntity);
			reqEntity.setContentType(basicHeader);
			HttpResponse httpResponse = httpClient.execute(httpPost);
						
			Log.d(TAG, "status = " + httpResponse.getStatusLine().getStatusCode());
			Log.d(TAG, "status phrase = " + httpResponse.getStatusLine().getReasonPhrase());
			
			if (httpResponse.getStatusLine().getStatusCode() == 200) {
				HttpEntity entity = httpResponse.getEntity();
				if (entity != null) {
					isResponseOK = true;
					InputStream inputStream = entity.getContent();
					String response = convertToString(inputStream);
					Log.d(TAG, "response = "+response);
					
					JSONObject objResponse = (new JSONObject(response)).getJSONObject("response");
		    		status = objResponse.getString("status");
					message = objResponse.getString("message");
					
					Log.d(TAG, "status = "+status);
					if(status.equals("success")){                                                    
						if(response.contains("Register")){
							Log.d(TAG, "--Yes response contains Register--");
							if(AppUtil.getDataFromSharedPreferences(context, REDIRECT_STATUS).equals("Register")){
							}else{
								Intent intent = new Intent(context, PaymentConfirmationActivity.class);
								context.startActivity(intent);
							}
						}else if(response.contains("paymentdetails")){
							Log.d(TAG, "--Yes response contains paymentdetails--");
							
							JSONObject jsonePaymentStatus = (new JSONObject(response)).getJSONObject("paymentdetails").getJSONObject("status");
							JSONObject jsonePaymentDetails = (new JSONObject(response)).getJSONObject("paymentdetails").getJSONObject("details");
							String transactionStatus = jsonePaymentStatus.getString("transaction");
							String registrationStatus = jsonePaymentStatus.getString("registration");
							
							if(transactionStatus.equals("true") && registrationStatus.equals("true")){
								AppUtil.saveDataInSharedPreferences(context, TRANSACTION_STATUS, "Success");
								AppUtil.saveDataInSharedPreferences(context, INVOICE_NO, jsonePaymentDetails.getString("Invoice Number"));
								AppUtil.saveDataInSharedPreferences(context, TRANSACTION_DATE, jsonePaymentDetails.getString("Transaction Date"));
								AppUtil.saveDataInSharedPreferences(context, AMOUNT_PAID, jsonePaymentDetails.getString("Amount Paid"));
								AppUtil.saveDataInSharedPreferences(context, NAME, jsonePaymentDetails.getString("Name"));
								AppUtil.saveDataInSharedPreferences(context, EMAIL_ID, jsonePaymentDetails.getString("Email"));
								AppUtil.saveDataInSharedPreferences(context, SUBSCRIPTION_DURATION, jsonePaymentDetails.getString("Subscription Duration"));
							}else{
								message = context.getResources().getString(R.string.alert_registration_or_transaction_fail_message);
								AppUtil.saveDataInSharedPreferences(context, TRANSACTION_STATUS, "Failed");
								AppUtil.saveDataInSharedPreferences(context, INVOICE_NO, jsonePaymentDetails.getString("Invoice Number"));
								AppUtil.saveDataInSharedPreferences(context, TRANSACTION_DATE, jsonePaymentDetails.getString("Transaction Date"));
								AppUtil.saveDataInSharedPreferences(context, AMOUNT_PAID, jsonePaymentDetails.getString("Amount Paid"));
								AppUtil.saveDataInSharedPreferences(context, NAME, jsonePaymentDetails.getString("Name"));
								AppUtil.saveDataInSharedPreferences(context, EMAIL_ID, jsonePaymentDetails.getString("Email"));
								AppUtil.saveDataInSharedPreferences(context, SUBSCRIPTION_DURATION, jsonePaymentDetails.getString("Subscription Duration"));
							}
						}else{
							Header header[] = httpResponse.getHeaders("Set-Cookie");
							token = header[0].getValue().split("=")[1].split(";")[0];
							Log.e(TAG, "token = "+token);
							parseResponse(response, token);
						}
					}
				}else{
					Log.e(TAG, "Empty Resposne");  
					status = "failed";
					message = "Empty Response! Not able to communicate with Server Please try again after some time.";
				}
			}else {
				Log.e(TAG, "SERVICE_STATUS_ERROR: " + httpResponse.getStatusLine().getReasonPhrase());
				status = "failed";
				message = httpResponse.getStatusLine().getReasonPhrase();
			}
		}catch(SocketTimeoutException exp){
            Log.e(TAG, "time out error: " + exp.getMessage());
            status = "failed";
            message = exp.getMessage();
            exp.printStackTrace();
        }catch (Throwable t){
			Log.e(TAG, "SERVICE_CONNECTION_ERROR = " + t.getMessage());
			t.printStackTrace();
			status = "failed";                                                       
			message = "Service Connection Error! Please try again after some time.";
		}
		return isResponseOK;
    }
  
    public boolean executePostMethodToValidateRegistrationFields(String url, String request){
		Log.d(TAG, "--In executePostMethodToValidateRegistrationFields()--");
		Log.d(TAG, "url = "+url);
		Log.d(TAG, "request = "+request);
		boolean isResponseOK = false;		
		
		try {
			DefaultHttpClient httpClient = getHttpClient();
			HttpPost httpPost = new HttpPost(url);

			httpPost.setHeader("X-XSRF-TOKEN",context.getResources().getString(R.string.CSRF_TOKEN));
			httpPost.setHeader("Cookie","csrf-token="+context.getResources().getString(R.string.CSRF_TOKEN));
					 
			StringEntity reqEntity = new StringEntity(request, "UTF-8");
			BasicHeader basicHeader = new BasicHeader(HTTP.CONTENT_TYPE,"application/json");
			
			httpPost.setEntity(reqEntity);
			reqEntity.setContentType(basicHeader);
			HttpResponse httpResponse = httpClient.execute(httpPost);
						
			Log.d(TAG, "status = " + httpResponse.getStatusLine().getStatusCode());
			Log.d(TAG, "status phrase = " + httpResponse.getStatusLine().getReasonPhrase());
			
			if (httpResponse.getStatusLine().getStatusCode() == 200) {
				HttpEntity entity = httpResponse.getEntity();
				Log.d(TAG, "entity = "+entity);
				if (entity != null) {
					isResponseOK = true;
					InputStream inputStream = entity.getContent();
					String response = convertToString(inputStream);
					Log.d(TAG, "response --->"+response);
					JSONObject objResponse = (new JSONObject(response)).getJSONObject("response");
					
		    		status = objResponse.getString("status");
					message = objResponse.getString("message");
					                     
					if(response.contains("success")){
						status = "success";
						String redirectStatus = (new JSONObject(response)).getString("redirectStatus");
						Log.d(TAG, "redirectStatus = "+redirectStatus);
						if(redirectStatus.equals("PG")){
							AppUtil.saveDataInSharedPreferences(context, REDIRECT_STATUS, redirectStatus);
							Intent intent = new Intent(context, MakePaymentActivity.class);
							context.startActivity(intent);
						}else if(redirectStatus.equals("Pricing")){
							AppUtil.saveDataInSharedPreferences(context, REDIRECT_STATUS, redirectStatus);
							Intent intent = new Intent(context, PricingActivity.class);
							context.startActivity(intent);
						}else if(redirectStatus.equals("Register")){
							AppUtil.saveDataInSharedPreferences(context, REDIRECT_STATUS, redirectStatus);
							Intent intent = new Intent(context, BlanckActivityToRegister.class);
							//intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
							context.startActivity(intent);
						
						}
					}else{
						String errMessage = objResponse.getString("errormessages");
						String arrErrMsg[] = errMessage.split("#");
						String splitedMsg = "";
						for(int i = 0; i < arrErrMsg.length; i++){
							splitedMsg = splitedMsg+"\n\n"+arrErrMsg[i];
						}
						message = message+"\n"+splitedMsg;
					}
				}else{
					Log.e(TAG, "Empty Resposne");  
					status = "failed";
					message = "Empty Response! Not able to communicate with Server Please try again after some time.";
				}
			}else{
				Log.e(TAG, "SERVICE_STATUS_ERROR: " + httpResponse.getStatusLine().getReasonPhrase());
				status = "failed";
				message = httpResponse.getStatusLine().getReasonPhrase();
			}
		}catch(SocketTimeoutException exp){
            Log.e(TAG, "time out error: " + exp.getMessage());
            status = "failed";
            message = exp.getMessage();
            exp.printStackTrace();
        }catch (Throwable t){
			Log.e(TAG, "SERVICE_CONNECTION_ERROR = " + t.getMessage());
			t.printStackTrace();
			status = "failed";
			message = "Service Connection Error! Please try again after some time.";
		}
		return isResponseOK;
    }
    
    private void parseResponse(String response, String token){
    	try{
    		Log.d(TAG, "response = "+response);
			if(response.contains("person")){
				JSONObject objPerson = (new JSONObject(response)).getJSONObject("person");
				String userFirstname = objPerson.getString("userFirstname");
	    		String AIR = objPerson.getString("AIR");
	    		String SR = objPerson.getString("SR");
	    		String userEmail = objPerson.getString("userEmail");
	    		String role = objPerson.getString("role");
	    		
	    		String cheLevel = objPerson.getString("che");
	    		String mathLevel = objPerson.getString("mat");
	    		String phyLevel = objPerson.getString("phy");

	    		Log.d(TAG, "message = "+message);
	    		Log.d(TAG, "userFirstname = "+userFirstname);
	    		Log.d(TAG, "AIR = "+AIR);
	    		Log.d(TAG, "SR = "+SR);
	    		Log.d(TAG, "userEmail = "+userEmail);
	    		Log.d(TAG, "role = "+role);
	    		Log.d(TAG, "cheLevel = "+cheLevel);
	    		Log.d(TAG, "mathLevel = "+mathLevel);
	    		Log.d(TAG, "phyLevel = "+phyLevel);
	    		
	    		Intent i = new Intent(context, HomeActivity.class);
	    		i.putExtra("NAME", userFirstname);
	    		i.putExtra("EMAIL", userEmail);
	    		i.putExtra("AIR", AIR);
	    		i.putExtra("SR", SR);
	    		i.putExtra("PHY_LEVEL", phyLevel);
	    		i.putExtra("CHE_LEVEL", cheLevel);
	    		i.putExtra("MATH_LEVEL", mathLevel);
	    		i.putExtra("TOKEN", token);
	    		context.startActivity(i);
			}
        }catch(Exception e){
        	e.printStackTrace(); 
        }
    }
   
    public String convertToString(InputStream inputStream){
        StringBuffer string = new StringBuffer();
        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
        String line;
        try{
            while((line = reader.readLine()) != null) {
                string.append(line + "\n");
            }
        }catch(IOException e){
        	e.printStackTrace();
        }
        return string.toString();
    }

	public static DefaultHttpClient getHttpClient() {
		HttpParams httpParams = new BasicHttpParams();
		HttpConnectionParams.setConnectionTimeout(httpParams, 40000);
		HttpConnectionParams.setSoTimeout(httpParams, 40000);
		DefaultHttpClient httpClient = new DefaultHttpClient(httpParams);	
		return httpClient;
	}
}