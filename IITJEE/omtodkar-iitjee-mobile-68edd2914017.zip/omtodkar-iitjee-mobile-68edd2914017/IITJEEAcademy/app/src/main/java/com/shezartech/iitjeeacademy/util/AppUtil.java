package com.shezartech.iitjeeacademy.util;

import java.util.Calendar;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

public class AppUtil {
	
	public static void saveDataInSharedPreferences(Context context, String name, String value){
		SharedPreferences sharedPreferences = context.getSharedPreferences("AppPreferences", Context.MODE_PRIVATE);
	    Editor editor = sharedPreferences.edit();
	    editor.putString(name, value);
	    editor.commit();
	}
	
	public static String getDataFromSharedPreferences(Context context, String name){
		String value = "";
		SharedPreferences sharedPreferences = context.getSharedPreferences("AppPreferences", Context.MODE_PRIVATE);
		if(sharedPreferences.contains(name)){
			value = sharedPreferences.getString(name, "");
		}                         
		return value;
	}
	
	public static void removeDataFromSharedPreferences(Context context){
		SharedPreferences settings = context.getSharedPreferences("AppPreferences", Context.MODE_PRIVATE);
		settings.edit().clear().commit();
	}
	
	public static boolean isOnline(Context context) {
        ConnectivityManager connMgr = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo ni = connMgr.getActiveNetworkInfo();
        if (ni != null && ni.isAvailable() && ni.isConnected()) {
            return true;
        } else {
            return false;
        }
    }
	
	public static int currentSystemYear(){
		Calendar calendar = Calendar.getInstance();
		int year = calendar.get(Calendar.YEAR);
		return year;
	}
}