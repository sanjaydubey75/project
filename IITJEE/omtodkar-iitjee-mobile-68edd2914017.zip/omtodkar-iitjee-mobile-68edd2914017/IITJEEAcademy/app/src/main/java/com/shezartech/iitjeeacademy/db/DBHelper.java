package com.shezartech.iitjeeacademy.db;

import static com.shezartech.iitjeeacademy.db.DBTablesColumns.ID;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.NAME;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.SUBJECT;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.TABLE_SUBJECTS_DETAILS;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.TABLE_TOPIC_DETAILS;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.TABLE_STATES;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.STATES_NAME;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.TABLE_INSTITUTES;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.INSTITUTE_NAME;
import java.util.ArrayList;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DBHelper extends SQLiteOpenHelper {
	private static final String TAG = "DBHelper-->";
    private static final int DATABASE_VERSION = 1;
    private static final String DB_NAME = "shopappdb";
    
    private static final String DATABASE_NAME = DB_NAME;//DB_PATH+DB_NAME;
    
	public DBHelper(Context mContext) {
        super(mContext, DATABASE_NAME, null, DATABASE_VERSION);        
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
		String CREATE_TABLE1 = "CREATE TABLE IF NOT EXISTS " +TABLE_SUBJECTS_DETAILS+" ("+ID+" TEXT,"+NAME+" TEXT)";   		
		db.execSQL(CREATE_TABLE1);    		
		Log.d(TAG, CREATE_TABLE1+" Table created.");
		
		String CREATE_TABLE2 = "CREATE TABLE IF NOT EXISTS " +TABLE_TOPIC_DETAILS+" ("+ID+" TEXT,"+NAME+" TEXT,"+SUBJECT+" TEXT)";   		
		db.execSQL(CREATE_TABLE2);    		
		Log.d(TAG, CREATE_TABLE2+" Table created.");
		
		String CREATE_TABLE3 = "CREATE TABLE IF NOT EXISTS " +TABLE_STATES+" ("+STATES_NAME+" TEXT)";   		
		db.execSQL(CREATE_TABLE3);    		
		Log.d(TAG, CREATE_TABLE3+" Table created.");
		
		String CREATE_TABLE4 = "CREATE TABLE IF NOT EXISTS " +TABLE_INSTITUTES+" ("+INSTITUTE_NAME+" TEXT)";   		
		db.execSQL(CREATE_TABLE4);    		
		Log.d(TAG, CREATE_TABLE4+" Table created.");
    }

    public void insertSubjectDetails(String id, String name) {    	
    	SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        long insertedRows = 0;      	
        Log.d(TAG, "--Start Inserting row in "+TABLE_SUBJECTS_DETAILS +"table");       			
        Log.d(TAG, "id = "+id); 
        Log.d(TAG, "name = "+name); 
      
        try{  
        	values.put(ID,id);
     	   	values.put(NAME,name);

     	   	insertedRows = db.insert(TABLE_SUBJECTS_DETAILS, null, values);
     	   	Log.d(TAG, insertedRows + " Row inserted successfully in "+TABLE_SUBJECTS_DETAILS +" table");            	           		        	        		        		   
        } catch(Exception e){
        	e.getMessage();
        }finally { 
     	   db.rawQuery("COMMIT", null);    
     	   db.close();     		    		
        } 
    }
    
    public void insertTopicDetails(String id, String name, String subject) {    	
    	SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        long insertedRows = 0;      	
        Log.d(TAG, "--Start Inserting row in "+TABLE_TOPIC_DETAILS +"table");       			
        try{  
        	values.put(ID,id);
     	   	values.put(NAME,name);
     	   	values.put(SUBJECT,subject);

     	   	insertedRows = db.insert(TABLE_TOPIC_DETAILS, null, values);
     	   	Log.d(TAG, insertedRows + " Row inserted successfully in "+TABLE_TOPIC_DETAILS +" table");            	           		        	        		        		   
        } catch(Exception e){
        	e.getMessage();
        }finally { 
     	   db.rawQuery("COMMIT", null);    
     	   db.close();     		    		
        } 
    }
    
    public void insertStates(String stateName) {    	
    	SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        long insertedRows = 0;      	
        Log.d(TAG, "--Start Inserting row in "+TABLE_STATES +"table");       			
        try{  
        	values.put(STATES_NAME, stateName);

     	   	insertedRows = db.insert(TABLE_STATES, null, values);
     	   	Log.d(TAG, insertedRows + " Row inserted successfully in "+TABLE_STATES +" table");            	           		        	        		        		   
        } catch(Exception e){
        	e.getMessage();
        }finally { 
     	   db.rawQuery("COMMIT", null);    
     	   db.close();     		    		
        } 
    }
    
    public void insertInstitute(String instituteName) {    	
    	SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        long insertedRows = 0;      	
        Log.d(TAG, "--Start Inserting row in "+TABLE_INSTITUTES +"table");       			
        try{  
        	values.put(INSTITUTE_NAME, instituteName);

     	   	insertedRows = db.insert(TABLE_INSTITUTES, null, values);
     	   	Log.d(TAG, insertedRows + " Row inserted successfully in "+TABLE_INSTITUTES +" table");            	           		        	        		        		   
        } catch(Exception e){
        	e.getMessage();
        }finally { 
     	   db.rawQuery("COMMIT", null);    
     	   db.close();     		    		
        } 
    }
    
    public String selectSubjectId(String subName) {
    	Log.d(TAG, "--selectSubjectId--");
    	String subjectId = "";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_SUBJECTS_DETAILS, new String[] {ID}, NAME + "=?", new String[] {String.valueOf(subName)}, null, null, null, null);
        
        Log.d(TAG, "cursor.getCount() = "+cursor.getCount()) ;
        try{
        	if(cursor.moveToFirst()) {
        		do{
        			subjectId = cursor.getString(0);
        		}while(cursor.moveToNext());
        		if(cursor != null && !cursor.isClosed())
        			cursor.close();
        	}
        }catch(Exception e){
        	e.printStackTrace();
        }finally {
	    	cursor.close();	    	
	       	db.close();
    	}
        return subjectId;
    }
    
    public ArrayList<String> selectSubjectName(String tableName) {
    	Log.d(TAG, "--selectSubjectName--");
    	ArrayList<String> listOfSubjectName = new ArrayList<String>();
    	
    	if(tableName.equals(TABLE_SUBJECTS_DETAILS)){
    		listOfSubjectName.add("Select Subject");
    	}else if(tableName.equals(TABLE_TOPIC_DETAILS)){
    		listOfSubjectName.add("Select Topic");
    	}
    	
    	String name = "";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(tableName, new String[] {NAME}, null, null, null, null, null, null);
        Log.d(TAG, "cursor.getCount() = "+cursor.getCount()) ;
        try{
        	if(cursor.moveToFirst()) {
        		do{
        			name = cursor.getString(0);
        			listOfSubjectName.add(name);
        		}while(cursor.moveToNext());
        		if(cursor != null && !cursor.isClosed())
        			cursor.close();
        	}
        }catch(Exception e){
        	e.printStackTrace();
        }finally {
	    	cursor.close();	    	
	       	db.close();
    	}
        return listOfSubjectName;
    }
    
    public String selectTopicId(String topicName) {
    	Log.d(TAG, "--selectTopicId--");
    	
    	String topicId = "";
    	
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_TOPIC_DETAILS, new String[] {ID}, NAME + "=?", new String[] {String.valueOf(topicName)}, null, null, null, null);
        
        Log.d(TAG, "cursor.getCount() = "+cursor.getCount()) ;
        try{
        	if(cursor.moveToFirst()) {
        		do{
        			topicId = cursor.getString(0);
        		}while(cursor.moveToNext());
        		if(cursor != null && !cursor.isClosed())
        			cursor.close();
        	}
        }catch(Exception e){
        	e.printStackTrace();
        }finally {
	    	cursor.close();	    	
	       	db.close();
    	}
        return topicId;
    }
    
    public ArrayList<String> selectTopicName(String subjectId) {
    	Log.d(TAG, "--selectTopicName--");
    	
    	ArrayList<String> listOfSubjectName = new ArrayList<String>();
    	
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_TOPIC_DETAILS, new String[] {NAME}, SUBJECT + "=?", new String[] {String.valueOf(subjectId)}, null, null, null, null);
        
        Log.d(TAG, "cursor.getCount() = "+cursor.getCount()) ;
        try{
        	if(cursor.moveToFirst()) {
        		do{
        			listOfSubjectName.add(cursor.getString(0));
        			
        		}while(cursor.moveToNext());
        		if(cursor != null && !cursor.isClosed())
        			cursor.close();
        	}
        }catch(Exception e){
        	e.printStackTrace();
        }finally {
	    	cursor.close();	    	
	       	db.close();
    	}
        return listOfSubjectName;
    }
    
    public ArrayList<String> selectState() {
    	Log.d(TAG, "--selectState--");
    	ArrayList<String> listOfStatesName = new ArrayList<String>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_STATES, new String[] {STATES_NAME}, null, null, null, null, null, null);
        Log.d(TAG, "cursor.getCount() = "+cursor.getCount()) ;
        try{
        	if(cursor.moveToFirst()) {
        		do{
        			listOfStatesName.add(cursor.getString(0));
        		}while(cursor.moveToNext());
        		if(cursor != null && !cursor.isClosed())
        			cursor.close();
        	}
        }catch(Exception e){
        	e.printStackTrace();
        }finally {
	    	cursor.close();	    	
	       	db.close();
    	}
        return listOfStatesName;
    }
    
    public ArrayList<String> selectInstitute() {
    	Log.d(TAG, "--selectInstitute--");
    	ArrayList<String> listOfInstitutesName = new ArrayList<String>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_INSTITUTES, new String[] {INSTITUTE_NAME}, null, null, null, null, null, null);
        Log.d(TAG, "cursor.getCount() = "+cursor.getCount()) ;
        try{
        	if(cursor.moveToFirst()) {
        		do{
        			listOfInstitutesName.add(cursor.getString(0));
        		}while(cursor.moveToNext());
        		if(cursor != null && !cursor.isClosed())
        			cursor.close();
        	}
        }catch(Exception e){
        	e.printStackTrace();
        }finally {
	    	cursor.close();	    	
	       	db.close();
    	}
        return listOfInstitutesName;
    }
    
    public int checkTableEmpty(String tableName, String columnName){
    	Log.d(TAG, "--checkTableEmpty--");
    	int selectedRow = 0;
    	SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(tableName, new String[] {columnName}, null, null, null, null, null, null);
        selectedRow = cursor.getCount();
        cursor.close();	    	
        db.close();
        return selectedRow;
    }
   
    public void deleteAllRowsFromTable(String tableName) {
        SQLiteDatabase db = this.getWritableDatabase();
        int deletedRows = db.delete(tableName,null,null);
        Log.d(TAG, deletedRows+" Deleted successfully from "+tableName+" Table");
        db.close();
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    	Log.d(TAG, "Upgrading database from version " + oldVersion + " to " + newVersion + ", which will destroy all old data");
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_SUBJECTS_DETAILS);
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_TOPIC_DETAILS);
        onCreate(db);
    } 
}