package com.shezartech.iitjeeacademy.ui.activity;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.KeyEvent;
import android.widget.ImageView;
import android.widget.Toast;

public class SendQuestionActivity extends Activity {

	private final static String TAG = "UploadQuestionImageActivity-->";
	private ImageView imgFavorite;
	private final static int CAPTURE_IMAGE_REQUEST_CODE = 1;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.send_question_image);
		imgFavorite = (ImageView)findViewById(R.id.imageView1);
		open();
//      imgFavorite.setOnClickListener(new OnClickListener() {
//         @Override
//         public void onClick(View v) {
//            open();
//         }
//      });
	}
	
	public void open(){
		Intent intent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
		startActivityForResult(intent, CAPTURE_IMAGE_REQUEST_CODE);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
// 		TODO Auto-generated method stub
//      super.onActivityResult(requestCode, resultCode, data);
//      Bitmap bp = (Bitmap) data.getExtras().get("data");
//      imgFavorite.setImageBitmap(bp);
		Log.d(TAG, "requestCode = "+requestCode);
		Log.d(TAG, "resultCode = "+resultCode);
	   
		if (requestCode == CAPTURE_IMAGE_REQUEST_CODE && resultCode == RESULT_OK) {
			super.onActivityResult(requestCode, resultCode, data);
			showAlert(getResources().getString(R.string.alert_upload_image_title), getResources().getString(R.string.alert_upload_image_message));
			saveImageInSDCard(data);
          
		   	Bitmap bp = (Bitmap) data.getExtras().get("data");
		   	int h = 400; // height in pixels
		   	int w = 400; // width in pixels    
		   	Bitmap scaled = Bitmap.createScaledBitmap(bp, h, w, true);
		   	imgFavorite.setImageBitmap(scaled);
		   	
		} else if ( resultCode == RESULT_CANCELED) {
			Toast.makeText(this, " Picture was not taken ", Toast.LENGTH_SHORT).show();
		} else {       
			Toast.makeText(this, " Picture was not taken ", Toast.LENGTH_SHORT).show();
		}
	}
   
	private void saveImageInSDCard(Intent imageData){
		Bitmap thumbnail = (Bitmap) imageData.getExtras().get("data");  
		ByteArrayOutputStream bytes = new ByteArrayOutputStream();
		thumbnail.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
		File file = new File(Environment.getExternalStorageDirectory()+File.separator + "iitjee_question.jpg");
		Log.d(TAG, "file.getPath() = "+file.getPath());
		try {
			if(file.exists()){
				boolean isFileDeleted = file.delete();
				Log.d(TAG, "File Deleted Successfully isFileDeleted = "+isFileDeleted);
			}else{
				file.createNewFile();
				FileOutputStream fo = new FileOutputStream(file);
				fo.write(bytes.toByteArray());
				fo.close();
			}
		}catch (IOException e) {
			e.printStackTrace();
		}
	}
   
	public void showAlert(String title, String message){
		AlertDialog.Builder alertDialog = new AlertDialog.Builder(SendQuestionActivity.this);
		alertDialog.setTitle(title);
		alertDialog.setMessage(message);
		//alertDialog.setIcon(R.drawable.ic_delete);
		alertDialog.setCancelable(false);
		alertDialog.setPositiveButton(getResources().getString(R.string.btn_send_email), new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog,int which) {
				dialog.dismiss();
				Intent i = new Intent(SendQuestionActivity.this, LoginActivity.class);
				startActivity(i);
				finish();
			}
		});
		alertDialog.setNegativeButton(getResources().getString(R.string.btn_cancel), new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog,int which) {
				dialog.dismiss();
				Intent i = new Intent(SendQuestionActivity.this, LoginActivity.class);
				startActivity(i);
				finish();
			}
		});
		alertDialog.show();
	}
   
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if ((keyCode == KeyEvent.KEYCODE_BACK)) { //Back key pressed
			Log.d("CDA", "onKeyDown Called");
	    	Intent i = new Intent(SendQuestionActivity.this, LoginActivity.class);
	    	startActivity(i);
	    	finish();
	    	return true;
		}
	    return super.onKeyDown(keyCode, event);
	}
}