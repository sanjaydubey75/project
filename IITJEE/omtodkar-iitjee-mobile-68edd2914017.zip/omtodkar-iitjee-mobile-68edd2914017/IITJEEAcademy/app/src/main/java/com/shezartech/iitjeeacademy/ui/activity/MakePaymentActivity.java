package com.shezartech.iitjeeacademy.ui.activity;

import static com.shezartech.iitjeeacademy.db.DBTablesColumns.COUPON_CODE;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.EMAIL_ID;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.FIRST_NAME;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.INSTITUTE_NAME;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.LAST_NAME;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.MOBILE_NO;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.USER_REGISTRATION_REQUEST;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.SUBSCRIPTION_MODEL;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.TRANSACTION_ID;
import static com.shezartech.iitjeeacademy.db.DBTablesColumns.REDIRECT_STATUS;
import java.util.Timer;
import java.util.TimerTask;

import org.json.JSONObject;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.shezartech.iitjeeacademy.service.PostServiceConnector;
import com.shezartech.iitjeeacademy.util.AppUtil;
import com.shezartech.iitjeeacademy.util.DialogUtil;

public class MakePaymentActivity extends Activity{
	private static final String TAG = "MakePaymentActivity-->";
	private WebView webView;
	private DialogUtil dialogUtil;
	private String cookies = "";
	private String subscriptionPlan;
	@Override		
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.webview_layout);
		Bundle extras = getIntent().getExtras(); 
        if (extras != null) {
        	subscriptionPlan = extras.getString(SUBSCRIPTION_MODEL);
        }
        
		dialogUtil = new DialogUtil(MakePaymentActivity.this);
		dialogUtil.showToast("Please wait for a moment");
		webView = (WebView)findViewById(R.id.webView1);
		webView.setWebViewClient(new MyBrowser());
		open();
	}

	public void open(){
		String email = AppUtil.getDataFromSharedPreferences(MakePaymentActivity.this, EMAIL_ID);
		String firstName = AppUtil.getDataFromSharedPreferences(MakePaymentActivity.this, FIRST_NAME);
		String lastName = AppUtil.getDataFromSharedPreferences(MakePaymentActivity.this, LAST_NAME);
		String mobileNo = AppUtil.getDataFromSharedPreferences(MakePaymentActivity.this, MOBILE_NO);
		String institutionName = AppUtil.getDataFromSharedPreferences(MakePaymentActivity.this, INSTITUTE_NAME);
		String couponCode = AppUtil.getDataFromSharedPreferences(MakePaymentActivity.this, COUPON_CODE);
		
		String redirectStatus = AppUtil.getDataFromSharedPreferences(MakePaymentActivity.this, REDIRECT_STATUS);
		String paymentGatewayURL = "";
		if(redirectStatus.equals("PG")){
			paymentGatewayURL = getResources().getString(R.string.server_domain)+getResources().getString(R.string.payment_gateway_service)+"&email="+email+"&firstname="+firstName+"&lastname="+lastName+"&mobilenumber="+mobileNo+"&institution="+institutionName+"&couponcode="+couponCode;
		}else if(redirectStatus.equals("Pricing")){
			paymentGatewayURL = getResources().getString(R.string.server_domain)+getResources().getString(R.string.payment_gateway_service)+"model="+subscriptionPlan+"&email="+email+"&firstname="+firstName+"&lastname="+lastName+"&mobilenumber="+mobileNo;
		}
		//String urlDetails = subjectId+"/"+topicId+"/"+name+"/"+loginId+"/"+pwd;
		//String url = getResources().getString(R.string.server_domain) + getResources().getString(R.string.get_question_page_url_service)+urlDetails;
		
		//final String paymentGatewayURL = getResources().getString(R.string.server_domain)+getResources().getString(R.string.payment_gateway_service)+"model="+subscriptionPlan+"&email="+email+"&firstname="+firstName+"&lastname="+lastName+"&mobileNumber="+mobileNo;
//		final String transactionFailedUrl = "http://192.168.1.85/api/PaymentGatewayUrl/end";
//		String transactionFailedRequest = "{'model':'1','email':'shobhit@gmail.com','firstname':'shobhit','lastname':'mah','mobileNumber':'2342342212'}";;
//		GetServiceConnector connector = new GetServiceConnector(MakePaymentActivity.this);
//		connector.execute(url);
//		String request = "{'model':'1','email':'shobhit@gmail.com','firstname':'shobhit','lastname':'mah','mobileNumber':'2342342212'}";
//		request = request.replace("'", "\"");
		
//		PostServiceConnector serviceConnector = new PostServiceConnector(MakePaymentActivity.this);
//		serviceConnector.executePostMethod("http://192.168.1.85/PaymentGatewayUrl/start", request);
//		
		//String url = "http://192.168.1.53/iitjeeacademy/mobile/question/MAT/AEA/Shobhit/abcd@abcd.com/aA12!@";
		webView.getSettings().setLoadsImagesAutomatically(true);
		webView.getSettings().setJavaScriptEnabled(true);
		webView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY); 
		webView.loadUrl(paymentGatewayURL);
	    Log.d(TAG, "paymentGatewayURL--> = "+paymentGatewayURL);
	   
	    
	    callAsynchronousTask(paymentGatewayURL);
	}
	 
	private void callAsynchronousTask(final String paymentGatewayURL) {
	    final Handler handler = new Handler();
	    final Timer timer = new Timer();
	    CookieManager.getInstance().removeAllCookie();
	    TimerTask doAsynchronousTask = new TimerTask() {       
	        @Override
	        public void run() {
	            handler.post(new Runnable() {
	                public void run() {       
	                    try {
	                    	cookies = CookieManager.getInstance().getCookie(paymentGatewayURL);
	                        Log.d(TAG, "Cookies = " + cookies);
	                        if(cookies != null){
	                	    	timer.cancel();
	                	    	Log.d(TAG, "timer.cancel() invoked"); 
	                	    	JSONObject objResponse = (new JSONObject(cookies.split("=")[1]));
	        		    		String email = objResponse.getString("email");
	        					String transactionId = objResponse.getString("transactionId");
	        					String status = objResponse.getString("status");
	        					
	        					Log.d(TAG, "status = "+status); 
	        					Log.d(TAG, "email = "+email); 
	        					Log.d(TAG, "transactionId = "+transactionId); 
	        					AppUtil.saveDataInSharedPreferences(MakePaymentActivity.this, TRANSACTION_ID, transactionId);
	        					String request = AppUtil.getDataFromSharedPreferences(MakePaymentActivity.this, USER_REGISTRATION_REQUEST);
	        					request = request+",'transactionId':'"+transactionId+"'}";
		                    	request = request.replace("'", "\"");
		                    	
	        					if(status.equals("true")){
	        						if(AppUtil.isOnline(MakePaymentActivity.this)){
	        							PostServiceConnector serviceConnector = new PostServiceConnector(MakePaymentActivity.this);
	        							serviceConnector.execute(getResources().getString(R.string.server_domain)+getResources().getString(R.string.user_registration_service), request);
	        						}else{
	        							dialogUtil.showAlert("Internet Error",getResources().getString(R.string.alert_internet_unavailable_message));
	        						}
	        					}
	                	    }
	                    }catch(Exception e){
	                    	e.printStackTrace();
	                    }
	                }
	            });
	        }
	    };
	    timer.schedule(doAsynchronousTask, 0, 1500); //execute in every 50000 ms
	}
	
	private class MyBrowser extends WebViewClient { 
		@Override
		public boolean shouldOverrideUrlLoading(WebView view, String url){
			view.loadUrl(url);
			return true;
		}
	}
}