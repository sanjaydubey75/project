package com.shezartech.iitjeeacademy.ui.activity;

import java.util.regex.Pattern;

import com.shezartech.iitjeeacademy.util.DialogUtil;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class UserTellUsActivity  extends Activity{
	
	private TextView tvWebSiteIITJEEAcademy;
	private EditText etName;
	private EditText etMobileNo;
	private EditText etSubject;
	private EditText etMessage;
	private Button btnSendMessage;
	
	@Override
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
        setContentView(R.layout.user_tell_us_layout);
        tvWebSiteIITJEEAcademy = (TextView)findViewById(R.id.tv_web_site_iitjeeacademy);
        
        etName = (EditText) findViewById(R.id.et_name);
        etMobileNo = (EditText) findViewById(R.id.et_mobile);
        etSubject = (EditText) findViewById(R.id.et_subject);
        etMessage = (EditText) findViewById(R.id.et_message);
        btnSendMessage = (Button) findViewById(R.id.btn_send_message);
		
        addListenerTextView();
        addListenerButton();
	}
        
	private void addListenerTextView(){
		tvWebSiteIITJEEAcademy.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				String url = "http://"+tvWebSiteIITJEEAcademy.getText().toString();
				Intent i = new Intent(Intent.ACTION_VIEW);
				i.setData(Uri.parse(url)); 
				startActivity(i); 
			}
		});
	}
	
	private void addListenerButton(){
		btnSendMessage.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if(isValidate()){
					String sendTo = getResources().getString(R.string.tv_contact_email);
					String name = etName.getText().toString();
					String mobileNo = etMobileNo.getText().toString();
					String subject = etSubject.getText().toString();
					String message = "User Name: "+name+"\nUser Mobile No.: "+mobileNo+"\n\n"+etMessage.getText().toString();
		 
					Intent email = new Intent(Intent.ACTION_SEND);
					email.putExtra(Intent.EXTRA_EMAIL, new String[]{sendTo});
					email.putExtra(Intent.EXTRA_SUBJECT, subject);
					email.putExtra(Intent.EXTRA_TEXT, message);
					email.setType("message/rfc822");
					startActivity(Intent.createChooser(email, "Choose an Email client:"));
				}
			}
		});
	}
	
	private boolean isValidate(){
		boolean isValidate = false;
		
		if(etName.getText().length() <= 0){
			DialogUtil dialogUtil = new DialogUtil(UserTellUsActivity.this);
			dialogUtil.showToast(getResources().getString(R.string.toast_enter_name));
		}else if(!MOBILE_NO_PATTERN.matcher(etMobileNo.getText()).matches()){
			DialogUtil dialogUtil = new DialogUtil(UserTellUsActivity.this);
			dialogUtil.showToast(getResources().getString(R.string.alert_mobile_no));
		}else if(etSubject.getText().length() <= 0){
			DialogUtil dialogUtil = new DialogUtil(UserTellUsActivity.this);
			dialogUtil.showToast(getResources().getString(R.string.toast_enter_subject));
		}else if(etMessage.getText().length() <= 0){
			DialogUtil dialogUtil = new DialogUtil(UserTellUsActivity.this);
			dialogUtil.showToast(getResources().getString(R.string.toast_enter_message));
		}else{
			isValidate = true;
		}
		return isValidate;
	}
	
	public final Pattern MOBILE_NO_PATTERN = Pattern.compile(
    		"[0-9]{10}"
    );
}
