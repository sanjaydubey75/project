package com.shezartech.iitjeeacademy.ui.activity;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;

public class UserMeetUsActivity  extends Activity{
	private TextView tvWebSiteIITJEEAcademy;
	@Override
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.user_meet_us_layout);
		tvWebSiteIITJEEAcademy = (TextView)findViewById(R.id.tv_web_site_iitjeeacademy);
        addListenerTextView();
	}
	
	private void addListenerTextView(){
		tvWebSiteIITJEEAcademy.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				String url = "http://"+tvWebSiteIITJEEAcademy.getText().toString();
				Intent i = new Intent(Intent.ACTION_VIEW);
				i.setData(Uri.parse(url)); 
				startActivity(i); 
			}
		});
	}
}
