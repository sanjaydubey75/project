<?php
namespace Shezartech\IITJEEAcademy\ServiceProviders{
    use Illuminate\Support\ServiceProvider;

    class StudentServiceProvider extends ServiceProvider{

        protected $defer = true;

        public function register(){
            $this->app->bind(
                "Shezartech\\IITJEEAcademy\\Repositories\\Interfaces\\StudentRepositoryInterface",
                "Shezartech\\IITJEEAcademy\\Repositories\\StudentRepository"
            );
        }

        public function provides(){
            return [
                "Shezartech\\IITJEEAcademy\\Repositories\\Interfaces\\StudentRepositoryInterface",
            ];
        }
    }
}