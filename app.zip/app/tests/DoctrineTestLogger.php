<?php

namespace Shezar\IITJEEAcademy{
	use Doctrine\DBAL\Logging\SQLLogger;

	class DoctrineTestLogger implements SQLLogger
	{
		/**
		 * {@inheritdoc}
		 */
		public function startQuery($sql, array $params = null, array $types = null)
		{
			$myfile = fopen(app_path()."/tests/log/testsqllogger.txt", "a") or die("Unable to open file!");

//			fwrite($myfile, $sql."\n");

			foreach(explode('?', $sql) as $i => $part) {
				$xkcd = (isset($xkcd) ? $xkcd : null) . $part;
				if (isset($params[$i])) $xkcd .= "'".$params[$i]."'";
			}
			fwrite($myfile, $xkcd."\n");
//			if(count($params)>0){
//				foreach ($params as $index => $param)
//					fwrite($myfile, $index." => ".$param."\n");
//			}

	        fwrite($myfile, "--------------------------------------\n");
			fclose($myfile);

		}

		/**
		 * {@inheritdoc}
		 */
		public function stopQuery()
		{

		}
	}
}
