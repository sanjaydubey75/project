<?php

$relPath = "../..";

require $relPath.'/bootstrap/autoload.php';
$app = require_once $relPath.'/bootstrap/start.php';
$app->run();

use Illuminate\Foundation\Application;
use Shezartech\IITJEEAcademy\Repositories\Interfaces\QuestionRepositoryInterface;
use Shezartech\IITJEEAcademy\Repositories\QuestionRepository;
use Shezartech\IITJEEAcademy\Repositories\StudentRepository;

/** @var \Doctrine\ORM\EntityManager $em */
$em = App::make('Doctrine\ORM\EntityManagerInterface');

/** @var Student $student */
$student = $em->getRepository('Student')->find(46);
$correctnessProb = 1;
$topicId = 'A';
$subjectId = 'MAT';

function getRandomCorrect($correctnessProb){
	if(mt_rand(0, 99) > (100*$correctnessProb - 1)){
		$correct = false;
	} else $correct = true;
	return $correct;
}


$myfile = fopen("log/ranktest.txt", "a") or die("Unable to open file!");
fwrite($myfile, "global rank\t"."state rank\t"."subject global rank\t\t\t"."subject state rank\t\t\t"."subject level\t\t\t"    ."topic level\t\t\t\t\t"                                                     ."question id\t"."is correct"."\n");
fwrite($myfile, "\t".           "\t".          "phy\t"."chem\t"."mat\t"   ."phy\t"."chem\t"."mat\t"  ."phy\t"."chem\t"."mat\t" ."level\t"."correct attempt\t"."wrong attempt\t"."score\t"."accuracy array\t"."\t"                     ."\n");

function writeToFile($myfile, $student, $topicId, $questionId, $correct){
	fwrite($myfile,
		$student->getGlobalRank()."\t".
		$student->getStateRank()."\t".
		$student->getSubjectGlobalRank('PHY')->getRank()."\t".
		$student->getSubjectGlobalRank('CHE')->getRank()."\t".
		$student->getSubjectGlobalRank('MAT')->getRank()."\t".
		$student->getSubjectStateRank('PHY')->getRank()."\t".
		$student->getSubjectStateRank('CHE')->getRank()."\t".
		$student->getSubjectStateRank('MAT')->getRank()."\t".

		$student->getSubjectLevel('PHY')->getLevel()."\t".
		$student->getSubjectLevel('CHE')->getLevel()."\t".
		$student->getSubjectLevel('MAT')->getLevel()."\t".

		$student->getTopicLevel($topicId)->getLevel()."\t".
		($student->getTopicLevel($topicId)->getCorrectAttempts()?$student->getTopicLevel($topicId)->getCorrectAttempts():0)."\t".
		($student->getTopicLevel($topicId)->getWrongAttempts()?$student->getTopicLevel($topicId)->getWrongAttempts():0)."\t".
		$student->getTopicLevel($topicId)->getScore()."\t".

		$student->getAccuracy($topicId)->getAccuracy()."\t".
		$questionId."\t".
		($correct?1:0).
		"\n"
	);
}

writeToFile($myfile, $student, $topicId, null, null);

for ($i = 0; $i < 20; $i++){

	$questionRepo = new QuestionRepository($em, new StudentRepository($em));
	/** @var Question $question */
	$question = $questionRepo->getRandomQuestion($student, $topicId, $subjectId);
	if($question){
		$correct = getRandomCorrect($correctnessProb);
		RankingService::start($student, $subjectId, $topicId, $correct, $question->getId());
		writeToFile($myfile, $student, $topicId, $question->getId(), $correct);
	}

}
fclose($myfile);