<?php
/*
 * Created on Nov 5, 2014
 *
 * To change the template for this generated file go to
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */

use Doctrine\ORM\EntityManagerInterface;
use Doctrine\ORM\EntityRepository;

class RankingServiceTest extends TestCase {

    public function xcv__construct(EntityManagerInterface $entityManager){
        $this->entityManager = $entityManager;
    }

	/**
	 * A basic functional test example.
	 *
	 * @return void
	 */
	public function testBasicExample()
	{
		Route::enableFilters();

		$server = [
			'HTTP_Cookie' => 'csrf-token=IDvzx2UR70mZI1UawDTbwmxznAjI5Yeiixghoyqi',
			'HTTP_X-XSRF-TOKEN' => 'IDvzx2UR70mZI1UawDTbwmxznAjI5Yeiixghoyqi',
			'HTTP_Connection'=> 'keep-alive',
			'HTTP_Accept' => 'application/json, text/plain, */*',
			'HTTP_Origin' => 'http://localhost',
			'HTTP_Content-Type' => 'application/json;charset=UTF-8',
			'HTTP_Accept-Encoding' => 'gzip, deflate'
		];
		
		$authServer = [
			'HTTP_Cookie' => 'csrf-token=9akW0SQAPJLV87IoEbSGB3QCcfgbFbPUfEiwWN1L; auth-token=eyJpdiI6IkVpUVlQSGF3VzBVNVNBMmwyUHRcL2tRPT0iLCJ2YWx1ZSI6IlUrQmxVaTczeTcxYUJmTmV4em1FQTczV1k3d3dWV1RKUG84eU0wcWhWVnRpQjFtaVY4WWhLYmpDN3VCc1NBQmpiczZ4UFkxTDcyUVBhV2NoXC9rOVVsQnhcL3NndGF2MFMzSHFUWStOeWxmOXBEcXl2VFBLMXNyS0RLN2c4cytabE82d1dYOWZGQ2V2Q3NkeEZ1bkFcLzRqcGpuclwvZUlHQ3dtYTFjaUIyMzRkV0U9IiwibWFjIjoiODJlYzE4OTlmNDY2OTZmZGUwNWVjMDg1NGEyZDc0MjMzZDdiZjIwNTVmMzE0ZjUyN2RjYjJhYTZmZjlhMzVkNCJ9',
			'HTTP_X-XSRF-TOKEN' => '9akW0SQAPJLV87IoEbSGB3QCcfgbFbPUfEiwWN1L',
			'HTTP_Connection'=> 'keep-alive',
			'HTTP_Accept' => 'application/json, text/plain, */*',
			'HTTP_Origin' => 'http://localhost',
			'HTTP_Content-Type' => 'application/json;charset=UTF-8',
			'HTTP_Accept-Encoding' => 'gzip, deflate',
			'HTTP_role' => 'student',
			'HTTP_userEmail' => 'appsdaily@shezartech.com'
		];

		$data = ["userEmail"=>"appsdaily@shezartech.com","password"=>"aA12!@","role"=>"student"];


        $user = $this->entityManager->getRepository('Student')->findOneBy(array('email' => 'appsdaily@shezartech.com'));
        //$authToken = json_encode(array('userName' => $user->getFirstName(), 'userEmail' => $user-> getEmail(), 'datestampcreated' => time(), 'role' => $role));
        //Cookie::shouldReceive('queue')->once()->with('auth-token', $authToken, 60);

        //$response = $this->call('POST', 'api/auth/login', $data, array(), $server);
        //$response = $this->call('GET', 'api/state', array(), array(), $authServer);
        //$response = $this->call('GET', '/', array(), array(), $authServer);
		//$response = $this->call('GET', 'api/auth/student', array(), array(), $authServer);


		
		echo $response->getContent();
		
		echo "\r\n";
		
		echo $response->headers->get('Set-Cookie');
        echo "jygfjy";
		
//		$this->assertTrue($this->client->getResponse()->isOk());
	}

}
?>