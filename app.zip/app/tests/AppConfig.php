<?php

namespace Shezar\IITJEEAcademy{

	require "../../bootstrap/autoload.php";
	/** @var \Illuminate\Foundation\Application $app */
	$app = require_once '../../bootstrap/start.php';
	$app->run();
	/** @var \Doctrine\ORM\EntityManager $em */
	$em = \App::make('Doctrine\ORM\EntityManagerInterface');

	class AppConfig{
		protected $entityManager;
		public function __construct(){
			global $em;
			$this->entityManager = $em;
		}
		public static function main(){
			QuestionRepoTest::main();
		}
	}

	AppConfig::main();
}