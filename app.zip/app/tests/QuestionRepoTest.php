<?php

namespace Shezar\IITJEEAcademy{
	use Shezar\IITJEEAcademy\Repositories\QuestionRepository;
	use Shezar\IITJEEAcademy\Services\QuestionService;

	class QuestionRepoTest extends AppConfig{
		/** @var QuestionRepository */
		private $questionRepository;
		/** @var QuestionService  */
		private $questionService;
		public function __construct(){
			parent::__construct();
			$this->questionRepository = new QuestionRepository($this->entityManager);
			$this->questionRepository->setSQLLogger(new DoctrineTestLogger());
			$this->questionService = new QuestionService($this->questionRepository);
		}

		public static function main(){
			$test = new QuestionRepoTest();
			$test->testGetQuestion();
		}

		public function testGetQuestion(){
			$this->questionService->getQuestionsForLevelTest('A');
		}
	}
}
