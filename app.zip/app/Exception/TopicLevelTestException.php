<?php
namespace Shezar\IITJEEAcademy\Exceptions{
	class TopicLevelTestException extends \Exception{
		private $message1;
		public function __construct($message1){
			parent::__construct();
			$this->message1 = $message1;
		}
		public function display(){
			return $this->message1;
		}
	}
}