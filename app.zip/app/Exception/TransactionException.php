<?php
namespace Shezar\IITJEEAcademy\Exceptions{
	class TransactionException extends \Exception{
		protected $rootUrl;

		public function __construct($rootUrl){
			parent::__construct();
			$this->rootUrl = $rootUrl;
		}
	}

	class TransactionStartException extends TransactionException{
		private $paymentgatewayResponse;

		public function __construct($rootUrl, $paymentGatewayResponse){
			parent::__construct($rootUrl);
			$this->paymentgatewayResponse = $paymentGatewayResponse;
		}

		public function display(){
			return array(
				'oPGResp' => $this->paymentgatewayResponse,
				'rootUrl' => $this->rootUrl
			);
		}
	}

	class TransactionEndException extends TransactionException{
		protected $message;

		public function __construct($rootUrl, $message){
			parent::__construct($rootUrl);
			$this->message = $message;
		}

		public function display(){
			return array(
				'message' => $this->message,
				'rootUrl' => $this->rootUrl
			);
		}
	}
}