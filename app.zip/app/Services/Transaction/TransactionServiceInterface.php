<?php
namespace Shezar\IITJEEAcademy\Services{
	interface TransactionServiceInterface{

	}
}