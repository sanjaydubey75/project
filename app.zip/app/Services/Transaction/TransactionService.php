<?php
namespace Shezar\IITJEEAcademy\Services {
	use Shezar\IITJEEAcademy\Exceptions\TransactionEndException;
	use Shezar\IITJEEAcademy\Exceptions\TransactionStartException;
	use Shezar\IITJEEAcademy\Models\PricingModels;
	use Shezar\IITJEEAcademy\Repositories\BaseRepositoryInterface;
	use Shezar\IITJEEAcademy\Repositories\InstituteRepositoryInterface;
	use Shezar\IITJEEAcademy\Repositories\TransactionRepositoryInterface;
	use Shezar\IITJEEAcademy\Repositories\StudentRepositoryInterface;
	use Skip32;

	class TransactionService implements TransactionServiceInterface
	{

		/** @var BaseRepositoryInterface */
		private $baseRepository;
		/** @var TransactionValidationInterface */
		private $transactionValidation;
		/** @var TransactionRepositoryInterface */
		private $transactionRepository;
		/** @var InstituteRepositoryInterface */
		private $instituteRepository;
		/** @var StudentRepositoryInterface  */
		private $studentRepository;

		public function __construct(BaseRepositoryInterface $baseRepository,
		                            InstituteRepositoryInterface $instituteRepository,
		                            TransactionValidationInterface $transactionValidation,
		                            StudentRepositoryInterface $studentRepository,
		                            TransactionRepositoryInterface $transactionRepository)
		{
			$this->transactionValidation = $transactionValidation;
			$this->instituteRepository = $instituteRepository;
			$this->baseRepository = $baseRepository;
			$this->transactionRepository = $transactionRepository;
			$this->studentRepository = $studentRepository;
		}

		/**
		 * @param $input
		 * @return \Transaction
		 */
		private function createTransaction($input)
		{
			if (array_get($input, 'couponcode', null)) {
				/** @var \Institute $institute */
				$institute = $this->instituteRepository->findOneBy(
					array('name' => array_key_exists('institution', $input) ? $input['institution'] : null)
				);

				if ($institute) {
					/** @var \InstituteCouponCode $value */
					foreach (($institute->getCouponCodes()) as $key => $value) {
						if (!$value->isRegistered() && $value->__toString() == $input['couponcode']) {
							/** @var \InstituteCouponCode $couponcode */
							$couponcode = $value;
						}
					}
					$pricingModel = (new PricingModels())->getModel($couponcode->getSubscriptionModel());
					$amount = (1 - $couponcode->getDiscount() / 100) * $pricingModel->getAmount();
				}
			} else {
				$pricingModel = (new PricingModels())->getModel($input['model']);
				$amount = $pricingModel->getAmount();
			}

			/** @var \Transaction $transaction */
			$transaction = new \Transaction();
			$this->transactionRepository->save($transaction);

			$key = '0123456789abcdef0123'; // 10 bytes key
			$orderReferenceNumber = Skip32::encrypt($key, $transaction->getTransactionId());
			$invoiceNumber = $orderReferenceNumber;

			$transaction->setAmount($amount);
			$transaction->setComplete(false);
			$transaction->setEmail($input['email']);
			$transaction->setInvoiceNumber($invoiceNumber);
			$transaction->setOrderRefNumber($orderReferenceNumber);
			$transaction->setStartTime(new \DateTime());
			$transaction->setSubscriptionModel($pricingModel->getId());
			$transaction->setMobileNumber(array_get($input, 'mobilenumber'));
			$transaction->setFirstName(array_get($input, 'firstname', null));
			$transaction->setLastName(array_get($input, 'lastname', null));
			$transaction->setRegistrationComplete(false);
			$this->transactionRepository->save($transaction);

			return $transaction;
		}

		public function getPaymentGatewayUrl($input, $rootUrl)
		{
			$oMPI = new \MPIData();
			$oPostLibphp = new    \PostLibPHP();
			$oMerchant = new    \Merchant();
			$oBTA = new    \BillToAddress();
			$oSTA = new    \ShipToAddress();
			$oPGReserveData = new \PGReserveData();
			$responseUrl = $rootUrl . "/PaymentGatewayUrl/end";

			$transaction = $this->createTransaction($input);

			$oMerchant->setMerchantDetails("00214012", "00214012", "00214012", "", $transaction->getTransactionId(),
				$transaction->getOrderRefNumber(), $responseUrl, "POST", "INR", $transaction->getInvoiceNumber(),
				"req.Sale", $transaction->getAmount(), "", "Ext1", "true", "Ext3", "Ext4", "New PHP");
			$oBTA->setAddressDetails("", "", "Aline1", "", "", "Mumbai", "Maharashtra", "400065", "IND", "");
			$oSTA->setAddressDetails("Add1", "", "", "Mumbai", "Maharashtra", "400065", "IND", "");

			$oPGResp = $oPostLibphp->postSSL($oBTA, $oSTA, $oMerchant, $oMPI, $oPGReserveData);

			if ($oPGResp->getRespCode() == '000') {
				return $oPGResp->getRedirectionUrl();
			} else {
				throw new TransactionStartException($rootUrl, $oPGResp);
			}
		}

		public function postTransactionProcess($input, $rootUrl, $output)
		{
			/** @var Transaction $transaction */
			$transaction = $this->transactionRepository->find($output['TxnID']);
			if (array_key_exists('RespCode', $output) == 1) {
				$transaction->setResponseCode($output['RespCode']);
			}
			if (array_key_exists('Message', $output) == 1) {
				$transaction->setResponseMessage($output['Message']);
			}
			if (array_key_exists('ePGTxnID', $output) == 1) {
				$transaction->setEPGTransactionId($output['ePGTxnID']);
			}
			if (array_key_exists('AuthIdCode', $output) == 1) {
				$transaction->setAuthIdentityCode($output['AuthIdCode']);
			}
			if (array_key_exists('RRN', $output) == 1) {
				$transaction->setRRN($output['RRN']);
			}
			if (array_key_exists('CVRespCode', $output) == 1) {
				$transaction->setCVResponseCode($output['CVRespCode']);
			}
			$transaction->setEndTime(new \DateTime());
			$transaction->setComplete(true);
			$this->transactionRepository->save($transaction);
			$transactionDetails = array(
				'email' => $transaction->getEmail(),
				'transactionId' => $output['TxnID'],
				'status' => $output['RespCode'] == 0
			);
			return $transactionDetails;
		}

		public function getTransactionDetails($input){
			$details = array();
			$status = array();

			$details['Email'] = $input['email'];

			if(array_get($input, 'transactionId', null)){
				/** @var \Transaction $transaction */
				$transaction = $this->transactionRepository->find($input['transactionId']);
				$details['Invoice Number'] = $transaction->getInvoiceNumber();
				$details['Message'] = $transaction->getResponseMessage();
				$details['Amount Paid'] = $transaction->getAmount();
				$details['Transaction Date'] = $transaction->getEndTime()->setTimezone(new \DateTimeZone('Asia/Kolkata'))->format('d/m/Y');
				$details['Name'] = $transaction->getFirstName() ." ". $transaction->getLastName();
				$details['Subscription Duration'] = (new PricingModels())->getModel($transaction->getSubscriptionModel())->getDuration();

				$status['transaction'] = $transaction->getResponseCode() == 0;
			}

			if(array_get($input, 'couponcode', null)){
				$details['Coupon Code'] = $input['couponcode'];
			}

			/** @var \Student $student */
			$student = $this->studentRepository->findOneBy(array('email' => $input['email']));
			if($student){
				$details['Name'] = $student->getFirstname() ." ". $student->getLastname();
				$details['Subscription Duration'] = (new PricingModels())->getModel($student->getSubscriptionModel())->getDuration();
			}

			$status['registration'] = !($student == null);

			return array(
				'details' => $details,
				'status' => $status
			);
		}
	}
}