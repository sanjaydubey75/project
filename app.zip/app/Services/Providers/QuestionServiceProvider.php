<?php
namespace Shezar\IITJEEAcademy\Services\Providers{
	use Illuminate\Support\ServiceProvider;

	class QuestionServiceProvider extends ServiceProvider{

		protected $defer = true;

		public function register(){
			$this->app->bind(
				"Shezar\\IITJEEAcademy\\Services\\QuestionServiceInterface",
				"Shezar\\IITJEEAcademy\\Services\\QuestionService"
			);
		}

		public function provides(){
			return [
				"Shezar\\IITJEEAcademy\\Services\\QuestionServiceInterface",
			];
		}
	}
}