<?php
namespace Shezar\IITJEEAcademy\Services\Providers{
	use Illuminate\Support\ServiceProvider;

	class StudentServiceProvider extends ServiceProvider{

		protected $defer = true;

		public function register(){
			$this->app->bind(
				"Shezar\\IITJEEAcademy\\Services\\StudentServiceInterface",
				"Shezar\\IITJEEAcademy\\Services\\StudentService"
			);
		}

		public function provides(){
			return [
				"Shezar\\IITJEEAcademy\\Services\\StudentServiceInterface",
			];
		}
	}
}