<?php
namespace Shezar\IITJEEAcademy\Services\Providers{
	use Illuminate\Support\ServiceProvider;

	class TransactionValidationProvider extends ServiceProvider{

		protected $defer = true;

		public function register(){
			$this->app->bind(
				"Shezar\\IITJEEAcademy\\Services\\TransactionValidationInterface",
				"Shezar\\IITJEEAcademy\\Services\\TransactionValidation"
			);
		}

		public function provides(){
			return [
				"Shezar\\IITJEEAcademy\\Services\\TransactionValidationInterface",
			];
		}
	}
}