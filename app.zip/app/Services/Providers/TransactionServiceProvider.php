<?php
namespace Shezar\IITJEEAcademy\Services\Providers{
	use Illuminate\Support\ServiceProvider;

	class TransactionServiceProvider extends ServiceProvider{

		protected $defer = true;

		public function register(){
			$this->app->bind(
				"Shezar\\IITJEEAcademy\\Services\\TransactionServiceInterface",
				"Shezar\\IITJEEAcademy\\Services\\TransactionService"
			);
		}

		public function provides(){
			return [
				"Shezar\\IITJEEAcademy\\Services\\TransactionServiceInterface",
			];
		}
	}
}