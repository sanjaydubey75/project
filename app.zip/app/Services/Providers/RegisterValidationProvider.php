<?php
namespace Shezar\IITJEEAcademy\Services\Providers{
	use Illuminate\Support\ServiceProvider;

	class RegisterValidationProvider extends ServiceProvider{

		protected $defer = true;

		public function register(){
			$this->app->bind(
				"Shezar\\IITJEEAcademy\\Services\\RegisterValidationInterface",
				"Shezar\\IITJEEAcademy\\Services\\RegisterValidation"
			);
		}

		public function provides(){
			return [
				"Shezar\\IITJEEAcademy\\Services\\RegisterValidationInterface",
			];
		}
	}
}