<?php

namespace Shezar\IITJEEAcademy\Services{

	use Shezar\IITJEEAcademy\Exceptions\TopicLevelTestException;
	use Shezar\IITJEEAcademy\Models\PricingModels;
	use Shezar\IITJEEAcademy\Repositories\BaseRepositoryInterface;
	use Shezar\IITJEEAcademy\Repositories\InstituteRepositoryInterface;
	use Shezar\IITJEEAcademy\Repositories\StatewiseSelectionRepositoryInterface;
	use Shezar\IITJEEAcademy\Repositories\StudentRepository;
	use Shezar\IITJEEAcademy\Repositories\StudentRepositoryInterface;
	use Shezar\IITJEEAcademy\Repositories\SubjectRepositoryInterface;
	use Shezar\IITJEEAcademy\Repositories\TopicRepositoryInterface;
	use Shezar\IITJEEAcademy\Repositories\TransactionRepositoryInterface;

	class StudentService implements StudentServiceInterface{

		/** @var BaseRepositoryInterface  */
		private $baseRepository;
		/** @var StudentRepository  */
		private $studentRepository;
		/** @var TransactionRepositoryInterface  */
		private $transactionRepository;
		/** @var InstituteRepositoryInterface  */
		private $instituteRepository;
		/** @var StatewiseSelectionRepositoryInterface  */
		private $statewiseSelectionRepository;
		/** @var TopicRepositoryInterface  */
		private $topicRepository;
		/** @var SubjectRepositoryInterface  */
		private $subjectRepository;

		/**
		 * @param BaseRepositoryInterface $baseRepository
		 * @param StudentRepositoryInterface $studentRepository
		 * @param TransactionRepositoryInterface $transactionRepository
		 * @param InstituteRepositoryInterface $instituteRepository
		 * @param StatewiseSelectionRepositoryInterface $statewiseSelectionRepository
		 * @param TopicRepositoryInterface $topicRepository
		 * @param SubjectRepositoryInterface $subjectRepository
		 */
		public function __construct(
			BaseRepositoryInterface $baseRepository,
			StudentRepositoryInterface $studentRepository,
		    TransactionRepositoryInterface $transactionRepository,
			InstituteRepositoryInterface $instituteRepository,
			StatewiseSelectionRepositoryInterface $statewiseSelectionRepository,
			TopicRepositoryInterface $topicRepository,
			SubjectRepositoryInterface $subjectRepository)
		{
			$this->baseRepository = $baseRepository;
			$this->studentRepository = $studentRepository;
			$this->transactionRepository = $transactionRepository;
			$this->instituteRepository = $instituteRepository;
			$this->statewiseSelectionRepository = $statewiseSelectionRepository;
			$this->topicRepository = $topicRepository;
			$this->subjectRepository = $subjectRepository;
		}

		/**
		 * @param $input
		 * @throws \Exception
		 */
		public function register($input)
		{
			$this->baseRepository->beginTransaction();
			try{
				/** @var \Student $student */
				$student = new \Student;
				$student->setFirstname(array_key_exists('firstname', $input) ? $input['firstname'] :null);
				$student->setLastName(array_key_exists('lastname', $input) ? $input['lastname'] : null);
				$student->setPassword(\Hash::make(array_key_exists('password', $input) ? $input['password'] : null));
				$student->setEmail(array_key_exists('email', $input) ? $input['email'] : null);
				$student->setInstitution(array_key_exists('institution', $input) ? $input['institution'] : null);
				$student->setTargetYear(array_key_exists('year', $input) ? $input['year'] : null);

				/** @var /StatewiseSelection $state */
				$state = $this->statewiseSelectionRepository->findOneBy(array('name' => $input['state']));
				$student->setState($state);
				if (array_key_exists('mobileNumber', $input)){
					$student->setMobileNumber($input['mobileNumber']);
				}

				if (array_key_exists('parentEmail', $input)){
					$student->setParentEmail($input['parentEmail']);
				}

				$glrank = 500000;
				$strank = $glrank * $state->getPercentageSelected() / 100;

				$student->setGlobalRank($glrank);
				$student->setStateRank($strank);
				$student->setPhotoPath("0");
				$student->setBirthday(array_key_exists('dateOfBirth', $input) ? new \DateTime($input['dateOfBirth']) : null);

				$this->studentRepository->save($student);

				$subjects = $this->subjectRepository->findAll();
				$topics = $this->topicRepository->findAll();

				foreach ($subjects as $subject){
					$student->addSubjectLevel($subject, 1);
					$student->addSubjectStateRank($subject, $strank);
					$student->addSubjectGlobalRank($subject, $glrank);
				}
				foreach ($topics as $topic){
					$student->addTopicLevel($topic, 1);
					$student->addAccuracy($topic, json_encode(array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)));
					if(in_array($topic->getId(), array('PT', 'MT', 'KVP', 'oct', 'BXW')))
						$student->getTopicLevel($topic->getId())->setLevelTestAttempt(0);
				}

				//check if transaction or subscription

				if(array_key_exists('transactionId', $input) && $input['transactionId']!=""){

					/** @var \Transaction $transaction */
					$transaction = $this->transactionRepository->find($input['transactionId']);
					$model = (new PricingModels())->getModel($transaction->getSubscriptionModel());
					$student->setTransactionId($transaction->getTransactionId());
					$transaction->setRegistrationComplete(true);

					$this->transactionRepository->save($transaction);

				}
				if(array_key_exists('couponcode', $input) && $input['couponcode']!=""){
					$institute = $this->instituteRepository->findOneBy(array('name' => $input['institution']));

					/** @var \InstituteCouponCode[] $couponCodes */
					$couponCodes = $institute->getCouponCodes();

					foreach($couponCodes as $key => $value){

						if($value->getValue() == $input['couponcode'] && !$value->isRegistered()){
							//$value->setRegistered(true);
							//$value->setEmail($student->getEmail());
							$model = (new PricingModels())->getModel($value->getSubscriptionModel());
							$student->setCouponCode($value->getValue());
						}
					}
					$this->instituteRepository->save($institute);
				}

				$subscriptionLimit = (new \DateTime())->add($model->getSubscriptionInterval());
				$student->setSubscriptionLimit($subscriptionLimit);
				$student->setSubscriptionModel($model->getId());
				$student->setRegistrationDate(new \DateTime());

				$this->studentRepository->save($student);

				$this->baseRepository->commit();
			} catch(\Exception $e){
				$this->baseRepository->rollback();
				throw $e;
			}
		}

		public function registertrial($input)
		{
			$this->baseRepository->beginTransaction();
			try{
				/** @var \Student $student */
				$student = new \Student;
				$student->setFirstname(array_key_exists('firstname', $input) ? $input['firstname'] :null);
				$student->setLastName(array_key_exists('lastname', $input) ? $input['lastname'] : null);
				$student->setPassword(\Hash::make(array_key_exists('password', $input) ? $input['password'] : null));
				$student->setEmail(array_key_exists('email', $input) ? $input['email'] : null);

				/** @var /StatewiseSelection $state */
				$state = $this->statewiseSelectionRepository->findOneBy(array('name' => $input['state']));
				$student->setState($state);
				if (array_key_exists('mobileNumber', $input)){
					$student->setMobileNumber($input['mobileNumber']);
				}
				if (array_key_exists('mobilenumber', $input)){
					$student->setMobileNumber($input['mobilenumber']);
				}

				$glrank = 500000;
				$strank = $glrank * $state->getPercentageSelected() / 100;

				$student->setGlobalRank($glrank);
				$student->setStateRank($strank);
				$student->setPhotoPath("0");

				$this->studentRepository->save($student);

				$subjects = $this->subjectRepository->findAll();
				$topics = $this->topicRepository->findAll();

				foreach ($subjects as $subject){
					$student->addSubjectLevel($subject, 1);
					$student->addSubjectStateRank($subject, $strank);
					$student->addSubjectGlobalRank($subject, $glrank);
				}
				foreach ($topics as $topic){
					$student->addTopicLevel($topic, 1);
					$student->addAccuracy($topic, json_encode(array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)));

					//this looks to be very bad. I don't know why I did this. Please take care asap.
					if(in_array($topic->getId(), array('PT', 'MT', 'KVP', 'oct', 'BXW')))
						$student->getTopicLevel($topic->getId())->setLevelTestAttempt(0);
				}

				$model = (new PricingModels())->getModel(4);

				$subscriptionLimit = (new \DateTime())->add($model->getSubscriptionInterval());
				$student->setSubscriptionLimit($subscriptionLimit);
				$student->setSubscriptionModel($model->getId());
				$student->setRegistrationDate(new \DateTime());

				$this->studentRepository->save($student);

				$this->baseRepository->commit();
			} catch(\Exception $e){
				$this->baseRepository->rollback();
				throw $e;
			}
		}

		public function getRegistrationDetails($input, $cookie){

			$details = json_decode(array_get($cookie, 'transactionDetails', null));
			if(!$details) $details = array();
			else{
				$details = get_object_vars($details);
			}

			/** @var \Student $student */
			$student = $this->studentRepository->findOneBy(array('email' => $input['email']));
			if($student->getCouponCode()){
				$details['email'] = $student->getEmail();
				$details['couponcode'] = $student->getCouponCode();
				$details['institution'] = $student->getInstitution();
			}
			return $details;
		}

		public function setTopicLevel($topicId, $level, $authToken){
			/** @var \Student $student */
			$student = $this->studentRepository->getStudentFromToken($authToken);

			if($student->getTopicLevel($topicId)->getLevelTestAttempt() == false){
				throw new TopicLevelTestException('You have completed level determination test for this topic');
			}
			$topicLevel = $student->getTopicLevel($topicId);
			$topicLevel->setLevel($level);
			$topicLevel->setLevelTestAttempt(false);
			$this->studentRepository->save($student);
		}

		public function getTopicLevelTestAttemptStatus($topicId, $authToken){
			$student = $this->studentRepository->getStudentFromToken($authToken);
			return $student->getTopicLevel($topicId)->getLevelTestAttempt();
		}

		public function setTopicLevelTestAttemptStatus($topicId, $authToken, $status){
			$student = $this->studentRepository->getStudentFromToken($authToken);
			$student->getTopicLevel($topicId)->setLevelTestAttempt($status);
			$this->studentRepository->save($student);
		}
	}
}