<?php

namespace Shezar\IITJEEAcademy\Services {

	use Shezar\IITJEEAcademy\Models\PricingModels;
	use Shezar\IITJEEAcademy\Repositories\InstituteRepositoryInterface;
	use Shezar\IITJEEAcademy\Repositories\TransactionRepositoryInterface;
	use Validator as Validator;

	class RegisterValidation implements RegisterValidationInterface
	{

		/** @var TransactionRepositoryInterface */
		private $transactionRepository;
		/** @var InstituteRepositoryInterface */
		private $instituteRepository;

		/**
		 * @param InstituteRepositoryInterface $instituteRepository
		 * @param TransactionRepositoryInterface $transactionRepository
		 */
		public function __construct(InstituteRepositoryInterface $instituteRepository,
		                            TransactionRepositoryInterface $transactionRepository)
		{
			$this->transactionRepository = $transactionRepository;
			$this->instituteRepository = $instituteRepository;
		}

		public function validateInitial($input){
			$validator = Validator::make(
				array(
					'firstname' => array_key_exists('firstname', $input) ? $input['firstname'] : null,
					'lastname' => array_key_exists('lastname', $input) ? $input['lastname'] : null,
					'password' => array_key_exists('password', $input) ? $input['password'] : null,
					'email' => array_key_exists('email', $input) ? $input['email'] : null,
					'institution' => array_key_exists('institution', $input) ? $input['institution'] : null,
					'targetyear' => array_key_exists('year', $input) ? $input['year'] : null,
					'state' => array_key_exists('state', $input) ? $input['state'] : null,
					'mobilenumber' => array_key_exists('mobilenumber', $input) ? $input['mobilenumber'] : null,
					'parentEmail' => array_key_exists('parentEmail', $input) ? $input['parentEmail'] : null,
					'birthday' => array_key_exists('dateOfBirth', $input) ? $input['dateOfBirth'] : null,
					'role' => array_key_exists('role', $input) ? $input['role'] : null,
					'couponcode' => array_key_exists('couponcode', $input) ? $input['couponcode'] : null
				),
				array(
					'firstname' => 'required|max:500',
					'lastname' => 'required|max:500',
					'password' => 'required',
					'email' => 'required|email|unique:student|max:200',
					'institution' => 'max:500',
					'targetyear' => 'integer|min:' . date("Y"),
					'state' => 'exists:statewiseselection,name',
					'mobilenumber' => 'max:20',
					'parentEmail' => 'email|max:200',
					'birthday' => 'before:' . (new \DateTime())->format('m/d/Y') . '|date_format:m/d/Y',
					'role' => 'required'
				),
				array('birthday.before' => 'The :attribute must be a date before '.(new \DateTime())->format('d F Y'))
			);

			/** @var \Institute $institute */
			$institute = $this->instituteRepository->findOneBy(
				array('name' => array_key_exists('institution', $input) ? $input['institution'] : null)
			);
			$str = '';
			if ($institute) {
				/** @var \InstituteCouponCode $value */
				foreach (($institute->getCouponCodes()) as $key => $value) {
					if (!$value->isRegistered()) {
						$str = $str . $value . ",";
					}
				}
			}
			$str = rtrim($str, ",");

			$validator->sometimes('couponcode', 'in:' . $str, function ($input) {
				return $input->couponcode != null;
			});

			if ($validator->fails())
				return $validator->messages();
			else{
				return null;
			}
		}

		public function validate($input)
		{
			$transaction = array_key_exists('transactionId', $input) ?
				$this->transactionRepository->find($input['transactionId']) : null;
			$matchemail = $transaction ? $transaction->getEmail() : null;
			$transactionCode = $transaction ? $transaction->getResponseCode() : null;
			$validator = Validator::make(
				array(
					'firstname' => array_key_exists('firstname', $input) ? $input['firstname'] : null,
					'lastname' => array_key_exists('lastname', $input) ? $input['lastname'] : null,
					'password' => array_key_exists('password', $input) ? $input['password'] : null,
					'email' => array_key_exists('email', $input) ? $input['email'] : null,
					'institution' => array_key_exists('institution', $input) ? $input['institution'] : null,
					'targetyear' => array_key_exists('year', $input) ? $input['year'] : null,
					'state' => array_key_exists('state', $input) ? $input['state'] : null,
					'mobilenumber' => array_key_exists('mobilenumber', $input) ? $input['mobilenumber'] : null,
					'parentEmail' => array_key_exists('parentEmail', $input) ? $input['parentEmail'] : null,
					'birthday' => array_key_exists('dateOfBirth', $input) ? $input['dateOfBirth'] : null,
					'role' => array_key_exists('role', $input) ? $input['role'] : null,
					'transactionId' => array_key_exists('transactionId', $input) ? $input['transactionId'] : null,
					'couponcode' => array_key_exists('couponcode', $input) ? $input['couponcode'] : null,
					'transactionemail' => $matchemail,
					'transactionCode' => $transactionCode
				),
				array(
					'firstname' => 'required|max:500',
					'lastname' => 'required|max:500',
					'password' => 'required',
					'email' => 'required|email|unique:student|max:200',
					'institution' => 'max:500',
					'targetyear' => 'integer|min:' . date("Y"),
					'state' => 'required|exists:statewiseselection,name',
					'mobilenumber' => 'max:20',
					'parentEmail' => 'email|max:200',
					'birthday' => 'before:' . (new \DateTime())->format('m/d/Y') . '|date_format:m/d/Y',
					'role' => 'required',
					'transactionId' => 'exists:transactions,transactionId|required_without:couponcode',
					'couponcode' => 'required_without:transactionId'
				)
			);

			$validator->sometimes('email', 'same:transactionemail', function ($input) {
				return $input->transactionemail != null;
			});

			$validator->sometimes('transactionCode', 'in:0', function ($input) {
				return $input->transactionCode != null;
			});

			/** @var \Institute $institute */
			$institute = $this->instituteRepository->findOneBy(
				array('name' => array_key_exists('institution', $input) ? $input['institution'] : null)
			);
			$str = '';
			if ($institute) {
				/** @var \InstituteCouponCode $value */
				foreach (($institute->getCouponCodes()) as $key => $value) {
					if (!$value->isRegistered()) {
						$str = $str . $value . ",";
					}
				}
			}
			$str = rtrim($str, ",");

			$validator->sometimes('couponcode', 'in:' . $str, function ($input) {
				return $input->couponcode != null;
			});

			/** @var \InstituteCouponCode $couponcode */
			$couponcode = null;
			if ($institute && array_get($input, 'couponcode', null)) {
				/** @var \InstituteCouponCode $code */
				foreach (($institute->getCouponCodes()) as $key => $code) {
					if ($code->getValue() == $input['couponcode']) {
						$couponcode = $code;
						break;
					}
				}
			}

			if ($validator->fails())
				return $validator->messages();
			else{
				if(!$this->validateTransaction($transaction, $couponcode)){
					return array('transactionvalidity' => 'The transaction is not valid');
				}
				return null;
			}
		}

		/**
		 * @param $institute \Institute
		 * @param $transaction \Transaction
		 * @param $couponcode \InstituteCouponCode
		 * @return bool
		 */
		private function validateTransaction($transaction, $couponcode)
		{
			// if both are present
			if ($transaction && $couponcode) {

				// check if transaction id subscription model is same as that of institute coupon code
				// subscription model
				if ($transaction->getSubscriptionModel() != $couponcode->getSubscriptionModel())
					return false;

				//check if the amount in transaction + coupon code discount add up to same
				if((new PricingModels())->getModel($couponcode->getSubscriptionModel())
					->getAmount()*(1 - $couponcode->getDiscount()*.01) != $transaction->getAmount()){
					return false;
				}
				return true;
			}

			// if only instituteId,
			if($transaction){
				// the amount from transaction id should match the model
				if((new PricingModels())->getModel($transaction->getSubscriptionModel())->getAmount() != $transaction->getAmount()){
					return false;
				}
				return true;
			}

			// if only coupon code
			// the discount should be 100%
			if($couponcode){
				if($couponcode->getDiscount() != 100){
					return false;
				}
				return true;
			}
		}

		public function getDiscount($input){

			$institute = $this->instituteRepository->findOneBy(
				array('name' => array_key_exists('institution', $input) ? $input['institution'] : null)
			);

			$couponcode = null;
			if ($institute && array_get($input, 'couponcode', null)) {
				/** @var \InstituteCouponCode $code */
				foreach (($institute->getCouponCodes()) as $key => $code) {
					if ($code->getValue() == $input['couponcode']) {
						$couponcode = $code;
						break;
					}
				}
			}

			if($couponcode){return $couponcode->getDiscount();}
			return null;
		}
	}
}