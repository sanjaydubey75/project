<?php

namespace Shezar\IITJEEAcademy\Services{
	use Shezar\IITJEEAcademy\Exceptions\TransactionEndException;
	use Shezar\IITJEEAcademy\Repositories\InstituteRepositoryInterface;
	use Shezar\IITJEEAcademy\Repositories\TransactionRepositoryInterface;
	use Shezar\IITJEEAcademy\Repositories\StudentRepositoryInterface;

	class TransactionValidation implements TransactionValidationInterface{

		/** @var TransactionRepositoryInterface */
		private $transactionRepository;
		/** @var InstituteRepositoryInterface */
		private $instituteRepository;
		/** @var StudentRepositoryInterface  */
		private $studentRepository;


		/**
		 * @param InstituteRepositoryInterface $instituteRepository
		 * @param TransactionRepositoryInterface $transactionRepository
		 * @param StudentRepositoryInterface $studentRepository
		 */
		public function __construct(InstituteRepositoryInterface $instituteRepository,
		                            TransactionRepositoryInterface $transactionRepository,
		                            StudentRepositoryInterface $studentRepository)
		{
			$this->transactionRepository = $transactionRepository;
			$this->instituteRepository = $instituteRepository;
			$this->studentRepository = $studentRepository;
		}

		public function validateStart($input){
			$validation = array(
					'firstname' => 'required|max:500',
					'lastname' => 'required|max:500',
					'email' => 'required|email|unique:student|max:200',
					'mobilenumber' => 'max:20',
					'institution' => 'required_without:model|max:500',
					'couponcode' => 'required_without:model',
					'model' => 'in:1,2,3|required_without:couponcode'
				);
			
			if(array_key_exists('subscribeupdate', $input)){
				$validation["email"] = 'required|email|max:200';   // unique:student
			}
			
			$validator = \Validator::make(
				array(
					'firstname' => array_key_exists('firstname', $input) ? $input['firstname'] : null,
					'lastname' => array_key_exists('lastname', $input) ? $input['lastname'] : null,
					'email' => array_key_exists('email', $input) ? $input['email'] : null,
					'mobilenumber' => array_key_exists('mobilenumber', $input) ? $input['mobilenumber'] : null,
					'institution' => array_key_exists('institution', $input) ? $input['institution'] : null,
					'couponcode' => array_key_exists('couponcode', $input) ? $input['couponcode'] : null,
					'model' => array_get($input, 'model', null)
				),
				$validation
			);

			/** @var \Institute $institute */
			$institute = $this->instituteRepository->findOneBy(
				array('name' => array_key_exists('institution', $input) ? $input['institution'] : null)
			);
			$str = '';
			if ($institute) {
				/** @var \InstituteCouponCode $value */
				foreach (($institute->getCouponCodes()) as $key => $value) {
					if (!$value->isRegistered()) {
						$str = $str . $value . ",";
					}
				}
			}
			$str = rtrim($str, ",");

			$validator->sometimes('couponcode', 'in:' . $str, function ($input) {
				return $input->couponcode != null;
			});

			if ($validator->fails())
				return $validator->messages();
			else{
				return null;
			}
		}

		public function validateEnd($input, $rootUrl)
		{
			$masterResponseData = array_get($input, 'DATA', null);
			$masterDigest = array_get($input, 'EncryptedData', null);
			$masterFileName = app_path() . "/Sfa/key/icici/00214012.key";
			$masterMerchantId = "00214012";

			$oEncryptionUtilenc = new \EncryptionUtil();
			$mastersfaDigest = $oEncryptionUtilenc->getHMAC($masterResponseData, $masterFileName, $masterMerchantId);

			$validator = \Validator::make(
				array(
					'DATA' => $masterResponseData,
					'Digest' => $masterDigest,
					'mastersfadigest' => $mastersfaDigest,
					'cmp' => strcasecmp($masterDigest, $mastersfaDigest)
				),
				array(
					'DATA' => 'required',
					'Digest' => 'required',
					'mastersfadigest' => 'required',
					'cmp' => 'required|in:0'
				)
			);

			if ($validator->fails()) {
				throw new TransactionEndException($rootUrl, 'No data returned');
			} elseif (strcasecmp($masterDigest, $mastersfaDigest) != 0) {
				throw new TransactionEndException($rootUrl, 'No data returned');
			} else {
				parse_str($masterResponseData, $output);
				if (array_key_exists('TxnID', $output) != 1) {
					throw new TransactionEndException($rootUrl, 'No data returned');
				}
				return $output;
			}
		}

		public function validateGetDetails($input){

			$transactionEmail = null;
			if(array_get($input, 'transactionId')){
				/** @var \Transaction $transaction */
				$transaction = $this->transactionRepository->find($input['transactionId']);
				if($transaction)
					$transactionEmail = $transaction->getEmail();
			}

			$validator = \Validator::make(
				array(
					'transactionId' => array_get($input, 'transactionId', null),
					'email' => array_get($input, 'email', null),
					'transactionEmail' => $transactionEmail,
					'couponcode' => array_get($input, 'couponcode', null),
					'institution' => array_get($input, 'institution', null)
				),
				array(
					'transactionId' => 'required_without:couponcode,institution|required_with:transactionEmail|exists:transactions,transactionId',
					'email' => 'required|email|max:200',
					'transactionEmail' => 'required_without:couponcode,institution|required_with:transactionId|same:email',
					'couponcode' => 'required_with:institution|required_without:transactionId,transactionEmail',
					'institution' => 'required_with:couponcode|required_without:transactionId,transactionEmail'
				)
			);

			if(array_get($input, 'institution', null)){
				/** @var \Institute $institute */
				$institute = $this->instituteRepository->findOneBy(array('name' => $input['institution']));
				$str = '';
				if ($institute) {
					/** @var \InstituteCouponCode $value */
					foreach (($institute->getCouponCodes()) as $key => $value) {
						$str = $str . $value . ",";
					}
				}
				$str = rtrim($str, ",");

				$validator->sometimes('couponcode', 'in:' . $str, function ($input) {
					return $input->couponcode != null;
				});
			}

			$validator->sometimes('email', 'same:transactionEmail', function($input){
				return $input->transactionEmail != null;
			});

			if($validator->fails()){
				throw new \Exception('valid details are not set');
			}
		}
	}
}