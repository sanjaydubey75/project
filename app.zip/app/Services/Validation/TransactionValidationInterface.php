<?php
namespace Shezar\IITJEEAcademy\Services{
	interface TransactionValidationInterface{
		public function validateStart($input);
		public function validateEnd($input, $rootUrl);
	}
}