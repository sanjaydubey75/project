<?php

namespace Shezar\IITJEEAcademy\Services{

	use Shezar\IITJEEAcademy\Exceptions\TopicLevelTestException;
	use Shezar\IITJEEAcademy\Repositories\QuestionRepository;
	use Shezar\IITJEEAcademy\Repositories\QuestionRepositoryInterface;
	use Shezar\IITJEEAcademy\Repositories\StudentRepository;
	use Shezar\IITJEEAcademy\Repositories\StudentRepositoryInterface;

	class QuestionService implements QuestionServiceInterface{

		/** @var QuestionRepository  */
		private $questionRepository;

		/** @var StudentRepository */
		private $studentRepository;

		public function __construct(QuestionRepositoryInterface $questionRepository, StudentRepositoryInterface $studentRepository){
			$this->questionRepository = $questionRepository;
			$this->studentRepository = $studentRepository;
		}

		public function getQuestionsForLevelTest($topicId, $authToken){

			$student = $this->studentRepository->getStudentFromToken($authToken);
			if($student->getTopicLevel($topicId)->getLevelTestAttempt()){
				if($student->getTopicLevel($topicId)->getLevelTestAttempt() == false){
					throw new TopicLevelTestException('You have completed level determination test for this topic');
				}
			}

			/** @var \Question[] $questions */
			$questions = array();
			for($i = 1; $i < 6; $i++){
				$temp = $this->questionRepository->getQuestions(
					array('topicId' => $topicId, 'level' => $i),
					array('random' =>true, 'quantity' => 2)
				);
				foreach($temp as $key => $value)
					array_push($questions, $value);
			}
			$result=array();
			foreach($questions as $key=>$question){
				array_push($result, array('question' => $question->getDetails(), 'choices' => $question->getChoices(), 'solution' => $question->getSolutions()));
			}
			return $result;
		}
	}
}