<?php

namespace Shezar\IITJEEAcademy\Services{

	interface QuestionServiceInterface{


    }
}