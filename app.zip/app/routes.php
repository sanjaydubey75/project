<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the Closure to execute when that URI is requested.
|
*/

Route::get('/', array('before' => array('force.ssl', 'log'), function()
{	
	$response = Response::view('index');

//	$expirydate = (new DateTime(date(DateTime::COOKIE)))->add(new DateInterval('P1Y'));
//	$expirydate = (new DateTime())->add(new DateInterval('P1Y'));
//	$csrf_token = "csrf-token=".csrf_token()."; expires=".$expirydate->format(DateTime::COOKIE)."; path=/;";

	$csrf_token = "csrf-token=".csrf_token()."; path=/;";
	Config::set('session.driver', 'array');
	
	return $response->header('Set-Cookie', $csrf_token);
}));

Route::get('mobile/question/{subid}/{topicid}/{userFirstname}/{userEmail}/{password}', array(
	'uses' => 'MobileController@index'
))->where(array('password' => '(.*)', 'userEmail' => '(.*)'));

Route::any('mobile/{data?}', array('before' => array('force.ssl', 'log'), function()
{
	$response = Response::view('mobileindex');
//	$csrf_token = "csrf-token=".csrf_token()."; path=/;";
	Config::set('session.driver', 'array');
	return $response;
}))->where('data', '(.*)');

Route::get('PaymentGatewayUrl/start', array('before' => array('log'), 'uses' => 'PaymentGatewayController@start'));
Route::post('PaymentGatewayUrl/end', array('before' => array('log'), 'uses' => 'PaymentGatewayController@end'));
Route::get('api/PaymentGatewayUrl/end', array('before' => array('log', 'csrf_header'), 'uses' => 'PaymentGatewayController@result'));
Route::post('api/PaymentGatewayUrl/end/mobile', array('before' => array('log', 'csrf_header'), 'uses' => 'PaymentGatewayController@mobileresult'));

Route::group(array('prefix' => 'api/auth'), function(){

	Route::get('renewToken', array('before' => array('auth-with-authtoken'), function(){
		Config::set('session.driver', 'array');
		return Response::json(array('response' => array('status' => 'success')));
	}));
	
	Route::post('register', array('uses' => 'RegisterController@register'));
	Route::post('register/trial', array('uses' => 'RegisterController@registertrial'));
	Route::post('register/validate', array('uses' => 'RegisterController@validate'));
	Route::post('register/validate/email', array('uses' => 'RegisterController@validateEmail'));
	Route::post('register/validate/couponcode', array('uses' => 'RegisterController@validateCouponCode'));
	
	Route::post('login', array('before'=>array('log', 'csrf_header'), 'uses' => 'AuthenticationController@checkCredentials'));
	
	Route::post('logout', array('before'=>array('log', 'csrf_header'), 'uses' => 'AuthenticationController@logout'));

    Route::post('photoupload', 'StudentController@uploadPhoto');
	Route::resource('student', 'StudentController');
	
	Route::get('subject/details/{data}', 'SubjectController@details')->where('data', '(.*)');
	Route::resource('subject', 'SubjectController');
	
	Route::get('topic/details/{data}', 'TopicController@details')->where('data', '(.*)');
	Route::resource('topic', 'TopicController');
	
	Route::get('tutordetail', array('before' => array('csrf_header', 'auth-with-authtoken'), 'uses' => 'TutorController@details'));
	
	Route::get('question/{subjectId}/{topicId}', 'QuestionController@index');
// 	Route::get('question/{subjectId}/{topicId}', array('before' => array('log', 'auth-with-authtoken', 'csrf_header', 'auth-student'), 'uses' => 'QuestionController@index'));
	Route::resource('question', 'QuestionController');

    Route::post('ranking/submit/{data?}', 'RankingController@store')->where('data', '(.*)');
	Route::post('ranking/skip/{data?}', 'RankingController@skipped')->where('data', '(.*)');
	
	Route::post('share', 'ShareFriendController@share');

    Route::post('report/error', 'ReportController@error');
    Route::post('report/feedback', 'ReportController@feedback');

	Route::get('topicleveltest/getQuestions/{topicId}', 'TopicLevelTestController@index');
	Route::post('topicleveltest/setLevel/{topicId}', 'TopicLevelTestController@setLevel');
	Route::get('topicleveltest/getAttemptStatus/{topicId}', 'TopicLevelTestController@getAttemptStatus');
	Route::post('topicleveltest/setAttemptStatus/{topicId}', 'TopicLevelTestController@setAttemptStatus');

	Route::post('sendfeedback', 'FeedbackController@feedback');
});

Route::get('api/state', 'StateController@index');
Route::get('api/institute', 'InstituteController@index');
Route::get('api/questionshuffle', 'QuestionShuffleController@store');
Route::post('api/forgetpassword', 'ForgetPasswordController@index');
Route::post('api/changepassword', 'ForgetPasswordController@changePassword');

Route::post('api/contactus', 'ContactController@contactus');

Route::any('{slug}', array('before' => array('force.ssl', 'log'), function($slug)
{
	$response =Response::view('index');
	$csrf_token = "csrf-token=".csrf_token()."; path=/;";
	Config::set('session.driver', 'array');
	return $response->header('Set-Cookie', $csrf_token);
	
}))->where('slug', '(.*)');