<?php

use Doctrine\ORM\Mapping AS ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="share_friend_request")
 */
class ShareFriendRequest{
	
	/**
	 * @ORM\Id
	 * @ORM\Column(type="guid", nullable = false)
	 * @ORM\GeneratedValue(strategy="UUID")
	 */
	private $Id;
	
	/**
     * @ORM\ManyToOne(targetEntity="Student")
     * @ORM\JoinColumn(name="studentId", referencedColumnName="id", nullable=false)
     */
    private $student;
    
    /**
     * @ORM\Column(name="friendEmail", nullable=false)
     */
    private $friendEmail;
    
    /**
     * @ORM\Column(type="datetime", nullable=false)
     */
	private $time;

	/**
	 * @ORM\ManyToOne(targetEntity = "Question")
	 */
	private $question;

	function __construct($friendEmail, $question, $student, $time)
	{
		$this->friendEmail = $friendEmail;
		$this->question = $question;
		$this->student = $student;
		$this->time = $time;
	}

	public function getId(){
		return $this->Id;
	}
	
	public function getTime(){
		return $this->time;
	}
	
	public function getFriendEmail(){
		return $this->friendEmail;
	}
	
	public function getStudent(){
		return $this->student;
	}
}
?>