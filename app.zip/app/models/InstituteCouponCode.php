<?php

use Doctrine\ORM\Mapping AS ORM;
use Doctrine\Common\Collections\ArrayCollection;

/**
 * @ORM\Entity
 * @ORM\Table(name="institutecouponcode")
 */
class InstituteCouponCode{

	/**
	 * @ORM\Id
	 * @ORM\ManyToOne(targetEntity="Institute", inversedBy="couponCodes")
	 */
	private $instituteId;

	/**
	 * @ORM\Id
	 * @ORM\Column(type="string")
	 */
	private $value;

	/**
	 * @ORM\Column(type="boolean")
	 */
	private $registered;

	/**
	 * @ORM\Column(type="integer")
	 */
	private $subscriptionModel;

	/**
	 * @ORM\Column(type="integer")
	 */
	private $discount;

	/**
	 * @ORM\Column(type="string", length = 200, nullable=true)
	 */
	private $email;

	/**
	 * @return mixed
	 */
	public function getValue()
	{
		return $this->value;
	}

	public function __toString(){
		return $this->value;
	}

	public function isRegistered(){
		return $this->registered;
	}

	public function setRegistered($registered){
		$this->registered = $registered;
	}

	/**
	 * @return mixed
	 */
	public function getSubscriptionModel()
	{
		return $this->subscriptionModel;
	}

	/**
	 * @param mixed $subscriptionModel
	 */
	public function setSubscriptionModel($subscriptionModel)
	{
		$this->subscriptionModel = $subscriptionModel;
	}

	/**
	 * @return mixed
	 */
	public function getDiscount()
	{
		return $this->discount;
	}

	/**
	 * @return mixed
	 */
	public function getEmail()
	{
		return $this->email;
	}

	/**
	 * @param mixed $email
	 */
	public function setEmail($email)
	{
		$this->email = $email;
	}



}