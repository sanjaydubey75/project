<?php

use Doctrine\ORM\Mapping AS ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="topiclevels")
 */
class TopicLevel{
	/**
     * @ORM\Id
     * @ORM\ManyToOne(targetEntity="Student", inversedBy="topicLevels")
     */
    private $user;
    
    /**
     * @ORM\Id
     * @ORM\ManyToOne(targetEntity="Topic")
     * @ORM\JoinColumn(name="topicId", referencedColumnName="topic_id", nullable=false)
     */
    private $topic;
    
    /**
     * @ORM\Column(type="integer", length=20) 
     */
    private $level;
    
    /**
     * @ORM\Column(type="integer", length=20, nullable=true)
     */
    private $correctAttempts;
    
    /**
     * @ORM\Column(type="integer", length=20, nullable=true)
     */
    private $wrongAttempts;
    
    /**
     * @ORM\Column(type="float", length=20, nullable = true)
     */
    private $score;

	/**
	 * @ORM\Column(type="boolean", nullable=true)
	 * @var boolean
	 * it has 3 states
	 * null - the user will be directed to a prompt page to confirm whether he wants to give test or not (after that it will change to true or false)
	 * true - the user will be directed to the test page (on submitting test it will be ascertained that this flag is true and it will be changed to false thereafter.)
	 * false - the user will be directed to questions
	 */
	private $levelTestAttempt;
    
    public function __construct($user, $topic, $level)
    {
        $this->user = $user;
        $this->topic = $topic;
        $this->level = $level;
    }
    
    public function getLevel(){
    	return $this->level;
    }

	/**
	 * @param mixed $level
	 */
	public function setLevel($level)
	{
		$this->level = $level;
	}
    
    public function incrementLevel(){
    	$this->level++;
    	$this->correctAttempts = NULL;
    	$this->wrongAttempts = NULL;
    }
    
    public function setAttemptStatus($value){
    	if($value)
    		$this->correctAttempts++;
    	else
    		$this->wrongAttempts++;
    }
	
    public function getCorrectRatio(){
    	return $this->correctAttempts/($this->correctAttempts + $this->wrongAttempts);
    }
    
    public function setScore($value){
    	$this->score = $value;
    }
    
    public function getScore(){
    	return $this->score;
    }

	/**
	 * @return mixed
	 */
	public function getCorrectAttempts()
	{
		return $this->correctAttempts;
	}

	/**
	 * @return mixed
	 */
	public function getWrongAttempts()
	{
		return $this->wrongAttempts;
	}

	/**
	 * @return boolean
	 */
	public function getLevelTestAttempt()
	{
		return $this->levelTestAttempt;
	}

	/**
	 * @param boolean $levelTestAttempt
	 */
	public function setLevelTestAttempt($levelTestAttempt)
	{
		$this->levelTestAttempt = $levelTestAttempt;
	}


}
?>