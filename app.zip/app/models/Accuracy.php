<?php

use Doctrine\ORM\Mapping AS ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="accuracy")
 */
class Accuracy{
	/**
     * @ORM\Id
     * @ORM\ManyToOne(targetEntity="Student", inversedBy="accuracy")
     */
    private $user;
    
    /**
     * @ORM\Id
     * @ORM\ManyToOne(targetEntity="Topic")
     * @ORM\JoinColumn(name="topic_id", referencedColumnName="topic_id", nullable=false)
     */
    private $topic;
    
    /**
     * @ORM\Column(type="string", length=1000) 
     */
    private $accuracy;
    
    public function __construct($user, $topic, $accuracy)
    {
        $this->user = $user;
        $this->topic = $topic;
        $this->accuracy = $accuracy;
    }
    
    public function setAccuracy($value){
    	$this->accuracy = $value;
    }
    
    public function getAccuracy(){
    	return $this->accuracy;
    }
}
?>