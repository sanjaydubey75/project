<?php
/*
 * Created on Sep 29, 2014
 *
 * To change the template for this generated file go to
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */
use Doctrine\ORM\Mapping AS ORM;
/**
 * @ORM\Entity
 * @ORM\Table(name="topics")
 */
class Topic {

	/**
     * @ORM\Id
     * @ORM\Column(type="string", name="topic_id", length=50)
     */
    private $id;

    /**
     * @ORM\Column(type="string", name="name", length=500)
     */
    private $name;
    
    /**
     * @ORM\Column(type="string", length = 1000, name="info", length=1000)
     */
    private $info;
    
    /**
     * @ORM\ManyToOne(targetEntity="Subject")
     * @ORM\JoinColumn(name="subject_id", referencedColumnName="subject_id", nullable=false)
     */
	private $subject;

	/**
	 * @ORM\Column(type="integer")
	 */
	private $order;

	function __construct($id, $info, $name, $order, $subject)
	{
		$this->id = $id;
		$this->info = $info;
		$this->name = $name;
		$this->order = $order;
		$this->subject = $subject;
	}

	public function getId()
    {
        return $this->id;
    }

    public function getName()
    {
        return $this->name;
    }
    
    public function getInfo(){
    	return $this->info;
    }

    public function setName($name)
    {
        $this->name = $name;
    }

	/**
	 * @return Subject
	 */
	public function getSubjectId(){
    	return $this->subject;
    }

	/**
	 * @return mixed
	 */
	public function getOrder()
	{
		return $this->order;
	}
}
?>
