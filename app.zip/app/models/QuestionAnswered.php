<?php

use Doctrine\ORM\Mapping AS ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="questionanswered")
 */
class QuestionAnswered {

	/**
     * @ORM\Id
     * @ORM\ManyToOne(targetEntity = "Student")
     * @ORM\JoinColumn(name="userId", referencedColumnName="id", nullable=false)
     */
    private $user;
    
    /**
     * @ORM\Id
     * @ORM\ManyToOne(targetEntity = "Question")
     * @ORM\JoinColumn(name="questionId", referencedColumnName="id", nullable=false)
     */
    private $question;

    /**
     * @ORM\Column(name="status")
     */
    private $status;
    
    public function getUserId(){
        return $this->user;
    }
    
    public function getQuestionId(){
    	return $this->question;
    }
    
    public function __construct($user, $question){
    	$this->user = $user;
    	$this->question = $question;
    }
}
