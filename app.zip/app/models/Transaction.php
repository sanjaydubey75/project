<?php

use Doctrine\ORM\Mapping AS ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="transactions")
 */
class Transaction{
	/**
	 * @ORM\Id
	 * @ORM\Column(type = "integer", options={"unsigned"=true})
	 * @ORM\GeneratedValue(strategy="AUTO")
	 * @var int
	 */
	private $transactionId;

	/**
	 * @ORM\Column(type = "integer", unique = true, options={"unsigned"=true}, nullable=true)
	 * @var int
	 */
	private $orderRefNumber;

	/**
	 * @ORM\Column(type = "integer", unique = true, options={"unsigned"=true}, nullable=true)
	 * @var int
	 */
	private $invoiceNumber;

	/**
	 * @var \DateTime
	 * @ORM\Column(type="datetime", nullable=true)
	 */
	private $startTime;

	/**
	 * @var \DateTime
	 * @ORM\Column(type="datetime", nullable=true)
	 */
	private $endTime;

	/**
	 * @var boolean
	 * @ORM\Column(type="boolean", nullable=true)
	 */
	private $complete;

	/**
	 * @var boolean
	 * @ORM\Column(type="boolean", nullable=true)
	 */
	private $registrationComplete;

	/**
	 * @ORM\Column(type="string", length = 200, nullable=true)
	 * @var string
	 */
	private $email;

	/**
	 * @ORM\Column(type="string", length = 1000, nullable=true)
	 * @var string
	 */
	private $firstName;

	/**
	 * @ORM\Column(type="string", length = 100, nullable=true)
	 * @var string
	 */
	private $lastName;

	/**
	 * @ORM\Column(type="string", length = 20, nullable = true)
	 * @var string
	 */
	private $mobileNumber;

	/**
	 * @var int
	 * @ORM\Column(type="integer", nullable=true)
	 */
	private $amount;

	/**
	 * @var string
	 * @ORM\Column(type = "string", length = 30, nullable=true)
	 */
	private $subscriptionModel;

	/**
	 * @var int
	 * @ORM\Column(type="integer", length=5, nullable=true)
	 */
	private $responseCode;

	/**
	 * @var string
	 * @ORM\Column(type="string", length=50, nullable=true)
	 */
	private $responseMessage;

	/**
	 * @var string
	 * @ORM\Column(type="string", length=20, nullable=true)
	 */
	private $EPGTransactionId;

	/**
	 * @var int
	 * @ORM\Column(type="integer", nullable=true)
	 */
	private $authIdentityCode;

	/**
	 * @var string
	 * @ORM\Column(type="string", length=20, nullable=true)
	 */
	private $RRN;

	/**
	 * @var string
	 * @ORM\Column(type="string", length=5, nullable=true)
	 */
	private $CVResponseCode;

	/**
	 * @return int
	 */
	public function getTransactionId()
	{
		return $this->transactionId;
	}

	/**
	 * @param int $orderRefNumber
	 */
	public function setOrderRefNumber($orderRefNumber)
	{
		$this->orderRefNumber = $orderRefNumber;
	}

	/**
	 * @param int $invoiceNumber
	 */
	public function setInvoiceNumber($invoiceNumber)
	{
		$this->invoiceNumber = $invoiceNumber;
	}

	/**
	 * @param DateTime $startTime
	 */
	public function setStartTime($startTime)
	{
		$this->startTime = $startTime;
	}

	/**
	 * @param boolean $complete
	 */
	public function setComplete($complete)
	{
		$this->complete = $complete;
	}

	/**
	 * @param string $email
	 */
	public function setEmail($email)
	{
		$this->email = $email;
	}

	/**
	 * @param int $amount
	 */
	public function setAmount($amount)
	{
		$this->amount = $amount;
	}


	/**
	 * @param $subscriptionModel
	 */
	public function setSubscriptionModel($subscriptionModel)
	{
		$this->subscriptionModel = $subscriptionModel;
	}

	/**
	 * @param int $responseCode
	 */
	public function setResponseCode($responseCode)
	{
		$this->responseCode = $responseCode;
	}

	/**
	 * @param string $responseMessage
	 */
	public function setResponseMessage($responseMessage)
	{
		$this->responseMessage = $responseMessage;
	}

	/**
	 * @param DateTime $endTime
	 */
	public function setEndTime($endTime)
	{
		$this->endTime = $endTime;
	}

	/**
	 * @param int $authIdentityCode
	 */
	public function setAuthIdentityCode($authIdentityCode)
	{
		$this->authIdentityCode = $authIdentityCode;
	}

	/**
	 * @param string $RRN
	 */
	public function setRRN($RRN)
	{
		$this->RRN = $RRN;
	}

	/**
	 * @param string $EPGTransactionId
	 */
	public function setEPGTransactionId($EPGTransactionId)
	{
		$this->EPGTransactionId = $EPGTransactionId;
	}

	/**
	 * @param string $CVResponseCode
	 */
	public function setCVResponseCode($CVResponseCode)
	{
		$this->CVResponseCode = $CVResponseCode;
	}

	/**
	 * @return string
	 */
	public function getEmail()
	{
		return $this->email;
	}

	/**
	 * @return int
	 */
	public function getInvoiceNumber()
	{
		return $this->invoiceNumber;
	}

	/**
	 * @return int
	 */
	public function getResponseCode()
	{
		return $this->responseCode;
	}

	/**
	 * @return string
	 */
	public function getResponseMessage()
	{
		return $this->responseMessage;
	}



	/**
	 * @param string $mobileNumber
	 */
	public function setMobileNumber($mobileNumber)
	{
		$this->mobileNumber = $mobileNumber;
	}

	/**
	 * @param string $firstName
	 */
	public function setFirstName($firstName)
	{
		$this->firstName = $firstName;
	}

	/**
	 * @param string $lastName
	 */
	public function setLastName($lastName)
	{
		$this->lastName = $lastName;
	}

	/**
	 * @return string
	 */
	public function getSubscriptionModel()
	{
		return $this->subscriptionModel;
	}

	/**
	 * @return int
	 */
	public function getAmount()
	{
		return $this->amount;
	}

	/**
	 * @return string
	 */
	public function getFirstName()
	{
		return $this->firstName;
	}

	/**
	 * @return string
	 */
	public function getLastName()
	{
		return $this->lastName;
	}

	/**
	 * @param boolean $registrationComplete
	 */
	public function setRegistrationComplete($registrationComplete)
	{
		$this->registrationComplete = $registrationComplete;
	}

	/**
	 * @return boolean
	 */
	public function isRegistrationComplete()
	{
		return $this->registrationComplete;
	}

	/**
	 * @return DateTime
	 */
	public function getEndTime()
	{
		return $this->endTime;
	}

	/**
	 * @return int
	 */
	public function getOrderRefNumber()
	{
		return $this->orderRefNumber;
	}


}
?>