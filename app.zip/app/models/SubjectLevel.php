<?php
use Doctrine\ORM\Mapping AS ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="subjectlevels")
 */
class SubjectLevel{
	/**
	 * @ORM\Id
	 * @ORM\ManyToOne(targetEntity="Student", inversedBy="subjectLevels")
	 */
	private $user;

	/**
	 * @ORM\Id
	 * @ORM\ManyToOne(targetEntity="Subject")
	 * @ORM\JoinColumn(name="subjectId", referencedColumnName="subject_id", nullable=false)
	 */
	private $subject;

	/**
	 * @ORM\Column(type="integer", length=20)
	 */
	private $level;

	/**
	 * @ORM\Column(type = "boolean", nullable=true, name = "started_practice")
	 * @var boolean
	 * This is to make sure that rank is not displayed to user until he starts practicing
	 */
	private $startedPractice;

	public function __construct($user, $subject, $level)
	{
		$this->user = $user;
		$this->subject = $subject;
		$this->level = $level;
	}

	public function getLevel(){
		return $this->level;
	}

	public function setLevel($level){
		$this->level = $level;
	}

	/**
	 * @return boolean
	 */
	public function isStartedPractice()
	{
		return $this->startedPractice;
	}

	/**
	 * @param boolean $startedPractice
	 */
	public function setStartedPractice($startedPractice)
	{
		$this->startedPractice = $startedPractice;
	}
}
?>