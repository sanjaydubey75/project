<?php

use Doctrine\ORM\Mapping AS ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="password_change_request")
 */
class PasswordChangeRequest{
	
	/**
	 * @ORM\Column(type="string", nullable = false)
	 */
	private $hash;
	
	/**
	 * @ORM\Id
     * @ORM\OneToOne(targetEntity="Student")
     */
    private $user;
    
    /**
     * @ORM\Column(type="datetime", nullable=false)
     */
    private $time;
    
    public function __construct($user, $hash, $time)
    {
        $this->user = $user;
        $this->hash = $hash;
        $this->time = $time;
    }
    
    public function getUser(){
    	return $this->user;
    }
    
    public function getTime(){
    	return $this->time;
    }
    
    public function setTime($time){
    	$this->time = $time;
    }
    
    public function setHash($hash){
    	$this->hash = $hash;
    }
    
    public function getHash(){
    	return $this->hash;
    }
}
?>