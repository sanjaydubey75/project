<?php
/*
 * Created on Sep 24, 2014
 *
 * To change the template for this generated file go to
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */

use Doctrine\ORM\Mapping AS ORM;



/**
 * @ORM\Entity
 * @ORM\Table(name="tutor")
 */
class Tutor {

	/**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer", name="id")
     */
    private $id;

    /**
     * @ORM\Column(type="string", name="FirstName")
     */
    private $firstName;
    
    /**
     * @ORM\Column(type="string", length = 300, name="Email")
     */
    private $email;
    
    /**
     * @ORM\Column(type="string", length = 1000, name="Password")
     */
    private $password;

    public function getId()
    {
        return $this->id;
    }

    public function getName()
    {
        return $this->firstName;
    }

    public function setName($name)
    {
        $this->firstName = $name;
    }
    
    public function getEmail(){
    	return $this->email;
    }
    
    public function setEmail($email){
    	$this->email = $email;
    }
    
    public function getPassword(){
    	return $this->password;
    }
    
    public function setPassword($password){
    	$this->password = $password;
    }
}

?>
