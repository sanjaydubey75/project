<?php

use Doctrine\ORM\Mapping AS ORM;
use Doctrine\Common\Collections\ArrayCollection;

/**
 * @ORM\Entity
 * @ORM\Table(name="student")
 */
class Student {

	/**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer", length=11)
     */
    private $id;
    
    /**
     * @ORM\Column(type="string", length = 1000)
     */
    private $password;

    /**
     * @ORM\Column(type="string", length = 500)
     */
    private $firstName;
    
    /**
     * @ORM\Column(type="string", length = 500)
     */
    private $lastName;
    
    /**
     * @ORM\Column(type="string", length = 200, unique=true)
     */
    private $email;

    /**
     * @ORM\Column(type="string", length = 200, nullable = true)
     */
    private $parentEmail;
    
    /**
     * @ORM\Column(type="string", length = 500, nullable = true)
     */
    private $institution;

	/**
	 * @var date $birthday
	 * @ORM\Column(name="birthday", type="date", nullable=true)
	 */
    private $birthday;

	/**
	 * @var int
	 * @ORM\Column(type = "integer", options={"unsigned"=true}, nullable=true)
	 */
	private $transactionId;
    
    /**
     * @ORM\Column(type="integer", length = 11)
     */
    private $globalrank;
    
    /**
     * @ORM\Column(type="integer", length = 11)
     */
    private $stateRank;

    /**
     * @var \DateTime $subscriptionLimit
     * @ORM\Column(name="SubscriptionLimit", type="datetime", nullable=true)
     */
    private $subscriptionLimit;

	/**
	 * @var  \DateTime $registrationDate
	 * @ORM\Column(name="registration_date", type="datetime" , nullable = true)
	 */
	private $registrationDate;

    /**
     * @var \DateTime $lastLoginTime
     * @ORM\Column(name="LastLoginTime", type="datetime", nullable=true)
     */
    private $lastLoginTime;

    /**
     * @var string
     * @ORM\Column(name="TargetYear", type="string", length = 10, nullable=true)
     */
    private $targetYear;
    
    /**
     * @ORM\Column(length=1000)
     */
    private $photopath;
    
    /**
     * @ORM\Column(type="string", length=20, nullable = true)
     */
    private $mobileNumber;

	/**
	 * @ORM\Column(type="string", nullable=true)
	 */
	private $couponCode;

	/**
	 * @var string
	 * @ORM\Column(type = "string", length = 30, nullable=true)
	 */
	private $subscriptionModel;
    
    /**
     * @ORM\ManyToOne(targetEntity="StatewiseSelection")
     * @ORM\JoinColumn(name="state", referencedColumnName="id", nullable=false)
     */
    private $state;
    
    /**
     * @ORM\OneToMany(targetEntity = "SubjectGlobalRank", mappedBy="user", cascade={"ALL"}, indexBy="subjectId")
     */
    private $subjectGlobalRanks;
    
    /**
     * @ORM\OneToMany(targetEntity = "SubjectStateRank", mappedBy="user", cascade={"ALL"}, indexBy="subjectId")
     */
    private $subjectStateRanks;
    
    /**
     * @ORM\OneTomany(targetEntity="TopicLevel", mappedBy="user", cascade={"ALL"}, indexBy = "topicId")
     */
    private $topicLevels;
    
    /**
     * @ORM\OneToMany(targetEntity="SubjectLevel", mappedBy="user", cascade={"ALL"}, indexBy="subjectId")
     * @var SubjectLevels[]
     */
    private $subjectLevels;
    
    /**
     * @ORM\OneToMany(targetEntity="Accuracy", mappedBy="user", cascade={"ALL"}, indexBy="topic_id")
     */
    private $accuracy;
    
    public function __construct()
    {        
        $this->subjectLevels = new ArrayCollection();
    }
    
    public function getId()
    {
        return $this->id;
    }
    
    public function getPassword(){
    	return $this->password;
    }
    
    public function setPassword($password){
    	$this->password = $password;
    }

    public function getFirstname()
    {
        return $this->firstName;
    }

    public function setFirstname($name)
    {
        $this->firstName = $name;
    }
    
    public function getLastname()
    {
        return $this->lastName;
    }

    public function setLastname($name)
    {
        $this->lastName = $name;
    }
    
    public function getEmail(){
    	return $this->email;
    }
    
    public function setEmail($email){
    	$this->email = $email;
    }

    /**
     * @param mixed $parentEmail
     */
    public function setParentEmail($parentEmail)
    {
        $this->parentEmail = $parentEmail;
    }
    
    public function getGlobalRank(){
    	return $this->globalrank;
    }
    
    public function setGlobalRank($value){
    	$this->globalrank = $value;
    }
    
    public function getStateRank(){
    	return $this->stateRank;
    }
    
    public function setStateRank($stateRank){
    	$this->stateRank = $stateRank;
    }
    
    public function getPhotoPath(){
    	return $this->photopath;
    }
    
    public function setPhotoPath($value){
    	$this->photopath = $value;
    }
    
    public function getInstitution(){
    	return $this->institution;
    }
    
    public function setInstitution($institution){
    	$this->institution = $institution;
    }
    
    /**
     * @param date $birthday
     */
    public function setBirthday($birthday){
    	$this->birthday = $birthday;
    }

    /**
     * @return date
     */
    public function getBirthday(){
        return $this->birthday;
    }

    /**
     * @return DateTime
     */
    public function getLastLoginTime()
    {
        return $this->lastLoginTime;
    }

    /**
     * @param DateTime $lastLoginTime
     */
    public function setLastLoginTime($lastLoginTime)
    {
        $this->lastLoginTime = $lastLoginTime;
    }
    
    public function setMobileNumber($value){
    	$this->mobileNumber = $value;
    }
    
    public function setState($state){
    	$this->state = $state;
    }
    
    public function getState(){
    	return $this->state;
    }
    
    public function addSubjectLevel($subject, $level){
    	$this->subjectLevels[$subject->getId()] = new SubjectLevel($this, $subject, $level);
    }
    
    public function setSubjectLevel($subject, $level){
    	$this->subjectLevels[$subject->getId()]->setLevel($level);
    }
    
    /**
     * @return SubjectLevel
     */
    public function getSubjectLevel($subjectId){
    	return $this->subjectLevels[$subjectId];
    }
    
    public function addTopicLevel($topic, $level){
		$this->topicLevels[$topic->getId()] = new TopicLevel($this, $topic, $level);
    }
        
    /**
     * @return TopicLevel
     */
    public function getTopicLevel($topicId){
    	return $this->topicLevels[$topicId];
    }
    
    public function addSubjectStateRank($subject, $rank){
    	$this->subjectStateRanks[$subject->getId()] = new SubjectStateRank($this, $subject, $rank);
    }
    
    /**
     * @return SubjectStateRank
     */
    public function getSubjectStateRank($subjectId){
    	return $this->subjectStateRanks[$subjectId];
    }
    
    public function addSubjectGlobalRank($subject, $rank){
    	$this->subjectGlobalRanks[$subject->getId()] = new SubjectGlobalRank($this, $subject, $rank);
	}
	
	/**
	 * @return SubjectGlobalRank
	 */
	public function getSubjectGlobalRank($subjectId){
		return $this->subjectGlobalRanks[$subjectId];
	}
	
	public function addAccuracy($topic, $accuracy){
		$this->accuracy[$topic->getId()] = new Accuracy($this, $topic, $accuracy);
	}
	
	/**
	 * @return Accuracy
	 */
	public function getAccuracy($topicId){
		if (!isset($this->accuracy[$topicId])) {
            throw new \InvalidArgumentException("Symbol is not traded on this market.");
        }
		return $this->accuracy[$topicId];
	}

    /**
     * @return string
     */
    public function getTargetYear()
    {
        return $this->targetYear;
    }

    /**
     * @param string $targetYear
     */
    public function setTargetYear($targetYear)
    {
        $this->targetYear = $targetYear;
    }

    /**
     * @return DateTime
     */
    public function getSubscriptionLimit()
    {
        return $this->subscriptionLimit;
    }

    /**
     * @param DateTime $subscriptionLimit
     */
    public function setSubscriptionLimit($subscriptionLimit)
    {
        $this->subscriptionLimit = $subscriptionLimit;
    }

	/**
	 * @param DateTime $registrationDate
	 */
	public function setRegistrationDate($registrationDate)
	{
		$this->registrationDate = $registrationDate;
	}

	/**
	 * @param int $transactionId
	 */
	public function setTransactionId($transactionId)
	{
		$this->transactionId = $transactionId;
	}

	/**
	 * @return mixed
	 */
	public function getCouponCode()
	{
		return $this->couponCode;
	}

	/**
	 * @param mixed $couponCode
	 */
	public function setCouponCode($couponCode)
	{
		$this->couponCode = $couponCode;
	}

	/**
	 * @return string
	 */
	public function getSubscriptionModel()
	{
		return $this->subscriptionModel;
	}

	/**
	 * @param string $subscriptionModel
	 */
	public function setSubscriptionModel($subscriptionModel)
	{
		$this->subscriptionModel = $subscriptionModel;
	}

	/**
	 * @return int
	 */
	public function getTransactionId()
	{
		return $this->transactionId;
	}
}