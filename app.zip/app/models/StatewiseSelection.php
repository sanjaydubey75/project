<?php

use Doctrine\ORM\Mapping AS ORM;
use Doctrine\Common\Collections\ArrayCollection;

/**
 * @ORM\Entity
 * @ORM\Table(name="statewiseselection")
 */
class StatewiseSelection {

	/**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer", length=11)
     */
    private $id;
    
    /**
     * @ORM\Column(type="string", length = 100, unique=true)
     */
    private $name;

    /**
     * @ORM\Column(type="float")
     */
    private $percentageSelected;
    
    
    public function __construct($name, $percentageSelected){
    	$this->name = $name;
    	$this->percentageSelected = $percentageSelected;
    }
    
    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     *
     * @return StatewiseSelection
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set percentageSelected
     *
     * @param float $percentageSelected
     *
     * @return StatewiseSelection
     */
    public function setPercentageSelected($percentageSelected)
    {
        $this->percentageSelected = $percentageSelected;

        return $this;
    }

    /**
     * Get percentageSelected
     *
     * @return float
     */
    public function getPercentageSelected()
    {
        return $this->percentageSelected;
    }
}
