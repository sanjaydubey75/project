<?php

use Doctrine\ORM\Mapping AS ORM;
use Doctrine\Common\Collections\ArrayCollection;

/**
 * @ORM\Entity
 * @ORM\Table(name="topicweightage")
 */
 
 class TopicWeightage {
 	
 	/**
 	 * @ORM\Id
 	 * @ORM\GeneratedValue
 	 * @ORM\Column(type="integer", length=11)
 	 */
 	private $id;

	/**
     * @ORM\OneToOne(targetEntity="Topic")
     * @ORM\JoinColumn(name="topic_id", referencedColumnName="topic_id", nullable=false)
     */
    private $topic;
    
    /**
     * @ORM\Column(type="string", name="name", length=500)
     */
    private $name;
    
    /**
     * @ORM\Column(type="float", length = 20, nullable = true)
     */
    private $subjectWeightage;

    /**
     * @ORM\Column(type="float", length = 20, nullable = true)
     */
    private $globalWeightage;
    
    /**
     * @ORM\ManyToOne(targetEntity = "Subject")
     * @ORM\JoinColumn(name="subject_id", referencedColumnName="subject_id", nullable=false, unique=false)
     */
    private $subject;
    
    public function __construct($topic, $name, $subject){
    	$this->topic = $topic;
    	$this->name = $name;
    	$this->subject = $subject;
    }
    
    public function setTopic($topic){
    	$this->topic = $topic;
    }
    
    public function setSubjectWeights($subjectWeightage){
    	$this->subjectWeightage = $subjectWeightage;
    }
    
    public function setGlobalWeights($globalWeightage){
    	$this->globalWeightage = $globalWeightage;
    }
 }