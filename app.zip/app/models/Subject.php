<?php

use Doctrine\ORM\Mapping AS ORM;



/**
 * @ORM\Entity
 * @ORM\Table(name="subjects")
 */
class Subject {

	/**
     * @ORM\Id
     * @ORM\Column(type="string", name="subject_id", length=50)
     */
    private $id;

    /**
     * @ORM\Column(type="string", name="name", length=500)
     */
    private $name;
    
    /**
     * @ORM\Column(type="string", name="info", length=1000)
     */
    private $info;

    public function getId()
    {
        return $this->id;
    }

    public function getName()
    {
        return $this->name;
    }

    public function setName($name)
    {
        $this->name = $name;
    }
}
