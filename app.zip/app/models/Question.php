<?php
/*
 * Created on Sep 29, 2014
 *
 * To change the template for this generated file go to
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */
use Doctrine\ORM\Mapping AS ORM;
/**
 * @ORM\Entity
 * @ORM\Table(name="questions")
 */
class Question {

	/**
     * @ORM\Id
     * @ORM\Column(type="string", name="id", length=100)
     */
    private $id;

    /**
     * @ORM\ManyToOne(targetEntity="Subject")
     * @ORM\JoinColumn(name="subject_id", referencedColumnName="subject_id", nullable=false)
     */
    private $subject;
    
    /**
     * @ORM\ManyToOne(targetEntity="Topic")
     * @ORM\JoinColumn(name="topic_id", referencedColumnName="topic_id", nullable=false)
     */
    private $topic;
    
    /**
     * @ORM\Column(type="string", length = 5500, name="description")
     */
    private $description;
    
    /**
     * @ORM\Column(type="string", length = 500, name="pic")
     */
    private $pic;
    
    /**
     * @ORM\Column(type="string", length = 1500, name="cha")
     */
    private $choiceA;
    
    /**
     * @ORM\Column(type="string", length = 500, name="pica")
     */
    private $picA;
    
    /**
     * @ORM\Column(type="string", length = 1500, name="chb")
     */
    private $choiceB;
    
    /**
     * @ORM\Column(type="string", length = 500, name="picb")
     */
    private $picB;
    
    /**
     * @ORM\Column(type="string", length = 1500, name="chc")
     */
    private $choiceC;
    
    /**
     * @ORM\Column(type="string", length = 500, name="picc")
     */
    private $picC;
    
    /**
     * @ORM\Column(type="string", length = 1500, name="chd")
     */
    private $choiceD;
    
    /**
     * @ORM\Column(type="string", length = 500, name="picd")
     */
    private $picD;
    
    /**
     * @ORM\Column(type="string", length = 100, name="answer")
     */
    private $answer;
    
    /**
     * @ORM\Column(type="bigint", length = 20, name="attempt")
     */
    private $attempt;
    
    /**
     * @ORM\Column(type="bigint", length = 20, name="correct")
     */
    private $correct;
    
    /**
     * @ORM\Column(type="integer", length = 11, name="level")
     */
    private $level;
    
    /**
     * @ORM\Column(type="integer", length=11, name="checked")
     */
	private $checked;
	
	/**
	 * @ORM\Column(type="integer", length=10, name="BookId")
	 */
	private $BookId;
	
	/**
	 * @ORM\Column(type="string", length=10, name="PageNumber")
	 */
	private $pageNumber;

    /**
     * @ORM\Column(type="boolean", name="SolutionAvailable")
     */
    private $solutionAvailable;

    /**
     * @ORM\Column(type="string", length = 1500, name="Solution")
     */
    private $solution;

    /**
     * @ORM\Column(type="string", length = 500, name="picSol")
     */
    private $picSol;

	/**
	 * @ORM\Column(type="time")
	 * @var DateTime
	 */
	private $timelimit;
	
    public function getId(){
    	return $this->id;
    }
    
    public function getSubjectId(){
    	return $this->subject;
    }
    
    public function getTopicId(){
    	return $this->topic;
    }
    
    public function setTopicId($topic){
    	$this->topic = $topic;
    }
    
    public function getDetails(){
		return array(
			'content' => $this->description,
			'id' => $this->id,
			'pic' => $this->pic,
			'time' => array(
				'hour' => $this->timelimit->format('H'),
				'min' => $this->timelimit->format('i'),
				'sec' =>$this->timelimit->format('s')
			),
//			'time' => $this->timelimit->format('Y-m-dTH:i:s'),
			'answer' => json_decode($this->answer),
			'subject' => $this->subject->getName(),
			'topic' => $this->topic->getName()
		);
    }
    
    public function getChoices(){
    	return array(
				array(
					'content' => $this->choiceA,
					'pic' => $this->picA,
					'id' => 'A'
				),
				array(
					'content' => $this->choiceB,
					'pic' => $this->picB,
					'id' => 'B'
				),
				array(
					'content' => $this->choiceC,
					'pic' => $this->picC,
					'id' => 'C'
				),
				array(
					'content' => $this->choiceD,
					'pic' => $this->picD,
					'id' => 'D'
				),
			);
    }


    public function getSolutions(){
        return array(
                'isAvailable' => $this->solutionAvailable,
                'content' => $this->solution,
                'pic' => $this->picSol
        );
    }

    public function getAnswer(){
    	return $this->answer;
    }

    public function setAnswer($answer){
        $this->answer = $answer;
    }
    
    public function getLevel(){
    	return $this->level;
    }
    
    public function setLevel($level){
    	$this->level = $level;
    }
    
    public function setAttempt(){
    	$this->attempt++;
    }
    
    public function setCorrect(){
    	$this->correct++;
    }
    
    public function getAttempt(){
    	return $this->attempt;
    }
    
    public function getCorrect(){
    	return $this->correct;
    }
}
?>
