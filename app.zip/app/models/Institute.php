<?php

use Doctrine\ORM\Mapping AS ORM;
use Doctrine\Common\Collections\ArrayCollection;

/**
 * @ORM\Entity
 * @ORM\Table(name="institute")
 */
class Institute{

	/**
	 * @ORM\Id
	 * @ORM\GeneratedValue
	 * @ORM\Column(type="integer")
	 */
	private $id;

	/**
	 * @ORM\Column(type="string", unique=true)
	 */
	private $name;

	/**
	 * @ORM\OneToMany(targetEntity="InstituteCouponCode", mappedBy="instituteId", cascade={"ALL"})
	 */
	private $couponCodes;

	public function __construct(){
		$this->couponCodes = new ArrayCollection();
	}

	/**
	 * @return string
	 */
	public function getName()
	{
		return $this->name;
	}

	/**
	 * @return mixed
	 */
	public function getCouponCodes()
	{
		return $this->couponCodes;
	}
}