<?php

use Doctrine\ORM\Mapping AS ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="subjectstateranks")
 */
class SubjectStateRank{
	/**
     * @ORM\Id
     * @ORM\ManyToOne(targetEntity="Student", inversedBy="subjectStateRanks")
     */
    private $user;
    
    /**
     * @ORM\Id
     * @ORM\ManyToOne(targetEntity="Subject")
     * @ORM\JoinColumn(name="subjectId", referencedColumnName="subject_id", nullable=false)
     */
    private $subject;
    
    /**
     * @ORM\Column(type="integer", length=20) 
     */
    private $rank;
    
    public function __construct($user, $subject, $rank)
    {
        $this->user = $user;
        $this->subject = $subject;
        $this->rank = $rank;
    }
    
    public function getRank(){
    	return $this->rank;
    }
    
    public function setRank($rank){
		$this->rank = $rank;
	}    
}
?>