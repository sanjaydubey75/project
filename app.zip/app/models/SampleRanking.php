<?php

use Doctrine\ORM\Mapping AS ORM;
use Doctrine\Common\Collections\ArrayCollection;

/**
 * @ORM\Entity
 * @ORM\Table(name="sampleranking")
 */
 
 class SampleRanking {

	/**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer", length=11)
     */
    private $id;
    
    /**
     * @ORM\Column(type="integer", length = 11)
     */
    private $marks;

    /**
     * @ORM\Column(type="integer", length = 11)
     */
    private $students;
    
    public function __construct($marks, $students){
    	$this->marks = $marks;
    	$this->students = $students;
	}
}   