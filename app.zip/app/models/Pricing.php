<?php

namespace Shezar\IITJEEAcademy\Models{

	class Pricing{

		private $id;
		private $duration;
		private $amount;
		private $subscriptionInterval;

		function __construct($id, $amount, $duration, $subscriptionInterval)
		{
			$this->id = $id;
			$this->amount = $amount;
			$this->duration = $duration;
			$this->subscriptionInterval = $subscriptionInterval;
		}

		/**
		 * @return mixed
		 */
		public function getAmount()
		{
			return $this->amount;
		}

		/**
		 * @return mixed
		 */
		public function getDuration()
		{
			return $this->duration;
		}

		/**
		 * @return mixed
		 */
		public function getSubscriptionInterval()
		{
			return $this->subscriptionInterval;
		}

		/**
		 * @return mixed
		 */
		public function getId()
		{
			return $this->id;
		}

	}

	class PricingModels{

		public $models;

		public function  __construct(){
			$this->models = array(
				new Pricing(1, 2500, '6 Months', new \DateInterval('P6M')),
				new Pricing(2, 3000, '1 Year', new \DateInterval('P1Y')),
				new Pricing(3, 5000, '2 Years', new \DateInterval('P2Y')),
				new Pricing(4, 0, '1 Day', new \DateInterval('P1D')),//for trial
			);
		}

		/**
		 * @return array
		 */
		public function getModels()
		{
			return $this->models;
		}

		/**
		 * @param $id
		 * @return Pricing
		 */
		public function getModel($id){
			return $this->models[$id - 1 ];
		}
	}
}