<?php

namespace Shezar\IITJEEAcademy\Repositories{

	interface StudentRepositoryInterface extends BaseRepositoryInterface{

	}
}
