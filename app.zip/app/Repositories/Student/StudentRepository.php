<?php

namespace Shezar\IITJEEAcademy\Repositories{

	use Doctrine\ORM\EntityManagerInterface;

	class StudentRepository extends BaseRepository implements StudentRepositoryInterface{

		public function __construct(EntityManagerInterface $entityManager)
		{
			parent::__construct($entityManager);
			parent::setModel('Student');
		}

		public function getStudentFromToken($authToken){

			$authToken = json_decode($authToken, true);

			/** @var \Student $student */
			$student = $this->findOneBy(array('email' => $authToken['userEmail']));

			return $student;
		}
	}
}









