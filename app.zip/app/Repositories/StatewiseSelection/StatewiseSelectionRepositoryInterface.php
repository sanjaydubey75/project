<?php

namespace Shezar\IITJEEAcademy\Repositories{

	interface StatewiseSelectionRepositoryInterface extends BaseRepositoryInterface{

	}
}