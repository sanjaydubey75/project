<?php

namespace Shezar\IITJEEAcademy\Repositories{

	use Doctrine\ORM\EntityManagerInterface;

	class StatewiseSelectionRepository extends BaseRepository implements StatewiseSelectionRepositoryInterface{

		public function __construct(EntityManagerInterface $entityManager){
			parent::__construct($entityManager);
			parent::setModel('StatewiseSelection');
		}

	}
}