<?php

namespace Shezar\IITJEEAcademy\Repositories{

	use Doctrine\ORM\EntityManagerInterface;

	class TopicRepository extends BaseRepository implements TopicRepositoryInterface{

		public function __construct(EntityManagerInterface $entityManager){
			parent::__construct($entityManager);
			parent::setModel('Topic');
		}
	}
}