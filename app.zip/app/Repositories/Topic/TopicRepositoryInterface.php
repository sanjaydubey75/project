<?php

namespace Shezar\IITJEEAcademy\Repositories{
	interface TopicRepositoryInterface extends BaseRepositoryInterface{

	}
}