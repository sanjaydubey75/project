<?php
namespace Shezar\IITJEEAcademy\Repositories{
	use Doctrine\ORM\EntityManagerInterface;

	class SubjectRepository extends BaseRepository implements SubjectRepositoryInterface{
		public function __construct(EntityManagerInterface $entityManager){
			parent::__construct($entityManager);
			parent::setModel('Subject');
		}
	}
}