<?php

namespace Shezar\IITJEEAcademy\Repositories{

	interface SubjectRepositoryInterface extends BaseRepositoryInterface{

	}
}