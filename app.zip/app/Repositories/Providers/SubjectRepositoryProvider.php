<?php
namespace Shezar\IITJEEAcademy\Repositories\Providers{
	use Illuminate\Support\ServiceProvider;

	class SubjectRepositoryProvider extends ServiceProvider{

		protected $defer = true;

		public function register(){
			$this->app->bind(
				"Shezar\\IITJEEAcademy\\Repositories\\SubjectRepositoryInterface",
				"Shezar\\IITJEEAcademy\\Repositories\\SubjectRepository"
			);
		}

		public function provides(){
			return [
				"Shezar\\IITJEEAcademy\\Repositories\\SubjectRepositoryInterface",
			];
		}
	}
}