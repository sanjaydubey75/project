<?php
namespace Shezar\IITJEEAcademy\Repositories\Providers{
	use Illuminate\Support\ServiceProvider;

	class QuestionRepositoryProvider extends ServiceProvider{

		protected $defer = true;

		public function register(){
			$this->app->bind(
				"Shezar\\IITJEEAcademy\\Repositories\\QuestionRepositoryInterface",
				"Shezar\\IITJEEAcademy\\Repositories\\QuestionRepository"
			);
		}

		public function provides(){
			return [
				"Shezar\\IITJEEAcademy\\Repositories\\QuestionRepositoryInterface",
			];
		}
	}
}