<?php
namespace Shezar\IITJEEAcademy\Repositories\Providers{
	use Illuminate\Support\ServiceProvider;

	class StudentRepositoryProvider extends ServiceProvider{

		protected $defer = true;

		public function register(){
			$this->app->bind(
				"Shezar\\IITJEEAcademy\\Repositories\\StudentRepositoryInterface",
				"Shezar\\IITJEEAcademy\\Repositories\\StudentRepository"
			);
		}

		public function provides(){
			return [
				"Shezar\\IITJEEAcademy\\Repositories\\StudentRepositoryInterface",
			];
		}
	}
}