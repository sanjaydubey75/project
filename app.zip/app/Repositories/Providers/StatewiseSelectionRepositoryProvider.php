<?php
namespace Shezar\IITJEEAcademy\Repositories\Providers{
	use Illuminate\Support\ServiceProvider;

	class StatewiseSelectionRepositoryProvider extends ServiceProvider{

		protected $defer = true;

		public function register(){
			$this->app->bind(
				"Shezar\\IITJEEAcademy\\Repositories\\StatewiseSelectionRepositoryInterface",
				"Shezar\\IITJEEAcademy\\Repositories\\StatewiseSelectionRepository"
			);
		}

		public function provides(){
			return [
				"Shezar\\IITJEEAcademy\\Repositories\\StatewiseSelectionRepositoryInterface",
			];
		}
	}
}