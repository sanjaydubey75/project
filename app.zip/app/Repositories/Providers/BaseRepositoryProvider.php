<?php
namespace Shezar\IITJEEAcademy\Repositories\Providers{
	use Illuminate\Support\ServiceProvider;

	class BaseRepositoryProvider extends ServiceProvider{

		protected $defer = true;

		public function register(){
			$this->app->bind(
				"Shezar\\IITJEEAcademy\\Repositories\\BaseRepositoryInterface",
				"Shezar\\IITJEEAcademy\\Repositories\\BaseRepository"
			);
		}

		public function provides(){
			return [
				"Shezar\\IITJEEAcademy\\Repositories\\BaseRepositoryInterface",
			];
		}
	}
}