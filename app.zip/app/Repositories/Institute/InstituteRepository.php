<?php

namespace Shezar\IITJEEAcademy\Repositories{

	use Doctrine\ORM\EntityManagerInterface;

	class InstituteRepository extends BaseRepository implements InstituteRepositoryInterface{

		public function __construct(EntityManagerInterface $entityManager){
			parent::__construct($entityManager);
			parent::setModel('Institute');
		}
	}
}