<?php

namespace Shezar\IITJEEAcademy\Repositories{

	interface InstituteRepositoryInterface extends BaseRepositoryInterface{

	}
}