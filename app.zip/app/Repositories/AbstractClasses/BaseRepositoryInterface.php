<?php

namespace Shezar\IITJEEAcademy\Repositories{
	use Doctrine\DBAL\Logging\SQLLogger;
	use Doctrine\ORM\EntityManagerInterface;

	interface BaseRepositoryInterface{

		public function __construct(EntityManagerInterface $entityManager);

		public function setModel($model);

		public function save($model);

		public function find($id);

		public function findOneBy($array);

		public function findAll();

		public function beginTransaction();

		public function commit();

		public function rollback();

		public function setSQLLogger(SQLLogger $logger);
	}
}