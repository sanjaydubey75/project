<?php

namespace Shezar\IITJEEAcademy\Repositories{

	use Doctrine\DBAL\Logging\SQLLogger;
	use Doctrine\ORM\EntityManagerInterface;

	class BaseRepository implements BaseRepositoryInterface{

		protected $entityManager;
		private $model;

		public function __construct(EntityManagerInterface $entityManager){
			$this->entityManager = $entityManager;
		}

		public function setModel($model){
			$this->model = $model;
		}

		public function save($model){
			$this->entityManager->persist($model);
			$this->entityManager->flush();
		}

		public function find($id){
			return $this->entityManager->getRepository($this->model)->find($id);
		}

		public function findOneBy($array){
			return $this->entityManager->getRepository($this->model)->findOneBy($array);
		}

		public function findAll(){
			return $this->entityManager->getRepository($this->model)->findAll();
		}

		public function beginTransaction(){
			$this->entityManager->getConnection()->beginTransaction();
		}

		public function commit(){
			$this->entityManager->getConnection()->commit();
		}

		public function rollback(){
			$this->entityManager->getConnection()->rollBack();
		}

		public function setSQLLogger(SQLLogger $logger){
			$this->entityManager->getConnection()->getConfiguration()->setSQLLogger($logger);
		}
	}
}