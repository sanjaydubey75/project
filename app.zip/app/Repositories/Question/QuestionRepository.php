<?php

namespace Shezar\IITJEEAcademy\Repositories{

	use Doctrine\ORM\EntityManagerInterface;
	use Doctrine\ORM\QueryBuilder;

	class QuestionRepository extends BaseRepository implements QuestionRepositoryInterface{

		public function __construct(EntityManagerInterface $entityManager){
			parent::__construct($entityManager);
			parent::setModel('Question');
		}

		/**
		 * @param $qb QueryBuilder
		 * @param $temp
		 * @param $array
		 * @return QueryBuilder
		 */
		private function optionalWhere($qb, $temp, $array){

			if(array_get($array,'subjectId', null)){
				$temp = $temp->andWhere($qb->expr()->eq('IDENTITY(q.subject)', ':subjectId'))
					->setParameter('subjectId', $array['subjectId']);
			}
			if(array_get($array, 'topicId', null)){
				$temp = $temp->andWhere($qb->expr()->eq('IDENTITY(q.topic)', ':topicId'))
					->setParameter('topicId', $array['topicId']);
			}
			if(array_get($array, 'level', null)){
				$temp = $temp->andWhere($qb->expr()->eq('q.level', ':level'))
					->setParameter('level', $array['level']);
			}
			return $temp;
		}

		private function getCount($array){
			/** @var QueryBuilder $countqb */
			$countqb = $this->entityManager->createQueryBuilder();
			$temp = $countqb->select('COUNT(q)')
				->from('Question', 'q');
			$countQuery = $this->optionalWhere($countqb, $temp, $array)->getQuery();
			$count = $countQuery->getOneOrNullResult()['1'];
			return $count;
		}

		private function getAll($array){
			$qb1 = $this->entityManager->createQueryBuilder();
			$temp = $qb1->select('q')
				->from('Question', 'q');
			$temp = $this->optionalWhere($qb1, $temp, $array);
			return $temp->getQuery()->getResult();
		}

		private function getRandomQuestions($array, $quantity){
			$count = $this->getCount($array);
			if($count < 1)return null;
			if($count < $quantity){//get all questions
				return $this->getAll($array);
			}

			$questions = array();
			$questionsId = array();

			for($i = 0; $i < $quantity; $i++, $count--){

				$offset = max(0, rand(0, $count - 1));

				$qb = $this->entityManager->createQueryBuilder();
				$temp = $qb->select('q')
					->from('Question', 'q');
				$temp = $this->optionalWhere($qb, $temp, $array);
				/** @var \Question $question */
				$question = $temp
					->andWhere("q.id NOT IN ( '".implode($questionsId, "', '")."' )")
					->setMaxResults(1)
					->setFirstResult($offset)
					->getQuery()
					->getOneOrNullResult();

				if($question){
					array_push($questions, $question);
					array_push($questionsId, $question->getId());
				}
			}
			return $questions;
		}

		public function getQuestions($array, $status){

			$random = array_get($status, 'random', false);

			if($random){
				return $this->getRandomQuestions($array, array_get($status, 'quantity', 1));
			}
		}
	}
}