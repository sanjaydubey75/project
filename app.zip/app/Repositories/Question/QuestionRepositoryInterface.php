<?php

namespace Shezar\IITJEEAcademy\Repositories{

	interface QuestionRepositoryInterface extends BaseRepositoryInterface{

	}
}