<?php

namespace Shezartech\IITJEEAcademy\Repositories;


use Doctrine\ORM\EntityManagerInterface;
use Shezartech\IITJEEAcademy\Repositories;

class QuestionRepository implements Repositories\Interfaces\QuestionRepositoryInterface{

    private $entityManager;
    private $studentRepository;

    public function __construct(EntityManagerInterface $entityManager,
                                Repositories\Interfaces\StudentRepositoryInterface $studentRepository){
        $this->entityManager = $entityManager;
        $this->studentRepository = $studentRepository;
    }

    public function getRandomQuestion(\Student $student, $topicId, $subjectId){

        $topicLevel = $this->studentRepository->getTopicLevel($student, $topicId);

        $qb = $this->entityManager->createQueryBuilder();

        $xyz = $qb->select('COUNT(q)')
            ->from('Question', 'q')
            ->where($qb->expr()->andX(
                $qb->expr()->eq('IDENTITY(q.subject)' , ':subjectId'),
                $qb->expr()->eq('IDENTITY(q.topic)', ':topicId'),
                $qb->expr()->eq('q.level', ':level')
            ))
            ->andWhere('q.id NOT IN (SELECT IDENTITY(a.question) FROM QuestionAnswered a WHERE IDENTITY(a.user) = :userId and a.status in (0, 2))')
            ->setParameter('subjectId', $subjectId)
            ->setParameter('topicId', $topicId)
            ->setParameter('level', $topicLevel)
            ->setParameter('userId', $this->studentRepository->getStudentId($student))
            ->getQuery();

        // the following serves as an example to retrieve parameters from query object
        // $query = $em-> bla. bla. ->getQuery();
        // $query->getSql()
        // $query->getDql()
        // $query->getParameter('subjectId')->getValue()
        // foreach ($xyz->getParameters() as $index => $param){
        //     $param->getValue();
        // }

        $rows = $xyz->getOneOrNullResult()['1'];

        if($rows < 1)
            return null;

        $offset = max(0, rand(0, $rows - 1));

        $qb1 = $this->entityManager->createQueryBuilder();
        $question = $qb1->select('q')
            ->from('Question', 'q')
            ->where($qb1->expr()->andX(
                $qb1->expr()->eq('IDENTITY(q.subject)' , ':subjectId'),
                $qb1->expr()->eq('IDENTITY(q.topic)', ':topicId'),
                $qb1->expr()->eq('q.level', ':level')
            ))
            ->andWhere('q.id NOT IN (SELECT IDENTITY(a.question) FROM QuestionAnswered a WHERE IDENTITY(a.user) = :userId and a.status in (0,2))')
            ->setParameter('subjectId', $subjectId)
            ->setParameter('topicId', $topicId)
            ->setParameter('level', $topicLevel)
            ->setParameter('userId', $this->studentRepository->getStudentId($student))
            ->setMaxResults(1)
            ->setFirstResult($offset)
            ->getQuery()
            ->getOneOrNullResult()
        ;
        return $question;
    }

    public function getQuestionById($questionId)
    {
        // see this carefully. This is one of the only places where I've successfully retrived a foreign key value
        // in this format by aliasing. Though I won't be using it.
        // the format is $question['subject'] will evaluate to MAT or PHY, etc
        // $question = $this->entityManager->createQueryBuilder()->select(array('q.id', 'q.description', 'q.answer', 'q.pic', 'q.choiceA', 'q.picA', 'q.choiceB', 'q.picB', 'q.choiceC', 'q.picC', 'q.choiceD', 'q.picD', 'IDENTITY(q.subject) as subject'))
        return $this->entityManager->getRepository('Question')->findOneBy(array('id' => $questionId));
    }

    public function display(\Question $question){
        return \Response::json(array(
            'response' => array('status' => 'success', 'message' => ''),
            'question' => $question->getDetails(),
            'choices' => $question->getChoices(),
            'solution' =>$question->getSolutions()
        ));
    }
}