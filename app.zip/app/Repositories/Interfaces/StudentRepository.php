<?php
namespace Shezartech\IITJEEAcademy\Repositories{

    use Doctrine\ORM\EntityManagerInterface;


    class StudentRepository implements Interfaces\StudentRepositoryInterface
    {
        public function __construct(EntityManagerInterface $entityManager){
            $this->entityManager = $entityManager;
        }

        public function getStudentFromToken($authToken){
            $authToken = json_decode($authToken, true);

            $user = $this->entityManager->getRepository('\Student')->findOneBy(
                array('email' => $authToken['userEmail'])
            );

            return $user;
        }

        public function getStudentId(\Student $student)
        {
            return $student->getId();
        }

        public function getTopicLevel(\Student $student, $topicId){
            return $student->getTopicLevel($topicId)->getLevel();
        }

        public function increaseTopicLevel(\Student $student, $topicId)
        {
            $this->entityManager->persist($student);
            $student->getTopicLevel($topicId)->incrementLevel();
            $this->entityManager->flush();
        }


    }
}