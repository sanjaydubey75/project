<?php

namespace Shezartech\IITJEEAcademy\Repositories\Interfaces;


interface QuestionRepositoryInterface {
    public function getRandomQuestion(\Student $student, $topicId, $subjectId);

    public function getQuestionById($questionId);

    public function display(\Question $question);
} 