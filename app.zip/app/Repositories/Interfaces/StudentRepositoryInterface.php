<?php
namespace Shezartech\IITJEEAcademy\Repositories\Interfaces
{
    interface StudentRepositoryInterface{
        public function getStudentFromToken($authToken);

        //later convert this to topic class
        public function getTopicLevel(\Student $student, $topicId);

        public function getStudentId(\Student $student);

        public function increaseTopicLevel(\Student $student, $topicId);
    }
}