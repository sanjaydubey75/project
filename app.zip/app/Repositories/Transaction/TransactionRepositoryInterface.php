<?php

namespace Shezar\IITJEEAcademy\Repositories{

	interface TransactionRepositoryInterface extends BaseRepositoryInterface{

	}
}