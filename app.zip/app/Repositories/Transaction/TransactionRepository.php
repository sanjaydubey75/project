<?php

namespace Shezar\IITJEEAcademy\Repositories{

	use Doctrine\ORM\EntityManagerInterface;

	class TransactionRepository extends  BaseRepository implements TransactionRepositoryInterface{

		public function __construct(EntityManagerInterface $entityManager)
		{
			parent::__construct($entityManager);
			parent::setModel('Transaction');
		}
	}
}