<?php

use Doctrine\ORM\EntityManagerInterface;
use Doctrine\ORM\EntityRepository;

class TopicWeightageDbSeeder extends Seeder {
	
	private $entityManager;
	
	public function __construct(EntityManagerInterface $entityManager){
		$this->entityManager = $entityManager;
		
		$this->entityManager->getConnection()->getConfiguration()->setSQLLogger(new \Doctrine\DBAL\Logging\DoctrineSQLLogger());
	}
	
	public static function NormalDistribution($mu, $sigma, $x){
		return exp(-.5*pow(($x-$mu)/$sigma, 2))/($sigma*pow(2*M_PI, .5));
	}

    public function run()
    {
        DB::table('topicweightage')->delete();
		
		//create all entries for db
		
		$qbTopics = $this->entityManager->createQueryBuilder();
		
		//first calculate global weightage
		
		
		
		$topics = $this->entityManager->getRepository('Topic')->findAll();
		
		$topicsCount = count($topics);
		
		foreach($topics as $key => $topic){
			$subject = $this->entityManager->getRepository('Subject')->findOneBy(array('id' => $topic->getSubjectId()));
			$topicWeightage = new TopicWeightage($topic, $topic->getName(), $subject);
			$topicWeightage->setGlobalWeights(1/$topicsCount);
			$this->entityManager->persist($topicWeightage);
		}
		$this->entityManager->flush();
		
		$subjects = $this->entityManager->createQueryBuilder()
			->select('s.id')
			->from('Subject', 's')
			->getQuery()
			->getResult();
		
		foreach($subjects as $key => $value){
			
			$topics = $this->entityManager->getRepository('Topic')->findBy(array('subject' => $value['id']));
			
//			$topicsQb = $this->entityManager->createQueryBuilder();
//			$topics = $topicsQb
//				->select('Identity(t.id)')
//				->from('TopicWeightage', 't')
//				->innerJoin('Topic', 't1', 'WITH', $topicsQb->expr()->eq('t1.id', 't.id'))
//				->where($topicsQb->expr()->andX(
//					$topicsQb->expr()->eq('t1.subject_id', ':subjectId')
//				))
//				->setParameter('subjectId', $value['id'])
//				->getQuery()
//				->getResult();
			
			$topicsCount = count($topics);
			
			foreach($topics as $key => $value){
				$topicWeightage = $this->entityManager->getRepository('TopicWeightage')->findOneBy(
					array('topic' => $value->getId())
				);
				$topicWeightage->setSubjectWeights(1/$topicsCount);
				$this->entityManager->persist($topicWeightage);
				
			}
		}
		$this->entityManager->flush();
	}
}