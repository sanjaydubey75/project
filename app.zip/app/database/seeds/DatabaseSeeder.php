<?php

class DatabaseSeeder extends Seeder {

	/**
	 * Run the database seeds.
	 *
	 * @return void
	 */
	public function run()
	{
		Eloquent::unguard();

		$this->call('SampleRankingDbSeeder');
		
		$this->command->info('SampleRanking table seeded!');
		
		$this->call('TopicWeightageDbSeeder');
		
		$this->command->info('TopicWeightage table seeded!');
		
		$this->call('StatewiseSelectionDbSeeder');
		
		$this->command->info('StatewiseSelection table seeded!');
	}

}
