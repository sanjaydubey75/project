<?php

use Doctrine\ORM\EntityManagerInterface;
use Doctrine\ORM\EntityRepository;

class StatewiseSelectionDbSeeder extends Seeder {
	
	private $entityManager;
	
	public function __construct(EntityManagerInterface $entityManager){
		$this->entityManager = $entityManager;
	}

    public function run()
    {
        DB::table('statewiseselection')->delete();
		
		//create all entries for db
		
		$data = array(
			array(
				'name' => "Andhra Pradesh",
				'percentageSelected' => 19
			),
			array(
				'name' => "Rajasthan",
				'percentageSelected' => 12.9
			),
			array(
				'name' => "Delhi",
				'percentageSelected' => 11.5
			),
			array(
				'name' => "Uttar Pradesh",
				'percentageSelected' => 8.1
			),
			array(
				'name' => "Maharashtra",
				'percentageSelected' => 8
			),
			array(
				'name' => "Bihar",
				'percentageSelected' => 5.4
			),
			array(
				'name' => "Madhya Pradesh",
				'percentageSelected' => 4.4
			),
			array(
				'name' => "Jharkhand",
				'percentageSelected' => 4.3
			),
			array(
				'name' => "Gujarat",
				'percentageSelected' => 3.8
			),
			array(
				'name' => "Haryana",
				'percentageSelected' => 3.2
			),
			array(
				'name' => "West Bengal",
				'percentageSelected' => 2.8
			),
			array(
				'name' => "Orissa",
				'percentageSelected' => 2.8
			),
			array(
				'name' => "Karnataka",
				'percentageSelected' => 2.2
			),
			array(
				'name' => "Chattisgarh",
				'percentageSelected' => 2.1
			),
			array(
				'name' => "Kerala",
				'percentageSelected' => 2
			),
			array(
				'name' => "Tamil Nadu",
				'percentageSelected' => 2
			),
			array(
				'name' => "Punjab",
				'percentageSelected' => 2
			),
			array(
				'name' => "Uttarakhand",
				'percentageSelected' => 1.3
			),
			array(
				'name' => "Assam",
				'percentageSelected' => .8
			),
			array(
				'name' => "Jammu and Kashmir",
				'percentageSelected' => .5
			),
			array(
				'name' => "Meghalaya",
				'percentageSelected' => .4
			),
			array(
				'name' => "Himachal Pradesh",
				'percentageSelected' => .3
			),
			array(
				'name' => "Arunachal Pradesh",
				'percentageSelected' => .2
			),
			array(
				'name' => "Goa",
				'percentageSelected' => .2
			),
			array(
				'name' => "Manipur",
				'percentageSelected' => .2
			),
			array(
				'name' => "Mizoram",
				'percentageSelected' => .2
			),
			array(
				'name' => "Nagaland",
				'percentageSelected' => .2
			),
			array(
				'name' => "Sikkim",
				'percentageSelected' => .2
			),
			array(
				'name' => "Tripura",
				'percentageSelected' => .2
			)
		);
		
		foreach($data as $key => $value){
			$statewiseSelection = new StatewiseSelection($value['name'], $value['percentageSelected']);
			$this->entityManager->persist($statewiseSelection);
		}
		
		$this->entityManager->flush();
    }

}