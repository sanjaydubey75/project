<?php

use Doctrine\ORM\EntityManagerInterface;
use Doctrine\ORM\EntityRepository;

class SampleRankingDbSeeder extends Seeder {
	
	private $entityManager;
	
	public function __construct(EntityManagerInterface $entityManager){
		$this->entityManager = $entityManager;
	}
	
	public static function NormalDistribution($mu, $sigma, $x){
		return exp(-.5*pow(($x-$mu)/$sigma, 2))/($sigma*pow(2*M_PI, .5));
	}

    public function run()
    {
        DB::table('sampleranking')->delete();
		
		//create all entries for db
		
		$minMarks = 0;
		$maxMarks = 100;
		$studentCount = 500000;
		$mu = 50;
		$sigma = 15;
		
		for($i = $minMarks; $i <= $maxMarks; $i++){
			$temp = new SampleRanking($i, round($studentCount*SampleRankingDbSeeder::NormalDistribution($mu, $sigma, $i)));
			$this->entityManager->persist($temp);
		}
		
		$this->entityManager->flush();
    }

}