<?php

use Doctrine\ORM\EntityManagerInterface;
use Doctrine\ORM\EntityRepository;

class StudentController extends BaseController{
	
	private $entityManager;
	
	public function __construct(EntityManagerInterface $entityManager)
    {
    	$this->entityManager = $entityManager;
    	
    	$this->beforeFilter('log');

        $this->beforeFilter('force.ssl');
    	
        $this->beforeFilter('auth-with-authtoken');

        $this->beforeFilter('csrf_header');
        
        $this->beforeFilter('auth-student');
        
        $this->entityManager->getConnection()->getConfiguration()->setSQLLogger(new \Doctrine\DBAL\Logging\DoctrineSQLLogger());
    }
	public function index(){
		Config::set('session.driver', 'array');
		
		$authToken = json_decode(Cookie::get('auth-token'), true);
		$userEmail = $authToken['userEmail'];
		$UserRepo = $this->entityManager->getRepository('Student');
		/** @var Student $user */
		$user = $UserRepo->findOneBy(
			array('email' => $userEmail)
		);
		
		//currently not accounting for the dynamic entry for topics and all the other stuff

		$startedPractisingIITJEE = false;

		$subjectLevels = array();
		$subjectGlobalRanks = array();
		$subjectStateRanks = array();
		$subjects = $this->entityManager->getRepository('Subject')->findAll();
		foreach($subjects as $key=> $subject){
			$subjectLevels[$subject->getId()] = $user->getSubjectLevel($subject->getId())->getLevel();

			if($user->getSubjectLevel($subject->getId())->isStartedPractice()){
				$subjectGlobalRanks[$subject->getId()] = $user->getSubjectGlobalRank($subject->getId())->getRank();
				$subjectStateRanks[$subject->getId()] = $user->getSubjectStateRank($subject->getId())->getRank();

				$startedPractisingIITJEE = true;
			} else {
				$subjectGlobalRanks[$subject->getId()] = null;
				$subjectStateRanks[$subject->getId()] = null;
			}
		}

		if($startedPractisingIITJEE){
			$rank = array(
				'globalRank'=>$user->getGlobalRank(),
				'stateRank' => $user->getStateRank()
			);
		} else {
			$rank = array(
				'globalRank'=> null,
				'stateRank' => null
			);
		}

		$response = Response::json(array(
			'response' => array('status' => 'success', 'message' => ''),
			'userFirstname' => $user->getFirstname(),
			'userLastname' => $user->getLastname(),
			'rank' => $rank,
			'photopath'=>($user->getPhotoPath() != '0') ? ('img/profilepics/'.$user->getPhotoPath()) : "img/user.png",
			'subject_level'=> $subjectLevels,
			'subjectGlobalRank' => $subjectGlobalRanks,
			'subjectStateRank' => $subjectStateRanks,
			'email' => $userEmail,
			'role' => 'student'
		));
		return $response;
	}

    public function uploadPhoto(){

        Config::set('session.driver', 'array');

        $authToken = json_decode(Cookie::get('auth-token'), true);
        $userEmail = $authToken['userEmail'];
        $UserRepo = $this->entityManager->getRepository('Student');
        $user = $UserRepo->findOneBy(
            array('email' => $userEmail)
        );

        if (Input::hasFile('file'))
        {
            $file = Input::file('file');

            if(file_exists(base_path()."/img/profilepics/".$user->getPhotopath())){
                $path = base_path()."/img/profilepics/".$user->getPhotopath();
                unlink($path);
            }

            $name = md5(uniqid($user->getId(), true));
            $file->move('img/profilepics/', $name.".".(pathinfo($file->getClientOriginalName())['extension']));
            $user->setPhotoPath($name.".".(pathinfo($file->getClientOriginalName())['extension']));
        }

        $this->entityManager->flush();

        return Response::json(array(
            'response' => array('status' => 'success', 'message' => 'uploaded'),
        ));
    }
}
?>
