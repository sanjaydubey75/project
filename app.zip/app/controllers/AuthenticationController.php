<?php
/*
 * Created on Sep 23, 2014
 *
 * To change the template for this generated file go to
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */

use Doctrine\ORM\EntityManagerInterface;
use Doctrine\ORM\EntityRepository;

class AuthenticationController extends BaseController{
	
	private $entityManager;

    public function __construct(EntityManagerInterface $entityManager)
    {
        $this->entityManager = $entityManager;
        $this->beforeFilter('force.ssl');
//        $this->entityManager->getConnection()->getConfiguration()->setSQLLogger(new \Doctrine\DBAL\Logging\DoctrineSQLLogger());
    }

    /**
     * @return \Illuminate\Http\JsonResponse
     */
    public function checkCredentials(){
		
		$csrf_token = csrf_token();
		Config::set('session.driver', 'array');
		
		if (Input::has('userEmail') && Input::has('password') && Input::has('type'))
		{
			$userEmail = Input::get('userEmail');
			$password = Input::get('password');
			$role = Input::get('type');
		}
		else {
			return Response::json(array('response' => array('status' => 'failed', 'message' => 'Credentials not provided')));
		}
		
		if($role == 'student'){
			$UserRepo = $this->entityManager->getRepository('Student');
		} else if($role == 'tutor'){
			$UserRepo = $this->entityManager->getRepository('Tutor');
		} else{
			return Response::json(array('response' => array('status' => 'failed', 'message' => 'Please log in as a student or tutor')));
		}


        /** @var \Student $user */
        $user = $UserRepo->findOneBy(
			array('email' => $userEmail)
		);
		
		if(!$user){
			return Response::json(array('response' => array(
                'status' => 'failed',
                'message' => 'Username and Password does not match',
                'code' => 'password-err'
            )));
		}
		if(!Hash::check($password, $user->getPassword())){
			return Response::json(array('response' => array(
                'status' => 'failed',
                'message' => 'Username and Password does not match',
                'code' => 'password-err'
            )));
		}

	    $lastLogin = null;
        if($user->getLastLoginTime()){
            $lastLogin = $user->getLastLoginTime();
            $lastLogin->setTimezone(new DateTimeZone('Asia/Kolkata'));
        }

		$userprofile=array(
			'userFirstname' => $user->getFirstname(),
			'AIR' => $user->getGlobalRank(),
			'SR' => $user->getStateRank(),
			'userEmail'=>$user->getEmail(),
			'role'=>$role,
			'che' => $user->getSubjectLevel('CHE')->getLevel(),
			'mat'=> $user->getSubjectLevel('MAT')->getLevel(),
			'phy'=>$user->getSubjectLevel('PHY')->getLevel(),
			'lastLogin' => $lastLogin ? json_encode(array("date" => $lastLogin->format('d M, Y'), "time" => $lastLogin->format('H:i'))) : null
		);

        $user->setLastLoginTime(new DateTime());
        $this->entityManager->flush();

		$response = Response::json(array(
			'response' => array('status' => 'success', 'message' => 'Logged in Successfully'),
			'person' => ($userprofile)
		));
		
		$authToken = json_encode(array('userName' => $user->getFirstName(), 'userEmail' => $user-> getEmail(), 'datestampcreated' => time(), 'type' => $role));
		Cookie::queue('auth-token', $authToken, 60);
		return $response;
	}
	
	public function logout(){
		$csrf_token = csrf_token();
		Config::set('session.driver', 'array');
		$cookie = Cookie::forget('auth-token');
		$response = Response::json(array('response' => array('status' => 'success', 'message' => 'Logged out successfully')));
		return $response->withCookie($cookie);
	}
}
?>