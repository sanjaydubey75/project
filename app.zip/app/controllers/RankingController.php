<?php

use Doctrine\ORM\EntityManagerInterface;
use Shezartech\IITJEEAcademy\Repositories;

class RankingController extends BaseController{
	
	private $entityManager;
	/** @var  Student */
	private $user;
	
	public function __construct(EntityManagerInterface $entityManager, Repositories\Interfaces\StudentRepositoryInterface $studentRepository)
	{
		$this->entityManager = $entityManager;
		$this->studentRepository = $studentRepository;

		$this->beforeFilter('log');

		$this->beforeFilter('force.ssl');

		$this->beforeFilter('auth-with-authtoken');

		$this->beforeFilter('csrf_header');

		$this->beforeFilter('auth-student');

		// enable when necessary
//        $this->entityManager->getConnection()->getConfiguration()->setSQLLogger(new \Doctrine\DBAL\Logging\DoctrineSQLLogger());

		$this->user = $this->studentRepository->getStudentFromToken(Cookie::get('auth-token'));
	}

	public function store($data){
		Config::set('session.driver', 'array');
		$pattern = '/^([0-9a-zA-Z ]+)\/([0-9a-zA-Z ]+)$/';
		preg_match($pattern, $data, $output);
		$subjectId = $output[1];
		$topicId = $output[2];
		
		$questionId = Input::get('questionId');
//		$correct = Input::get('time') - time() > 60*3 ? false : Input::get('correct');
		$correct = Input::get('correct');
		
		RankingService::start($this->user, $subjectId, $topicId, $correct, $questionId);
		$this->user->getSubjectLevel($subjectId)->setStartedPractice(true);
		$this->entityManager->flush();

		return Response::json(array(
			'response' => array('status' => 'success', 'message' => 'ranking completed')
		));
	}

	public function skipped($data){
		Config::set('session.driver', 'array');
		$pattern = '/^([0-9a-zA-Z ]+)\/([0-9a-zA-Z ]+)$/';
		preg_match($pattern, $data, $output);
		$subjectId = $output[1];
		$topicId = $output[2];

		RankingService::startSkipped($this->user, $subjectId, $topicId);

		$this->user->getSubjectLevel($subjectId)->setStartedPractice(true);
		$this->entityManager->flush();

		return Response::json(array(
			'response' => array('status' => 'success', 'message' => 'ranking completed')
		));
	}
}