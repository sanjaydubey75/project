<?php
/*
 * Created on Sep 23, 2014
*
* To change the template for this generated file go to
* Window - Preferences - PHPeclipse - PHP - Code Templates
*/

use Doctrine\ORM\EntityManagerInterface;
use Doctrine\ORM\EntityRepository;

class ForgetPasswordController extends BaseController{

	private $entityManager;

	public function __construct(EntityManagerInterface $entityManager)
	{
		$this->entityManager = $entityManager;

        $this->beforeFilter('force.ssl');

// 		$this->entityManager->getConnection()->getConfiguration()->setSQLLogger(new \Doctrine\DBAL\Logging\DoctrineSQLLogger());
	}

	private function generateRandomString($length = 20) {
		$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$randomString = '';
		for ($i = 0; $i < $length; $i++) {
			$randomString .= $characters[rand(0, strlen($characters) - 1)];
		}
		return $randomString;
	}

	public function index(){
		
		Config::set('session.driver', 'array');
		
		if(!Input::has('email') || !Input::has('dateOfBirth'))
			return Response::json(array('response' => array('status' => 'failed', 'message' => 'Credentials not provided')));
		
		$user = $this->entityManager->getRepository('Student')->findOneBy(array('email' => Input::get('email')));
		
// 		tutors' date of birth not yet done
// 		if(!$user)
// 			$user = $this->entityManager->getRepository('Tutor')->findOneBy(array('email' => $email));
		
		if(!$user || $user->getBirthday()->format('m/d/Y') != Input::get('dateOfBirth')){
			return Response::json(array('response' => array('status' => 'failed', 'message' => 'Email or Date of Birth do not match')));
		}

		$str = ForgetPasswordController::generateRandomString();
		$hash = Hash::make($str);
		
		$passwordChangeRequest = $this->entityManager->getRepository('PasswordChangeRequest')->find($user);
		
		if(!$passwordChangeRequest){
			$passwordChangeRequest = new PasswordChangeRequest($user, $hash, new \Datetime());
		}
		else{
			$passwordChangeRequest->setHash($hash);
			$passwordChangeRequest->setTime(new \DateTime());
		}
		$this->entityManager->persist($passwordChangeRequest);
		$this->entityManager->flush();
		
		$data = array(
			'name' => $user->getFirstName(),
			'link' => str_replace(Request::path(), '', Request::url())."changePassword/".$str."/".$user->getEmail(),
			'relativeUrl' => str_replace(Request::path(), '', Request::url())
		);
		
		Mail::queue('emails.ChangePassword', $data, function($message) use ($user)
		{
			$message->from('info@iitjeeacademy.com', 'IITJEE Academy');
			$message->to($user->getEmail(), 'Jon Doe')->subject('Change Password for IITJEE Academy');
		});
		
		$response = Response::json(array(
			'response' => array('status' => 'success', 'message' => 'Check your email to change your password')
		));

		return $response;
	}
	
	public function changePassword(){
		
		Config::set('session.driver', 'array');
		
		$response = Response::json(array(
			'response' => array('status' => 'success', 'message' => 'Login again')
		));
		
		$user = $this->entityManager->getRepository('Student')->findOneBy(array('email' => Input::get('email')));
		if(!$user){
			return $response;
		}
		
		$request = $this->entityManager->getRepository('PasswordChangeRequest')->find($user);
		
		if($request && ((new \Datetime())->getTimestamp() - $request->getTime()->getTimestamp() < 3600)){
			if(Hash::check(Input::get('tokenId'), $request->getHash())){
				$request->getUser()->setPassword(Hash::make(Input::get('newPassword')));
			}
		}
		
		$this->entityManager->flush();
		
		return $response;
	}
}

?>
