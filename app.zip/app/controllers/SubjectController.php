<?php

use Doctrine\ORM\EntityManagerInterface;
use Doctrine\ORM\EntityRepository;

class SubjectController extends BaseController{
	
	private $entityManager;
	
	public function __construct(EntityManagerInterface $entityManager)
    {
    	$this->entityManager = $entityManager;
    	
    	$this->beforeFilter('log');

        $this->beforeFilter('force.ssl');
    	
        $this->beforeFilter('auth-with-authtoken');

        $this->beforeFilter('csrf_header');
        
        $this->beforeFilter('auth-student');
        
        $this->entityManager->getConnection()->getConfiguration()->setSQLLogger(new \Doctrine\DBAL\Logging\DoctrineSQLLogger());
        
    }
	public function index(){
		Config::set('session.driver', 'array');
		
		$qb = $this->entityManager->createQueryBuilder();
		$qb->select(array('s.id', 's.name'))
			->from('Subject', 's');
		$query = $qb->getQuery();
		$subjects = $query->getResult();
		$response = Response::json(array('subjects' => $subjects, 'response' => array('status' => 'success', 'message' => '')));
		
		return $response;
	}
	
	public function details($data){
    	Config::set('session.driver', 'array');
    	
    	$authToken = json_decode(Cookie::get('auth-token'), true);
		$userEmail = $authToken['userEmail'];
		$UserRepo = $this->entityManager->getRepository('Student');
		$user = $UserRepo->findOneBy(
			array('email' => $userEmail)
		);
		
		$subject = $this->entityManager->getRepository('Subject')
			->findOneBy(array(
				'id' => $data
			));
		
		if(!$subject){
			throw new Exception('subject does not exist');
		}

		$startedPractice = $user->getSubjectLevel($subject->getId())->isStartedPractice();

		$response = Response::json(array(
			'response' => array('status' => 'success', 'message' => ''),
			'subject' => array(
				'id' => $subject->getId(),
				'name' => $subject->getName(),
				'AIR' => $startedPractice ? $user->getSubjectGlobalRank($data)->getRank() : null,
				'SR' => $startedPractice ? $user->getSubjectStateRank($data)->getRank() : null,
				'level' => $user->getSubjectLevel($data)->getLevel()
			)
		));
		
		return $response;
    }
}

?>
