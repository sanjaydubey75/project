<?php

use Doctrine\ORM\EntityManagerInterface;
use Shezar\IITJEEAcademy\Models\PricingModels;
use \Shezar\IITJEEAcademy\Services\TransactionValidationInterface;
use \Shezar\IITJEEAcademy\Repositories\BaseRepositoryInterface;
use \Shezar\IITJEEAcademy\Services\TransactionServiceInterface;
use \Shezar\IITJEEAcademy\Repositories\TransactionRepositoryInterface;
use Shezar\IITJEEAcademy\Repositories\StudentRepositoryInterface;

class PaymentGatewayController extends BaseController
{
	/** @var EntityManagerInterface  */
	private $entityManager;
	/** @var BaseRepositoryInterface  */
	private $baseRepository;
	/** @var TransactionRepositoryInterface  */
	private $transactionRepository;
	/** @var TransactionValidationInterface  */
	private $transactionValidation;
	/** @var TransactionServiceInterface  */
	private $transactionService;
	/** @var StudentRepositoryInterface  */
	private $studentRepository;

	public function __construct(BaseRepositoryInterface $baseRepository,
	                            EntityManagerInterface $entityManager,
	                            TransactionValidationInterface $transactionValidation,
	                            TransactionServiceInterface $transactionService,
	                            TransactionRepositoryInterface $transactionRepository,
								StudentRepositoryInterface $studentRepository)
	{
		$this->beforeFilter('force.ssl');

		$this->transactionValidation = $transactionValidation;
		$this->transactionService = $transactionService;
		$this->baseRepository = $baseRepository;
		$this->entityManager = $entityManager;
		$this->transactionRepository = $transactionRepository;
		$this->studentRepository = $studentRepository;

//         $this->entityManager->getConnection()->getConfiguration()->setSQLLogger(new \Doctrine\DBAL\Logging\DoctrineSQLLogger());
	}

	public function start()
	{
		Config::set('session.driver', 'array');
		$input = Input::all();

		$messages = $this->transactionValidation->validateStart($input);
		if(!$messages){
			try{
				$url = $this->transactionService->getPaymentGatewayUrl($input, Request::root());
			} catch(Exception $e){
				if($e instanceof \Shezar\IITJEEAcademy\Exceptions\TransactionStartException)
					return View::make('payment.error.preprocessing', $e->display());
				else throw $e;
			}
			return Redirect::to($url);
		}

		return Response::json(array(
			'response' => array(
				'status' => 'failed',
				'message' => ''
			),
			'messages' => $messages
		));
	}

	public function end()
	{
		Config::set('session.driver', 'array');

		try{
			ob_start(); // this is to prevent any php code sending output to client in between
			$output = $this->transactionValidation->validateEnd(Input::all(), Request::root());
			$transactionDetails = $this->transactionService->postTransactionProcess(Input::all(), Request::root(), $output);
			
			if($transactionDetails["status"] == 1){
				$this->baseRepository->beginTransaction();
				$student = $this->studentRepository->findOneBy(array('email' => $transactionDetails['email']));
				$transaction = $this->transactionRepository->find($transactionDetails['transactionId']);
				if($student){
					$transaction->getSubscriptionModel(); 
					$student->setSubscriptionModel($transaction->getSubscriptionModel());
					$subscriptionLimit = (new PricingModels())->getModel($transaction->getSubscriptionModel())->getDuration();
					
					$subscriptionLimitDate = date('Y-m-d H:i:s', strtotime('+'.$subscriptionLimit));
					$subscriptionLimit2 = \DateTime::createFromFormat('Y-m-d H:i:s', trim($subscriptionLimitDate));
					$student->setSubscriptionLimit($subscriptionLimit2);
					
					$this->studentRepository->save($student);
					
				}
				$this->baseRepository->commit();
			};
			if(isset($subscriptionLimitDate)) $transactionDetails["subscribeLimit"] = strtotime($subscriptionLimitDate)*1000;
			
			$response = Response::view('payment.success.close');
			$response->header('Set-Cookie', "transactionDetails=" . json_encode($transactionDetails) . "; path=/;");
			
			return $response;
		}
		catch(Exception $e){
			if($e instanceof \Shezar\IITJEEAcademy\Exceptions\TransactionEndException)
				return View::make('payment.error.postprocessing', $e->display());
			else throw $e;
		}
	}

	public function result(){
		Config::set('session.driver', 'array');

		try{
			$input = get_object_vars(json_decode(array_get($_COOKIE, 'transactionDetails', null)));
			$this->transactionValidation->validateGetDetails($input);
			$transactionDetails = $this->transactionService->getTransactionDetails($input);
			return Response::json(array(
				'response' => array('status' => 'success', 'message' => ''),
				'transactionDetails' => $transactionDetails
			));
		}
		catch(Exception $e){
			throw $e;
		}
	}

	public function mobileresult(){
		Config::set('session.driver', 'array');

		try{
			$input = Input::all();
			$this->transactionValidation->validateGetDetails($input);
			$transactionDetails = $this->transactionService->getTransactionDetails($input);
			return Response::json(array(
				'response' => array('status' => 'success', 'message' => ''),
				'paymentdetails' => $transactionDetails
			));
		}
		catch(Exception $e){
			throw $e;
		}
	}
}