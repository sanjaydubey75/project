<?php

use Doctrine\ORM\EntityManagerInterface;

class ReportController extends BaseController{
    public function __construct(EntityManagerInterface $entityManager)
    {
        $this->entityManager = $entityManager;
        $this->beforeFilter('log');

        $this->beforeFilter('force.ssl');

        $this->beforeFilter('auth-with-authtoken');

        $this->beforeFilter('csrf_header');

        $this->beforeFilter('auth-student');
// 		$this->entityManager->getConnection()->getConfiguration()->setSQLLogger(new \Doctrine\DBAL\Logging\DoctrineSQLLogger());
    }

    public function error(){
        Config::set('session.driver', 'array');
        $authToken = json_decode(Cookie::get('auth-token'), true);
        $userEmail = $authToken['userEmail'];

        $student = $this->entityManager->getRepository('Student')->findOneBy(array('email' => $userEmail));

        $data = array(
            'question' => Input::get('questionId'),
            'studentemail' => $student->getEmail()
        );

        Mail::later(60, 'emails.ReportQuestionError', $data, function($message)
        {
	        $message->from('info@iitjeeacademy.com', 'IITJEE Academy');
            $message->to('support@iitjeeacademy.com', 'Jon Doe')->subject('Flagged question');
        });

        return Response::json(array(
            'response' => array('status' => 'success', 'message' => 'Thanks for reporting')
        ));
    }
}