<?php

use Doctrine\ORM\EntityManagerInterface;
use Doctrine\ORM\EntityRepository;

class ContactController extends BaseController{
	private $entityManager;

	public function __construct(EntityManagerInterface $entityManager)
	{
		$this->entityManager = $entityManager;

		$this->beforeFilter('log');

		$this->beforeFilter('force.ssl');

		$this->beforeFilter('csrf_header');

		$this->entityManager->getConnection()->getConfiguration()->setSQLLogger(new \Doctrine\DBAL\Logging\DoctrineSQLLogger());

	}

	public function contactus(){
		Config::set('session.driver', 'array');

		$username = Input::get('username');
		$subject = Input::get('subject');
		$email = Input::get('email');
		$message = Input::get('message');

		if(!($username && $subject && $email && $message)){
			return Response::json(array('response' => array('status' => 'failed', 'message' => 'request not valid')));
		}
		$validator = Validator::make(
			array('email' => $email),
			array('email' => 'required|email')
		);
		if($validator->fails()){
			return Response::json(array('response' => array('status' => 'failed', 'message' => 'email not valid')));
		}

		$data = array(
			'username' => $username,
			'subject' => $subject,
			'email' => $email,
			'message1' => $message
		);

		Mail::later(60, 'emails.ContactUsForm', $data, function($message)
		{
			$message->from('info@iitjeeacademy.com', 'IITJEE Academy');
			$message->to('info@iitjeeacademy.com', 'Jon Doe')->subject('Contact Us message');

		});

        return Response::json(array('response' => array('status' => 'success', 'message' => 'message sent')));
	}
}