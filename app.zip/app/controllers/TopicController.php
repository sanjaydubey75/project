<?php
/*
 * Created on Sep 29, 2014
 *
 * To change the template for this generated file go to
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\ORM\EntityRepository;

class TopicController extends BaseController{
	private $entityManager;

    public function __construct(EntityManagerInterface $entityManager)
    {
        $this->entityManager = $entityManager;
        
        $this->beforeFilter('log');

        $this->beforeFilter('force.ssl');
        
        $this->beforeFilter('auth-with-authtoken');

        $this->beforeFilter('csrf_header');
        
        $this->beforeFilter('auth-student');
        
        $this->entityManager->getConnection()->getConfiguration()->setSQLLogger(new \Doctrine\DBAL\Logging\DoctrineSQLLogger());
    }
    
    public function show($id){
    	
    	Config::set('session.driver', 'array');
    	
    	$qb = $this->entityManager->createQueryBuilder();
    	
		$qb->select('t')
			->from('Topic', 't')
			->where($qb->expr()->eq("IDENTITY(t.subject)", ':subjectid'))
			->orderBy('t.name', 'ASC')
			->setParameter('subjectid', $id);
		$query = $qb->getQuery();
		$topics = $query->getResult();
		
		$a = array();
		foreach($topics as $key => $topic){
			$a[$key] = array(
				'id' => $topic->getId(),
				'name' => $topic->getName(),
				'subject_id' => $topic->getSubjectId()->getId(),
                'info' => $topic->getInfo(),
				'order' => $topic->getOrder()
			);
		}
		
		$response = Response::json(
			array(
				'topics' => $a,
				'response' => array('status' => 'success', 'message' => '')
			)
		);
		
		return $response;
    }
    
    public function details($data){
    	Config::set('session.driver', 'array');
    	
    	$authToken = json_decode(Cookie::get('auth-token'), true);
		$userEmail = $authToken['userEmail'];
		$UserRepo = $this->entityManager->getRepository('Student');
		$user = $UserRepo->findOneBy(
			array('email' => $userEmail)
		);

	    /** @var Topic $topic */
	    $topic = $this->entityManager->getRepository('Topic')
			->findOneBy(array(
				'id' => $data
			));

	    /** @var TopicLevel $topicLevel */
	    $topicLevel = $user->getTopicLevel($topic->getId());

	    $QuestionAnsweredCount = $topicLevel->getCorrectAttempts();

	    $fakeScore = $topicLevel->getScore()/RankingService::$gamma[$user->getTopicLevel($topic->getId())->getLevel() - 1];

		$response = Response::json(array(
			'response' => array('status' => 'success', 'message' => ''),
			'topic' => array(
				'id' => $topic->getId(),
				'name' => $topic->getName(),
				'subject_id' => $topic->getSubjectId()->getId(),
				'subject_name'=>$topic->getSubjectId()->getName(),
				'level' => $topicLevel->getLevel(),
				'topicLevelTestCompleted' => $topicLevel->getLevelTestAttempt(),
				'score' =>
					$topicLevel->getScore() ?
						(
							(
								($QuestionAnsweredCount < RankingService::$minQuestionsBeforeLevelUp) &&
								($fakeScore > .9 )
							) ? .9
								: ($fakeScore > 1 ? 1 : $fakeScore)
						)
						: null
			)
		));
		
		return $response;
    }
}
?>
