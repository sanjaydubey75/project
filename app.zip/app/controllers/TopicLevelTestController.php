<?php
use \Shezar\IITJEEAcademy\Services\QuestionServiceInterface;
use \Shezar\IITJEEAcademy\Services\QuestionService;
use \Shezar\IITJEEAcademy\Services\StudentService;
use \Shezar\IITJEEAcademy\Services\StudentServiceInterface;

class TopicLevelTestController extends BaseController{
	/** @var QuestionService  */
	private $questionService;

	/** @var  StudentService */
	private $studentService;

	public function __construct(QuestionServiceInterface $questionService, StudentServiceInterface $studentService){
		$this->beforeFilter('log');

		$this->beforeFilter('force.ssl');
		$this->beforeFilter('csrf_header');
		$this->beforeFilter('auth-with-authtoken');
		$this->beforeFilter('auth-student');

		$this->questionService = $questionService;
		$this->studentService = $studentService;

	}

	public function index($topicId){

		Config::set('session.driver', 'array');

		try{
			$questions = $this->questionService->getQuestionsForLevelTest($topicId, Cookie::get('auth-token'));
			return Response::json(array(
				'questions' => $questions,
				'response' => array('status' => 'success', 'message' => '')
			));
		} catch(Exception $e){
			if($e instanceof \Shezar\IITJEEAcademy\Exceptions\TopicLevelTestException)
				return Response::json(array(
					'response' => array('status' => 'failed', 'message' => $e->display())
				));
			else throw $e;
		}
	}

	public function setLevel($topicId){
		try{
			$this->studentService->setTopicLevel($topicId, Input::get('level'), Cookie::get('auth-token'));
			return Response::json(
				array('response' => array('status' => 'success'))
			);
		}catch(Exception $e){
			if($e instanceof \Shezar\IITJEEAcademy\Exceptions\TopicLevelTestException)
				return Response::json(array(
					'response' => array('status' => 'failed', 'message' => $e->display())
				));
			else throw $e;
		}
	}

	public function getAttemptStatus($topicId){
		$status = $this->studentService->getTopicLevelTestAttemptStatus($topicId, Cookie::get('auth-token'));
		return Response::json(
			array('response' => array('status' => 'success'), 'attemptStatus' => $status)
		);
	}

	public function setAttemptStatus($topicId){
		$status = Input::get('attemptStatus');
		$this->studentService->setTopicLevelTestAttemptStatus($topicId, Cookie::get('auth-token'), $status);
		return Response::json(
			array('response' => array('status' => 'success'))
		);
	}
}