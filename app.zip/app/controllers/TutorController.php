<?php
/*
 * Created on Sep 23, 2014
 *
 * To change the template for this generated file go to
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */

class TutorController extends BaseController{
	public function details(){
		Config::set('session.driver', 'array');
		return Response::json(array('total' => '$500', 'message' => 'success'));
	}
}

?>
