<?php
/*
 * Created on Sep 23, 2014
*
* To change the template for this generated file go to
* Window - Preferences - PHPeclipse - PHP - Code Templates
*/

use Doctrine\ORM\EntityManagerInterface;
use Doctrine\ORM\EntityRepository;

class ShareFriendController extends BaseController{

	private $entityManager;

	public function __construct(EntityManagerInterface $entityManager)
	{
		$this->entityManager = $entityManager;
    	
// 		$this->entityManager->getConnection()->getConfiguration()->setSQLLogger(new \Doctrine\DBAL\Logging\DoctrineSQLLogger());
    	
    	$this->beforeFilter('log');

        $this->beforeFilter('force.ssl');
    	
        $this->beforeFilter('auth-with-authtoken');

        $this->beforeFilter('csrf_header');
        
        $this->beforeFilter('auth-student');
	}

	public function share(){
		
		Config::set('session.driver', 'array');
		
		$questionId = Input::get('question');
		$friendEmail = Input::get('email');
		
		//email has to be validated
		$validator = Validator::make(
			array('email' => $friendEmail),
			array('email' => 'required|email')
		);
		
		if($validator->fails()){
			return Response::json(array('response' => array('status' => 'failed', 'message' => 'Email is not valid')));
		}

		/** @var Student $user */
		$user = $this->entityManager->getRepository('Student')->findOneBy(
			array('email' => json_decode(Cookie::get('auth-token'), true)['userEmail'])
		);

		$now = new DateTime();
		$yesterday = ((new DateTime())->sub(new \DateInterval("P1D")));
		$yesterday->setTime(0, 0, 0);


		$qb = $this->entityManager->createQueryBuilder();
		$qb->select('count(s.Id)')
			->from('ShareFriendRequest','s')
			->where('s.student = :studentId')
			->andWhere('s.time > :yesterday')
			->setParameter('yesterday', $yesterday)
			->setParameter('studentId', $user->getId());

		$count = $qb->getQuery()->getSingleScalarResult();
		if($count>15){
			return Response::json(array('response' => array('status' => 'failed', 'message' => 'You have exceeded your sharing quota')));
		}


		$question = $this->entityManager->getRepository('Question')->find($questionId);

		$shareFriendRequest = new ShareFriendRequest($friendEmail, $question, $user, new \Datetime());
		$this->entityManager->persist($shareFriendRequest);
		$this->entityManager->flush();
		
		$data = array(
			'student' => $user->getFirstName(),
			'relativeUrl' => str_replace(Request::path(), '', Request::url()),
			'tokenId' => $shareFriendRequest->getId(),
			'questionId' => $questionId,
			'studentEmail' => $user->getEmail(),
			'friendEmail' => $friendEmail
		);
		
		Mail::later(60, 'emails.ShareQuestion', $data, function($message) use ($user, $friendEmail)
		{
			/** @var Illuminate\Mail\Message $message */
			$message->from('info@iitjeeacademy.com', 'IITJEE Academy');
			$message->to($friendEmail, 'Jon Doe')->subject('Challenge from '.$user->getFirstname().' to solve question');
		});
		
		$response = Response::json(array(
			'response' => array('status' => 'success', 'message' => 'Email sent'),
			'xyz' => array('question' => $questionId, 'email' => $friendEmail, 'useremail' => $user->getEmail())
		));
		
		return $response;
	}
}

?>
