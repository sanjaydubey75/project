<?php

use Doctrine\ORM\EntityManagerInterface;
use Shezartech\IITJEEAcademy\Repositories;

class QuestionController extends BaseController{
	
	private $entityManager;
    /**
     * @var \Student
     */
    private $user;

    public function __construct(EntityManagerInterface $entityManager,
                                Repositories\Interfaces\StudentRepositoryInterface $studentRepository,
                                Repositories\Interfaces\QuestionRepositoryInterface $questionRepository)
    {
    	$this->entityManager = $entityManager;
        $this->studentRepository = $studentRepository;
        $this->questionRepository = $questionRepository;

//    	$this->entityManager->getConnection()->getConfiguration()->setSQLLogger(new \Doctrine\DBAL\Logging\EchoSQLLogger());
		$this->entityManager->getConnection()->getConfiguration()->setSQLLogger(new \Doctrine\DBAL\Logging\DoctrineSQLLogger());
    	
    	$this->beforeFilter('log');

        $this->beforeFilter('force.ssl');
    	
		$this->beforeFilter('auth-with-authtoken', array('only' => array('index')));

		$this->beforeFilter('csrf_header');
        
        $this->beforeFilter('auth-student', array('only' => array('index')));

        $this->beforeFilter('@subscriptionLimit', array('only' => array('index')));
        
        $this->beforeFilter('@validateFriendRequest', array('only' => array('show')));

        $this->user = $this->studentRepository->getStudentFromToken(Cookie::get('auth-token'));
    }
    
	public function index($subjectId, $topicId){
		Config::set('session.driver', 'array');

		if($this->user->getTopicLevel($topicId)->getLevel() == 8){
			return Response::json(array(
				'response' => array('status' => 'failed', 'message' => 'No questions for this topic', 'code' => 'level-over')
			));
		}
		
		$question = $this->questionRepository->getRandomQuestion($this->user, $topicId, $subjectId);

		if(!$question){
            $this->studentRepository->increaseTopicLevel($this->user, $topicId);
            return $this->index($subjectId, $topicId);
		}

        return $this->questionRepository->display($question);
	}
	
	public function show($id){
		
		Config::set('session.driver', 'array');
		
		$question = $this->questionRepository->getQuestionById($id);
		return $this->questionRepository->display($question);
		
	}
	
	public function validateFriendRequest($route, $request){
		Config::set('session.driver', 'array');
		
		$request = $this->entityManager->getRepository('ShareFriendRequest')->findOneBy(array('Id' => Input::get('token')));
		
		if(!($request && ((new \Datetime())->getTimestamp() - $request->getTime()->getTimestamp() < 1296000) && ($request->getStudent()->getEmail() == Input::get('student')) && ($request->getfriendEmail() == Input::get('friend')))){
			return Response::json(array(
				'response' => array('status' => 'failed', 'message' => 'not authorized')
			));
		}
	}

    public function subscriptionLimit(){
        Config::set('session.driver', 'array');

        $subscriptionLimit = $this->user->getSubscriptionLimit();
        $time = new \DateTime();

        $diffInSeconds = $subscriptionLimit->getTimestamp() - $time->getTimestamp();

        if($diffInSeconds < 0){
            return Response::json(array(
                'response' => array('status' => 'failed', 'message' => 'subscription over', 'code' => 'subscription-over')
            ));
        }

    }
}
?>