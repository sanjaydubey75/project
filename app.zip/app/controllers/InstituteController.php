<?php


use Doctrine\ORM\EntityManagerInterface;
use Doctrine\ORM\EntityRepository;
use \Shezar\IITJEEAcademy\Repositories\InstituteRepositoryInterface;

class InstituteController extends BaseController{
	private $instituteRepository;

	public function __construct(InstituteRepositoryInterface $instituteRepository)
	{
		$this->instituteRepository = $instituteRepository;
		$this->beforeFilter('force.ssl');
//         $this->entityManager->getConnection()->getConfiguration()->setSQLLogger(new \Doctrine\DBAL\Logging\DoctrineSQLLogger());
	}

	public function index(){
		Config::set('session.driver', 'array');

		/** @var Institute[] $institutes */
		$institutes = $this->instituteRepository->findAll();

		$name=array();
		foreach($institutes as $key => $institute){
			$name[$key] = $institute->getName();
		}

		return Response::json(array(
			'response' => array(
				'status' => 'success',
				'message' => ''
			),
			'institutes' => $name
		));
	}
}