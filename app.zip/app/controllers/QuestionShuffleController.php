<?php

use Doctrine\ORM\EntityManagerInterface;
use Doctrine\ORM\EntityRepository;

class QuestionShuffleController extends BaseController{
	
	private $entityManager;
	
	public function __construct(EntityManagerInterface $entityManager)
    {
    	$this->entityManager = $entityManager;
    	
    	$this->beforeFilter('log');

        $this->beforeFilter('force.ssl');
    	
        $this->entityManager->getConnection()->getConfiguration()->setSQLLogger(new \Doctrine\DBAL\Logging\DoctrineSQLLogger());
    }
    
    private static function stablecmp($fn)
	{
	    return function($a, $b) use ($fn) {
	        if (($tmp = call_user_func($fn, $a[0], $b[0])) != 0) {
	            return $tmp;
	        } else {
	            return $a[1] - $b[1];
	        }
	    };
	}
    
    public function store(){
		$qb = $this->entityManager->createQueryBuilder();
		$topics = $this->entityManager->createQueryBuilder()
			->select('t.id')
			->from('Topic', 't')
			->getQuery()
			->getResult();
			
		foreach($topics as $key => $value){
			$allquestions=array();

			$questions = $this->entityManager->createQueryBuilder()
				->select(array('q'))
				->from('Question', 'q')
				->where('q.topic = :topicId')
//				->andWhere('q.attempt != :attempt')
//				->setParameter('attempt', 0)
				->setParameter('topicId', $value['id'])
				->orderBy('q.level', 'ASC')
				->getQuery()
				->getResult();

			array_walk($questions, function(&$element, $index) {
				$element = array($element, $index); // decorate
			});
//			foreach($questions as $key1=>$value1){
//				echo $value1->getAttempt();
//				echo '----';
//			}
			
			
			usort($questions, function($a, $b) {
				if($a[0]->getAttempt() == 0)
					return $a[1] - $b[1];
				
				if($b[0]->getAttempt() == 0)
					return $a[1] - $b[1];
				
				if(($a[0]->getCorrect() / $a[0]->getAttempt()) > ($b[0]->getCorrect() / $b[0]->getAttempt())){
					return -1;
				}
				else if (($a[0]->getCorrect() / $a[0]->getAttempt()) < ($b[0]->getCorrect() / $b[0]->getAttempt())){
					return 1;
				}
				else{
					return $a[1] - $b[1];
				}
				// $a[0] and $b[0] contain the primary sort key
				// $a[1] and $b[1] contain the secondary sort key
			});
			array_walk($questions, function(&$element) {
				$element = $element[0];
			});
//			usort($questions, function($a, $b) {
//				
//				
//				if(($a->getCorrect() / $a->getAttempt()) > ($b->getCorrect() / $b->getAttempt())){
//					return -1;
//				}
//				else if (($a->getCorrect() / $a->getAttempt()) < ($b->getCorrect() / $b->getAttempt())){
//					return 1;
//				}
//				else return 0;
//			});
			$total = count($questions);
			$rem= $total% 7;
			$eq=($total-$rem)/7;
			$lev=1;
			$count=0;
			foreach ($questions as $key => $value) {
				if($count > (($lev * $eq)+$rem)){
					$lev++;
				}
				$value->setLevel($lev);
				$this->entityManager->persist($value);
				
				$count++;
			}
		}
		$this->entityManager->flush();
		
		return Response::json(
			array(
				'response' => array(
					'status' => 'success',
					'message' => 'completed'
				)
			)
		);
	}
    
}