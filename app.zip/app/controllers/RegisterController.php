<?php

use Shezar\IITJEEAcademy\Services\StudentServiceInterface;
use Shezar\IITJEEAcademy\Services\RegisterValidationInterface;

class RegisterController extends BaseController{

	/** @var RegisterValidationInterface  */
	private $registerValidation;
	/** @var \Shezar\IITJEEAcademy\Services\StudentService  */
	private $studentService;

	/**
	 * @param RegisterValidationInterface $registerValidation
	 * @param StudentServiceInterface $studentService
	 */
	public function __construct(RegisterValidationInterface $registerValidation,
	                            StudentServiceInterface $studentService)
	{
		$this->beforeFilter('log');
		$this->beforeFilter('force.ssl');
		$this->beforeFilter('csrf_header');
//         $this->entityManager->getConnection()->getConfiguration()->setSQLLogger(new \Doctrine\DBAL\Logging\DoctrineSQLLogger());

		$this->registerValidation = $registerValidation;
		$this->studentService = $studentService;
	}

	public function register(){

		Config::set('session.driver', 'array');

		$input = Input::all();

		$messages = $this->registerValidation->validate($input);

		if(!$messages){
			$this->studentService->register($input);

			$response = Response::json(array(
				'response' => array(
					'status' => 'success',
					'message' => 'Registered Successfully'
				)
			));
			$registerDetails = $this->studentService->getRegistrationDetails($input, $_COOKIE);
			if($registerDetails)
				$response->header('Set-Cookie', "transactionDetails=" . json_encode($registerDetails) . "; path=/;");

			return $response;
		} else {
			return Response::json(array(
				'response' => array(
					'status' => 'failed',
					'message' => 'Registration Failed'
				),
				'errormessages' => $messages
			));
		}
	}

	public function registertrial(){

		Config::set('session.driver', 'array');

		$this->studentService->registertrial(Input::all());

		return Response::json(array(
			'response' => array(
				'status' => 'success',
				'message' => 'Registered Successfully'
			)
		));
	}

	public function validate(){

		Config::set('session.driver', 'array');

		$input = Input::all();

		$messages = $this->registerValidation->validateInitial($input);

		if ($messages) {
			$temp = "";
			foreach ($messages->all() as $key => $value) {
				$temp = $temp.$value."#";
			}

			return Response::json(array(
				'response' => array(
					'status' => 'failed',
					'message' => 'Validation Error',
					'errormessages' => $temp
				),
				'errormessages' => $messages
			));
		}

		$discount = $this->registerValidation->getDiscount($input);
		if($discount){
			if ($discount == 100)
				return Response::json(array(
					'response' => array(
						'status' => 'success',
						'message' => 'Validation Pass'
					),
					'redirectStatus' => 'Register'
//					'redirectToPG' => false,
//					'couponcodevalid' => true
				));
			return Response::json(array(
				'response' => array(
					'status' => 'success',
					'message' => 'Validation Pass'
				),
				'redirectStatus' => 'PG'
//				'redirectToPG' => true,
//				'couponcodevalid' => true
			));
		}
		return Response::json(array(
			'response' => array(
				'status' => 'success',
				'message' => 'Validation Pass'
			),
			'redirectStatus' => 'Pricing'
//			'redirectToPG' => true,
//			'couponcodevalid' => false
		));
	}

	public function validateEmail(){
		Config::set('session.driver', 'array');
		$validator = Validator::make(
			array('email' => Input::get('value')),
			array('email' => 'required|email|unique:student|max:200')
		);
		if($validator->fails()){
			return Response::json(array(
				'isValid' => false,
				'value' => Input::get('value')
			));
		} else {
			return Response::json(array(
				'isValid' => true,
				'value' => Input::get('value')
			));
		}
	}

	public function validateCouponCode(){
		Config::set('session.driver', 'array');
		if(Input::has(array('couponcode', 'institution'))){
			$messages = $this->registerValidation->validateInitial(Input::all());

			foreach($messages->getMessages() as $key => $value){
				if($key == 'couponcode') return Response::json(array('isValid' => false));
			}
			return Response::json(array('isValid' => true));
		}
		return Response::json(array('isValid' => false));
	}
}
?>