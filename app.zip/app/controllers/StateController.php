<?php

use Doctrine\ORM\EntityManagerInterface;
use Doctrine\ORM\EntityRepository;

class StateController extends BaseController{
	
	private $entityManager;
	
	public function __construct(EntityManagerInterface $entityManager)
    {
		$this->entityManager = $entityManager;

//    	$this->entityManager->getConnection()->getConfiguration()->setSQLLogger(new \Doctrine\DBAL\Logging\EchoSQLLogger());    	
		$this->entityManager->getConnection()->getConfiguration()->setSQLLogger(new \Doctrine\DBAL\Logging\DoctrineSQLLogger());
    	
		$this->beforeFilter('log');

        $this->beforeFilter('force.ssl');

		$this->beforeFilter('csrf_header');
        
    }
    
	public function index(){
		Config::set('session.driver', 'array');
		
		$states = $this->entityManager->getRepository('StatewiseSelection')->findall();
		
		$list = array();
		foreach($states as $key=>$state){
			$list[$key] = $state->getName();
		}
		
		sort($list);
		
		$response = Response::json(array(
			'response' => array('status' => 'success', 'message' => ''),
			'states' => $list
		));
		
		return $response;
	}
}
?>