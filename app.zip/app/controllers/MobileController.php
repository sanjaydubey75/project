<?php

use Doctrine\ORM\EntityManagerInterface;
use Doctrine\ORM\EntityRepository;

class MobileController extends BaseController{
	
	private $entityManager;
	
	public function __construct(EntityManagerInterface $entityManager)
    {
    	$this->entityManager = $entityManager;
    	
    	$this->beforeFilter('log');
    	
    	$this->beforeFilter('force.ssl');
    	
    	$this->entityManager->getConnection()->getConfiguration()->setSQLLogger(new \Doctrine\DBAL\Logging\DoctrineSQLLogger());

    }
	public function index($subid, $topicid, $userFirstname, $userEmail, $password){
		
		$csrf_token = csrf_token();
		Config::set('session.driver', 'array');
		
		$student = $this->entityManager->getRepository('Student')->findOneBy(
			array('email' => $userEmail)
		);
		
		if(!$student){
			return Response::json(array('response' => array('status' => 'failed', 'message' => 'Username and Password does not match')));
		}
		if(!Hash::check($password, $student->getPassword())){
			return Response::json(array('response' => array('status' => 'failed', 'message' => 'Username and Password does not match')));
		}
		
		//set auth token
		$authToken = json_encode(array(
			'userName' => $student->getFirstName(),
			'userEmail' => $student->getEmail(),
			'datestampcreated' => time(),
			'type' => 'student'
		));
		
		Cookie::queue('auth-token', $authToken, 60);
		
		
		$response = Response::view('mobileindex');
		$csrf_token = "csrf-token=".$csrf_token."; path=/;";
		$response->header('Set-Cookie', $csrf_token);
		
		return $response;
		
		// a get request to 
		// http://localhost/iitjee/mobile/question/MAT/AEA/Shobhit/abcd@abcd.com/aA12!@
		// works
	}
}

?>
