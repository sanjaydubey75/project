<?php

use Shezar\IITJEEAcademy\Repositories\StudentRepositoryInterface;
use Shezar\IITJEEAcademy\Repositories\StudentRepository;

class FeedbackController extends BaseController{
	/** @var  StudentRepository */
	private $studentRepository;
	public function __construct(StudentRepositoryInterface $studentRepository){
		$this->beforeFilter('log');

		$this->beforeFilter('force.ssl');

		$this->beforeFilter('csrf_header');

		$this->beforeFilter('auth-with-authtoken');

		$this->studentRepository = $studentRepository;
	}

	public function feedback(){

		Config::set('session.driver', 'array');
		if(!(Input::has('subject') && Input::has('message')))return Response::json(array('response' => array('status' => 'failed')));

		/** @var Student $student */
		$student = $this->studentRepository->getStudentFromToken(Cookie::get('auth-token'));
		$subject = Input::get('subject');
		$data = array('message1' => Input::get('message'), 'email' => $student->getEmail(), 'username' => $student->getFirstname()." ".$student->getLastname());

		Mail::queue('emails.FeedbackForm', $data, function($message) use ($subject)
		{
			$message->from('info@iitjeeacademy.com', 'IITJEE Academy');
			$message->to('info@iitjeeacademy.com', 'Jon Doe')->subject($subject);
		});
		return Response::json(array('response' => array('status' => 'success', 'message' => 'Thank you for your feedback')));
	}
}