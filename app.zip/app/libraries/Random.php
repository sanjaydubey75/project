<?php


use Illuminate\Foundation\Application;

// check out http://stackoverflow.com/questions/17088917/what-are-the-best-practices-and-best-places-for-laravel-4-helpers-or-basic-funct/
// to know more about how to set this

// After you update your composer.json file, you need to run the command
// composer dump-autoload
// To verfiy that you files will be loaded, check out
// vendor/composer/autoload_classmap.php

class Random{
	public static function generateRandomString($length = 20) {
		$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$randomString = '';
		for ($i = 0; $i < $length; $i++) {
			$randomString .= $characters[rand(0, strlen($characters) - 1)];
		}
		return $randomString;
	}
}