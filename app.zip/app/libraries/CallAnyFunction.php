<?php
require_once "D:/development/egit/workrepo1/iitjeeacademy/vendor/autoload.php";
use Illuminate\Foundation\Application;
use Doctrine\ORM\Tools\Setup;
use Doctrine\ORM\EntityManager;

class W extends Worker{
	public function run(){
		$myfile = fopen("D:\Sprocess.txt", "a") or die("Unable to open file!");
		fwrite($myfile, "--------------------------------------\n");
		fwrite($myfile, "time \t\t".(new DateTime(null, new DateTimeZone('Asia/Kolkata')))->format('m-d-Y H:i:s')."\n");
    	fwrite($myfile, "w started  \t"."\n");
    	fwrite($myfile, "--------------------------------------\n");
    	fclose($myfile);
	}
}
class Sprocess extends Stackable {
	
	public function __construct(Student $student, $subjectId, $topicId, $correct, $questionId){
		$this->student = $student;
		$this->subjectId = $subjectId;
		$this->topicId = $topicId;
		$this->correct = $correct;
		$this->questionId = $questionId;
	}
	
    public function run(){
    	$myfile = fopen("D:\Sprocess.txt", "a") or die("Unable to open file!");
		fwrite($myfile, "--------------------------------------\n");
		fwrite($myfile, "time \t\t".(new DateTime(null, new DateTimeZone('Asia/Kolkata')))->format('m-d-Y H:i:s')."\n");
    	fwrite($myfile, "sprocess started  \t"."\n");
    	fwrite($myfile, "__DIR__  \t".__DIR__."\n");
    	fwrite($myfile, "--------------------------------------\n");
    	fclose($myfile);
    	try{
    		$student = $this->student;
	    	$subjectId = $this->subjectId;
	    	$topicId = $this->topicId;
	    	$correct = $this->correct;
	    	$questionId = $this->questionId;
	    	
//	    	$em = App::make('Doctrine\ORM\EntityManagerInterface');

			
	    	
			
			
			
			
			$paths = array(__DIR__.'/../../app/models');
			$isDevMode = false;
			
			// the connection configuration
			$dbParams = array(
			    'driver'   => 'pdo_mysql',
			    'user'     => 'root',
			    'password' => '',
			    'dbname'   => 'shezartc_elearning1',
				'host'	   => 'localhost',
			);
			
			$config = Setup::createAnnotationMetadataConfiguration($paths, $isDevMode, null, null, false);
	    	
	    	
	    	$myfile = fopen("D:\Sprocess.txt", "a") or die("Unable to open file!");
			fwrite($myfile, "--------------------------------------\n");
			fwrite($myfile, "time \t\t".(new DateTime(null, new DateTimeZone('Asia/Kolkata')))->format('m-d-Y H:i:s')."\n");
	    	fwrite($myfile, "sprocess middle  \t"."\n");
	    	fwrite($myfile, "--------------------------------------\n");
	    	fclose($myfile);
			
			//first put increase correct or wrong counter in TopicLevels object
			$student->getTopic($topicId)->setAttemptStatus($correct);
			
			$accuracy = json_decode($student->getAccuracy($topicId)->getAccuracy(), true);
			//shift the accuracy
			array_shift($accuracy);
			array_push($accuracy, $correct ? 1 : 0);
			$student->getAccuracy($topicId)->setAccuracy(json_encode($accuracy));
			$em->persist($student);
			$em->flush();
			
			//if correct, then put this question in QuestionAnswered Table
			//remember to uncomment this 
	//		if($correct){
	//			$questionAnswered = new QuestionAnswered($student->getId(), $questionId);
	//			$em->persist($questionAnswered);
	//			$em->flush();
	//		}
			
			$qb = $em->createQueryBuilder();
			$QuestionsAnsweredCountQuery = $qb
				->select('COUNT(q.questionId)')
				->from('QuestionAnswered', 'q')
				->where($qb->expr()->andX(
					$qb->expr()->eq('q.userId' , ':userId')
				))
				->innerJoin('Question', 'q1', 'WITH', $qb->expr()->eq('q.questionId', 'q1.id'))
				->andWhere($qb->expr()->andX(
					$qb->expr()->eq('q1.topicId' , ':topicId')
				))
				->setParameter('userId', $student->getId())
				->setParameter('topicId', $topicId)
				->getQuery();
	//		return Response::json((array(
	//			'x' => $QuestionsAnsweredCountQuery->getSql(),
	//			'y' => $QuestionsAnsweredCountQuery->getDql(),
	//			'userId' => $QuestionsAnsweredCountQuery->getParameter('userId')->getValue(),
	//			'topicId' => $QuestionsAnsweredCountQuery->getParameter('topicId')->getValue()
	//		)));
			
			$QuestionAnsweredCount = $QuestionsAnsweredCountQuery->getResult();
			
			//$QuestionAnsweredCount = array(array(0,11));
			
			//empirical score is hardcoded
			$empiricalScore = RankingService::$alpha*$student->getTopic($topicId)->getCorrectRatio()
				+RankingService::$beta*(array_key_exists('1', array_count_values($accuracy)) ? array_count_values($accuracy)['1'] : 0)/20;
			
			if($empiricalScore > RankingService::$gamma && $QuestionAnsweredCount[0][1] > RankingService::$minQuestionsBeforeLevelUp){
				$student->getTopic($topicId)->incrementLevel();
				$student->getAccuracy($topicId)->setAccuracy(json_encode(array(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0)));
			}
			
			$student->getTopic($topicId)->setScore($empiricalScore/RankingService::$gamma);
			
			$em->persist($student);
			$em->flush();
			
			//implement ranking
			//take a look at http://plnkr.co/edit/Ae5JSLXbNx6GkQVB6tB1?p=preview
			
			
			
	//		$rankArray = RankingService::integrate($student->getTopic($topicId)->getLevel());
	//		$currentTopicRank = ($empiricalScore/RankingService::$gamma)*$rankArray['studentsInCurrentLevel']
	//			+ $rankArray['studentsBelowCurrentLevel'];
	//		
	//		
	//		
	//		return Response::json(array(
	//			'x'=>$student->getTopic($topicId)->getLevel(),
	//			'topicId' => $topicId,
	//			'empiricalScore' => $empiricalScore,
	//			'ratio' => $student->getTopic($topicId)->getCorrectRatio(),
	//			'$accuracy' => $accuracy,
	//			'$rankArray' => $rankArray,
	//			'$currentTopicRank' => $currentTopicRank
	//		));
			$myfile = fopen("D:\Sprocess.txt", "a") or die("Unable to open file!");
			fwrite($myfile, "--------------------------------------\n");
			fwrite($myfile, "time \t\t".(new DateTime(null, new DateTimeZone('Asia/Kolkata')))->format('m-d-Y H:i:s')."\n");
    		fwrite($myfile, "sprocess suceeded  \t"."\n");
    		fwrite($myfile, "--------------------------------------\n");
    		fclose($myfile);
    	}
    	catch(Exception $e){
    		$myfile = fopen("D:\Sprocess.txt", "a") or die("Unable to open file!");
    		fwrite($myfile, "--------------------------------------\n");
    		fwrite($myfile, "time \t\t".(new DateTime(null, new DateTimeZone('Asia/Kolkata')))->format('m-d-Y H:i:s')."\n");
    		fwrite($myfile, "sprocess failed.  \t"."\n");
    		fwrite($myfile, "The error message is  \t".$e."\n");
    		fwrite($myfile, "--------------------------------------\n");
    		fclose($myfile);
    	}
    }
}

class SrankingEvaluation extends Stackable {
	public function __construct(Student $student){
		$this->student = $student;
	}
	
    public function run(){
    	try{
    		$student = $this->student;
    	
	    	$em = App::make('Doctrine\ORM\EntityManagerInterface');
			
			$topicsqb = $em->createQueryBuilder();
			$topics = $topicsqb
				->select('t.id')
				->from('Topic', 't')
				->getQuery()
				->getResult();
			
			$totScore = 0;
			foreach($topics as $key => $value){
				$topicGlobalWeight = $em->createQueryBuilder()
					->select('t.globalWeightage')
					->from('TopicWeightage', 't')
					->where('t.id = :topicId')
					->setParameter('topicId', $value['id'])
					->getQuery()
					->getResult();
				
				$totScore += ($student->getTopic($value['id'])->getScore() + $student->getTopic($value['id'])->getLevel() - 1) * $topicGlobalWeight[0]['globalWeightage'];
				
			}
			
			
			$effectiveLevel = $totScore - floor($totScore) == 0? $totScore + 1 : ceil($totScore);
			$rankArray = RankingService::integrate($effectiveLevel);
			
			$globalRank = ($totScore - floor($totScore))*$rankArray['studentsInCurrentLevel']
				+ $rankArray['studentsBelowCurrentLevel'];
			
			$student->setGlobalRank($globalRank);
			$em->persist($student);
			$em->flush();
			
			$myfile = fopen("D:\Sprocess.txt", "a") or die("Unable to open file!");
			fwrite($myfile, "--------------------------------------\n");
			fwrite($myfile, "time \t\t".(new DateTime(null, new DateTimeZone('Asia/Kolkata')))->format('m-d-Y H:i:s')."\n");
    		fwrite($myfile, "srankingevaluation suceeded  \t"."\n");
    		fwrite($myfile, "--------------------------------------\n");
    		fclose($myfile);
    	}
    	catch (Exception $e){
    		$myfile = fopen("D:\Sprocess.txt", "a") or die("Unable to open file!");
    		fwrite($myfile, "--------------------------------------\n");
    		fwrite($myfile, "time \t\t".(new DateTime(null, new DateTimeZone('Asia/Kolkata')))->format('m-d-Y H:i:s')."\n");
    		fwrite($myfile, "srankingevaluation failed.  \t"."\n");
    		fwrite($myfile, "The error message is  \t".$e."\n");
    		fwrite($myfile, "--------------------------------------\n");
    		fclose($myfile);
    	}
    	
    }
}