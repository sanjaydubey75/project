<?php

namespace Doctrine\DBAL\Logging;


class DoctrineSQLLogger implements SQLLogger
{
	/**
	 * {@inheritdoc}
	 */
	public function startQuery($sql, array $params = null, array $types = null)
	{
//		$myfile = fopen("sqllogger.txt", "a") or die("Unable to open file!");
//		fwrite($myfile, "time \t\t".(new \DateTime(null, new \DateTimeZone('Asia/Kolkata')))->format('m-d-Y H:i:s')."\n");

//		fwrite($myfile, $sql."\n");
		
//		foreach(explode('?', $sql) as $i => $part) {
//			$xkcd = (isset($xkcd) ? $xkcd : null) . $part;
//			if (isset($params[$i])) $xkcd .= "'".$params[$i]."'";
//		}
//		fwrite($myfile, $xkcd."\n");
//		if(count($params)>0){
//			foreach ($params as $index => $param)
//				fwrite($myfile, $index." => ".$param."\n");
//		}
		
//  		fwrite($myfile, "--------------------------------------\n");
//		fclose($myfile);

	}
 
	/**
	 * {@inheritdoc}
	 */
	public function stopQuery()
	{
		
	}
}