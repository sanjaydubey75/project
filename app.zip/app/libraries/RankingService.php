<?php


use Illuminate\Foundation\Application;

// check out http://stackoverflow.com/questions/17088917/what-are-the-best-practices-and-best-places-for-laravel-4-helpers-or-basic-funct/
// to know more about how to set this

// After you update your composer.json file, you need to run the command
// composer dump-autoload
// To verfiy that you files will be loaded, check out
// vendor/composer/autoload_classmap.php

class RankingService{

	private static $alpha = .5;
	private static $beta = .5;
//	private static $gamma = 1.5;
	public static $gamma = array(.4, .45, .5, .55, .6, .65, .7);
	public static $minQuestionsBeforeLevelUp = 10;

	public static function sum($arr){
		$count = 0;
		foreach($arr as $key=>$value){
			$count = $count + $value['students'];
		}
		return $count;
	}

	public static function integrate($level){

		$entityManager = App::make('Doctrine\ORM\EntityManagerInterface');
		$sampleRankRepo = $entityManager->getRepository('SampleRanking');
		$count = $sampleRankRepo->createQueryBuilder('sr')
			->select('COUNT(sr.id)')
			->getQuery()
			->getResult();

		$tempQuery = $sampleRankRepo->createQueryBuilder('sr')
			->select(array('sr.marks', 'sr.students'))
			->orderBy('sr.marks', 'ASC')
			->setMaxResults((($count[0][1])/7)*($level - 1))
			->getQuery();

		$temp = $tempQuery->getResult();
		$studentsBelowCurrentLevel = RankingService::sum($temp);

		$temp = $sampleRankRepo->createQueryBuilder('sr')
			->select(array('sr.marks', 'sr.students'))
			->orderBy('sr.marks', 'ASC')
			->setfirstResult((($count[0][1])/7)*($level - 1))
			->setMaxResults((($count[0][1])/7))
			->getQuery()
			->getResult();
		$studentsInCurrentLevel = RankingService::sum($temp);

		return array(
			'studentsBelowCurrentLevel' => $studentsBelowCurrentLevel,
			'studentsInCurrentLevel' => $studentsInCurrentLevel,
			'totalStudents' => RankingService::sum($sampleRankRepo->createQueryBuilder('sr')
				->select(array('sr.id','sr.students'))
				->getQuery()
				->getResult())
		);
	}

	public static function process(Student $student, $subjectId, $topicId, $correct, $questionId){

		$em = App::make('Doctrine\ORM\EntityManagerInterface');

		// set attempt status for question

		$question = $em->find('Question', $questionId);
		$question->setAttempt();
		if($correct){
			$question->setCorrect();
		}
		$em->persist($question);

		//Put increase correct or wrong counter in TopicLevels object

		$student->getTopicLevel($topicId)->setAttemptStatus($correct);

		// Set the accuracy

		$accuracy = json_decode($student->getAccuracy($topicId)->getAccuracy(), true);

		//shift the accuracy
		array_shift($accuracy);
		array_push($accuracy, $correct ? 1 : 0);
		$student->getAccuracy($topicId)->setAccuracy(json_encode($accuracy));
		$em->persist($student);
		$em->flush();

		//if correct, then put this question in QuestionAnswered Table

		if($correct){
			$questionAnswered = new QuestionAnswered($student, $question);
			$em->persist($questionAnswered);
			$em->flush();
		}

//		$qb = $em->createQueryBuilder();
//		$QuestionsAnsweredCountQuery = $qb
//			->select('COUNT(IDENTITY(q.question))')
//			->from('QuestionAnswered', 'q')
//			->where($qb->expr()->andX(
//				$qb->expr()->eq('q.user' , ':userId')
//			))
//			->innerJoin('Question', 'q1', 'WITH', $qb->expr()->eq('q.question', 'q1.id'))
//			->andWhere($qb->expr()->andX(
//				$qb->expr()->eq('q1.topic' , ':topicId')
//			))
//			->setParameter('userId', $student->getId())
//			->setParameter('topicId', $topicId)
//			->getQuery();

//		return Response::json((array(
//			'x' => $QuestionsAnsweredCountQuery->getSql(),
//			'y' => $QuestionsAnsweredCountQuery->getDql(),
//			'userId' => $QuestionsAnsweredCountQuery->getParameter('userId')->getValue()
//		)));

//		$QuestionAnsweredCount = $QuestionsAnsweredCountQuery->getResult();

		$QuestionAnsweredCount = $student->getTopicLevel($topicId)->getCorrectAttempts();

		//empirical score is hardcoded
		$empiricalScore = RankingService::$alpha * $student -> getTopicLevel($topicId) -> getCorrectRatio()
				+ RankingService::$beta*(array_key_exists('1', array_count_values($accuracy)) ? array_count_values($accuracy)['1'] : 0)/20;

		$student->getTopicLevel($topicId)->setScore($empiricalScore);

		if($empiricalScore > RankingService::$gamma[$student->getTopicLevel($topicId)->getLevel() - 1] &&
			$QuestionAnsweredCount > RankingService::$minQuestionsBeforeLevelUp){

			$student->getTopicLevel($topicId)->incrementLevel();
			$student->getAccuracy($topicId)->setAccuracy(json_encode(array(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0)));
			$student->getTopicLevel($topicId)->setScore(0);
		}

		$em->persist($student);
		$em->flush();

		//take a look at http://plnkr.co/edit/Ae5JSLXbNx6GkQVB6tB1?p=preview
	}

	public static function skipped(Student $student, $subjectId, $topicId){
		$em = App::make('Doctrine\ORM\EntityManagerInterface');

		$student->getTopicLevel($topicId)->setAttemptStatus(false);
		$accuracy = json_decode($student->getAccuracy($topicId)->getAccuracy(), true);
		array_shift($accuracy);
		array_push($accuracy, 0);
		$student->getAccuracy($topicId)->setAccuracy(json_encode($accuracy));

		$em->persist($student);
		$em->flush();

		$empiricalScore = RankingService::$alpha*$student->getTopicLevel($topicId)->getCorrectRatio()
			+RankingService::$beta*(array_key_exists('1', array_count_values($accuracy)) ? array_count_values($accuracy)['1'] : 0)/20;

		$student->getTopicLevel($topicId)->setScore($empiricalScore);

		$em->persist($student);
		$em->flush();
	}

	public static function rankingEvaluation(Student $student){
		// first calculate global rank
		//get score

		$em = App::make('Doctrine\ORM\EntityManagerInterface');

		$topics = $em->createQueryBuilder()
			->select('t.id')
			->from('Topic', 't')
			->getQuery()
			->getResult();

		$totScore = 0;
		foreach($topics as $key => $value){
			$topicGlobalWeight = $em->createQueryBuilder()
				->select('t.globalWeightage')
				->from('TopicWeightage', 't')
				->where('t.topic = :topicId')
				->setParameter('topicId', $value['id'])
				->getQuery()
				->getResult();


			$totScore += ($student->getTopicLevel($value['id'])->getScore() + $student->getTopicLevel($value['id'])->getLevel() - 1) * $topicGlobalWeight[0]['globalWeightage'];
		}

		$effectiveLevel = $totScore - floor($totScore) == 0? $totScore + 1 : ceil($totScore);
		$rankArray = RankingService::integrate($effectiveLevel);

		$globalRank = $rankArray['totalStudents'] - (
				($totScore - floor($totScore))*$rankArray['studentsInCurrentLevel']
				+ $rankArray['studentsBelowCurrentLevel']);


		$statePercentageSelection = $em->createQueryBuilder()
			->select('x.percentageSelected')
			->from('StatewiseSelection', 'x')
			->where('x.name = :name')
			->setParameter('name', $student->getState()->getName())
			->getQuery()
			->getResult();

		$percentageSelected = $statePercentageSelection[0]['percentageSelected'];

		$stateRank = $globalRank * $percentageSelected/100;

		$subjects = $em->createQueryBuilder()
			->select('s.id')
			->from('Subject', 's')
			->getQuery()
			->getResult();

		foreach($subjects as $key1 => $value1){
			$topicSubjectScore = 0;
			foreach($topics as $key => $value){
				$topicSubjectWeight = $em->createQueryBuilder()
					->select('t.subjectWeightage')
					->from('TopicWeightage', 't')
					->where('t.topic = :topicId')
					->andWhere('t.subject = :subjectId')
					->setParameter('topicId', $value['id'])
					->setParameter('subjectId', $value1['id'])
					->getQuery()
					->getResult();

				if(count($topicSubjectWeight) <= 0)
					continue;
				$topicSubjectScore += ($student->getTopicLevel($value['id'])->getScore() + $student->getTopicLevel($value['id'])->getLevel() - 1) * $topicSubjectWeight[0]['subjectWeightage'];
			}
			$effectiveSubjectLevel = $topicSubjectScore - floor($topicSubjectScore) == 0? $topicSubjectScore + 1 : ceil($topicSubjectScore);

			$tempSubject = $em->getRepository('Subject')->findOneBy(array('id' => $value1['id']));
			$student->setSubjectLevel($tempSubject, $effectiveSubjectLevel);

			$rankArray = RankingService::integrate($effectiveSubjectLevel);
			$subjectGlobalRank = $rankArray['totalStudents'] - (
					($topicSubjectScore - floor($topicSubjectScore))*$rankArray['studentsInCurrentLevel']
					+ $rankArray['studentsBelowCurrentLevel']);

			$subjectStateRank = $percentageSelected * $subjectGlobalRank/100;
			$student->getSubjectGlobalRank($value1['id'])->setRank($subjectGlobalRank);
			$student->getSubjectStateRank($value1['id'])->setRank($subjectStateRank);

			$em->persist($student);
		}

		$student->setGlobalRank($globalRank);
		$student->setStateRank($stateRank);
		$em->persist($student);
		$em->flush();

	}

	public static function start($user, $subjectId, $topicId, $correct, $questionId){

		RankingService::process($user, $subjectId, $topicId, $correct, $questionId);
		RankingService::rankingEvaluation($user);
		//check for subject level increment
	}

	public static function startSkipped($user, $subjectId, $topicId){

		RankingService::skipped($user, $subjectId, $topicId);
		RankingService::skipped($user, $subjectId, $topicId);

		RankingService::rankingEvaluation($user);
	}
}