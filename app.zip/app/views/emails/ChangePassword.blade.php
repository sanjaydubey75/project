<!doctype html>
<html lang="en">
<head>
</head>
<body>
	<div>
		<div>Hi {{{$name}}},</div>
		<br/>
		<div>It seems that you forgot your password. Please click <a href="{{{$link}}}">here</a> within one hour to change your password. If you did not send us a request to change your password, simply ignore this message.</div>
		<div class="row">
            <div class="col-xs-12" style="overflow: hidden;">
        	    <img src="{{{$relativeUrl}}}views/Content/emailbanner/email_default_banner.jpg" style="width: 100%;"/>
            </div>
        </div>
	</div>
</body>
</html>