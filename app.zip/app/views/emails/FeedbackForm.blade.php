<!doctype html>
<html lang="en">
<head>
</head>
<body>
	<table style="width: 100%;">
		<tr>
			<td>
				<h1>Feedback from {{{$username}}}</h1>
			</td>
		</tr>
		<tr>
			<td>
				Email address
			</td>
			<td>
				{{{$email}}}
			</td>
		</tr>
		<tr>
			<td>
				message
			</td>
			<td>
				{{{$message1}}}
			</td>
		</tr>
	</table>
</body>
</html>