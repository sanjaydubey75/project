<!doctype html>
<html lang="en">
<head>
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.0.3/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
	<div>
		<div>Hi,</div>
		<br/>
		<div>You've been challenged by {{{$student}}} to solve a question. Please click <a href="{{{$relativeUrl}}}question/{{{$questionId}}}?token={{{$tokenId}}}&student={{{$studentEmail}}}&friend={{{$friendEmail}}}">here</a> within fifteen days to solve it.</div>
		<div style="margin-top: 20px;">
		    Best Of Luck!<br/>
		    Warm Regards,<br/>
		    <a href="http://iitjeeacademy.com">iitjeeacademy.com team</a><br/>
		</div>
		<div class="row">
		    <div class="col-xs-12" style="overflow: hidden;">
		        <img src="{{{$relativeUrl}}}views/Content/emailbanner/email_default_banner.jpg" style="width: 100%;"/>
		    </div>
		</div>
	</div>
</body>
</html>