<!doctype html>
<html lang="en">
<head>
</head>
<body>
	<table style="width: 100%;">
		<tr>
			<td>
				username
			</td>
			<td>
	            {{{$username}}}
			</td>
		</tr>
		<tr>
			<td>
                email address
			</td>
			<td>
                {{{$email}}}
			</td>
		</tr>
        <tr>
			<td>
			    subject
			</td>
			<td>
                {{{$subject}}}
			</td>
		</tr>
        <tr>
			<td>
			    message
			</td>
			<td>
				{{{$message1}}}
			</td>
		</tr>
	</table>
</body>
</html>