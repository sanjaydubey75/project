<!DOCTYPE html>
<html>
	<head>
		<title>IITJEE Academy Payment</title>
		<base href="{{{$rootUrl}}}/"/>
		<link rel='shortcut icon' type='image/x-icon' href='views/Content/favicon.ico' />
		<link rel="stylesheet" href="views/bootstrap-3.2.0-dist/css/bootstrap.min.css" />
	</head>
	<body>
		<div class="container-fluid">
		    <div class="row">
		        <div class="col-md-8 col-md-offset-2 col-xs-12">
		            <div class="row">
		                <a href="{{{$rootUrl}}}">
                            <img src="views/Content/logo.jpg" alt="logo" style="width: 150px; margin-top: 30px; margin-bottom: 30px;"/>
                        </a>
                    </div>
                    <div class="row" style="border: 1px solid grey; padding: 30px;">
                        <div class="col-xs-1">
                            <img src="views/Content/failed_trns.png" style="display: inline-block"/>
                        </div>
                        <div class="col-xs-11">
                            <div class="row">
                                <h4 style="color: red; margin-top: 0;">We are sorry but the transaction failed.</h4>
                            </div>
                            <div class="row">
                                <b>Reason for failure: </b><p>{{{$message()}}}</p>
                            </div>
                        </div>
                    </div>
		        </div>
		    </div>
		</div>
	</body>
</html>