<!DOCTYPE html>
<html>
	<head>
		<script type="text/javascript">
            var cl = function (){
                window.close();
            };
		</script>
	</head>
	<body onload="cl()">
	</body>
</html>