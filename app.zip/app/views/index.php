<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>IITJEE Academy</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<script src="https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/MathJax.js?config=TeX-AMS-MML_HTMLorMML&delayStartupUntil=configured&dummy=.js"></script>

    <base href="https://iitjeeacademy.com/"/>

	<link rel='shortcut icon' type='image/x-icon' href='views/Content/favicon.ico'/>

	<script src = "views/angularjs/angular-1.3.8/angular.min.js"></script>
	<script src = "views/angularjs/angular-1.3.8/angular-cookies.min.js"></script>
	<script src = "views/angularjs/angular-1.3.8/angular-resource.min.js"></script>
	<script src = "views/uirouter/0.2.11/angular-ui-router.min.js"></script>

	<link rel="stylesheet" href="views/bootstrap/bootstrap-3.3.5-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="views/fonts/font-awesome-4.4.0/css/font-awesome.css">

	<script src="views/uibootstrap/ui-bootstrap-tpls-0.12.0.js"></script>

	<script src="views/thirdparty/danialfarid/angular-file-upload/dist/ng-file-upload.min.js"></script>
	<script src="views/thirdparty/webadvanced/ng-remote-validate/ngRemoteValidate.js" type="text/javascript" ></script>

	<script src="views/thirdparty/angular-ui/ui-utils-0.2.1/ui-utils.min.js"></script>
	<script src="views/thirdparty/oblador/angular-scroll-master/angular-scroll.min.js"></script>

	<script src="views/thirdparty/linkedin/Fiber-master/src/fiber.min.js"></script>

	<!-- This adds namespacing capability to angular-->
	<script src="views/thirdparty/callmehiphop/angular-namespacer/angular-namespacer.js"></script>

	<!-- Angular module for facebook SDK -->
	<script src="views/thirdparty/sahat/satellizer/satellizer.min.js"></script>

	<!-- angular side menu-->
	<script src="views/thirdparty/jakiestfu/Snap.js/snap.min.js"></script>
	<script src="views/thirdparty/jtrussell/angular-snap/built/angular-snap.min.js"></script>
	<link rel="stylesheet" href="views/thirdparty/jtrussell/angular-snap/built/angular-snap.css"/>

    <!-- angular chart d3, nvd3, nvd3ChartDirectives-->
	<script src="views/thirdparty/mbostock/d3/d3.min.js"></script>
	<script src="views/thirdparty/novus/novus-nvd3-fc2bee6/build/nv.d3.min.js"></script>
	<link rel="stylesheet" href="views/thirdparty/novus/novus-nvd3-fc2bee6/build/nv.d3.min.css"/>
	<script src="views/thirdparty/krispo/angular-nvd3/dist/angular-nvd3.min.js"></script>

	<script src="views/services/Module.js"></script>
	<script src="views/services/Config.js"></script>
	<script src="views/services/Controller.js"></script>
	<script src="views/services/Directive.js"></script>
	<script src="views/services/Run.js"></script>

	<script src="views/services/android/Module.js"></script>
	<script src="views/services/android/Controller.js"></script>
	<script src="views/services/android/Config.js"></script>

	<script src="views/services/interceptors/Module.js"></script>
	<script src="views/services/interceptors/Factory.js"></script>

	<script src="views/services/question/Module.js"></script>
	<script src="views/services/question/Controller.js"></script>
	<script src="views/services/question/Directive.js"></script>
	<script src="views/services/question/Factory.js"></script>
	<script src="views/services/question/Service.js"></script>

	<script src="views/services/security/Module.js"></script>
	<script src="views/services/security/Authentication.js"></script>
	<script src="views/services/security/Authorization.js"></script>
	<script src="views/services/security/Config.js"></script>
	<script src="views/services/security/Controller.js"></script>
	<script src="views/services/security/Principal.js"></script>
	<script src="views/services/security/Redirect.js"></script>
	<script src="views/services/security/Run.js"></script>
	<script src="views/services/security/Directive.js"></script>
	<script src="views/services/security/HandleError.js"></script>
	<script src="views/services/security/Interceptor.js"></script>

	<script src="views/services/subject/Module.js"></script>
	<script src="views/services/subject/Factory.js"></script>
	<script src="views/services/subject/Service.js"></script>
	<script src="views/services/subject/Resource.js"></script>

	<script src="views/services/topic/Module.js"></script>
	<script src="views/services/topic/Controller.js"></script>
	<script src="views/services/topic/Factory.js"></script>
	<script src="views/services/topic/Resource.js"></script>
	<script src="views/services/topic/Service.js"></script>

	<script src="views/services/web/Module.js"></script>
	<script src="views/services/web/Config.js"></script>
	<script src="views/services/web/Directive.js"></script>

	<script src="views/services/web/authentication/Module.js"></script>
	<script src="views/services/web/authentication/Config.js"></script>

	<script src="views/services/web/forgetpassword/Module.js"></script>
	<script src="views/services/web/forgetpassword/Config.js"></script>
	<script src="views/services/web/forgetpassword/Factory.js"></script>
	<script src="views/services/web/forgetpassword/Controller.js"></script>

	<script src="views/services/web/home/Module.js"></script>
    <script src="views/services/web/home/Config.js"></script>
    <script src="views/services/web/home/Controller.js"></script>
	<script src="views/services/web/home/Redirect.js"></script>

	<script src="views/services/web/home/feedback/Module.js"></script>
	<script src="views/services/web/home/feedback/Controller.js"></script>
	<script src="views/services/web/home/feedback/Config.js"></script>
	<script src="views/services/web/home/feedback/Factory.js"></script>

	<script src="views/services/web/question/Config.js"></script>

	<script src="views/services/web/register/Module.js"></script>
	<script src="views/services/web/register/Config.js"></script>
	<script src="views/services/web/register/Factory.js"></script>
	<script src="views/services/web/register/Controller.js"></script>
	<script src="views/services/web/register/Directive.js"></script>
	<script src="views/services/web/register/Model.js"></script>
	<script src="views/services/web/register/Service.js"></script>

	<script src="views/services/web/student/Module.js"></script>
	<script src="views/services/web/student/Config.js"></script>
	<script src="views/services/web/student/Controller.js"></script>
	<script src="views/services/web/student/Directive.js"></script>
	<script src="views/services/web/student/Factory.js"></script>
    <script src="views/services/web/student/Service.js"></script>

	<script src="views/services/web/student/home/Module.js"></script>
	<script src="views/services/web/student/home/Config.js"></script>
	<script src="views/services/web/student/home/Controller.js"></script>
	<script src="views/services/web/student/home/Service.js"></script>
	<script src="views/services/web/student/home/Factory.js"></script>

	<script src="views/services/web/student/resource/Module.js"></script>
	<script src="views/services/web/student/resource/Factory.js"></script>

	<script src="views/services/web/student/setting/Module.js"></script>
	<script src="views/services/web/student/setting/Config.js"></script>
	<script src="views/services/web/student/setting/Directive.js"></script>

	<script src="views/services/web/student/setting/motivator/Module.js"></script>
	<script src="views/services/web/student/setting/motivator/Config.js"></script>
	<script src="views/services/web/student/setting/motivator/Controller.js"></script>
	<script src="views/services/web/student/setting/motivator/Service.js"></script>

	<script src="views/services/web/student/setting/profile/Module.js"></script>
	<script src="views/services/web/student/setting/profile/Config.js"></script>
	<script src="views/services/web/student/setting/profile/Controller.js"></script>
	<script src="views/services/web/student/setting/profile/Factory.js"></script>
	<script src="views/services/web/student/setting/profile/Directive.js"></script>

	<script src="views/services/web/student/setting/report/Module.js"></script>
	<script src="views/services/web/student/setting/report/Config.js"></script>
	<script src="views/services/web/student/setting/report/Controller.js"></script>
	<script src="views/services/web/student/setting/report/Factory.js"></script>

	<script src="views/services/web/student/subject/Module.js"></script>
	<script src="views/services/web/student/subject/Config.js"></script>
	<script src="views/services/web/student/subject/Controller.js"></script>

    <script src="views/services/web/student/video/Module.js"></script>
    <script src="views/services/web/student/video/Config.js"></script>
    <script src="views/services/web/student/video/Controller.js"></script>
    <script src="views/services/web/student/video/Factory.js"></script>

	<script src="views/services/web/topicLevelTest/Module.js"></script>
	<script src="views/services/web/topicLevelTest/Config.js"></script>
	<script src="views/services/web/topicLevelTest/Controller.js"></script>
	<script src="views/services/web/topicLevelTest/Directive.js"></script>
	<script src="views/services/web/topicLevelTest/Factory.js"></script>
	<script src="views/services/web/topicLevelTest/Filter.js"></script>
	<script src="views/services/web/topicLevelTest/Service.js"></script>

	<script src="views/services/web/tutor/Module.js"></script>
	<script src="views/services/web/tutor/Config.js"></script>

	<script src="views/services/web/tutor/account/Module.js"></script>
	<script src="views/services/web/tutor/account/Config.js"></script>
	<script src="views/services/web/tutor/account/Controller.js"></script>
	<script src="views/services/web/tutor/account/Service.js"></script>

	<script src="views/services/web/tutor/config/Module.js"></script>
	<script src="views/services/web/tutor/config/Constant.js"></script>

	<script src="views/services/web/tutor/Dao/Module.js"></script>
	<script src="views/services/web/tutor/Dao/Factory.js"></script>

	<script src="views/services/web/tutor/homepage/Module.js"></script>
	<script src="views/services/web/tutor/homepage/Config.js"></script>
	<script src="views/services/web/tutor/homepage/Controller.js"></script>
	<script src="views/services/web/tutor/homepage/Service.js"></script>

	<script src="views/services/web/tutor/resources/Module.js"></script>
	<script src="views/services/web/tutor/resources/Student.js"></script>
	<script src="views/services/web/tutor/resources/Tutor.js"></script>

	<script src="views/services/web/tutor/student/Module.js"></script>
	<script src="views/services/web/tutor/student/Config.js"></script>
	<script src="views/services/web/tutor/student/Controller.js"></script>
	<script src="views/services/web/tutor/student/Service.js"></script>
	<script src="views/services/web/tutor/student/Factory.js"></script>

	<script src="views/thirdparty/grevory/angular-local-storage-master/dist/angular-local-storage.min.js"></script>
    <script src="views/thirdparty/youtube-embed/angular-youtube-embed.min.js"></script>
    <script src="https://www.youtube.com/iframe_api"></script>

    <link rel='stylesheet' type='text/css' href='views/fonts/google-oswald/oswald.css'>
    <link rel='stylesheet' type='text/css' href='views/fonts/google-lato/lato.css'>
    <link rel="stylesheet" type="text/css" href="views/css/index.css">
</head>

<body ng-app="app" ng-controller="mainAppController" style="margin: 0 0 0 0">
    <div ui-view></div>
    <!-- Google Analytics -->
	<script>(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)})(window,document,'script','//www.google-analytics.com/analytics.js','ga');ga('create','UA-57465686-1','auto');ga('send','pageview');</script>
    <!-- Facebook pixel -->
    <script>(function() {var _fbq = window._fbq || (window._fbq = []);if (!_fbq.loaded) {var fbds = document.createElement('script');fbds.async = true;fbds.src = '//connect.facebook.net/en_US/fbds.js';var s = document.getElementsByTagName('script')[0];s.parentNode.insertBefore(fbds, s);_fbq.loaded = true;}})();window._fbq = window._fbq || [];window._fbq.push(['track', '6020777124042', {'value':'0.00','currency':'INR'}]);</script>
	<noscript><img height="1" width="1" alt="" style="display:none" src="https://www.facebook.com/tr?ev=6020777124042&amp;cd[value]=0.00&amp;cd[currency]=INR&amp;noscript=1" /></noscript>
    <!-- Zopim chat -->
    <script type="text/javascript" src="views/silly_softwares/zopim/zopim.js"></script>
</body>
</html>