<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>IITJEE Academy</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<script src="//cdn.mathjax.org/mathjax/latest/MathJax.js?config=TeX-AMS-MML_HTMLorMML&delayStartupUntil=configured&dummy=.js"></script>

    <base href="https://iitjeeacademy.com/"/>

    <script src = "views/angularjs/angular-1.3.8/angular.min.js"></script>
	<script src = "views/angularjs/angular-1.3.8/angular-cookies.min.js"></script>
	<script src = "views/angularjs/angular-1.3.8/angular-resource.min.js"></script>
	<script src = "views/uirouter/0.2.12/angular-ui-router.min.js"></script>

	<link rel="stylesheet" href="views/bootstrap/bootstrap-3.3.5-dist/css/bootstrap.min.css">
    <script src="views/uibootstrap/ui-bootstrap-tpls-0.12.0.js"></script>

	<script src="views/thirdparty/angular-ui/ui-utils-0.2.1/ui-utils.min.js"></script>

	<script src="views/thirdparty/linkedin/Fiber-master/src/fiber.min.js"></script>

	<!-- This adds namespacing capability to angular-->
	<script src="views/thirdparty/callmehiphop/angular-namespacer/angular-namespacer.js"></script>

    <!-- Angular module for facebook SDK -->
    <script src="views/thirdparty/sahat/satellizer/satellizer.min.js"></script>

	<script src="views/services/Module_m.js"></script>
	<script src="views/services/Config.js"></script>
	<script src="views/services/Controller.js"></script>
	<script src="views/services/Directive.js"></script>

	<script src="views/services/android/Module.js"></script>
	<script src="views/services/android/Controller.js"></script>
	<script src="views/services/android/Config.js"></script>

	<script src="views/services/interceptors/Module.js"></script>
	<script src="views/services/interceptors/Factory.js"></script>

	<script src="views/services/question/Module.js"></script>
	<script src="views/services/question/Controller.js"></script>
	<script src="views/services/question/Directive.js"></script>
	<script src="views/services/question/Factory.js"></script>
	<script src="views/services/question/Service.js"></script>

	<script src="views/services/security/Module.js"></script>
	<script src="views/services/security/Authentication.js"></script>
	<script src="views/services/security/Authorization.js"></script>
	<script src="views/services/security/Config.js"></script>
	<script src="views/services/security/Controller.js"></script>
	<script src="views/services/security/Principal.js"></script>
	<script src="views/services/security/Redirect.js"></script>
	<script src="views/services/security/Run.js"></script>
	<script src="views/services/security/Directive.js"></script>
	<script src="views/services/security/HandleError.js"></script>
	<script src="views/services/security/Interceptor.js"></script>

	<script src="views/services/subject/Module.js"></script>
	<script src="views/services/subject/Factory.js"></script>
	<script src="views/services/subject/Service.js"></script>
	<script src="views/services/subject/Resource.js"></script>

	<script src="views/services/topic/Module.js"></script>
	<script src="views/services/topic/Controller.js"></script>
	<script src="views/services/topic/Factory.js"></script>
	<script src="views/services/topic/Resource.js"></script>
	<script src="views/services/topic/Service.js"></script>

	<script src="views/services/web/authentication/Module.js"></script>
	<script src="views/services/web/authentication/Config.js"></script>

	<script src="views/services/web/question/Config.js"></script>

	<script src="views/thirdparty/grevory/angular-local-storage-master/dist/angular-local-storage.min.js"></script>


	<link rel="stylesheet" type="text/css" href="views/css/index.css">
</head>
<body ng-app="app" style="margin: 0 0 0 0">
    <ui-view/>
</body>
</html>