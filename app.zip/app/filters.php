<?php

/*
|--------------------------------------------------------------------------
| Application & Route Filters
|--------------------------------------------------------------------------
|
| Below you will find the "before" and "after" events for the application
| which may be used to do any work before or after a request into your
| application. Here you may also register your custom route filters.
|
*/

App::before(function($request)
{
	//
});


App::after(function($request, $response)
{
	//
});

/*
|--------------------------------------------------------------------------
| Authentication Filters
|--------------------------------------------------------------------------
|
| The following filters are used to verify that the user of the current
| session is logged into this application. The "basic" filter easily
| integrates HTTP Basic authentication for quick, simple checking.
|
*/

Route::filter('auth', function()
{
	if (Auth::guest())
	{
		if (Request::ajax())
		{
			return Response::make('Unauthorized', 401);
		}
		else
		{
			return Redirect::guest('login');
		}
	}
});


Route::filter('auth.basic', function()
{
	return Auth::basic();
});

/*
|--------------------------------------------------------------------------
| Guest Filter
|--------------------------------------------------------------------------
|
| The "guest" filter is the counterpart of the authentication filters as
| it simply checks that the current user is not logged in. A redirect
| response will be issued if they are, which you may freely change.
|
*/

Route::filter('guest', function()
{
	if (Auth::check()) return Redirect::to('/');
});

/*
|--------------------------------------------------------------------------
| CSRF Protection Filter
|--------------------------------------------------------------------------
|
| The CSRF filter is responsible for protecting your application against
| cross-site request forgery attacks. If this special token in a user
| session does not match the one given in this request, we'll bail.
|
*/

Route::filter('csrf', function()
{
	if (Session::token() != Input::get('_token'))
	{
		throw new Illuminate\Session\TokenMismatchException;
	}
});

Route::filter('csrf_header', function($route, $request){
	$cookies = $request->header('Cookie');
	$pattern = '/csrf-token=(\w+);?.*$/';
	preg_match($pattern, $cookies, $output);
	if(count($output) < 1){
		Config::set('session.driver', 'array');
			return Response::json(array(
                'response' => array(
                    'status' => 'failed',
                    'message' => 'Token Mismatch',
                    'code' => 'csrf-mismatch'
                )
            ));
	}
	if($request->header('X-XSRF-TOKEN') && count($output) >= 1){
		if($request->header('X-XSRF-TOKEN') != $output[1]){
			Config::set('session.driver', 'array');
			return Response::json(array('response' => array(
                'status' => 'failed',
                'message' => 'Token Mismatch',
                'code' => 'csrf-mismatch'
            )));
		}
	}
	if(!$request->header('X-XSRF-TOKEN')){
		Config::set('session.driver', 'array');
		return Response::json(array('response' => array(
            'status' => 'failed',
            'message' => 'Token Mismatch',
            'code' => 'csrf-mismatch'
        )));
	}
});

Route::filter('auth-with-authtoken', function($route, $request){
	$authToken = json_decode(Cookie::get('auth-token'), true);

	if(strcasecmp($request->header('userEmail'),$authToken['userEmail'])!=0){
		Config::set('session.driver', 'array');
		return Response::json(array('response' => array('status' => 'failed', 'message' => 'Not Authorized', 'code' => 'token-expired')), 401);
	}
//	if($request->header('type') != $authToken['type']){
//		Config::set('session.driver', 'array');
//		return Response::json(array('response' => array('status' => 'failed', 'message' => 'Not Authorized', 'code' => 'token-expired')));
//	}
	
	if(time() - $authToken['datestampcreated'] > 3600){
		Config::set('session.driver', 'array');
		return Response::json(array('response' => array('status' => 'failed', 'message' => 'Not Authorized', 'code' => 'token-expired')), 401);
	}
	
	$authToken['datestampcreated'] = time();
	Cookie::queue('auth-token', json_encode($authToken), 60, null, null, true, false);
});

Route::filter('auth-student', function($route, $request){
	
//	if($request->header('type') != 'student'){
//		Config::set('session.driver', 'array');
//		return Response::json(array('response' => array('status' => 'failed', 'message' => 'Not Authorized')));
//	}
});

Route::filter('auth-tutor', function($route, $request){
	
	if($request->header('type') != 'tutor'){
		Config::set('session.driver', 'array');
		return Response::json(array('response' => array('status' => 'failed', 'message' => 'Not Authorized')));
	}
});

Route::filter('force.ssl', function()
{
    if( ! Request::secure())
    {
    	Config::set('session.driver', 'array');
        return Redirect::secure(Request::path());
    }
});

Route::filter('log', function(){
	
//	$myfile = fopen("webdictionary.txt", "a") or die("Unable to open file!");
//	fwrite($myfile, "time \t\t".(new DateTime(null, new DateTimeZone('Asia/Kolkata')))->format('m-d-Y H:i:s')."\n");
//	fwrite($myfile, "fullurl \t".Request::fullurl()."\n");
//	fwrite($myfile, "method \t\t".Request::method()."\n");
//	fwrite($myfile, "path \t\t".Request::path()."\n");
//	fwrite($myfile, "issecure \t".Request::secure()."\n");
//
//	fwrite($myfile, "Request headers\n\n");
//	fwrite($myfile, "Host \t\t\t".Request::header('Host')."\n");
//	fwrite($myfile, "Connection \t\t".Request::header('Connection')."\n");
//	fwrite($myfile, "Content-Length \t".Request::header('Content-Length')."\n");
//	fwrite($myfile, "Pragma \t\t\t".Request::header('Pragma')."\n");
//	fwrite($myfile, "Cache-Control \t".Request::header('Cache-Control')."\n");
//	fwrite($myfile, "Accept \t\t\t".Request::header('Accept')."\n");
//	fwrite($myfile, "Origin \t\t\t".Request::header('Origin')."\n");
//	fwrite($myfile, "X-XSRF-TOKEN \t".Request::header('X-XSRF-TOKEN')."\n");
//	fwrite($myfile, "User-Agent \t\t".Request::header('User-Agent')."\n");
//	fwrite($myfile, "Content-Type \t".Request::header('Content-Type')."\n");
//	fwrite($myfile, "Referer \t".Request::header('Referer')."\n");
//	fwrite($myfile, "Accept-Encoding \t".Request::header('Accept-Encoding')."\n");
//	fwrite($myfile, "Accept-Language \t".Request::header('Accept-Language')."\n");
//	fwrite($myfile, "Cookie \t\t\t".Request::header('Cookie')."\n");
//	fwrite($myfile, "Role \t\t\t".Request::header('role')."\n");
//	fwrite($myfile, "userEmail \t\t\t".Request::header('userEmail')."\n");
//
//	fwrite($myfile, "Data \t\t\t".json_encode(Input::all())."\n");
//	fwrite($myfile, "Request body \t\t\t".file_get_contents('php://input')."\n");
//
//	fwrite($myfile, "Auth Token Values\n");
//	$authToken = json_decode(Cookie::get('auth-token'), true);
//	fwrite($myfile, "userEmail \t\t\t".$authToken['userEmail']."\n");
//	fwrite($myfile, "role \t\t\t".$authToken['role']."\n");
//	fwrite($myfile, "timestamp \t\t\t".$authToken['datestampcreated']."\n");
//	fwrite($myfile, "currenttimestamp \t\t\t".time()."\n");
//
//	fwrite($myfile, "--------------------------------------\n");
//	//echo fread($myfile,filesize("webdictionary.txt"));
//	fclose($myfile);
});