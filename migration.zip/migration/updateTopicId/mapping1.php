<?php
$map = array(
	
	'A  J L' => 'EI',
	'B G K' => 'EI',
	'DOD' => 'EI',
	'E A.C.' => 'EI',
	'HFT' => 'EI',
	'LFI' => 'EI',
	'OPD' => 'EI',
		
		
		'a'=>'rr',
		'b' => 'rr',
		'c' => 'rr',
		
		'e' => 'q',
		'a' => 'q'
);

?>